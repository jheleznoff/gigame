package ru.sber.cs.ai.gigame.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.reactive.server.WebTestClient;
import ru.sber.cs.ai.gigame.TestConfiguration;
import ru.sber.cs.ai.gigame.service.ChatService;
import ru.sber.cs.ai.gigame.service.DocsTextCacheService;
import ru.sber.cs.ai.gigame.service.DocumentService;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = {ConversationController.class, TestConfiguration.class})
@WebFluxTest(controllers = ConversationController.class)
@SuppressWarnings("unused")
class ConversationControllerExceptionTest {

    private final String userId = "user123";
    @MockitoBean
    DocsTextCacheService docsTextCacheService;
    @Autowired
    private WebTestClient webClient;
    @Autowired
    private ObjectMapper objectMapper;
    @MockitoBean
    private ChatService chatService;
    @MockitoBean
    private DocumentService documentService;

    @Test
    void testCreateConversation_Validation_FailsWith400() {
        // Empty title
        webClient.post()
                .uri("/api/conversations")
                .header("X-UserId", userId)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue("")
                .exchange()
                .expectStatus().isBadRequest();
    }

    @Test
    void testGetConversation_WithInvalidUUID_Returns400() {
        webClient.get()
                .uri("/api/conversations/not-a-valid-uuid")
                .header("X-UserId", userId)
                .accept(MediaType.APPLICATION_JSON)
                .exchange()
                .expectStatus().isBadRequest();
    }

    @Test
    void testUpdateConversation_WithInvalidUUID_Returns400() {
        webClient.put()
                .uri("/api/conversations/not-a-valid-uuid")
                .header("X-UserId", userId)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(new ru.sber.cs.ai.gigame.dto.chat.ConversationCreate("Title", null, null, null, null))
                .exchange()
                .expectStatus().isBadRequest();
    }

    @Test
    void testDeleteConversation_WithInvalidUUID_Returns400() {
        webClient.delete()
                .uri("/api/conversations/not-a-valid-uuid")
                .header("X-UserId", userId)
                .exchange()
                .expectStatus().isBadRequest();
    }
}
