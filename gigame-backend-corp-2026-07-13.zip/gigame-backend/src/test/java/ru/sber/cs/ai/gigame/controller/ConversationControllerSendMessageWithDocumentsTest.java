package ru.sber.cs.ai.gigame.controller;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpEntity;
import org.springframework.http.MediaType;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.reactive.server.WebTestClient;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.reactive.function.BodyInserters;
import ru.sber.cs.ai.gigame.service.ChatService;
import ru.sber.cs.ai.gigame.service.DocsTextCacheService;
import ru.sber.cs.ai.gigame.service.DocumentService;

import java.nio.charset.StandardCharsets;
import java.time.OffsetDateTime;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * Тесты загрузки документов диалога в кэш (POST /api/conversations/{id}/upload).
 * Ответ ассистента запрашивается отдельно по WebSocket /ws/chat — SSE-ручек
 * отправки сообщений в корп. версии нет.
 */
@WebFluxTest(controllers = ConversationController.class)
@SuppressWarnings("unused")
class ConversationControllerSendMessageWithDocumentsTest {

    @MockitoBean
    DocsTextCacheService docsTextCacheService;
    @Autowired
    private WebTestClient webClient;
    @MockitoBean
    private ChatService chatService;
    @MockitoBean
    private DocumentService documentService;

    private static MultiValueMap<String, HttpEntity<?>> multipartWithFile(String fileText, String filename, String contentType) {
        MultiValueMap<String, HttpEntity<?>> body = new LinkedMultiValueMap<>();
        ByteArrayResource resource = new ByteArrayResource(fileText.getBytes(StandardCharsets.UTF_8)) {
            @Override
            public String getFilename() {
                return filename;
            }
        };
        LinkedMultiValueMap<String, String> fileHeaders = new LinkedMultiValueMap<>();
        fileHeaders.add("Content-Type", contentType);
        body.add("files", new HttpEntity<>(resource, fileHeaders));
        return body;
    }

    @Test
    void uploadDocuments_ShouldParseAndCacheTexts() {
        // Given
        String userId = "USER123";
        UUID conversationId = UUID.randomUUID();
        UUID docId = UUID.randomUUID();
        String filename = "test.pdf";
        String fileText = "Текст из PDF файла.";

        when(documentService.uploadDocument(any(), eq(userId)))
                .thenReturn(new DocumentService.DocumentResponse(
                        docId, filename, "application/pdf", fileText.length(),
                        fileText.length(), fileText, OffsetDateTime.now(), OffsetDateTime.now()));

        MultiValueMap<String, HttpEntity<?>> body =
                multipartWithFile(fileText, filename, MediaType.APPLICATION_PDF.toString());

        // When & Then
        webClient.post()
                .uri("/api/conversations/{id}/upload", conversationId)
                .header("X-UserId", userId)
                .contentType(MediaType.MULTIPART_FORM_DATA)
                .body(BodyInserters.fromMultipartData(body))
                .exchange()
                .expectStatus().isOk();

        verify(docsTextCacheService).cacheDocumentTexts(
                eq(conversationId), eq(List.of(fileText)), eq(List.of(filename)),
                eq(List.of(docId.toString())));
    }

    @Test
    void uploadDocuments_WithUnsupportedFile_ShouldFailWithUnprocessableEntity() {
        // Given
        String userId = "USER123";
        UUID conversationId = UUID.randomUUID();

        when(documentService.uploadDocument(any(), eq(userId)))
                .thenThrow(new IllegalArgumentException("Неподдерживаемый тип контента: application/xyz"));

        MultiValueMap<String, HttpEntity<?>> body =
                multipartWithFile("Текст из файла.", "test.xyz", "application/xyz");

        // When & Then
        webClient.post()
                .uri("/api/conversations/{id}/upload", conversationId)
                .header("X-UserId", userId)
                .contentType(MediaType.MULTIPART_FORM_DATA)
                .body(BodyInserters.fromMultipartData(body))
                .exchange()
                .expectStatus().isEqualTo(422);
    }

    @Test
    void uploadDocuments_WithTooManyFiles_ShouldFailWithUnprocessableEntity() {
        // Given
        String userId = "USER123";
        UUID conversationId = UUID.randomUUID();
        String filename = "test.txt";
        String fileText = "Текст";

        MultiValueMap<String, HttpEntity<?>> body = new LinkedMultiValueMap<>();
        for (int i = 0; i < ConversationController.MAX_FILES_PER_REQUEST + 1; i++) {
            final int idx = i;
            ByteArrayResource resource = new ByteArrayResource(fileText.getBytes(StandardCharsets.UTF_8)) {
                @Override
                public String getFilename() {
                    return idx + "_" + filename;
                }
            };
            LinkedMultiValueMap<String, String> headers = new LinkedMultiValueMap<>();
            headers.add("Content-Type", "text/plain");
            body.add("files", new HttpEntity<>(resource, headers));
        }

        // When & Then
        webClient.post()
                .uri("/api/conversations/{id}/upload", conversationId)
                .header("X-UserId", userId)
                .contentType(MediaType.MULTIPART_FORM_DATA)
                .body(BodyInserters.fromMultipartData(body))
                .exchange()
                .expectStatus().isEqualTo(422);
    }

    @Test
    void uploadDocuments_WithJsonInsteadOfMultipart_ShouldReturnUnsupportedMediaType() {
        // Given
        String userId = "USER123";
        UUID conversationId = UUID.randomUUID();
        Map<String, String> jsonBody = Map.of("content", "Сообщение с неправильным Content-Type");

        // When & Then
        webClient.post()
                .uri("/api/conversations/{id}/upload", conversationId)
                .header("X-UserId", userId)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(jsonBody)
                .exchange()
                .expectStatus().isEqualTo(415);
    }
}
