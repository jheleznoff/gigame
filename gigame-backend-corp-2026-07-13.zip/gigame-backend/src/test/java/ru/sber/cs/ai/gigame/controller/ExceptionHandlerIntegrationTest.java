package ru.sber.cs.ai.gigame.controller;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.reactive.server.WebTestClient;
import ru.sber.cs.ai.gigame.TestConfiguration;
import ru.sber.cs.ai.gigame.dto.ErrorResponse;
import ru.sber.cs.ai.gigame.exception.ApplicationErrorHandler;
import ru.sber.cs.ai.gigame.exception.NotFoundException;
import ru.sber.cs.ai.gigame.service.ChatService;
import ru.sber.cs.ai.gigame.service.DocsTextCacheService;
import ru.sber.cs.ai.gigame.service.DocumentService;

import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = {ConversationController.class, TestConfiguration.class, ApplicationErrorHandler.class})
@WebFluxTest(controllers = ConversationController.class)
@SuppressWarnings({"unused"})
class ExceptionHandlerIntegrationTest {

    private final String userId = "user123";
    @MockitoBean
    DocsTextCacheService docsTextCacheService;
    @Autowired
    private WebTestClient webClient;
    @MockitoBean
    private ChatService chatService;
    @MockitoBean
    private DocumentService documentService;

    @Test
    void testGetConversation_BadRequest_Returns400() {
        webClient.get()
                .uri("/api/conversations/{id}", "id")
                .header("X-UserId", userId)
                .accept(MediaType.APPLICATION_JSON)
                .exchange()
                .expectStatus().isBadRequest()
                .expectHeader().contentType(MediaType.APPLICATION_JSON);
    }

    @Test
    void testGetConversation_NotFound_Returns404() {
        when(chatService.getConversation(any(), any()))
                .thenThrow(new NotFoundException("Conversation not found"));

        webClient.get()
                .uri("/api/conversations/{id}", UUID.randomUUID().toString())
                .header("X-UserId", userId)
                .accept(MediaType.APPLICATION_JSON)
                .exchange()
                .expectStatus().isNotFound()
                .expectHeader().contentType(MediaType.APPLICATION_JSON)
                .expectBody(ErrorResponse.class)
                .value(response -> {
                    assertNotNull(response);
                    assertEquals(404, response.getStatusCode());
                    assertEquals("Not Found", response.getError());
                });
    }

    @Test
    void testUpdateConversation_NotFound_Returns404() {
        when(chatService.updateConversation(any(), any(),
                any(ru.sber.cs.ai.gigame.dto.chat.ConversationCreate.class)))
                .thenThrow(new NotFoundException("Conversation not found"));

        webClient.put()
                .uri("/api/conversations/{id}", UUID.randomUUID().toString())
                .header("X-UserId", userId)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(new ru.sber.cs.ai.gigame.dto.chat.ConversationCreate("New Title", null, null, null, null))
                .exchange()
                .expectStatus().isNotFound()
                .expectHeader().contentType(MediaType.APPLICATION_JSON)
                .expectBody(ErrorResponse.class);
    }

    @Test
    void testDeleteConversation_NotFound_Returns404() {
        doThrow(new NotFoundException("Conversation not found"))
                .when(chatService).deleteConversation(any(), any());

        webClient.delete()
                .uri("/api/conversations/{id}", UUID.randomUUID().toString())
                .header("X-UserId", userId)
                .exchange()
                .expectStatus().isNotFound()
                .expectHeader().contentType(MediaType.APPLICATION_JSON)
                .expectBody(ErrorResponse.class);
    }
}
