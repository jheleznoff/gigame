package ru.sber.cs.ai.gigame.service.scenario;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.core.io.buffer.DefaultDataBufferFactory;
import org.springframework.http.codec.ServerSentEvent;
import org.springframework.http.codec.multipart.FilePart;
import org.springframework.test.util.ReflectionTestUtils;
import reactor.core.publisher.Flux;
import ru.sber.cs.ai.gigame.exception.FileException;
import ru.sber.cs.ai.gigame.repository.ScenarioRepository;
import ru.sber.cs.ai.gigame.repository.ScenarioRunRepository;
import ru.sber.cs.ai.gigame.repository.ScenarioRunStepRepository;
import ru.sber.cs.ai.gigame.repository.ScenarioVersionRepository;
import ru.sber.cs.ai.gigame.service.DocumentService;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/**
 * Тесты getDocuments: распаковка ZIP, маркер скана, лимит документов.
 */
@ExtendWith(MockitoExtension.class)
class ScenarioServiceDocumentsTest {

    @Mock
    private ScenarioRepository scenarioRepository;
    @Mock
    private ScenarioRunRepository scenarioRunRepository;
    @Mock
    private ScenarioRunStepRepository scenarioRunStepRepository;
    @Mock
    private ScenarioVersionRepository scenarioVersionRepository;
    @Mock
    private ScenarioEngine scenarioEngine;
    @Mock
    private DocumentService documentService;
    @Mock
    private ru.sber.cs.ai.gigame.service.ScanOcrService scanOcrService;

    @InjectMocks
    private ScenarioService scenarioService;

    @BeforeEach
    void setUp() {
        ReflectionTestUtils.setField(scenarioService, "minParsedChars", 40);
        ReflectionTestUtils.setField(scenarioService, "maxDocumentsPerRun", 500);
    }

    private FilePart mockFilePart(String filename, byte[] content) {
        FilePart mockFile = mock(FilePart.class);
        when(mockFile.filename()).thenReturn(filename);
        lenient().when(mockFile.headers()).thenReturn(null);
        when(mockFile.content()).thenReturn(Flux.just(new DefaultDataBufferFactory().wrap(content)));
        return mockFile;
    }

    private static byte[] zipOf(Map<String, byte[]> entries) throws IOException {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        try (ZipOutputStream zos = new ZipOutputStream(bos)) {
            for (var e : entries.entrySet()) {
                zos.putNextEntry(new ZipEntry(e.getKey()));
                zos.write(e.getValue());
                zos.closeEntry();
            }
        }
        return bos.toByteArray();
    }

    @Test
    void getDocuments_zipIsUnpackedIntoSeveralDocuments() throws IOException {
        byte[] zip = zipOf(Map.of(
                "Договор 123/договор.pdf", "pdf".getBytes(),
                "Договор 123/Signature.sig", "junk".getBytes(),
                "Договор 123/акт.docx", "docx".getBytes()));
        FilePart file = mockFilePart("документы.zip", zip);
        when(documentService.parseText(any(InputStream.class), eq("pdf")))
                .thenReturn("Текст договора достаточной длины для порога скан-детекции");
        when(documentService.parseText(any(InputStream.class), eq("docx")))
                .thenReturn("Текст акта достаточной длины для порога скан-детекции!");

        List<DocumentText> docs = scenarioService.getDocuments(List.of(file), null);

        assertEquals(2, docs.size());
        assertTrue(docs.stream().anyMatch(d -> d.filename().equals("документы.zip/Договор 123/договор.pdf")));
        assertTrue(docs.stream().anyMatch(d -> d.filename().equals("документы.zip/Договор 123/акт.docx")));
    }

    @Test
    void getDocuments_zipWithoutSupportedDocuments_throws() throws IOException {
        byte[] zip = zipOf(Map.of("Signature.sig", "junk".getBytes()));
        FilePart file = mockFilePart("пустой.zip", zip);

        assertThrows(FileException.class, () -> scenarioService.getDocuments(List.of(file), null));
    }

    @Test
    void getDocuments_scannedPdf_replacedWithManualReviewMarker() throws IOException {
        FilePart file = mockFilePart("скан.pdf", "оригинальные байты".getBytes());
        when(documentService.parseText(any(InputStream.class), eq("pdf"))).thenReturn("  \n ");

        List<ServerSentEvent<Map<String, Object>>> events = new ArrayList<>();
        List<DocumentText> docs = scenarioService.getDocuments(List.of(file), events);

        assertEquals(1, docs.size());
        assertTrue(docs.get(0).text().contains("[ТРЕБУЕТСЯ РУЧНАЯ ПРОВЕРКА]"));
        assertTrue(docs.get(0).text().contains("скан.pdf"));
        assertTrue(events.stream().anyMatch(e ->
                "upload_warning".equals(e.data() != null ? e.data().get("type") : null)));
    }

    @Test
    void getDocuments_scannedPdf_ocrEnabled_recognizedTextUsed() throws IOException {
        FilePart file = mockFilePart("скан.pdf", "оригинальные байты".getBytes());
        when(documentService.parseText(any(InputStream.class), eq("pdf"))).thenReturn("");
        when(scanOcrService.isEnabled()).thenReturn(true);
        when(scanOcrService.recognize(eq("скан.pdf"), any()))
                .thenReturn("[РАСПОЗНАНО ИЗ СКАНА] Акт SSBRF21062 ИТОГО с НДС 10530672.68");

        List<ServerSentEvent<Map<String, Object>>> events = new ArrayList<>();
        List<DocumentText> docs = scenarioService.getDocuments(List.of(file), events);

        assertTrue(docs.get(0).text().contains("РАСПОЗНАНО ИЗ СКАНА"));
        assertTrue(docs.get(0).text().contains("10530672.68"));
        assertTrue(events.stream().anyMatch(e -> e.data() != null
                && String.valueOf(e.data().get("message")).contains("распознан через GigaChat")));
    }

    @Test
    void getDocuments_scannedPdf_ocrFails_fallsBackToManualReviewMarker() throws IOException {
        FilePart file = mockFilePart("скан.pdf", "оригинальные байты".getBytes());
        when(documentService.parseText(any(InputStream.class), eq("pdf"))).thenReturn("");
        when(scanOcrService.isEnabled()).thenReturn(true);
        when(scanOcrService.recognize(eq("скан.pdf"), any()))
                .thenThrow(new RuntimeException("хранилище недоступно"));

        List<DocumentText> docs = scenarioService.getDocuments(List.of(file), null);

        assertTrue(docs.get(0).text().contains("[ТРЕБУЕТСЯ РУЧНАЯ ПРОВЕРКА]"));
    }

    @Test
    void getDocuments_shortButNonEmptyTxt_isNotMarked() throws IOException {
        // маркер применяется только к PDF: короткий txt остаётся как есть
        FilePart file = mockFilePart("короткий.txt", "ok".getBytes());
        when(documentService.parseText(any(InputStream.class), eq("txt"))).thenReturn("ok");

        List<DocumentText> docs = scenarioService.getDocuments(List.of(file), null);

        assertEquals("ok", docs.get(0).text());
    }

    @Test
    void getDocumentsText_returnsTextsInOrder() throws IOException {
        FilePart file1 = mockFilePart("a.txt", "1".getBytes());
        FilePart file2 = mockFilePart("b.txt", "2".getBytes());
        when(documentService.parseText(any(InputStream.class), eq("txt")))
                .thenReturn("первый текст")
                .thenReturn("второй текст");

        List<String> texts = scenarioService.getDocumentsText(List.of(file1, file2), null);

        assertEquals(List.of("первый текст", "второй текст"), texts);
    }
}
