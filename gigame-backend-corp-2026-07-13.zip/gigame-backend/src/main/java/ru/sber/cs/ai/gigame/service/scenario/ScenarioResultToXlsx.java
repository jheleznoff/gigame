package ru.sber.cs.ai.gigame.service.scenario;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import ru.sber.cs.ai.gigame.dto.scenario.ScenarioRunDetailResponse;
import ru.sber.cs.ai.gigame.exception.FileException;
import ru.sber.cs.ai.gigame.utils.JsonCalcUtils;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Утилитарный класс для генерации XLSX-файлов из JSON-данных.
 * <p>
 * Преобразует массив JSON-объектов в таблицу Excel, где ключи объектов становятся колонками,
 * а каждый объект — отдельной строкой.
 */
@Component
public class ScenarioResultToXlsx {
    private static final String MARKDOWN_FENCE = "```";

    private static final ObjectMapper objectMapper = new ObjectMapper();

    private ScenarioResultToXlsx() {
        // утилитарный класс
    }

    public static ResponseEntity<Resource> generateXlsx(UUID runId, ScenarioRunDetailResponse runDetail) {
        var stepsSize = runDetail.steps().size();
        if (stepsSize >= 2) {
            var secondToLastStep = runDetail.steps().get(stepsSize - 2);
            var resource = new ByteArrayResource(jsonToXlsx(secondToLastStep.outputData().result()));
            return ResponseEntity.ok()
                    .contentType(MediaType.parseMediaType(
                            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"))
                    .header(HttpHeaders.CONTENT_DISPOSITION,
                            "attachment; filename=\"result_" + runId.toString().substring(0, 8) + ".xlsx\"")
                    .body(resource);
        }
        return null;
    }

    /**
     * Генерирует XLSX-файл из JSON-строки и возвращает его как {@link ResponseEntity}.
     *
     * @param jsonData JSON-строка с данными для экспорта
     * @return ResponseEntity с XLSX-файлом
     */
    public static byte[] jsonToXlsx(String jsonData) {
        return jsonToXlsx(jsonData, null);
    }

    /**
     * Генерирует XLSX по данным и (опционально) шаблону формы из конфига output-узла.
     * <p>
     * Шаблон — JSON в {@code data.rules} узла:
     * <pre>
     * {"лист": "Данные",
     *  "колонки": [{"ключ": "исполнитель", "заголовок": "Наименование…", "группа": "Основные данные"}, …]}
     * </pre>
     * При наличии непустого массива {@code колонки} порядок и состав колонок фиксируются:
     * значение ячейки берётся из строки данных по {@code ключ} (нет ключа — пустая ячейка),
     * лишние ключи данных игнорируются. Если хотя бы у одной колонки задана {@code группа},
     * строится двухуровневая шапка (группы объединяются по соседним одинаковым значениям).
     * Без шаблона колонки формируются динамически из ключей JSON (прежнее поведение).
     *
     * @param jsonData  JSON-строка с данными (массив объектов или объект)
     * @param rulesJson конфиг шаблона из output-узла (может быть null/пустым/"[]")
     * @return содержимое XLSX-файла
     */
    public static byte[] jsonToXlsx(String jsonData, String rulesJson) {
        try {
            // Извлекаем только JSON-часть (в {} или []) из строки
            String cleanJson = extractJson(jsonData);

            // Парсим JSON — ожидаем массив объектов
            List<Map<String, Object>> dataList = parseJsonToList(cleanJson);

            if (dataList.isEmpty()) {
                throw new FileException("Нет данных для экспорта");
            }

            XlsxTemplate template = XlsxTemplate.parse(rulesJson);
            if (template != null) {
                return createTemplatedXlsx(template, dataList);
            }

            // Собираем все уникальные ключи (колонки) в порядке появления
            Set<String> allKeys = new LinkedHashSet<>();
            for (Map<String, Object> item : dataList) {
                allKeys.addAll(item.keySet());
            }

            // Создаем workbook и обрабатываем данные
            return createXlsx(allKeys, dataList);
        } catch (Exception e) {
            throw new FileException("Ошибка при генерации XLSX-файла", e);
        }
    }

    /** Шаблон формы таблицы из конфига output-узла. */
    record XlsxTemplate(String sheetName, List<XlsxColumn> columns) {

        record XlsxColumn(String key, String title, String group) {
        }

        /** @return шаблон или {@code null}, если rules не содержит непустой массив "колонки" */
        static XlsxTemplate parse(String rulesJson) {
            if (rulesJson == null || rulesJson.isBlank() || rulesJson.trim().startsWith("[")) {
                return null;
            }
            try {
                Map<String, Object> rules = objectMapper.readValue(rulesJson, new TypeReference<>() {
                });
                List<XlsxColumn> columns = parseColumns(rules.get("колонки"));
                if (columns.isEmpty()) {
                    return null;
                }
                String sheet = stringOrEmpty(rules.get("лист"));
                return new XlsxTemplate(sheet.isBlank() ? "Данные" : sheet, columns);
            } catch (JsonProcessingException e) {
                // rules другого узла/формата (например, calc) — работаем без шаблона
                return null;
            }
        }

        /** Разбирает значение ключа "колонки"; невалидные элементы пропускаются. */
        private static List<XlsxColumn> parseColumns(Object columnsRaw) {
            if (!(columnsRaw instanceof List<?> columnsList)) {
                return List.of();
            }
            List<XlsxColumn> columns = new java.util.ArrayList<>();
            for (Object item : columnsList) {
                XlsxColumn column = parseColumn(item);
                if (column != null) {
                    columns.add(column);
                }
            }
            return columns;
        }

        /** @return колонка или {@code null}, если элемент не объект или без непустого "ключ" */
        @SuppressWarnings("unchecked")
        private static XlsxColumn parseColumn(Object item) {
            if (!(item instanceof Map<?, ?> col)) {
                return null;
            }
            Map<String, Object> colMap = (Map<String, Object>) col;
            String key = stringOrEmpty(colMap.get("ключ"));
            if (key.isBlank()) {
                return null;
            }
            String title = stringOrEmpty(colMap.get("заголовок"));
            return new XlsxColumn(key, title.isBlank() ? key : title, stringOrEmpty(colMap.get("группа")));
        }

        private static String stringOrEmpty(Object value) {
            return value == null ? "" : value.toString().strip();
        }

        boolean hasGroups() {
            return columns.stream().anyMatch(c -> !c.group().isBlank());
        }
    }

    /**
     * Создаёт XLSX с фиксированной формой: порядок колонок из шаблона,
     * опциональная двухуровневая шапка (строка групп + строка заголовков).
     */
    private static byte[] createTemplatedXlsx(XlsxTemplate template, List<Map<String, Object>> dataList) {
        try (Workbook workbook = new XSSFWorkbook()) {
            Sheet sheet = workbook.createSheet(template.sheetName());
            CellStyle headerStyle = createHeaderStyle(workbook);
            CellStyle dataStyle = createDataStyle(workbook);

            List<XlsxTemplate.XlsxColumn> columns = template.columns();
            int headerRows = createTemplateHeader(sheet, template, headerStyle);

            int rowNum = headerRows;
            for (Map<String, Object> item : dataList) {
                Row row = sheet.createRow(rowNum++);
                for (int i = 0; i < columns.size(); i++) {
                    Cell cell = row.createCell(i);
                    cell.setCellValue(formatValue(item.get(columns.get(i).key())));
                    cell.setCellStyle(dataStyle);
                }
            }

            for (int i = 0; i < columns.size(); i++) {
                sheet.autoSizeColumn(i);
            }

            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
            workbook.write(outputStream);
            return outputStream.toByteArray();
        } catch (IOException e) {
            throw new FileException("Ошибка создания Excel файла ", e);
        }
    }

    /**
     * Строит шапку по шаблону: при наличии групп — двухуровневую
     * (строка групп с объединением соседних одинаковых + строка заголовков).
     *
     * @return количество строк шапки
     */
    private static int createTemplateHeader(Sheet sheet, XlsxTemplate template, CellStyle headerStyle) {
        List<XlsxTemplate.XlsxColumn> columns = template.columns();
        boolean twoLevel = template.hasGroups();
        if (twoLevel) {
            createGroupRow(sheet, columns, headerStyle);
        }
        Row headerRow = sheet.createRow(twoLevel ? 1 : 0);
        for (int i = 0; i < columns.size(); i++) {
            Cell cell = headerRow.createCell(i);
            cell.setCellValue(columns.get(i).title());
            cell.setCellStyle(headerStyle);
        }
        return twoLevel ? 2 : 1;
    }

    /** Строка групп (строка 0) с объединением соседних колонок одинаковой непустой группы. */
    private static void createGroupRow(Sheet sheet, List<XlsxTemplate.XlsxColumn> columns, CellStyle headerStyle) {
        Row groupRow = sheet.createRow(0);
        for (int i = 0; i < columns.size(); i++) {
            Cell cell = groupRow.createCell(i);
            cell.setCellValue(columns.get(i).group());
            cell.setCellStyle(headerStyle);
        }
        mergeAdjacentGroups(sheet, columns);
    }

    /** Объединяет в строке 0 соседние колонки с одинаковой непустой группой. */
    private static void mergeAdjacentGroups(Sheet sheet, List<XlsxTemplate.XlsxColumn> columns) {
        int start = 0;
        for (int i = 1; i <= columns.size(); i++) {
            boolean sameGroup = i < columns.size()
                    && !columns.get(i).group().isBlank()
                    && columns.get(i).group().equals(columns.get(start).group());
            if (!sameGroup) {
                if (i - start > 1 && !columns.get(start).group().isBlank()) {
                    sheet.addMergedRegion(new org.apache.poi.ss.util.CellRangeAddress(0, 0, start, i - 1));
                }
                start = i;
            }
        }
    }

    /**
     * Создает XLSX-ресурс из собранных данных.
     * Вынесено в отдельный метод для избежания вложенных try блоков.
     *
     * @param allKeys  набор уникальных ключей-колонок
     * @param dataList список данных для экспорта
     * @return ResponseEntity с XLSX-файлом
     */
    private static byte[] createXlsx(Set<String> allKeys, List<Map<String, Object>> dataList) {
        try (Workbook workbook = new XSSFWorkbook()) {
            Sheet sheet = workbook.createSheet("Данные");

            // Стили
            CellStyle headerStyle = createHeaderStyle(workbook);
            CellStyle dataStyle = createDataStyle(workbook);

            // Заголовки — все ключи как колонки
            Row headerRow = sheet.createRow(0);
            int colIndex = 0;
            for (String key : allKeys) {
                Cell cell = headerRow.createCell(colIndex++);
                cell.setCellValue(key);
                cell.setCellStyle(headerStyle);
            }

            // Заполняем данные — каждая строка = один объект
            int rowNum = 1;
            for (Map<String, Object> item : dataList) {
                Row row = sheet.createRow(rowNum++);
                colIndex = 0;
                for (String key : allKeys) {
                    Cell cell = row.createCell(colIndex++);
                    Object value = item.get(key);
                    cell.setCellValue(formatValue(value));
                    cell.setCellStyle(dataStyle);
                }
            }

            // Автоширина колонок
            for (int i = 0; i < allKeys.size(); i++) {
                sheet.autoSizeColumn(i);
            }

            // Записываем в байтовый массив
            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
            workbook.write(outputStream);

            return outputStream.toByteArray();

        } catch (IOException e) {
            throw new FileException("Ошибка создания Excel файла ", e);
        }
    }

    /**
     * Парсит JSON-строку в список Map. Поддерживает как массив объектов, так и одиночный объект.
     */
    private static List<Map<String, Object>> parseJsonToList(String json) {
        String trimmed = json.trim();
        if (!trimmed.startsWith("[") && !trimmed.startsWith("{")) {
            throw new FileException("Неверный формат JSON: ожидается объект или массив");
        }
        try {
            // Массив объектов парсим как есть
            if (trimmed.startsWith("[")) {
                return objectMapper.readValue(json, new TypeReference<>() {
                });
            }
            // Одиночный объект оборачиваем в список
            Map<String, Object> singleObject = objectMapper.readValue(json, new TypeReference<>() {
            });
            return Collections.singletonList(singleObject);
        } catch (JsonProcessingException e) {
            throw new FileException("Неверный формат JSON: ожидается объект или массив");
        }
    }

    /**
     * Форматирует значение для записи в ячейку.
     * Массивы и объекты преобразуются в JSON-строку.
     */
    private static String formatValue(Object value) {
        if (value == null) {
            return "";
        }
        if (value instanceof String str) {
            return str;
        }
        if (value instanceof Boolean) {
            return value.toString();
        }
        if (value instanceof Number number) {
            // Double.toString даёт научную запись (1.21377795E7) — в ячейке нужно 12137779.5
            return new java.math.BigDecimal(number.toString()).stripTrailingZeros().toPlainString();
        }
        if (value instanceof List || value instanceof Map) {
            try {
                return objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(value);
            } catch (Exception e) {
                return value.toString();
            }
        }
        return value.toString();
    }

    /**
     * Извлекает JSON-объект или массив из строки, отбрасывая лишний текст.
     */
    private static String extractJson(String raw) {
        if (raw == null || raw.isBlank()) {
            return "[]";
        }

        // Сначала пробуем убрать markdown-блоки ```json ... ``` или ``` ... ```
        String sanitized = stripMarkdownFence(raw.trim());
        sanitized = sanitized.replace("\n", "").replace("\r", "");
        // Извлекаем первый JSON-объект или массив
        return firstJsonBlock(sanitized);
    }

    /**
     * Содержимое markdown-блока ```json ... ``` (или ``` ... ```), если он есть.
     * Закрывающая тройка учитывается только в самом конце строки; без неё
     * берётся всё после открывающей. Без блока строка возвращается как есть.
     */
    private static String stripMarkdownFence(String text) {
        int fence = text.indexOf(MARKDOWN_FENCE);
        if (fence < 0) {
            return text;
        }
        int start = fence + MARKDOWN_FENCE.length();
        if (text.startsWith("json", start)) {
            start += 4;
        }
        int end = text.length();
        if (text.endsWith(MARKDOWN_FENCE) && end - MARKDOWN_FENCE.length() >= start) {
            end -= MARKDOWN_FENCE.length();
        }
        return text.substring(start, end).trim();
    }

    /** Первый сбалансированный JSON-объект или массив в строке; "[]", если его нет. */
    private static String firstJsonBlock(String text) {
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            if (c == '{' || c == '[') {
                int end = JsonCalcUtils.balancedEnd(text, i);
                if (end >= 0) {
                    return text.substring(i, end + 1);
                }
            }
        }
        return "[]";
    }

    /**
     * Создает стиль для заголовков таблицы.
     */
    private static CellStyle createHeaderStyle(Workbook workbook) {
        CellStyle style = workbook.createCellStyle();
        Font font = workbook.createFont();
        font.setBold(true);
        font.setFontHeightInPoints((short) 12);
        style.setFont(font);
        style.setBorderBottom(BorderStyle.THIN);
        style.setBorderTop(BorderStyle.THIN);
        style.setBorderLeft(BorderStyle.THIN);
        style.setBorderRight(BorderStyle.THIN);
        return style;
    }

    /**
     * Создает стиль для ячеек с данными.
     */
    private static CellStyle createDataStyle(Workbook workbook) {
        CellStyle style = workbook.createCellStyle();
        style.setBorderBottom(BorderStyle.THIN);
        style.setBorderTop(BorderStyle.THIN);
        style.setBorderLeft(BorderStyle.THIN);
        style.setBorderRight(BorderStyle.THIN);
        style.setWrapText(true);
        return style;
    }
}