package ru.sber.cs.ai.gigame.service.scenario;

import jakarta.annotation.PreDestroy;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.codec.ServerSentEvent;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.FluxSink;
import ru.sber.cs.ai.gigame.dto.scenario.graph.GraphDataDto;
import ru.sber.cs.ai.gigame.exception.ScenarioException;
import ru.sber.cs.ai.gigame.model.ScenarioRun;
import ru.sber.cs.ai.gigame.model.ScenarioRunStep;
import ru.sber.cs.ai.gigame.service.DocsTextCacheService;
import ru.sber.cs.ai.gigame.service.EmbeddingService;
import ru.sber.cs.ai.gigame.service.GigaChatClient;
import ru.sber.cs.ai.gigame.service.scenario.enums.ScenarioStatus;
import ru.sber.cs.ai.gigame.service.scenario.executor.ScenarioExecutorFactory;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunGraph;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunNode;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static ru.sber.cs.ai.gigame.service.scenario.ScenarioEventEmission.emitNodeErrorEvent;
import static ru.sber.cs.ai.gigame.service.scenario.ScenarioEventEmission.emitNodeStatusEvent;
import static ru.sber.cs.ai.gigame.service.scenario.ScenarioEventEmission.emitStatusEvent;
import static ru.sber.cs.ai.gigame.service.scenario.ScenarioEventEmission.emitStepCompleteEvent;
import static ru.sber.cs.ai.gigame.service.scenario.ScenarioEventEmission.emitStepPausedEvent;

/**
 * Ядро движка выполнения сценариев.
 * <p>
 * Обходит граф узлов в топологическом порядке, выполняет каждый узел
 * и генерирует SSE-события, которые потребляет React-frontend в режиме реального времени.
 * <p>
 * Поддерживаемые типы узлов:
 * <ul>
 *   <li>input — входной узел с исходным текстом документов</li>
 *   <li>output — выходной узел, собирающий результаты</li>
 *   <li>loop — цикл по документам с классификацией или анализом</li>
 *   <li>switch — условный переход на основе правил</li>
 *   <li>if_node — узел ветвления по условию</li>
 *   <li>processing node — общий узел обработки с опциональным RAG</li>
 * </ul>
 * <p>
 * Особенности:
 * <ul>
 *   <li>Потоковое выполнение через {@link Flux}</li>
 *   <li>Режим пошагового выполнения для отладки</li>
 *   <li>RAG-поиск по базам знаний</li>
 *   <li>Проверка графа на циклы перед выполнением</li>
 * </ul>
 *
 * @see ScenarioRun
 * @see ScenarioRunStep
 * @see GigaChatClient
 * @see EmbeddingService
 */
@Service
@Slf4j
public class ScenarioEngine {

    private final ScenarioRunService runService;
    private final ScenarioRunStepService stepService;
    private final ScenarioExecutorFactory executorFactory;
    private final DocsTextCacheService docsTextCacheService;
    private final ExecutorService executor = Executors.newFixedThreadPool(2);
    // Состояние пошагового режима отладки в памяти (по run_id)
    private final ConcurrentHashMap<String, CompletableFuture<Void>> stepEvents = new ConcurrentHashMap<>();
    private final Set<String> stepModeEnabled = ConcurrentHashMap.newKeySet();
    private final Set<String> stepModeDisabled = ConcurrentHashMap.newKeySet();
    private final ConcurrentHashMap<String, Long> runTimestamps = new ConcurrentHashMap<>();

    private final ru.sber.cs.ai.gigame.repository.ScenarioRepository scenarioRepository;

    /**
     * Параллельное выполнение независимых ветвей графа.
     * Отключается конфигурацией; пошаговый режим всегда выполняется последовательно.
     */
    @org.springframework.beans.factory.annotation.Value("${app.scenario.parallel-enabled:true}")
    private boolean parallelEnabled;
    @org.springframework.beans.factory.annotation.Value("${app.scenario.parallel-threads:4}")
    private int parallelThreads;

    /**
     * Глубина вложенности под-сценариев в текущем потоке выполнения.
     */
    private static final ThreadLocal<Integer> SUB_DEPTH = ThreadLocal.withInitial(() -> 0);
    private static final int MAX_SUB_DEPTH = 2;

    public ScenarioEngine(ScenarioRunService runService,
                          ScenarioRunStepService stepService,
                          ScenarioExecutorFactory executorFactory,
                          DocsTextCacheService docsTextCacheService,
                          ru.sber.cs.ai.gigame.repository.ScenarioRepository scenarioRepository) {
        this.runService = runService;
        this.stepService = stepService;
        this.executorFactory = executorFactory;
        this.docsTextCacheService = docsTextCacheService;
        this.scenarioRepository = scenarioRepository;
    }

    private static void pauseFutureGet(CompletableFuture<Void> pauseFuture, String runId) {
        // Блокировка до вызова /continue
        try {
            pauseFuture.get();
        } catch (InterruptedException | ExecutionException e) {
            log.warn("Пауза шага прервана для запуска {}", runId);
            Thread.currentThread().interrupt();
        }
    }

    private static Set<String> getNodeIds(GraphDataDto graphData) {
        Set<String> nodeIds = new HashSet<>();
        for (var node : graphData.nodes()) {
            String id = node.id();
            if (id == null || id.isEmpty()) {
                throw new ScenarioException("Ошибка валидации графа: у узла отсутствует идентификатор");
            }
            nodeIds.add(id);
        }

        // Валидация ссылок рёбер
        for (var edge : graphData.edges()) {
            String source = edge.source();
            String target = edge.target();
            if (!nodeIds.contains(source)) {
                throw new ScenarioException("Ошибка валидации графа: источник ребра '" + source + "' ссылается на несуществующий узел");
            }
            if (!nodeIds.contains(target)) {
                throw new ScenarioException("Ошибка валидации графа: цель ребра '" + target + "' ссылается на несуществующий узел");
            }
        }
        return nodeIds;
    }

    // -------------------------------------------------------------------------
    // Main execution
    // -------------------------------------------------------------------------

    /**
     * Освобождает ресурсы при завершении работы приложения.
     * Ожидает завершения выполнения задач в пуле не более 5 секунд.
     */
    @PreDestroy
    void shutdown() {
        executor.shutdown();
        try {
            var terminated = executor.awaitTermination(5, TimeUnit.SECONDS);
            log.info("[shutdown] Завершено ожидание окончания потока result={}", terminated);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    /**
     * Удаляет устаревшее состояние пошагового режима для запусков старше 10 минут.
     * Выполняется по расписанию каждые 5 минут.
     */
    @Scheduled(fixedRateString = "${scenario.engine.evict-rate-ms:300000}")
    void evictStaleRuns() {
        long cutoff = System.currentTimeMillis() - 10 * 60 * 1000;
        // Snapshot keys to avoid ConcurrentModification when cleanupRun removes from runTimestamps
        Set<String> staleRunIds = new HashSet<>();
        for (var entry : runTimestamps.entrySet()) {
            if (entry.getValue() < cutoff) {
                staleRunIds.add(entry.getKey());
            }
        }
        for (String runId : staleRunIds) {
            log.debug("Evicting stale run state: {}", runId);
            cleanupRun(runId);
        }
        // Also clean step mode sets that may have been orphaned (enableStepMode called but
        // doExecute never reached — e.g., due to pre-execution failure or user cancel before runTimestamps was set)
        for (String runId : Set.copyOf(stepModeEnabled)) {
            if (!runTimestamps.containsKey(runId)) {
                log.debug("Evicting orphaned stepMode entry: {}", runId);
                stepModeEnabled.remove(runId);
                stepModeDisabled.remove(runId);
                evictStepEvents(runId);
            }
        }
    }

    /**
     * Периодически очищает старые stepEvents, которые не были завершены (timeout).
     * Выполняется каждую минуту.
     */
    @Scheduled(fixedRateString = "${scenario.engine.evict-step-events-rate-ms:60000}")
    void evictExpiredStepEvents() {
        // 10 минут
        long timeout = System.currentTimeMillis() - 10 * 60 * 1000;
        stepEvents.entrySet().removeIf(entry -> {
            Long timestamp = runTimestamps.get(entry.getKey());
            // Evict if expired OR if orphaned (runId not in runTimestamps at all)
            if (timestamp == null || timestamp < timeout) {
                log.debug("Evicting expired/orphaned step event for run: {}", entry.getKey());
                entry.getValue().complete(null);
                return true;
            }
            return false;
        });
    }

    private void evictStepEvents(String runId) {
        CompletableFuture<Void> future = stepEvents.get(runId);
        if (future != null) {
            future.complete(null);
            stepEvents.remove(runId);
        }
    }

    /**
     * Включает режим пошагового выполнения для указанного запуска.
     * Выполнение останавливается после каждого узла до вызова {@link #continueStep}.
     *
     * @param runId UUID запуска сценария
     */
    public void enableStepMode(String runId) {
        stepModeEnabled.add(runId);
    }

    /**
     * Отключает режим пошагового выполнения для указанного запуска.
     * Если выполнение на паузе, продолжает выполнение.
     *
     * @param runId UUID запуска сценария
     */
    public void disableStepMode(String runId) {
        stepModeDisabled.add(runId);
        CompletableFuture<Void> future = stepEvents.get(runId);
        if (future != null) {
            future.complete(null);
        }
    }

    // -------------------------------------------------------------------------
    // Main execution
    // -------------------------------------------------------------------------

    /**
     * Продолжает выполнение с паузы для указанного запуска.
     * Используется после включения пошагового режима.
     *
     * @param runId UUID запуска сценария
     */
    public void continueStep(String runId) {
        CompletableFuture<Void> future = stepEvents.get(runId);
        if (future != null) {
            future.complete(null);
        }
    }

    /**
     * Очищает внутреннее состояние для указанного запуска.
     * Удаляет события паузы, временные метки и кэш документов.
     *
     * @param runId UUID запуска сценария
     */
    public void cleanupRun(String runId) {
        stepEvents.remove(runId);
        stepModeEnabled.remove(runId);
        stepModeDisabled.remove(runId);
        runTimestamps.remove(runId);
        // Очистка кэша документов
        docsTextCacheService.clearCache(UUID.fromString(runId));
    }

    /**
     * Выполняет сценарий и возвращает поток SSE-событий.
     * <p>
     * Выполнение происходит в фоновом потоке, чтобы не блокировать Netty.
     * Возвращаемый Flux генерирует события для пошагового отображения
     * прогресса выполнения на frontend.
     *
     * @param run       сущность запуска сценария
     * @param graphData данные графа (узлы и рёбра)
     * @return поток SSE-событий {@link ServerSentEvent}
     */
    public Flux<ServerSentEvent<Map<String, Object>>> executeScenario(
            ScenarioRun run,
            GraphDataDto graphData) {

        return Flux.create(sink -> {
            // Register cancel handler first so it's always present
            sink.onCancel(() -> cleanupRun(run.getId().toString()));
            executor.submit(() -> {
                try {
                    doExecute(sink, run, graphData);
                } catch (Exception e) {
                    log.error("Scenario execution failed unexpectedly", e);
                    safeSetRunFailed(run);
                    emitStatusEvent(sink, run.getId(), ScenarioStatus.FAILED, null);
                    sink.complete();
                } finally {
                    cleanupRun(run.getId().toString());
                }
            });
        });
    }

    /**
     * Помечает прогон статусом FAILED, не давая ошибке сохранения
     * прервать обработку исходного сбоя выполнения.
     *
     * @param run сущность запуска сценария
     */
    private void safeSetRunFailed(ScenarioRun run) {
        try {
            runService.setScenarioRunStatusFailed(run);
        } catch (Exception persistError) {
            log.warn("Не удалось сохранить статус FAILED: {}", persistError.getMessage());
        }
    }

    /**
     * Выполняет сценарий в потоке.
     * <p>
     * Основной метод выполнения сценария. Осуществляет:
     * <ul>
     *   <li>Валидацию графа перед выполнением</li>
     *   <li>Топологическую сортировку узлов</li>
     *   <li>Обход узлов и их выполнение в зависимости от типа</li>
     *   <li>Генерацию SSE-событий для frontend</li>
     *   <li>Обработку ошибок и обновление статуса запуска</li>
     * </ul>
     *
     * @param sink      поток SSE-событий
     * @param run       сущность запуска сценария
     * @param graphData данные графа сценария
     */
    private void doExecute(FluxSink<ServerSentEvent<Map<String, Object>>> sink,
                           ScenarioRun run,
                           GraphDataDto graphData) {
        var runId = run.getId().toString();
        runTimestamps.put(runId, System.currentTimeMillis());
        graphData = stripNoteNodes(graphData);
        validateGraph(graphData);
        // Построение графа
        var graph = new ScenarioRunGraph(graphData);
        var docTextList = docsTextCacheService.getCachedDocumentTexts(run.getScenarioId());
        var filenameList = docsTextCacheService.getCachedFileNames(run.getScenarioId());
        graph.addDocs(docTextList, filenameList);
        // Обновление статуса запуска на выполняется
        run = runService.setScenarioRunStatusRunning(run);
        emitStatusEvent(sink, run.getId(), ScenarioStatus.RUNNING, null);
        var finalResult = executeGraph(sink, run, graph);
        runService.setScenarioRunStatusCompleted(run, finalResult);
        emitStatusEvent(sink, run.getId(), ScenarioStatus.COMPLETED, finalResult);
        cleanupRun(runId);
        sink.complete();
    }

    /**
     * Выполняет граф: параллельными волнами (независимые ветви — конкурентно)
     * либо последовательной рекурсией (пошаговый режим или параллелизм отключён).
     */
    private String executeGraph(FluxSink<ServerSentEvent<Map<String, Object>>> sink,
                                ScenarioRun run,
                                ScenarioRunGraph graph) {
        boolean stepMode = stepModeEnabled.contains(run.getId().toString());
        if (!parallelEnabled || stepMode) {
            return executeNode(sink, run, graph.getStartNode());
        }
        return executeWaves(sink, run, graph);
    }

    /**
     * Тело выполнения одного узла: шаг в БД, события, исполнитель, пауза пошагового
     * режима. При ошибке фиксирует шаг/событие; on_error узла определяет дальнейшее:
     * stop (по умолчанию) — исключение, прогон завершается со статусом FAILED;
     * continue — ошибка становится результатом узла, обычные ветки продолжаются;
     * branch — активируются только ветки с меткой «ошибка».
     */
    private String runNodeBody(FluxSink<ServerSentEvent<Map<String, Object>>> sink,
                               ScenarioRun run,
                               ScenarioRunNode node) {
        var runId = run.getId().toString();
        var step = stepService.setScenarioStepStatusRunning(run.getId(), node.getId(), node.getType());
        emitNodeStatusEvent(sink, node, ScenarioStatus.RUNNING);
        GigaChatClient.beginUsageCapture();
        try {
            var executorNode = executorFactory.createExecutor(node);
            String output = executorNode.execute(sink);
            var prompt = executorNode.getPrompt();
            var nodeDocs = node.getAllDocTexts();
            var input = String.join("\n\n", node.getInput());
            Integer tokensUsed = GigaChatClient.endUsageCapture();
            step = stepService.setScenarioStepStatusCompleted(step, input, nodeDocs, output, prompt, tokensUsed);
            saveInputDocNames(step, node);
            emitNodeStatusEvent(sink, node, ScenarioStatus.COMPLETED);
            node.setCompleted(true);
            // исполнители активируют всех детей — ветки «ошибка» при успехе возвращаются в спячку
            setErrorBranchSkip(node, true);
            // Отправка полных данных шага для живой отладки
            emitStepCompleteEvent(sink, node, step);
            pauseIfStepMode(sink, node, runId);
            return output;
        } catch (Exception e) {
            GigaChatClient.endUsageCapture();
            return handleNodeError(sink, node, step, e);
        }
    }

    /**
     * Пауза выполнения после узла, если включён пошаговый режим.
     *
     * @param sink  поток SSE-событий
     * @param node  завершившийся узел
     * @param runId UUID запуска сценария
     */
    private void pauseIfStepMode(FluxSink<ServerSentEvent<Map<String, Object>>> sink,
                                 ScenarioRunNode node,
                                 String runId) {
        if (stepModeEnabled.contains(runId) && !stepModeDisabled.contains(runId)) {
            CompletableFuture<Void> pauseFuture = new CompletableFuture<>();
            stepEvents.put(runId, pauseFuture);
            emitStepPausedEvent(sink, node, node.getTotal());
            pauseFutureGet(pauseFuture, runId);
        }
    }

    /**
     * Обрабатывает ошибку узла: фиксирует шаг/событие, а on_error узла определяет
     * дальнейшее: stop (по умолчанию) — исключение, прогон завершается со статусом
     * FAILED; continue — ошибка становится результатом узла, обычные ветки
     * продолжаются; branch — активируются только ветки с меткой «ошибка».
     *
     * @param sink поток SSE-событий
     * @param node узел, завершившийся ошибкой
     * @param step шаг узла в БД
     * @param e    возникшая ошибка
     * @return результат узла-ошибки (для on_error=continue/branch)
     */
    private String handleNodeError(FluxSink<ServerSentEvent<Map<String, Object>>> sink,
                                   ScenarioRunNode node,
                                   ScenarioRunStep step,
                                   Exception e) {
        log.error("Ошибка узла {} {}", node.getId(), e.getMessage());
        stepService.setScenarioStepStatusFailed(step, e.getMessage());
        emitNodeErrorEvent(sink, node, e.getMessage(), node.getTotal());
        String onError = node.getOnError();
        boolean isControl = node.getType()
                == ru.sber.cs.ai.gigame.service.scenario.enums.ScenarioNodeType.CONTROL_NODE;
        if (isControl || "stop".equals(onError)) {
            // узел «Контроль» всегда останавливает сценарий — в этом его смысл
            throw new ScenarioException("Узел «" + node.getLabel() + "» завершился ошибкой: "
                    + e.getMessage(), e);
        }
        // continue / branch: сценарий продолжается, ошибка становится результатом узла;
        // исполнитель упал до активации детей — активируем нужные ветки здесь
        String errOutput = "[ОШИБКА УЗЛА «" + node.getLabel() + "»: " + e.getMessage() + "]";
        node.getOutput().add(errOutput);
        node.setCompleted(true);
        boolean branchMode = "branch".equals(onError);
        String contribution = "=== РЕЗУЛЬТАТ ОТ \"" + node.getLabel() + "\" (ОШИБКА) ===\n" + errOutput;
        for (var child : node.getChildNodeList()) {
            boolean errorChild = isErrorEdge(node, child);
            if (branchMode == errorChild) {
                // branch: только ветки «ошибка»; continue: только обычные ветки
                child.setSkip(false);
                child.getInput().add(contribution);
            } else {
                child.setSkip(true);
            }
        }
        log.warn("Узел {} продолжен после ошибки (on_error={})", node.getId(), onError);
        return errOutput;
    }

    /**
     * Пропуск/включение дочерних узлов, соединённых ребром с меткой «ошибка».
     */
    private void setErrorBranchSkip(ScenarioRunNode node, boolean skip) {
        for (var child : node.getChildNodeList()) {
            if (isErrorEdge(node, child)) {
                child.setSkip(skip);
            }
        }
    }

    private boolean isErrorEdge(ScenarioRunNode from, ScenarioRunNode to) {
        var edgeData = from.getGraph().getEdgeMap()
                .get(org.apache.commons.lang3.tuple.Pair.of(from.getId(), to.getId()));
        if (edgeData == null || edgeData.label() == null) {
            return false;
        }
        String label = edgeData.label().trim().toLowerCase();
        return "ошибка".equals(label) || "error".equals(label);
    }

    private String executeNode(FluxSink<ServerSentEvent<Map<String, Object>>> sink,
                               ScenarioRun run,
                               ScenarioRunNode node) {
        var runId = run.getId().toString();
        var output = runNodeBody(sink, run, node);
        for (var nextNode : node.getChildNodeList()) {
            if (isNotReadyForTraversal(nextNode, runId)) {
                continue;
            }
            if (Boolean.FALSE.equals(nextNode.getSkip())) {
                output = executeNode(sink, run, nextNode);
            } else {
                log.info("Узел пропущен {} (runId={})", nextNode.getId(), runId);
            }
        }
        return output;
    }

    /**
     * Дочерний узел не готов к обходу: уже выполнен через другого родителя
     * (ромбовидная топология) либо ещё не все родители завершены.
     *
     * @param nextNode дочерний узел
     * @param runId    UUID запуска сценария
     * @return {@code true}, если узел нужно пропустить при обходе
     */
    private boolean isNotReadyForTraversal(ScenarioRunNode nextNode, String runId) {
        if (Boolean.TRUE.equals(nextNode.getCompleted())) {
            return true;
        }
        if (!isAllParentCompleted(nextNode)) {
            log.info("Ожидание завершения всех родительских узлов для узла {} (runId={})", nextNode.getId(), runId);
            return true;
        }
        return false;
    }

    /**
     * Волновое параллельное выполнение: на каждом цикле запускаются все узлы,
     * у которых завершены (или пропущены) родители; независимые ветви исполняются
     * конкурентно. Порядок добавления входов у узлов с несколькими родителями может
     * отличаться между прогонами. При ошибке любого узла (on_error=stop) оставшиеся
     * не запускаются.
     *
     * @return результат выходного узла (или последнего завершённого)
     */
    private String executeWaves(FluxSink<ServerSentEvent<Map<String, Object>>> sink,
                                ScenarioRun run,
                                ScenarioRunGraph graph) {
        var nodes = graph.getNodeMap().values();
        ExecutorService pool = Executors.newFixedThreadPool(Math.max(1, parallelThreads));
        var ecs = new java.util.concurrent.ExecutorCompletionService<Object[]>(pool);
        Set<ScenarioRunNode> scheduled = new HashSet<>();
        // Узлы, фактически пропущенные в этом прогоне. Поле skip здесь непригодно:
        // до активации родителем skip=true у ВСЕХ узлов (семантика активации ветвей),
        // и «родитель со skip=true» ещё не означает «родитель отработал».
        Set<ScenarioRunNode> skippedNodes = new HashSet<>();
        int active = 0;
        String finalResult = "";
        try {
            while (true) {
                active += scheduleReadyNodes(sink, run, nodes, ecs, scheduled, skippedNodes);
                if (active == 0) {
                    break;
                }
                Object[] done = takeCompletedNode(ecs);
                active--;
                var node = (ScenarioRunNode) done[0];
                if (node.getType() == ru.sber.cs.ai.gigame.service.scenario.enums.ScenarioNodeType.OUTPUT_NODE
                        || finalResult.isEmpty()) {
                    finalResult = (String) done[1];
                }
            }
            return finalResult;
        } finally {
            pool.shutdownNow();
        }
    }

    /**
     * Планирует на выполнение все узлы, готовые к запуску: родители завершены
     * либо пропущены. Узлы, не активированные ни одной веткой, помечаются
     * пропущенными (их дети каскадно пропускаются через skippedNodes).
     *
     * @param sink         поток SSE-событий
     * @param run          сущность запуска сценария
     * @param nodes        все узлы графа
     * @param ecs          сервис завершения задач пула
     * @param scheduled    уже запланированные узлы (пополняется)
     * @param skippedNodes фактически пропущенные узлы (пополняется)
     * @return количество узлов, отправленных на выполнение
     */
    private int scheduleReadyNodes(FluxSink<ServerSentEvent<Map<String, Object>>> sink,
                                   ScenarioRun run,
                                   java.util.Collection<ScenarioRunNode> nodes,
                                   java.util.concurrent.ExecutorCompletionService<Object[]> ecs,
                                   Set<ScenarioRunNode> scheduled,
                                   Set<ScenarioRunNode> skippedNodes) {
        int started = 0;
        for (var n : nodes) {
            if (scheduleNodeIfReady(sink, run, n, ecs, scheduled, skippedNodes)) {
                started++;
            }
        }
        return started;
    }

    /**
     * Планирует один узел, если он готов к запуску: родители завершены либо
     * пропущены. Узел, не активированный ни одной веткой, помечается пропущенным.
     *
     * @param sink         поток SSE-событий
     * @param run          сущность запуска сценария
     * @param n            проверяемый узел
     * @param ecs          сервис завершения задач пула
     * @param scheduled    уже запланированные узлы (пополняется)
     * @param skippedNodes фактически пропущенные узлы (пополняется)
     * @return {@code true}, если узел отправлен на выполнение
     */
    private boolean scheduleNodeIfReady(FluxSink<ServerSentEvent<Map<String, Object>>> sink,
                                        ScenarioRun run,
                                        ScenarioRunNode n,
                                        java.util.concurrent.ExecutorCompletionService<Object[]> ecs,
                                        Set<ScenarioRunNode> scheduled,
                                        Set<ScenarioRunNode> skippedNodes) {
        if (scheduled.contains(n)) {
            return false;
        }
        if (Boolean.TRUE.equals(n.getCompleted())) {
            // восстановлен из предыдущего прогона (resume)
            scheduled.add(n);
            return false;
        }
        var parents = n.getParentNodeList();
        boolean isStart = parents == null || parents.isEmpty();
        boolean parentsDone = isStart || parents.stream().allMatch(
                p -> Boolean.TRUE.equals(p.getCompleted()) || skippedNodes.contains(p));
        if (!parentsDone) {
            return false;
        }
        if (!isStart && Boolean.TRUE.equals(n.getSkip())) {
            // родители завершены, но узел не активирован ни одной веткой — пропущен;
            // completed не ставится: дети каскадно пропускаются через skippedNodes
            scheduled.add(n);
            skippedNodes.add(n);
            log.info("Узел пропущен {} (runId={})", n.getId(), run.getId());
            return false;
        }
        scheduled.add(n);
        ecs.submit(() -> new Object[]{n, runNodeBody(sink, run, n)});
        return true;
    }

    /**
     * Ожидает завершения очередного узла в пуле и возвращает пару
     * {узел, результат}. Прерывание и ошибки выполнения преобразуются
     * в {@link ScenarioException} (либо пробрасывается исходное RuntimeException).
     *
     * @param ecs сервис завершения задач пула
     * @return массив из двух элементов: узел и его результат
     */
    private Object[] takeCompletedNode(java.util.concurrent.ExecutorCompletionService<Object[]> ecs) {
        try {
            return ecs.take().get();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new ScenarioException("Выполнение сценария прервано");
        } catch (ExecutionException e) {
            throw e.getCause() instanceof RuntimeException re
                    ? re : new ScenarioException(String.valueOf(e.getCause()));
        }
    }

    /**
     * Выполняет под-сценарий внутри текущего (узел «Под-сценарий»).
     * <p>
     * Документами под-сценария становятся документы родительского узла, а при их
     * отсутствии — вход узла единым документом. Шаги под-сценария в БД не пишутся
     * и события узлов не эмитятся (id узлов под-сценария конфликтовали бы с холстом
     * родителя) — результатом является выход output-узла под-сценария.
     *
     * @param subScenarioIdRaw id вызываемого сценария
     * @param parentNode       узел «Под-сценарий» родительского графа
     * @param sink             поток SSE (для прогресса циклов внутри)
     * @return результат под-сценария
     */
    public String executeSubScenarioInline(String subScenarioIdRaw,
                                           ScenarioRunNode parentNode,
                                           FluxSink<ServerSentEvent<Map<String, Object>>> sink) {
        int depth = SUB_DEPTH.get();
        if (depth >= MAX_SUB_DEPTH) {
            throw new ScenarioException("Превышена глубина вложенности под-сценариев (максимум "
                    + MAX_SUB_DEPTH + ")");
        }
        UUID subId;
        try {
            subId = UUID.fromString(subScenarioIdRaw.trim());
        } catch (IllegalArgumentException e) {
            throw new ScenarioException("Узел «Под-сценарий»: некорректный идентификатор сценария: "
                    + subScenarioIdRaw);
        }
        var sub = scenarioRepository.findById(subId)
                .orElseThrow(() -> new ScenarioException("Узел «Под-сценарий»: сценарий не найден: " + subId));
        GraphDataDto graphData = ru.sber.cs.ai.gigame.dto.scenario.graph.GraphDataMapper.toDto(sub.getGraphData());
        graphData = stripNoteNodes(graphData);
        validateGraph(graphData);
        var graph = new ScenarioRunGraph(graphData);
        List<String> texts = new ArrayList<>();
        List<String> names = new ArrayList<>();
        for (String docId : parentNode.getDocList()) {
            var doc = parentNode.getGraph().getDocMap().get(docId);
            texts.add(doc.getText());
            names.add(doc.getFilename());
        }
        if (texts.isEmpty()) {
            String inputAll = String.join("\n\n", parentNode.getInput());
            if (!inputAll.isBlank()) {
                texts.add(inputAll);
                names.add("вход_узла.txt");
            }
        }
        graph.addDocs(texts, names);
        SUB_DEPTH.set(depth + 1);
        try {
            return executeSubGraph(sink, graph.getStartNode());
        } finally {
            SUB_DEPTH.set(depth);
        }
    }

    private String executeSubGraph(FluxSink<ServerSentEvent<Map<String, Object>>> sink,
                                   ScenarioRunNode node) {
        String output;
        var executorNode = executorFactory.createExecutor(node);
        output = executorNode.execute(sink);
        node.setCompleted(true);
        for (var nextNode : node.getChildNodeList()) {
            if (Boolean.TRUE.equals(nextNode.getCompleted()) || !isAllParentCompleted(nextNode)) {
                continue;
            }
            if (Boolean.FALSE.equals(nextNode.getSkip())) {
                output = executeSubGraph(sink, nextNode);
            }
        }
        return output;
    }

    /**
     * Возобновляет упавший прогон в фоне и возвращает поток SSE-событий
     * (обёртка над {@link #resumeExecution} по образцу executeScenario).
     *
     * @param run       НОВЫЙ прогон
     * @param graphData граф сценария
     * @param oldSteps  шаги исходного прогона
     * @return поток SSE-событий
     */
    public Flux<ServerSentEvent<Map<String, Object>>> resumeScenario(ScenarioRun run,
                                                                     GraphDataDto graphData,
                                                                     List<ScenarioRunStep> oldSteps) {
        return Flux.create(sink -> {
            sink.onCancel(() -> cleanupRun(run.getId().toString()));
            executor.submit(() -> {
                try {
                    resumeExecution(sink, run, graphData, oldSteps);
                } catch (Exception e) {
                    log.error("Scenario resume failed", e);
                    safeSetRunFailed(run);
                    emitStatusEvent(sink, run.getId(), ScenarioStatus.FAILED, null);
                    sink.complete();
                } finally {
                    cleanupRun(run.getId().toString());
                }
            });
        });
    }

    /**
     * Возобновляет упавший прогон: выходы завершённых LLM-узлов (processing, loop,
     * subscenario) восстанавливаются из шагов старого прогона, дешёвые узлы (input,
     * switch, if, calc, transform, output) выполняются заново, оставшиеся — как обычно.
     * Документы восстанавливаются из шага входного узла, классы документов —
     * из выхода классифицирующего цикла.
     *
     * @param sink      поток SSE-событий
     * @param run       НОВЫЙ прогон (создан сервисом)
     * @param graphData граф сценария
     * @param oldSteps  шаги исходного прогона
     */
    public void resumeExecution(FluxSink<ServerSentEvent<Map<String, Object>>> sink,
                                ScenarioRun run,
                                GraphDataDto graphData,
                                List<ScenarioRunStep> oldSteps) {
        var runId = run.getId().toString();
        runTimestamps.put(runId, System.currentTimeMillis());
        graphData = stripNoteNodes(graphData);
        validateGraph(graphData);
        var graph = new ScenarioRunGraph(graphData);
        restoreDocsFromSteps(graph, oldSteps);
        run = runService.setScenarioRunStatusRunning(run);
        emitStatusEvent(sink, run.getId(), ScenarioStatus.RUNNING, null);
        restoreCompletedLlmNodes(sink, run, graph, oldSteps);
        var finalResult = executeWaves(sink, run, graph);
        runService.setScenarioRunStatusCompleted(run, finalResult);
        emitStatusEvent(sink, run.getId(), ScenarioStatus.COMPLETED, finalResult);
        cleanupRun(runId);
        sink.complete();
    }

    /**
     * Восстанавливает документы прогона из сохранённого выхода входного узла
     * (формат «&lt;&lt;&lt;DOC_i&gt;&gt;&gt;текст&lt;&lt;&lt;END_DOC_i&gt;&gt;&gt;»).
     */
    private void restoreDocsFromSteps(ScenarioRunGraph graph, List<ScenarioRunStep> oldSteps) {
        var inputStep = stepByType(oldSteps, graph,
                ru.sber.cs.ai.gigame.service.scenario.enums.ScenarioNodeType.INPUT_NODE);
        String inputResult = inputStep == null || inputStep.getOutputData() == null
                ? null
                : java.util.Objects.toString(inputStep.getOutputData().get("result"), null);
        if (inputResult == null) {
            throw new ScenarioException("Возобновление невозможно: в исходном прогоне нет шага входного узла");
        }
        List<String> texts = new ArrayList<>();
        List<String> names = new ArrayList<>();
        var m = java.util.regex.Pattern
                .compile("<<<(DOC_\\d+)>>>\\n(.*?)\\n<<<END_\\1>>>", java.util.regex.Pattern.DOTALL)
                .matcher(inputResult);
        while (m.find()) {
            texts.add(m.group(2));
            names.add(m.group(1));
        }
        if (texts.isEmpty()) {
            throw new ScenarioException("Возобновление невозможно: не удалось восстановить документы "
                    + "из шага входного узла");
        }
        restoreRealDocNames(inputStep, names);
        graph.addDocs(texts, names);
    }

    /**
     * Подменяет технические имена DOC_i настоящими именами файлов из ключа
     * «doc_names» шага входного узла (сохраняется при выполнении) — иначе
     * возобновлённый прогон теряет группировку по имени/пути файла.
     * Старые прогоны без «doc_names» остаются на DOC_i.
     */
    private void restoreRealDocNames(ScenarioRunStep inputStep, List<String> names) {
        String saved = inputStep.getOutputData().get(ScenarioRunStepService.KEY_DOC_NAMES);
        if (saved == null || saved.isEmpty()) {
            return;
        }
        String[] savedNames = saved.split("\n", -1);
        if (savedNames.length == names.size()) {
            for (int i = 0; i < names.size(); i++) {
                names.set(i, savedNames[i]);
            }
        }
    }

    /**
     * Сохраняет настоящие имена файлов документов в выход шага входного узла
     * (ключ «doc_names») — для восстановления группировки при возобновлении.
     */
    private void saveInputDocNames(ScenarioRunStep step, ScenarioRunNode node) {
        if (node.getType() != ru.sber.cs.ai.gigame.service.scenario.enums.ScenarioNodeType.INPUT_NODE) {
            return;
        }
        var docMap = node.getGraph().getDocMap();
        if (docMap == null || docMap.isEmpty()) {
            return;
        }
        List<String> names = new ArrayList<>();
        for (int i = 1; i <= docMap.size(); i++) {
            var doc = docMap.get("DOC_" + i);
            if (doc == null) {
                return; // неожиданная нумерация — имена не сохраняем
            }
            names.add(doc.getFilename());
        }
        // имена не содержат перевода строки — компактная сериализация в String-поле
        stepService.appendOutputData(step, ScenarioRunStepService.KEY_DOC_NAMES,
                String.join("\n", names));
    }

    private ScenarioRunStep stepByType(List<ScenarioRunStep> steps, ScenarioRunGraph graph,
                                       ru.sber.cs.ai.gigame.service.scenario.enums.ScenarioNodeType type) {
        for (var step : steps) {
            var node = graph.getNodeMap().get(step.getNodeId());
            if (node != null && node.getType() == type && step.getOutputData() != null) {
                return step;
            }
        }
        return null;
    }

    private String stepResult(List<ScenarioRunStep> steps, ScenarioRunGraph graph,
                              ru.sber.cs.ai.gigame.service.scenario.enums.ScenarioNodeType type) {
        for (var step : steps) {
            var node = graph.getNodeMap().get(step.getNodeId());
            if (node != null && node.getType() == type && step.getOutputData() != null) {
                Object result = step.getOutputData().get("result");
                if (result != null) {
                    return String.valueOf(result);
                }
            }
        }
        return null;
    }

    /**
     * Помечает завершённые LLM-узлы восстановленными: выход — из шага старого прогона,
     * вклад в входы детей — как при обычном выполнении; классы документов —
     * из меток «&lt;&lt;&lt;DOC_i|CLASS:...&gt;&gt;&gt;» классифицирующего цикла.
     */
    private void restoreCompletedLlmNodes(FluxSink<ServerSentEvent<Map<String, Object>>> sink,
                                          ScenarioRun run,
                                          ScenarioRunGraph graph,
                                          List<ScenarioRunStep> oldSteps) {
        for (var step : oldSteps) {
            var node = graph.getNodeMap().get(step.getNodeId());
            if (isRestorableLlmStep(step, node)) {
                restoreLlmNode(sink, run, graph, step, node);
            }
        }
    }

    /**
     * Шаг пригоден для восстановления: узел найден в графе, шаг завершён успешно,
     * узел LLM-типа (processing, loop, subscenario) и в шаге сохранён результат.
     *
     * @param step шаг исходного прогона
     * @param node узел графа, соответствующий шагу (может быть {@code null})
     * @return {@code true}, если выход узла можно восстановить из шага
     */
    private boolean isRestorableLlmStep(ScenarioRunStep step, ScenarioRunNode node) {
        if (node == null || !"completed".equalsIgnoreCase(String.valueOf(step.getStatus()))) {
            return false;
        }
        var type = node.getType();
        boolean llmNode = type == ru.sber.cs.ai.gigame.service.scenario.enums.ScenarioNodeType.PROCESSING_NODE
                || type == ru.sber.cs.ai.gigame.service.scenario.enums.ScenarioNodeType.LOOP_NODE
                || type == ru.sber.cs.ai.gigame.service.scenario.enums.ScenarioNodeType.SUBSCENARIO_NODE;
        return llmNode && step.getOutputData() != null && step.getOutputData().get("result") != null;
    }

    /**
     * Восстанавливает один LLM-узел из шага старого прогона: выход, статусы,
     * копия шага в новый прогон, классы документов и вклад во входы детей.
     *
     * @param sink  поток SSE-событий
     * @param run   НОВЫЙ прогон
     * @param graph граф прогона
     * @param step  шаг исходного прогона с сохранённым результатом
     * @param node  восстанавливаемый узел
     */
    private void restoreLlmNode(FluxSink<ServerSentEvent<Map<String, Object>>> sink,
                                ScenarioRun run,
                                ScenarioRunGraph graph,
                                ScenarioRunStep step,
                                ScenarioRunNode node) {
        String output = String.valueOf(step.getOutputData().get("result"));
        node.getOutput().add(output);
        node.setCompleted(true);
        node.setSkip(false);
        // копия шага в новый прогон — иначе повторное возобновление не увидит
        // восстановленные LLM-узлы и перевыполнит их заново
        stepService.copyStepToRun(run.getId(), step);
        emitNodeStatusEvent(sink, node, ScenarioStatus.COMPLETED);
        // классы документов из классифицирующего цикла
        if (node.getType() == ru.sber.cs.ai.gigame.service.scenario.enums.ScenarioNodeType.LOOP_NODE
                && node.isClassifyStrict()) {
            restoreDocClasses(graph, output);
        }
        // вклад восстановленного узла во входы детей: обычные ветки активируются,
        // ветки «ошибка» остаются пропущенными (узел завершился успешно)
        String contribution = "=== РЕЗУЛЬТАТ ОТ \"" + node.getLabel() + "\" ===\n" + output;
        for (var child : node.getChildNodeList()) {
            child.getInput().add(contribution);
            if (!isErrorEdge(node, child)) {
                child.setSkip(false);
            }
        }
    }

    /**
     * Восстанавливает классы документов из меток
     * «&lt;&lt;&lt;DOC_i|CLASS:...&gt;&gt;&gt;» в выходе классифицирующего цикла.
     *
     * @param graph  граф прогона
     * @param output восстановленный выход узла-цикла
     */
    private void restoreDocClasses(ScenarioRunGraph graph, String output) {
        var cm = java.util.regex.Pattern.compile("<<<(DOC_\\d+)\\|CLASS:([^>]*)>>>").matcher(output);
        while (cm.find()) {
            var doc = graph.getDocMap().get(cm.group(1));
            if (doc != null) {
                doc.setDocClass(cm.group(2).trim());
            }
        }
    }

    private boolean isAllParentCompleted(ScenarioRunNode node) {
        var parentNodeList = node.getParentNodeList();
        if (parentNodeList == null || parentNodeList.isEmpty()) {
            return true;
        }
        return parentNodeList.stream().allMatch(p -> p.getCompleted() || p.getSkip());
    }

    /**
     * Валидирует граф сценария перед выполнением.
     * <p>
     * Проверяет:
     * <ul>
     *   <li>Наличие и непустота массивов nodes и edges</li>
     *   <li>Валидность ссылок рёбер на существующие узлы</li>
     *   <li>Отсутствие циклов (по результату топологической сортировки)</li>
     * </ul>
     *
     * @param graphData данные графа сценария
     * @throws IllegalArgumentException если валидация не пройдена
     */
    /**
     * Убирает из графа узлы-заметки (type=note) вместе с их рёбрами:
     * это аннотации для людей, в валидации и выполнении они не участвуют.
     */
    static GraphDataDto stripNoteNodes(GraphDataDto graphData) {
        Set<String> noteIds = graphData.nodes().stream()
                .filter(n -> ru.sber.cs.ai.gigame.service.scenario.enums.ScenarioNodeType.NOTE_NODE
                        .toString().equals(n.type()))
                .map(ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDto::id)
                .collect(Collectors.toSet());
        if (noteIds.isEmpty()) {
            return graphData;
        }
        return new GraphDataDto(
                graphData.nodes().stream().filter(n -> !noteIds.contains(n.id())).toList(),
                graphData.edges().stream()
                        .filter(e -> !noteIds.contains(e.source()) && !noteIds.contains(e.target()))
                        .toList());
    }

    private void validateGraph(GraphDataDto graphData) {
        if (graphData.nodes().isEmpty()) {
            throw new ScenarioException("Ошибка валидации графа: отсутствует или пуст массив nodes");
        }
        if (graphData.edges().isEmpty()) {
            throw new ScenarioException("Ошибка валидации графа: отсутствует или пуст массив edges");
        }
        if (graphData.nodes().stream()
                .noneMatch(n -> "input".equals(n.type()))) {
            throw new ScenarioException("Ошибка валидации графа: отсутствует узел с типом 'Вход'");
        }
        if (graphData.nodes().stream()
                .noneMatch(n -> "output".equals(n.type()))) {
            throw new ScenarioException("Ошибка валидации графа: отсутствует узел с типом 'Выход'");
        }
        Set<String> nodeIds = getNodeIds(graphData);
        if (!getDisconnectedNodes(graphData, nodeIds).isEmpty()) {
            throw new ScenarioException("Ошибка валидации графа: обнаружены узлы, не связанные рёбрами");
        }
        // Проверка успешной топологической сортировки (отсутствие циклов)
        List<String> sorted = topologicalSort(graphData);
        if (sorted.size() != nodeIds.size()) {
            throw new ScenarioException("Ошибка валидации графа: обнаружен цикл (" + sorted.size() + " из " + nodeIds.size() + " узлов отсортировано)");
        }
    }

    private List<String> getDisconnectedNodes(GraphDataDto graphData, Set<String> nodeIds) {
        // Проверка, что все узлы участвуют хотя бы в одном ребре (source или target)
        Set<String> edgeNodeIds = graphData.edges().stream()
                .flatMap(e -> Stream.of(e.source(), e.target()))
                .filter(Objects::nonNull)
                .collect(Collectors.toSet());
        return nodeIds.stream()
                .filter(id -> !edgeNodeIds.contains(id))
                .toList();
    }

    private List<String> topologicalSort(GraphDataDto graphData) {
        var nodes = graphData.nodes();
        var edges = graphData.edges();
        Map<String, List<String>> graph = new HashMap<>();
        Map<String, Integer> inDegree = new LinkedHashMap<>();

        for (var node : nodes) {
            inDegree.put(node.id(), 0);
        }

        for (var edge : edges) {
            String src = edge.source();
            String tgt = edge.target();
            graph.computeIfAbsent(src, k -> new ArrayList<>()).add(tgt);
            inDegree.merge(tgt, 1, Integer::sum);
        }

        Deque<String> queue = new ArrayDeque<>();
        for (Map.Entry<String, Integer> entry : inDegree.entrySet()) {
            if (entry.getValue() == 0) {
                queue.add(entry.getKey());
            }
        }

        List<String> result = new ArrayList<>();
        while (!queue.isEmpty()) {
            String nodeId = queue.poll();
            result.add(nodeId);
            for (String neighbor : graph.getOrDefault(nodeId, List.of())) {
                int newDeg = inDegree.merge(neighbor, -1, Integer::sum);
                if (newDeg == 0) {
                    queue.add(neighbor);
                }
            }
        }
        return result;
    }
}
