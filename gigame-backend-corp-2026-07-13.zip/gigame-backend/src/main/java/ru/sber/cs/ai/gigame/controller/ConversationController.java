package ru.sber.cs.ai.gigame.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.codec.multipart.FilePart;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;
import ru.sber.cs.ai.gigame.dto.ErrorResponse;
import ru.sber.cs.ai.gigame.dto.chat.ConversationCreate;
import ru.sber.cs.ai.gigame.dto.chat.ConversationResponse;
import ru.sber.cs.ai.gigame.dto.chat.ConversationWithMessages;
import ru.sber.cs.ai.gigame.exception.FileException;
import ru.sber.cs.ai.gigame.service.ChatService;
import ru.sber.cs.ai.gigame.service.DocsTextCacheService;
import ru.sber.cs.ai.gigame.service.DocumentService;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Контроллер для управления диалогами (разговорами).
 * <p>
 * Позволяет создавать, просматривать, обновлять и удалять диалоги,
 * а также отправлять сообщения с потоковой передачей ответов (SSE).
 */
@RestController
@RequestMapping("/api/conversations")
@RequiredArgsConstructor
@Tag(name = "chat", description = "Диалоги и отправка сообщений")
@Slf4j
@SuppressWarnings("unused")
public class ConversationController {

    static final int MAX_FILES_PER_REQUEST = 100;

    private final ChatService chatService;
    private final DocumentService documentService;
    private final DocsTextCacheService docsTextCacheService;

    /**
     * Список всех диалогов.
     * <p>
     * Возвращает список всех доступных диалогов, отсортированных по дате последнего обновления.
     * Поддерживает поиск по заголовку.
     *
     * @param search Поисковый запрос в заголовке диалога (необязательный параметр)
     * @return Список диалогов
     */
    @GetMapping
    @Operation(
            summary = "Получить список диалогов",
            description = "Возвращает список всех диалогов, отсортированных по дате обновления. " +
                    "При передаче параметра 'search' выполняется поиск по частичному совпадению заголовка.",
            responses = {
                    @ApiResponse(responseCode = "200",
                            description = "Список диалогов получен успешно",
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    array = @ArraySchema(maxItems = 1000, schema = @Schema(implementation = ConversationResponse.class)))),
                    @ApiResponse(responseCode = "400",
                            description = "Неверные данные запроса",
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ErrorResponse.class)))})
    public Mono<List<ConversationResponse>> listConversations(
            @RequestHeader(name = "X-UserId", required = false)
            @Parameter(
                    name = "X-UserId",
                    in = ParameterIn.HEADER,
                    schema = @Schema(type = "string", pattern = "^[A-Z0-9]{0,16}$")
            )
            String userId,
            @Parameter(description = "Поисковый запрос в заголовке диалога (необязательный)",
                    schema = @Schema(type = "string", pattern = "^[\\w\\W]{0,128}$"))
            @RequestParam(value = "q", defaultValue = "")
            String search) {
        log.debug("listConversations: userId={}, search='{}'", userId, search);
        return Mono.fromCallable(() -> chatService.getConversations(userId, search))
                .subscribeOn(Schedulers.boundedElastic());
    }

    /**
     * Создание нового диалога.
     * <p>
     * Создаёт новый диалог с указанным заголовком и необязательной привязкой к базе знаний.
     *
     * @param userId Идентификатор пользователя (из заголовка X-UserId)
     * @param body   Данные для создания диалога
     * @return Созданный диалог с уникальным идентификатором
     */
    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    @Operation(
            summary = "Создать новый диалог",
            description = "Создаёт новый диалог. Если заголовок не указан, используется значение по умолчанию " +
                    "'Новый диалог'. Опционально можно привязать диалог к базе знаний для RAG-поиска.",
            responses = {
                    @ApiResponse(responseCode = "201",
                            description = "Диалог успешно создан",
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ConversationResponse.class))
                    ),
                    @ApiResponse(responseCode = "400",
                            description = "Неверные данные запроса",
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ErrorResponse.class)))})
    public Mono<ConversationResponse> createConversation(
            @RequestHeader(name = "X-UserId", required = false)
            @Parameter(
                    name = "X-UserId",
                    in = ParameterIn.HEADER,
                    schema = @Schema(type = "string", pattern = "^[A-Z0-9]{0,16}$")
            )
            String userId,
            @Parameter(description = "Данные для создания диалога (заголовок и ID базы знаний)",
                    content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                            schema = @Schema(implementation = ConversationCreate.class)))
            @RequestBody ConversationCreate body) {
        log.debug("createConversation: userId={}, title='{}', knowledgeBaseId={}, knowledgeBaseIds={}",
                userId, body.title(), body.knowledgeBaseId(), body.knowledgeBaseIds());
        return Mono.fromCallable(() -> chatService.createConversation(userId, body))
                .subscribeOn(Schedulers.boundedElastic());
    }

    /**
     * Получение диалога с сообщениями.
     * <p>
     * Возвращает один диалог вместе со всеми сообщениями в хронологическом порядке.
     *
     * @param id Идентификатор диалога
     * @return Диалог с сообщениями
     */
    @GetMapping("/{id}")
    @Operation(
            summary = "Получить диалог с сообщениями",
            description = "Возвращает конкретный диалог по его идентификатору со всеми сообщениями.",
            responses = {
                    @ApiResponse(responseCode = "200",
                            description = "Диалог найден",
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ConversationWithMessages.class))
                    ),
                    @ApiResponse(responseCode = "400",
                            description = "Неверные данные запроса",
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ErrorResponse.class))
                    ),
                    @ApiResponse(responseCode = "404",
                            description = "Диалог не найден",
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ErrorResponse.class)))})
    public Mono<ConversationWithMessages> getConversation(
            @RequestHeader(name = "X-UserId", required = false)
            @Parameter(
                    name = "X-UserId",
                    in = ParameterIn.HEADER,
                    schema = @Schema(type = "string", pattern = "^[A-Z0-9]{0,16}$")
            )
            String userId,
            @Parameter(description = "Уникальный идентификатор диалога (UUID)",
                    schema = @Schema(type = "string", pattern = "^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"))
            @PathVariable UUID id) {
        log.debug("getConversation: userId={}, conversationId={}", userId, id);
        return Mono.fromCallable(() -> chatService.getConversation(userId, id))
                .subscribeOn(Schedulers.boundedElastic());
    }

    /**
     * Удаление диалога.
     * <p>
     * Удаляет диалог и все связанные сообщения.
     *
     * @param userId Идентификатор пользователя (из заголовка X-UserId)
     * @param id     Идентификатор диалога
     */
    @DeleteMapping("/{id}")
    @Operation(
            summary = "Удалить диалог",
            description = "Удаляет диалог и все сообщения, связанные с ним. Операция необратима.",
            responses = {
                    @ApiResponse(responseCode = "204",
                            description = "Диалог успешно удалён"
                    ),
                    @ApiResponse(responseCode = "400",
                            description = "Неверные данные запроса",
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ErrorResponse.class))
                    ),
                    @ApiResponse(responseCode = "404",
                            description = "Диалог не найден",
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ErrorResponse.class)))})
    public Mono<ResponseEntity<Void>> deleteConversation(
            @RequestHeader(name = "X-UserId", required = false)
            @Parameter(
                    name = "X-UserId",
                    in = ParameterIn.HEADER,
                    schema = @Schema(type = "string", pattern = "^[A-Z0-9]{0,16}$")
            )
            String userId,
            @Parameter(description = "Уникальный идентификатор диалога (UUID)",
                    schema = @Schema(type = "string", pattern = "^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"))
            @PathVariable UUID id) {
        log.debug("deleteConversation: userId={}, conversationId={}", userId, id);
        return Mono.fromRunnable(() -> {
                    chatService.deleteConversation(userId, id);
                    docsTextCacheService.clearCache(id);
                })
                .subscribeOn(Schedulers.boundedElastic())
                .then(Mono.just(ResponseEntity.noContent().build()));
    }

    /**
     * Обновление диалога.
     * <p>
     * Обновляет заголовок диалога.
     *
     * @param userId Идентификатор пользователя (из заголовка X-UserId)
     * @param id     Идентификатор диалога
     * @param body   Новые данные диалога
     * @return Обновлённый диалог
     */
    @PutMapping("/{id}")
    @Operation(
            summary = "Обновить диалог",
            description = "Обновляет настройки диалога: заголовок, привязанные базы знаний, " +
                    "модель и температуру. Поля со значением null не изменяются; " +
                    "пустой список knowledge_base_ids отвязывает все базы; пустая строка model " +
                    "и отрицательная temperature сбрасывают значения на глобальные.",
            responses = {
                    @ApiResponse(responseCode = "200",
                            description = "Диалог успешно обновлён",
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ConversationResponse.class))
                    ),
                    @ApiResponse(responseCode = "400",
                            description = "Неверные данные запроса",
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ErrorResponse.class))
                    ),
                    @ApiResponse(responseCode = "404",
                            description = "Диалог не найден",
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ErrorResponse.class)))})
    public Mono<ConversationResponse> updateConversation(
            @RequestHeader(name = "X-UserId", required = false)
            @Parameter(
                    name = "X-UserId",
                    in = ParameterIn.HEADER,
                    schema = @Schema(type = "string", pattern = "^[A-Z0-9]{0,16}$")
            )
            String userId,
            @Parameter(description = "Уникальный идентификатор диалога (UUID)",
                    schema = @Schema(type = "string", pattern = "^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"))
            @PathVariable UUID id,
            @Parameter(description = "Новые данные диалога (новый заголовок)",
                    content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                            schema = @Schema(implementation = ConversationCreate.class)))
            @RequestBody ConversationCreate body) {
        log.debug("updateConversation: userId={}, conversationId={}, newTitle='{}', kbIds={}, model={}, temperature={}",
                userId, id, body.title(), body.knowledgeBaseIds(), body.model(), body.temperature());
        return Mono.fromCallable(() -> chatService.updateConversation(userId, id, body))
                .subscribeOn(Schedulers.boundedElastic());
    }

    /**
     * Загрузка документов без отправки сообщения.
     * <p>
     * Позволяет загрузить документы (PDF, DOCX, XLSX, TXT) и сохранить их тексты
     * в кэше для последующего использования. Не возвращает ответ.
     *
     * @param userId   Идентификатор пользователя (из заголовка X-UserId)
     * @param id       Идентификатор диалога
     * @param fileFlux Поток файлов для загрузки
     */
    @PostMapping(value = "/{id}/upload",
            consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @Operation(
            summary = "Загрузить документы (без ответа)",
            description = """
                    Загружает документы и сохраняет их тексты в кэше для последующего использования.
                    Этот endpoint не возвращает ответ от ассистента.
                    
                    ## Поддерживаемые форматы:
                    - PDF (.pdf)
                    - Word (.docx)
                    - Excel (.xlsx, .xls)
                    - Текст (.txt, .text)
                    
                    ## Формат запроса (multipart/form-data):
                    - `files` (array): Массив файлов для загрузки
                    
                    ## Примечания:
                    - Максимальный размер файла: 50MB
                    - Максимальный размер запроса: 100MB
                    - Тексты документов хранятся в кэше и могут быть использованы
                      при последующей отправке сообщений
                    """,
            requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(
                    description = "Файлы для загрузки (multipart/form-data)"
            ),
            responses = {
                    @ApiResponse(responseCode = "200",
                            description = "Документы успешно загружены"
                    ),
                    @ApiResponse(responseCode = "400",
                            description = "Неверные данные запроса",
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ErrorResponse.class))
                    ),
                    @ApiResponse(responseCode = "404",
                            description = "Диалог не найден",
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ErrorResponse.class)))})
    public Mono<Void> uploadDocuments(
            @RequestHeader(name = "X-UserId", required = false)
            @Parameter(
                    name = "X-UserId",
                    in = ParameterIn.HEADER,
                    schema = @Schema(type = "string", pattern = "^[A-Z0-9]{0,16}$")
            )
            String userId,
            @Parameter(description = "Уникальный идентификатор диалога (UUID)",
                    schema = @Schema(type = "string", pattern = "^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"))
            @PathVariable UUID id,
            @Parameter(description = "Файлы для загрузки",
                    schema = @Schema(
                            type = "string",
                            format = "binary",
                            pattern = "^(1(01*0)*1|0)+$",
                            description = "Файлы в формате binary"))
            @RequestPart(value = "files") Flux<FilePart> fileFlux) {

        log.debug("uploadDocuments: userId={}, conversationId={}", userId, id);

        return Mono.fromCallable(() -> {
            // Проверяем, что диалог существует
            chatService.getConversation(userId, id);

            List<FilePart> files = fileFlux != null
                    ? fileFlux.collectList().block()
                    : List.of();
            assert files != null;
            log.debug("Обработка {} файла(ов) для загрузки", files.size());
            if (files.size() > MAX_FILES_PER_REQUEST) {
                throw new FileException("Превышено максимальное количество файлов: " + files.size()
                        + ". Максимум: " + MAX_FILES_PER_REQUEST);
            }
            List<String> documentTexts = new ArrayList<>();
            List<String> fileNames = new ArrayList<>();
            List<String> docIds = new ArrayList<>();
            for (FilePart file : files) {
                try {
                    var docResponse = documentService.uploadDocument(file, userId);
                    documentTexts.add(docResponse.extractedText());
                    fileNames.add(docResponse.filename());
                    docIds.add(docResponse.id().toString());
                    log.debug("Обработан файл: имя={}, contentType={}", docResponse.filename(), docResponse.contentType());
                } catch (Exception e) {
                    throw new FileException("Не удалось обработать файл: " + file.filename(), e);
                }
            }
            var fileNamesString = "";
            // Сохраняем тексты документов в кэш
            docsTextCacheService.cacheDocumentTexts(id, documentTexts, fileNames, docIds);
            log.debug("Сохранено {} текстов документов для диалога {}", documentTexts.size(), id);

            return (Void) null;
        }).subscribeOn(Schedulers.boundedElastic());
    }

}
