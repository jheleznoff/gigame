package ru.sber.cs.ai.gigame.utils;

import lombok.extern.slf4j.Slf4j;
import ru.sber.cs.ai.gigame.exception.FileException;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/**
 * Распаковка ZIP-архивов с документами для сценариев.
 * <p>
 * Возвращает только содержательные документы: служебные файлы ЭДО
 * (электронные подписи, хэши, паспорта, технологические квитанции,
 * протоколы передачи) отфильтровываются. Вложенные архивы распаковываются
 * рекурсивно. Имя каждого документа включает имя архива и путь внутри него
 * ("архив.zip/папка/файл.pdf") — путь используется для группировки документов.
 */
@Slf4j
public final class ZipExtractor {

    /** Файл, извлечённый из архива: полное имя (архив + путь внутри) и содержимое. */
    public record ExtractedFile(String name, byte[] content) {
    }

    /** Результат распаковки: документы и количество отфильтрованных служебных файлов. */
    public record ExtractionResult(List<ExtractedFile> files, int skippedCount) {
    }

    static final int MAX_ENTRIES = 500;
    static final long MAX_TOTAL_UNCOMPRESSED_BYTES = 500L * 1024 * 1024;
    static final int MAX_NESTING_DEPTH = 3;

    /** Кодировка имён записей для архивов без UTF-8-флага (архивы из Windows-инструментов). */
    private static final Charset LEGACY_NAME_CHARSET = Charset.forName("CP866");

    /** Расширения содержательных документов; всё прочее внутри архива пропускается. */
    private static final Set<String> DOCUMENT_EXTENSIONS = Set.of("pdf", "docx", "xlsx", "xls", "txt", "xml");

    /** Расширения служебных файлов ЭДО (подписи и хэши). */
    private static final Set<String> SIGNATURE_EXTENSIONS = Set.of("sig", "sgn", "hash", "hash2012", "p7s");

    private ZipExtractor() {
    }

    /**
     * Распаковывает архив, отфильтровывая служебные файлы.
     *
     * @param zipName имя архива (используется как префикс имён документов)
     * @param bytes   содержимое архива
     * @return содержательные документы и счётчик пропущенных файлов
     * @throws FileException если архив повреждён или превышены лимиты распаковки
     */
    public static ExtractionResult extract(String zipName, byte[] bytes) {
        List<ExtractedFile> files = new ArrayList<>();
        Budget budget = new Budget();
        extractInto(zipName, bytes, 1, files, budget);
        if (budget.entries == 0) {
            // ZipInputStream на «мусорных» байтах молча отдаёт 0 записей
            throw new FileException("Архив пуст или повреждён: " + zipName);
        }
        log.info("Архив '{}': извлечено {} документ(ов), пропущено {} служебных/неподдерживаемых файлов",
                zipName, files.size(), budget.skipped);
        return new ExtractionResult(files, budget.skipped);
    }

    private static final class Budget {
        int entries;
        long uncompressedBytes;
        int skipped;
    }

    private static void extractInto(String prefix, byte[] bytes, int depth,
                                    List<ExtractedFile> out, Budget budget) {
        try (ZipInputStream zis = new ZipInputStream(new ByteArrayInputStream(bytes), LEGACY_NAME_CHARSET)) {
            ZipEntry entry;
            while ((entry = zis.getNextEntry()) != null) {
                if (entry.isDirectory()) {
                    continue;
                }
                processEntry(prefix, entry, zis, depth, out, budget);
            }
        } catch (FileException e) {
            throw e;
        } catch (IOException e) {
            throw new FileException("Не удалось распаковать архив: " + prefix, e);
        }
    }

    /**
     * Обрабатывает одну запись архива: учитывает лимит записей, пропускает
     * служебные файлы, вложенный zip распаковывает рекурсивно (с учётом глубины),
     * содержательный документ добавляет в результат.
     */
    private static void processEntry(String prefix, ZipEntry entry, ZipInputStream zis, int depth,
                                     List<ExtractedFile> out, Budget budget) throws IOException {
        if (++budget.entries > MAX_ENTRIES) {
            throw new FileException("Архив содержит слишком много файлов (лимит " + MAX_ENTRIES + ")");
        }
        String entryName = entry.getName().replace('\\', '/');
        String fullName = prefix + "/" + entryName;
        String ext = extension(entryName);

        if ("zip".equals(ext)) {
            if (depth >= MAX_NESTING_DEPTH) {
                log.warn("Пропущен вложенный архив '{}': превышена глубина вложенности {}",
                        fullName, MAX_NESTING_DEPTH);
                budget.skipped++;
                return;
            }
            extractInto(fullName, readEntry(zis, entryName, budget), depth + 1, out, budget);
            return;
        }
        if (isJunk(entryName)) {
            budget.skipped++;
            return;
        }
        out.add(new ExtractedFile(fullName, readEntry(zis, entryName, budget)));
    }

    private static byte[] readEntry(ZipInputStream zis, String entryName, Budget budget) throws IOException {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        byte[] buf = new byte[64 * 1024];
        int read;
        while ((read = zis.read(buf)) > 0) {
            budget.uncompressedBytes += read;
            if (budget.uncompressedBytes > MAX_TOTAL_UNCOMPRESSED_BYTES) {
                throw new FileException("Превышен лимит распакованного размера архива ("
                        + (MAX_TOTAL_UNCOMPRESSED_BYTES / (1024 * 1024)) + " МБ) на файле: " + entryName);
            }
            bos.write(buf, 0, read);
        }
        return bos.toByteArray();
    }

    /**
     * Служебный файл ЭДО или неподдерживаемый формат — в обработку не идёт.
     * Видимость package-private для тестов.
     */
    static boolean isJunk(String entryPath) {
        String baseName = entryPath.substring(entryPath.lastIndexOf('/') + 1);
        String lower = baseName.toLowerCase(Locale.ROOT);
        String ext = extension(baseName);

        if (SIGNATURE_EXTENSIONS.contains(ext)) {
            return true;
        }
        if (!DOCUMENT_EXTENSIONS.contains(ext)) {
            return true;
        }
        // паспорта ЭП: Passport(01).txt и т.п.
        if ("txt".equals(ext) && lower.startsWith("passport")) {
            return true;
        }
        // протоколы оператора ЭДО о передаче документа
        if ("pdf".equals(ext) && lower.contains("протокол передачи документа")) {
            return true;
        }
        // из XML содержателен только сам УПД (ON_NSCHFDOPPR);
        // DP_* и ON_NSCHFDOPPOK — технологические квитанции документооборота
        if ("xml".equals(ext) && !lower.startsWith("on_nschfdoppr_")) {
            return true;
        }
        return false;
    }

    private static String extension(String name) {
        int dotIdx = name.lastIndexOf('.');
        return dotIdx < 0 ? "" : name.substring(dotIdx + 1).toLowerCase(Locale.ROOT);
    }
}
