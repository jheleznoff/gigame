-- Preliquibase выполняется ДО Liquibase и предназначен только для того,
-- что Liquibase сделать не может: создать схему, в которой он будет вести
-- свои таблицы. Все изменения объектов БД — в db/changelog/ (changeset'ы).
CREATE SCHEMA IF NOT EXISTS ${spring.liquibase.default-schema};
