--liquibase formatted sql
--changeset gigame:002-scenario-versions
--comment Версии сценариев: снапшот графа при каждом изменении (2026-07-08)
CREATE TABLE IF NOT EXISTS scenario_versions (
    id UUID PRIMARY KEY,
    scenario_id UUID NOT NULL,
    version_no INTEGER NOT NULL,
    name VARCHAR(255),
    description TEXT,
    graph_data JSONB,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_scenario_versions_sid
    ON scenario_versions(scenario_id, version_no);

--changeset gigame:003-chat-extensions
--comment Доработки чата: несколько БЗ на диалог, модель/температура, суммаризация истории, источники RAG (2026-07-09)
ALTER TABLE conversations
    ADD COLUMN IF NOT EXISTS knowledge_base_ids JSONB,
    ADD COLUMN IF NOT EXISTS model VARCHAR(64),
    ADD COLUMN IF NOT EXISTS temperature DOUBLE PRECISION,
    ADD COLUMN IF NOT EXISTS summary TEXT,
    ADD COLUMN IF NOT EXISTS summary_message_count INTEGER NOT NULL DEFAULT 0;
ALTER TABLE messages
    ADD COLUMN IF NOT EXISTS sources JSONB;

--changeset gigame:004-kb-shared
--comment Общие базы знаний: признак «видна всем» (2026-07-09)
ALTER TABLE knowledge_bases
    ADD COLUMN IF NOT EXISTS shared BOOLEAN NOT NULL DEFAULT FALSE;
