import { fetchApi } from './client';
import { BASE_URL} from './constants';
import { getScenarioWebSocketClient, type StreamEvent, type StreamEventCallback } from './websocket';

export interface Scenario {
  id: string;
  name: string;
  description: string | null;
  created_at: string;
  updated_at: string;
}

export interface ScenarioDetail extends Scenario {
  graph_data: {
    nodes: ScenarioNode[];
    edges: ScenarioEdge[];
  };
}

export interface ScenarioNode {
  id: string;
  type: string;
  position: { x: number; y: number };
  data: Record<string, string>;
}

export interface ScenarioEdge {
  id: string;
  source: string;
  target: string;
}

export interface ScenarioRun {
  id: string;
  scenario_id: string;
  status: 'pending' | 'running' | 'completed' | 'failed';
  input_document_ids: string[];
  result: { output: string } | null;
  started_at: string | null;
  completed_at: string | null;
}

export interface ScenarioRunStep {
  id: string;
  node_id: string;
  node_type: string;
  status: string;
  input_data: unknown;
  output_data: unknown;
  prompt_used: string | null;
  tokens_used: number | null;
  started_at: string | null;
  completed_at: string | null;
}

export interface ScenarioRunDetail extends ScenarioRun {
  steps: ScenarioRunStep[];
}

export function getScenarios(): Promise<Scenario[]> {
  return fetchApi('/scenarios');
}

export function getScenario(id: string): Promise<ScenarioDetail> {
  return fetchApi(`/scenarios/${id}`);
}

export function createScenario(
  name: string,
  description?: string,
  graphData?: unknown,
): Promise<Scenario> {
  return fetchApi('/scenarios', {
    method: 'POST',
    body: JSON.stringify({
      name,
      description: description || null,
      graph_data: graphData || { nodes: [], edges: [] },
    }),
  });
}

export function updateScenario(
  id: string,
  data: { name?: string; description?: string; graph_data?: unknown },
): Promise<Scenario> {
  return fetchApi(`/scenarios/${id}`, {
    method: 'PUT',
    body: JSON.stringify(data),
  });
}

export function duplicateScenario(id: string): Promise<Scenario> {
  return fetchApi(`/scenarios/${id}/duplicate`, { method: 'POST' });
}

export function deleteScenario(id: string): Promise<void> {
  return fetchApi(`/scenarios/${id}`, { method: 'DELETE' });
}

export function getScenarioRuns(scenarioId: string): Promise<ScenarioRun[]> {
  return fetchApi(`/scenarios/${scenarioId}/runs`);
}

export function getScenarioRun(runId: string): Promise<ScenarioRunDetail> {
  return fetchApi(`/scenarios/runs/${runId}`);
}

export function continueScenarioStep(runId: string): Promise<void> {
  return fetchApi(`/scenarios/runs/${runId}/continue`, { method: 'POST' });
}

export interface ScenarioVersionMeta {
  version_no: number;
  name: string;
  created_at: string;
}

export function getScenarioVersions(id: string): Promise<ScenarioVersionMeta[]> {
  return fetchApi(`/scenarios/${id}/versions`);
}

export function restoreScenarioVersion(id: string, versionNo: number): Promise<Scenario> {
  return fetchApi(`/scenarios/${id}/versions/${versionNo}/restore`, { method: 'POST' });
}


/**
 * Возобновление упавшего прогона по WebSocket (команда type=resume):
 * возвращает id нового прогона из первого события. Выполнение идёт на сервере
 * независимо от соединения — после получения id сокет закрывается.
 */
export function resumeScenarioRun(runId: string): Promise<string | null> {
  const client = getScenarioWebSocketClient();
  return new Promise<string | null>((resolve, reject) => {
    let settled = false;
    const finish = (value: string | null, err?: Error) => {
      if (settled) return;
      settled = true;
      client.setOnMessage(null);
      client.disconnect();
      if (err) reject(err);
      else resolve(value);
    };
    client.setOnMessage(((event: Record<string, unknown>) => {
      const data = (event.data ?? {}) as Record<string, unknown>;
      if (typeof data.run_id === 'string') {
        finish(data.run_id);
      } else if (event.error || data.error) {
        finish(null, new Error(String(event.error ?? data.error)));
      }
    }) as StreamEventCallback);
    client.connect();
    // send ставит сообщение в очередь до открытия сокета
    client.send({ type: 'resume', run_id: runId } as unknown as StreamEvent);
    // если id не пришёл — возобновление всё равно могло запуститься; вернём null,
    // вызывающий код предложит обновить список прогонов
    setTimeout(() => finish(null), 30000);
  });
}

export function disableScenarioStepMode(runId: string): Promise<void> {
  return fetchApi(`/scenarios/runs/${runId}/disable-step-mode`, { method: 'POST' });
}

export async function* runScenario(
  scenarioId: string,
  files: File[],
  stepMode: boolean = false,
): AsyncGenerator<Record<string, unknown>> {
  const client = getScenarioWebSocketClient();

  let cleanupDone = false;

  // Set up handlers before connecting
  const queue: Record<string, unknown>[] = [];

  const handleMessage = (event: Record<string, unknown>) => {
      console.log("Received message:", event);
    queue.push(event);
    if (event.done || event.error) {
      if (cleanupDone) return;
      cleanupDone = true;
      // Cleanup after queue is drained
      (async () => {
        await new Promise(resolve => setTimeout(resolve, 100)); // Small delay to drain queue
        client.setOnMessage(null);
        client.disconnect();
      })();
    }
  };

  client.setOnMessage(handleMessage as StreamEventCallback);

  // Connect if not already connected
  client.connect();

  // Wait for connection to be established
  const waitConnection = new Promise<void>((resolve, reject) => {
    const checkConnection = () => {
      if (client.isConnected()) {
        resolve();
      } else if (client.getWs() === null) {
        reject(new Error('WebSocket connection closed before established'));
      } else {
        setTimeout(checkConnection, 10);
      }
    };
    checkConnection();
  });

  try {
    await waitConnection;
  } catch (error) {
    console.error('WebSocket connect error:', error);
    client.setOnMessage(null);
    throw new Error('Failed to connect to server');
  }

  try {
    // Upload files if provided
    if (files && files.length > 0) {
      await uploadFiles(scenarioId, files);
      queue.push({ type: 'UPLOAD_DONE', count: files.length.toString()});
    }

    // Send run request via WebSocket
    client.send({
      scenario_id: scenarioId,
//       files: formData,
      step_mode: stepMode,
    } as StreamEvent);

    // Yield events as they arrive
    while (!cleanupDone || queue.length > 0) {
      if (queue.length > 0) {
        const event = queue.shift()!;
        yield event;
        if ((event as { done?: boolean; error?: string }).done || (event as { done?: boolean; error?: string }).error) {
          cleanupDone = true;
        }
      } else {
        // Wait a bit before checking again
        await new Promise((resolve) => setTimeout(resolve, 10));
      }
    }
  } catch (error) {
    console.error('Stream error:', error);
    if (!cleanupDone) {
      client.setOnMessage(null);
      client.disconnect();
      cleanupDone = true;
    }
    throw error;
  } finally {
    // Ensure cleanup happens
    if (!cleanupDone) {
      try {
        client.setOnMessage(null);
        client.disconnect();
      } catch (e) {
        // Ignore errors during cleanup
      }
      cleanupDone = true;
    }
  }
  // Upload files to the server and return document IDs
  async function uploadFiles(
    scenarioId: string,
    files: File[]
  ): Promise<void> {
    const formData = new FormData();
    formData.append('content', ''); // Empty content placeholder
    for (const file of files) {
      formData.append('files', file);
    }

    const response = await fetch(BASE_URL + `/scenarios/${scenarioId}/upload`, {
      method: 'POST',
      body: formData,
    });

    if (!response.ok) {
      throw new Error(`Upload error: ${response.status}`);
    }
  }
}