"""Восстановление после ошибочных слияний сущностей (авария --auto 2026-07-23).

Тексты заметок при слиянии не менялись — в них сохранились оригинальные
[[wiki-ссылки]]. Скрипт:
  1) воссоздаёт удалённые сущности по логу слияний (и/или по graph.graphml,
     если остался снапшот до аварии — оттуда берутся точные типы);
  2) полностью пересобирает связи заметка↔сущность из [[ссылок]] в текстах —
     это откатывает ошибочные перевесы на хабы («Максим», «AI», «2026»);
  3) печатает, что восстановить нельзя (упоминания в письмах и рёбра,
     перевешенные на хабы, источника для отката не имеют — они постепенно
     перенаберутся из новых писем).

Запуск (на корп-ноуте):
  1. Сохраните вывод консоли со слияниями в файл, например merge_log.txt
     (строки вида 'Имя' → 'Имя2' — лишние строки не мешают).
  2. python scripts\\repair_merged_entities.py merge_log.txt
     [--graphml data\\graph.graphml]   # если снапшот старше аварии
     [--dry-run]                        # сначала посмотреть план

Перед работой автоматически делается резервная копия БД.
"""

from __future__ import annotations

import argparse
import re
import shutil
from datetime import datetime
from pathlib import Path

from gigapost.config import settings, setup_logging
from gigapost.db.database import Database
from gigapost.db.repositories import Repos
from gigapost.knowledge.graph_store import parse_wikilinks

# 'Имя' (type) → 'Имя2' (type2)   |   'Имя' → 'Имя2'
_LINE_RE = re.compile(
    r"^\s*'(?P<src>.+?)'(?:\s+\((?P<stype>\w+)\))?\s+(?:→|->)\s+"
    r"'(?P<dst>.+?)'(?:\s+\((?P<dtype>\w+)\))?\s*$")

_FIO_RE = re.compile(r"^[А-ЯЁ][а-яё]+(\s[А-ЯЁ][а-яё]+){1,2}(\s[А-ЯЁ]\.\s?[А-ЯЁ]?\.?)?$")


def _parse_log(path: Path) -> list[dict]:
    pairs = []
    for line in path.read_text(encoding="utf-8", errors="replace").splitlines():
        m = _LINE_RE.match(line)
        if m:
            pairs.append({"src": m.group("src").strip(), "stype": m.group("stype"),
                          "dst": m.group("dst").strip(), "dtype": m.group("dtype")})
    return pairs


def _types_from_graphml(path: Path) -> dict[str, str]:
    """{normalized_name: type} из снапшота графа (если он старше аварии)."""
    try:
        import networkx as nx
        g = nx.read_graphml(str(path))
    except Exception as e:  # noqa: BLE001
        print(f"graphml не прочитан ({e}) — типы возьмём эвристикой")
        return {}
    out = {}
    for _, d in g.nodes(data=True):
        if d.get("kind") == "entity" and d.get("name"):
            norm = " ".join(str(d["name"]).lower().replace("ё", "е").split())
            out[norm] = d.get("type") or "topic"
    print(f"graphml: {len(out)} сущностей с типами")
    return out


def _guess_type(name: str, hint: str | None, gml: dict[str, str]) -> str:
    if hint:
        return hint
    norm = " ".join(name.lower().replace("ё", "е").split())
    if norm in gml:
        return gml[norm]
    return "person" if _FIO_RE.match(name.strip()) else "topic"


def repair(log_path: Path, graphml: Path | None, dry_run: bool) -> None:
    db = Database(settings.db_path)
    db.init_schema()
    repos = Repos(db)

    if not dry_run:
        backup = settings.db_path.with_name(
            f"gigapost.backup-{datetime.now():%Y%m%d-%H%M%S}.db")
        shutil.copy2(settings.db_path, backup)
        print(f"Резервная копия БД: {backup}")

    pairs = _parse_log(log_path)
    print(f"Лог слияний: {len(pairs)} пар")
    gml = _types_from_graphml(graphml) if graphml else {}

    # 1. воссоздать удалённые сущности
    recreated = 0
    for p in pairs:
        if repos.entities.find_exact(p["src"]):
            continue
        t = _guess_type(p["src"], p["stype"], gml)
        if dry_run:
            print(f"  [план] воссоздать: {p['src']!r} ({t})")
        else:
            repos.entities.upsert(p["src"], t)
        recreated += 1
    print(f"Воссоздано сущностей: {recreated}")

    # 2. пересобрать ВСЕ связи заметка↔сущность из [[ссылок]] в текстах
    if dry_run:
        print("[план] пересборка note_links из текстов заметок")
        return
    repos.db.execute("DELETE FROM note_links")
    relinked, unresolved = 0, set()
    for note in repos.notes.all_notes():
        for name in parse_wikilinks(note.get("body") or ""):
            exact = repos.entities.find_exact(name)
            if exact:
                repos.notes.link_entity(note["id"], exact["id"])
                relinked += 1
            else:
                unresolved.add(name)
    print(f"Связей пересобрано: {relinked}; неразрешённых [[имён]]: {len(unresolved)}")
    for name in sorted(unresolved)[:20]:
        print(f"  без сущности: [[{name}]]")

    print("\nЧто восстановить нельзя (перенаберётся из новых писем):\n"
          "  - упоминания в письмах (entity_mentions), перевешенные на хабы;\n"
          "  - рёбра граф-связей, перевешенные на хабы;\n"
          "  - досье слитых сущностей (пересоберутся кнопкой на /entity).\n"
          "После скрипта перезапустите сервер — граф в памяти пересоберётся.")


if __name__ == "__main__":
    import sys
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    setup_logging()
    parser = argparse.ArgumentParser()
    parser.add_argument("log", help="файл с сохранённым выводом слияний")
    parser.add_argument("--graphml", help="снапшот data/graph.graphml до аварии")
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()
    repair(Path(args.log), Path(args.graphml) if args.graphml else None,
           args.dry_run)
