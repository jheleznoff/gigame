"""Прогон тестового кейса (например, SberQ Тайга) через реальное решение.

Структура папки кейса:
  case/
  ├── knowledge.yaml        # изначальные знания
  │     entities: {"Имя": "person|org|project|topic", ...}
  │     notes:
  │       - {title: "...", kind: fact|agreement|decision|event|status,
  │          body: "текст с [[wiki-ссылками]]"}
  ├── emails/               # письма в порядке получения: 01_*.yaml, 02_*.yaml ...
  │     # каждое письмо:
  │     #   direction: in | out      (out — моё отправленное, прогон через SentProcessor)
  │     #   subject, sender_name, sender_email, received_at, body: |
  │     #   attachments: [{filename: ..., path: ...}]   # опционально
  │     #   expected_reply: |        # эталонный ответ (для direction: in) — опционально
  └── (результаты пишутся в case/out/)

Запуск: .venv\\Scripts\\python scripts\\run_case.py <папка кейса> [--no-vectors]

Для каждого входящего письма: классификация → извлечение → знания → черновик
ответа (если есть expected_reply) → сверка с эталоном (косинус эмбеддингов +
вывод обоих текстов рядом). Итоговый отчёт — case/out/report.md.
"""

import argparse
import sys
from pathlib import Path

import yaml

from gigapost.config import load_taxonomy, settings, setup_logging
from gigapost.context import AppContext, set_context
from gigapost.control.monitor import ControlMonitor
from gigapost.db.database import Database
from gigapost.db.repositories import Repos
from gigapost.knowledge.graph_store import KnowledgeGraph
from gigapost.outlook.client import NullOutlookClient
from gigapost.outlook.models import EmailMessage
from gigapost.pipeline.graph import build_ingest_graph
from gigapost.pipeline.nodes import PipelineNodes
from gigapost.pipeline.sent import SentProcessor


def load_case(case_dir: Path) -> tuple[dict, list[tuple[str, dict]]]:
    knowledge = {}
    kpath = case_dir / "knowledge.yaml"
    if kpath.exists():
        knowledge = yaml.safe_load(kpath.read_text(encoding="utf-8")) or {}
    emails = []
    for f in sorted((case_dir / "emails").glob("*.yaml")):
        emails.append((f.stem, yaml.safe_load(f.read_text(encoding="utf-8"))))
    return knowledge, emails


def seed_knowledge(kg: KnowledgeGraph, repos: Repos, knowledge: dict) -> tuple[int, int]:
    entities = knowledge.get("entities") or {}
    for name, type_ in entities.items():
        kg.upsert_entity(name, type_)
    known = {repos.entities.normalize(n): t for n, t in entities.items()}
    created = 0
    for note in knowledge.get("notes") or []:
        if kg.add_note(title=note["title"], body=note["body"],
                       kind=note.get("kind", "fact"), source_message_id=None,
                       conversation_id="CASE-KNOWLEDGE", known_types=known):
            created += 1
    return len(entities), created


def to_email(num: int, data: dict) -> EmailMessage:
    atts = data.get("attachments") or []
    return EmailMessage(
        message_id=f"<case-{num:02d}@case.local>",
        entry_id=f"CASE{num:02d}",
        conversation_id=data.get("conversation_id") or f"CASE-CONV-{num:02d}",
        subject=data.get("subject", ""),
        sender_name=data.get("sender_name", ""),
        sender_email=data.get("sender_email", ""),
        recipients=data.get("recipients") or ["me@case.local"],
        received_at=data.get("received_at", "2026-07-21T10:00:00"),
        body_text=data.get("body", ""),
        folder="Sent" if data.get("direction") == "out" else "Inbox",
        has_attachments=bool(atts),
        attachment_names=[a["filename"] for a in atts],
        attachment_paths=[a["path"] for a in atts if a.get("path")],
    )


def similarity(vectors, a: str, b: str) -> float | None:
    try:
        va = vectors.embeddings.embed_query(a[:2000])
        vb = vectors.embeddings.embed_query(b[:2000])
        dot = sum(x * y for x, y in zip(va, vb))
        na = sum(x * x for x in va) ** 0.5
        nb = sum(x * x for x in vb) ** 0.5
        return round(dot / (na * nb), 3)
    except Exception:  # noqa: BLE001
        return None


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("case_dir")
    parser.add_argument("--no-vectors", action="store_true")
    args = parser.parse_args()
    setup_logging()
    case_dir = Path(args.case_dir)
    out_dir = case_dir / "out"
    out_dir.mkdir(exist_ok=True)

    db = Database(settings.db_path)
    db.init_schema()
    repos = Repos(db)
    outlook = NullOutlookClient()
    kg = KnowledgeGraph(repos, settings.graphml_path)
    kg.rebuild()
    vectors = None
    if not args.no_vectors:
        try:
            from gigapost.knowledge.vector_store import VectorStore
            vectors = VectorStore(settings.chroma_path)
        except Exception as e:  # noqa: BLE001
            print(f"! векторы недоступны: {e}")
    set_context(AppContext(repos=repos, outlook=outlook, kg=kg, vectors=vectors))

    knowledge, emails = load_case(case_dir)
    n_ent, n_notes = seed_knowledge(kg, repos, knowledge)
    print(f"Знания загружены: сущностей {n_ent}, заметок {n_notes}")

    nodes = PipelineNodes(repos, outlook, load_taxonomy(), kg, vectors)
    graph = build_ingest_graph(nodes)
    sent_proc = SentProcessor(repos, outlook)
    monitor = ControlMonitor(repos)
    report = [f"# Отчёт прогона кейса {case_dir.name}\n",
              f"Знания: {n_ent} сущностей, {n_notes} заметок\n"]

    def _done_marker(message_id: str, direction: str) -> bool:
        stage = "sent" if direction == "out" else "kg"
        row = repos.db.query_one(
            "SELECT 1 FROM processing_log WHERE message_id=? AND stage=? AND status='ok'",
            (message_id, stage))
        return row is not None

    def _reset_derived(message_id: str) -> None:
        """Удалить производные незавершённого письма перед повторной обработкой."""
        repos.db.execute("DELETE FROM tasks WHERE source_message_id=?", (message_id,))
        repos.db.execute("DELETE FROM agreements WHERE source_message_id=?", (message_id,))
        repos.db.execute(
            "DELETE FROM note_links WHERE note_id IN "
            "(SELECT id FROM notes WHERE source_message_id=?)", (message_id,))
        repos.db.execute("DELETE FROM notes WHERE source_message_id=?", (message_id,))

    import time

    from gigachat.exceptions import RateLimitError

    for i, (name, data) in enumerate(emails, 1):
        email = to_email(i, data)
        direction = data.get("direction", "in")
        if _done_marker(email.message_id, direction):
            print(f"=== [{i}/{len(emails)}] {name}: уже обработано, пропускаю")
            continue
        print(f"\n=== [{i}/{len(emails)}] {name}: {email.subject[:60]} "
              f"({'исходящее' if direction == 'out' else 'входящее'})")
        if repos.emails.exists(email.message_id):
            _reset_derived(email.message_id)
        repos.emails.upsert(email)
        report.append(f"\n## {i}. {email.subject} "
                      f"({'исходящее' if direction == 'out' else 'входящее'})\n")

        def _process():
            if direction == "out":
                r = sent_proc.process_email(email)
                repos.log.log(email.message_id, "sent", "ok",
                              f"обещаний={r['promises']}")
                print(f"  обещаний: {r['promises']}, задач к закрытию: {r['maybe_done']}")
                report.append(f"- обещаний: {r['promises']}, к закрытию: {r['maybe_done']}\n")
            else:
                graph.invoke({"email": email})

        for attempt in range(4):
            try:
                _process()
                break
            except RateLimitError:
                wait = 120 * (attempt + 1)
                print(f"  429 исчерпал ретраи — пауза {wait} с и повтор письма "
                      f"(попытка {attempt + 2}/4)")
                time.sleep(wait)
                _reset_derived(email.message_id)
        else:
            print("  ! письмо пропущено из-за лимитов API")
            report.append("- ! ПРОПУЩЕНО из-за лимитов API\n")
            continue
        if direction == "out":
            continue
        if True:
            row = repos.emails.get(email.message_id)
            line = (f"категория={row.get('category')} conf={row.get('category_confidence')}"
                    f"{' → НА РАЗБОР' if row.get('needs_review') else ''}")
            print(f"  {line}")
            report.append(f"- классификация: {line}\n")
            new_tasks = [t for t in repos.tasks.list(limit=50)
                         if t.get("source_message_id") == email.message_id]
            for t in new_tasks:
                print(f"  задача: [{t['assignee']}] {t['title'][:70]} (срок {t['due_date']})")
                report.append(f"- задача: [{t['assignee']}] {t['title']} (срок {t['due_date']})\n")
            new_notes = repos.notes.for_email(email.message_id)
            for n in new_notes:
                report.append(f"- заметка [{n['kind']}]: {n['title']}\n")
            print(f"  заметок: {len(new_notes)}")

            expected = (data.get("expected_reply") or "").strip()
            if expected and (out_dir / f"{name}_reply.md").exists():
                print("  ответ уже сверён ранее, пропускаю")
                expected = ""
            if expected:
                from gigapost.agent.tools import build_reply_draft
                from gigapost.context import get_context
                draft = None
                for attempt in range(4):
                    try:
                        draft = build_reply_draft(get_context(), email.message_id)
                        break
                    except RateLimitError:
                        wait = 120 * (attempt + 1)
                        print(f"  429 на генерации ответа — пауза {wait} с")
                        time.sleep(wait)
                draft = draft or "(не сгенерирован — лимиты API)"
                sim = similarity(vectors, draft, expected) if vectors else None
                (out_dir / f"{name}_reply.md").write_text(
                    f"# {email.subject}\n\n## Ответ решения\n\n{draft}\n\n"
                    f"## Эталон SberQ\n\n{expected}\n\n## Сходство: {sim}\n",
                    encoding="utf-8")
                verdict = ("✅ близко" if sim and sim >= 0.75
                           else "⚠ РАСХОЖДЕНИЕ" if sim is not None else "?")
                print(f"  ответ сгенерирован, сходство с эталоном: {sim} {verdict}")
                report.append(f"- **черновик ответа**: сходство {sim} {verdict} "
                              f"(см. out/{name}_reply.md)\n")

    stats = monitor.run()
    report.append(f"\n## Контроль после прогона: {stats}\n")
    report.append(f"\n## Итог: {kg.stats()}, задач: "
                  f"{repos.tasks.count('draft')} черновиков / {repos.tasks.count('open')} открытых\n")
    (out_dir / "report.md").write_text("".join(report), encoding="utf-8")
    print(f"\nОтчёт: {out_dir / 'report.md'}")


if __name__ == "__main__":
    main()
