"""Основная точка входа: python scripts/run_web.py

Один процесс: поток ComWorker + APScheduler + Flask (waitress).
Никакого reloader'а — он форкает процесс и ломает COM-поток.
"""

import logging

from gigapost.config import load_taxonomy, settings, setup_logging
from gigapost.context import AppContext, set_context
from gigapost.control.monitor import ControlMonitor
from gigapost.db.database import Database
from gigapost.db.repositories import Repos
from gigapost.knowledge.graph_store import KnowledgeGraph
from gigapost.knowledge.vector_store import VectorStore
from gigapost.outlook.client import NullOutlookClient, OutlookClient
from gigapost.outlook.com_worker import ComWorker, ComWorkerError
from gigapost.pipeline.graph import IngestRunner
from gigapost.pipeline.nodes import PipelineNodes
from gigapost.scheduler import build_scheduler
from gigapost.web.app import create_app

logger = logging.getLogger("run_web")


def main() -> None:
    setup_logging()

    db = Database(settings.db_path)
    db.init_schema()
    repos = Repos(db)

    worker = ComWorker()
    taxonomy = load_taxonomy()
    try:
        worker.start()
        outlook = OutlookClient(worker, dry_run=settings.dry_run)
        if not settings.dry_run:
            outlook.register_categories(
                {c.outlook.category: c.outlook.color for c in taxonomy.categories
                 if c.outlook.category})
    except ComWorkerError as e:
        logger.warning("Outlook недоступен, работаю без него: %s", e)
        outlook = NullOutlookClient()

    if settings.has_ews:
        try:
            from gigapost.outlook.ews_client import EwsClient, HybridClient
            outlook = HybridClient(EwsClient(), outlook)
            logger.info("Чтение почты через EWS, мутации Outlook — через COM")
        except Exception as e:  # noqa: BLE001 — EWS опционален, COM остаётся
            logger.warning("EWS недоступен (%s) — читаю через COM", e)

    kg = KnowledgeGraph(repos, settings.graphml_path)
    kg.rebuild()
    try:
        vectors = VectorStore(settings.chroma_path)
    except Exception as e:  # noqa: BLE001 — без векторов работаем, поиск деградирует до FTS
        logger.warning("Векторное хранилище недоступно: %s", e)
        vectors = None

    set_context(AppContext(repos=repos, outlook=outlook, kg=kg, vectors=vectors))

    nodes = PipelineNodes(repos, outlook, taxonomy, kg, vectors)
    runner = IngestRunner(repos, outlook, nodes)
    monitor = ControlMonitor(repos, outlook)
    from gigapost.pipeline.sent import SentProcessor
    sent_processor = SentProcessor(repos, outlook)

    import os
    no_scheduler = os.environ.get("GIGAPOST_NO_SCHEDULER") == "1"
    scheduler = build_scheduler(runner, monitor, kg, sent_processor)
    if no_scheduler:
        logger.warning("Планировщик ОТКЛЮЧЁН (GIGAPOST_NO_SCHEDULER=1) — почта не опрашивается")
    else:
        scheduler.start()
        # файловый шлюз: если VBA-макрос выгружает письма в GigaMePost_Export,
        # подхватываем их через полный пайплайн (тела доступны даже там, где
        # политика блокирует чтение по COM)
        from gigapost.outlook.msg_import import DEFAULT_EXPORT_DIR, import_dir
        if DEFAULT_EXPORT_DIR.exists():
            scheduler.add_job(
                lambda: import_dir(repos, graph=runner.graph),
                "interval", minutes=settings.polling.interval_minutes,
                id="msg_import", coalesce=True, max_instances=1)
            # COM-опрос выключаем: те же письма придут через файлы с телами,
            # а через COM — обрезанные (политика) и с другими id → дубли
            try:
                scheduler.remove_job("poll_mailbox")
                logger.info("Импорт .msg включён (%s), COM-опрос почты отключён",
                            DEFAULT_EXPORT_DIR)
            except Exception:  # noqa: BLE001
                pass

    app = create_app()
    from gigapost.web.routes.dashboard import bp as dashboard_bp
    dashboard_bp.ingest_runner = runner  # для кнопки «проверить почту сейчас»

    mode = "DRY-RUN" if settings.dry_run else "БОЕВОЙ"
    url = f"http://{settings.web.host}:{settings.web.port}"
    logger.info("GigaMe.Post запущен: %s (режим Outlook: %s)", url, mode)
    print(f"\n  GigaMe.Post: {url}  (режим: {mode})\n")

    try:
        from waitress import serve
        serve(app, host=settings.web.host, port=settings.web.port, threads=8)
    finally:
        scheduler.shutdown(wait=False)
        kg.save_graphml()
        worker.stop()


if __name__ == "__main__":
    main()
