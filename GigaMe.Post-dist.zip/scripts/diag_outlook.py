"""Диагностика доступа к Outlook COM: какие операции/свойства блокируются.

Запуск:  python scripts\\diag_outlook.py [подстрока_хранилища]
Берёт 3 последних письма из Inbox и пробует прочитать каждое свойство отдельно.
Ничего не изменяет и никуда не отправляет.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from gigapost.outlook.client import (PR_INTERNET_MESSAGE_ID, _resolve_store,
                                     _restrict_date)
from gigapost.outlook.com_worker import ComWorker


def check(label, fn):
    try:
        value = fn()
        text = repr(value)
        if len(text) > 80:
            text = text[:80] + "..."
        print(f"  OK    {label}: {text}")
        return True
    except Exception as e:  # noqa: BLE001
        print(f"  FAIL  {label}: {e}")
        return False


def dump_security_policy() -> None:
    """Политики Object Model Guard из реестра (кто блокирует программный доступ)."""
    import winreg

    print("Политики программного доступа Outlook:")
    paths = [
        (winreg.HKEY_LOCAL_MACHINE,
         r"SOFTWARE\Policies\Microsoft\Office\16.0\Outlook\Security"),
        (winreg.HKEY_CURRENT_USER,
         r"SOFTWARE\Policies\Microsoft\Office\16.0\Outlook\Security"),
        (winreg.HKEY_CURRENT_USER,
         r"SOFTWARE\Microsoft\Office\16.0\Outlook\Security"),
    ]
    found = False
    for hive, path in paths:
        hive_name = "HKLM" if hive == winreg.HKEY_LOCAL_MACHINE else "HKCU"
        try:
            with winreg.OpenKey(hive, path) as key:
                i = 0
                while True:
                    try:
                        name, value, _ = winreg.EnumValue(key, i)
                    except OSError:
                        break
                    print(f"  {hive_name}\\...\\{path.rsplit(chr(92), 1)[-1]}: "
                          f"{name} = {value}")
                    found = True
                    i += 1
        except OSError:
            continue
    if not found:
        print("  (ключей политики нет — действует поведение по умолчанию:"
              " разрешать при исправном антивирусе)")
    print("  Справка: AdminSecurityMode 3=запросы отключены (доверять),"
          " 0/нет=по антивирусу; PromptOOMAddressInformationAccess"
          " 0=авто-отказ, 1=запрос, 2=авто-разрешение")


def main() -> None:
    prefer = sys.argv[1] if len(sys.argv) > 1 else None
    dump_security_policy()
    worker = ComWorker()
    worker.start()

    def fn(outlook, ns):
        print(f"Outlook {outlook.Version}")
        store = _resolve_store(ns, prefer)
        print(f"Хранилище: {store.DisplayName}")
        inbox = store.GetDefaultFolder(6)
        print(f"Inbox: писем всего {inbox.Items.Count}")

        items = inbox.Items
        check("Sort по ReceivedTime", lambda: items.Sort("[ReceivedTime]", True))
        from datetime import datetime, timedelta
        since = datetime.now() - timedelta(days=60)
        q = f"[ReceivedTime] >= '{_restrict_date(since)}'"
        restricted = None

        def do_restrict():
            nonlocal restricted
            restricted = items.Restrict(q)
            return restricted.Count
        check(f"Restrict ({q})", do_restrict)

        source = restricted if restricted is not None else items
        count = 0
        for item in source:
            count += 1
            print(f"\nПисьмо #{count}:")
            check("Class", lambda: item.Class)
            check("Subject", lambda: item.Subject)
            check("ReceivedTime", lambda: item.ReceivedTime)
            check("EntryID", lambda: item.EntryID[:20])
            check("ConversationID", lambda: item.ConversationID)
            check("SenderName", lambda: item.SenderName)
            check("SenderEmailAddress", lambda: item.SenderEmailAddress)
            check("SenderEmailType", lambda: item.SenderEmailType)
            check("Recipients.Count", lambda: item.Recipients.Count)
            check("Recipients[1].Address",
                  lambda: item.Recipients.Item(1).Address if item.Recipients.Count else "")
            check("Body[:60]", lambda: (item.Body or "")[:60])
            check("HTMLBody длина", lambda: len(item.HTMLBody or ""))
            check("Attachments.Count", lambda: item.Attachments.Count)
            check("PropertyAccessor Message-ID",
                  lambda: item.PropertyAccessor.GetProperty(PR_INTERNET_MESSAGE_ID))
            if count >= 3:
                break
        if count == 0:
            print("\nВ выборке не оказалось писем (Restrict вернул пусто?)")
        return None

    try:
        worker.submit(fn, timeout=300)
    finally:
        worker.stop()


if __name__ == "__main__":
    main()
