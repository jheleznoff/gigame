"""Инициализация БД: python scripts/init_db.py"""

from gigapost.config import settings, setup_logging
from gigapost.db.database import Database


def main() -> None:
    setup_logging()
    db = Database(settings.db_path)
    db.init_schema()
    print(f"База инициализирована: {settings.db_path}")


if __name__ == "__main__":
    main()
