"""Разовый прогон пайплайна: python scripts/run_ingest.py [--once] [--live]

По умолчанию dry-run (из settings.yaml); --live принудительно включает
боевой режим (реальные действия в Outlook).
"""

import argparse

from gigapost.config import load_taxonomy, settings, setup_logging
from gigapost.context import AppContext, set_context
from gigapost.db.database import Database
from gigapost.db.repositories import Repos
from gigapost.knowledge.graph_store import KnowledgeGraph
from gigapost.knowledge.vector_store import VectorStore
from gigapost.outlook.client import OutlookClient
from gigapost.outlook.com_worker import ComWorker
from gigapost.pipeline.graph import IngestRunner
from gigapost.pipeline.nodes import PipelineNodes


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--live", action="store_true",
                        help="боевой режим (игнорировать dry_run из настроек)")
    parser.add_argument("--no-vectors", action="store_true",
                        help="пропустить векторную индексацию (быстрее, без GigaChat Embeddings)")
    parser.add_argument("--days", type=int, default=None,
                        help="глубина первого прогона в днях (сдвинуть окно поиска назад)")
    args = parser.parse_args()

    setup_logging()
    dry_run = False if args.live else settings.dry_run

    db = Database(settings.db_path)
    db.init_schema()
    repos = Repos(db)

    worker = ComWorker()
    worker.start()
    try:
        outlook = OutlookClient(worker, dry_run=dry_run)
        taxonomy = load_taxonomy()
        if not dry_run:
            outlook.register_categories(
                {c.outlook.category: c.outlook.color for c in taxonomy.categories
                 if c.outlook.category})
        kg = KnowledgeGraph(repos, settings.graphml_path)
        kg.rebuild()
        vectors = None if args.no_vectors else VectorStore(settings.chroma_path)
        set_context(AppContext(repos=repos, outlook=outlook, kg=kg, vectors=vectors))

        nodes = PipelineNodes(repos, outlook, taxonomy, kg, vectors)
        runner = IngestRunner(repos, outlook, nodes)
        if args.days:
            from datetime import datetime, timedelta
            since = (datetime.now() - timedelta(days=args.days)).isoformat()
            for folder in settings.polling.folders:
                repos.settings.set(f"last_poll_ts:{folder}", since)
            print(f"Окно первого прогона: {args.days} дн. назад")
        mode = "DRY-RUN (только лог)" if dry_run else "БОЕВОЙ (реальные действия в Outlook)"
        print(f"Режим: {mode}")
        stats = runner.run_cycle()
        print(f"Готово: {stats}")
        kg.save_graphml()
    finally:
        worker.stop()


if __name__ == "__main__":
    main()
