"""Слияние сущностей-дублей графа знаний.

Запуск:
  .venv\\Scripts\\python scripts\\merge_entities.py --auto   # эвристика: вложенные имена
  .venv\\Scripts\\python scripts\\merge_entities.py --llm    # решение принимает GigaChat
  .venv\\Scripts\\python scripts\\merge_entities.py "Козлов" "Дмитрий Козлов"  # вручную
"""

import argparse
import difflib

from pydantic import BaseModel, Field

from gigapost.config import settings, setup_logging
from gigapost.db.database import Database
from gigapost.db.repositories import Repos


class MergeDecision(BaseModel):
    """Вердикт по паре кандидатов на слияние."""

    remove: str = Field(description="Имя сущности-дубля, которую удалить")
    keep: str = Field(description="Имя канонической сущности, в которую слить")
    merge: bool = Field(description="true — это один и тот же объект, false — разные")


class MergePlan(BaseModel):
    decisions: list[MergeDecision] = Field(default_factory=list)


def _candidates(repos: Repos) -> list[tuple[dict, dict]]:
    """Пары одного типа с похожими именами (подстрока-слово или difflib > 0.55)."""
    import re

    entities = repos.entities.all_entities()
    pairs = []
    for a in entities:
        for b in entities:
            if a["id"] >= b["id"] or a["type"] != b["type"]:
                continue
            na, nb = a["normalized_name"], b["normalized_name"]
            short, long_ = (na, nb) if len(na) < len(nb) else (nb, na)
            word_in = bool(re.search(rf"(^|\W){re.escape(short)}($|\W)", long_))
            ratio = difflib.SequenceMatcher(None, na, nb).ratio()
            if word_in or ratio > 0.55:
                pairs.append((a, b))
    return pairs


def llm_merge(repos: Repos) -> int:
    """GigaChat решает, какие кандидаты — действительно один объект."""
    from gigapost.llm.factory import get_llm
    from gigapost.llm.structured import structured_call

    pairs = _candidates(repos)
    if not pairs:
        print("Кандидатов на слияние нет")
        return 0
    lines = []
    for a, b in pairs:
        notes_a = len(repos.notes.for_entity(a["id"], limit=99))
        notes_b = len(repos.notes.for_entity(b["id"], limit=99))
        lines.append(f"- «{a['name']}» ({a['type']}, заметок: {notes_a}) ↔ "
                     f"«{b['name']}» ({b['type']}, заметок: {notes_b})")
    prompt = (
        "Ты чистишь граф знаний деловой переписки от дублей. Ниже пары похожих "
        "сущностей одного типа. Для каждой пары реши: это ОДИН И ТОТ ЖЕ объект "
        "(один человек, одна организация, один проект) или разные?\n"
        "Если один: merge=true, keep — каноническое имя (для людей — полное ФИО; "
        "для организаций и проектов — чистое короткое название без слов "
        "«проект», «бухгалтерия», ООО и кавычек), remove — второе имя.\n"
        "Если разные объекты (например, проект «Альфа» и продукт «Альфа-Склад») — "
        "merge=false.\n\nПары:\n" + "\n".join(lines))
    plan = structured_call(get_llm("extract"), MergePlan, prompt)
    merged = 0
    for d in plan.decisions:
        if not d.merge:
            print(f"  оставить раздельно: {d.remove!r} и {d.keep!r}")
            continue
        src = repos.entities.find_exact(d.remove)
        dst = repos.entities.find_exact(d.keep)
        if not src or not dst or src["id"] == dst["id"]:
            print(f"  пропуск (не найдено точно): {d.remove!r} → {d.keep!r}")
            continue
        print(f"  слито: {src['name']!r} → {dst['name']!r}")
        repos.entities.merge(src["id"], dst["id"])
        merged += 1
    return merged


def auto_merge(repos: Repos) -> int:
    """Осторожное слияние дублей ОДНОГО типа, где одно имя — слово внутри другого.

    Направление: для людей короткое сливается в полное («Козлов» → «Дмитрий Козлов»),
    для организаций/проектов/тем длинное — в короткое чистое имя
    («проект «Альфа» → «Альфа»). Разные типы не сливаются никогда.
    """
    import re

    entities = repos.entities.all_entities()
    merged = 0
    for a in entities:
        for b in entities:
            if a["id"] >= b["id"] or a["type"] != b["type"]:
                continue
            na, nb = a["normalized_name"], b["normalized_name"]
            if na == nb:
                continue
            short, long_ = (a, b) if len(na) < len(nb) else (b, a)
            # короткое имя должно входить в длинное целым словом
            if not re.search(rf"(^|\W){re.escape(short['normalized_name'])}($|\W)",
                             long_["normalized_name"]):
                continue
            if a["type"] == "person":
                src, dst = short, long_      # Козлов → Дмитрий Козлов
            else:
                src, dst = long_, short      # проект «Альфа → Альфа
            if repos.entities.get(src["id"]) and repos.entities.get(dst["id"]):
                print(f"  {src['name']!r} → {dst['name']!r}")
                repos.entities.merge(src["id"], dst["id"])
                merged += 1
    return merged


def main() -> None:
    setup_logging()
    parser = argparse.ArgumentParser()
    parser.add_argument("names", nargs="*", help="src dst — слить первую во вторую")
    parser.add_argument("--auto", action="store_true")
    parser.add_argument("--llm", action="store_true",
                        help="решение о слиянии принимает GigaChat")
    args = parser.parse_args()

    db = Database(settings.db_path)
    db.init_schema()
    repos = Repos(db)

    if args.llm:
        n = llm_merge(repos)
        print(f"Слито дублей: {n}")
    elif args.auto:
        n = auto_merge(repos)
        print(f"Слито дублей: {n}")
    elif len(args.names) == 2:
        src = repos.entities.find_exact(args.names[0])
        dst = repos.entities.find_exact(args.names[1])
        if not src or not dst:
            print("Сущность не найдена (нужно точное имя)")
            return
        repos.entities.merge(src["id"], dst["id"])
        print(f"{src['name']!r} слита в {dst['name']!r}")
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
