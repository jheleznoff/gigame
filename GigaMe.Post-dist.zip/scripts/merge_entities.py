"""Слияние сущностей-дублей графа знаний.

Запуск:
  .venv\\Scripts\\python scripts\\merge_entities.py --auto   # эвристика: вложенные имена
  .venv\\Scripts\\python scripts\\merge_entities.py --llm    # решение принимает GigaChat
  .venv\\Scripts\\python scripts\\merge_entities.py "Козлов" "Дмитрий Козлов"  # вручную
"""

import argparse
import difflib

from pydantic import BaseModel, Field

from gigapost.config import settings, setup_logging
from gigapost.db.database import Database
from gigapost.db.repositories import Repos


class MergeDecision(BaseModel):
    """Вердикт по паре кандидатов на слияние."""

    remove: str = Field(description="Имя сущности-дубля, которую удалить")
    keep: str = Field(description="Имя канонической сущности, в которую слить")
    merge: bool = Field(description="true — это один и тот же объект, false — разные")


class MergePlan(BaseModel):
    decisions: list[MergeDecision] = Field(default_factory=list)


# организация/проект/тема — взаимозаменяемые типы: «GigaMe» проект и
# «GigaME» тема в переписке почти всегда один объект
_NONPERSON = ("org", "project", "topic")

_RU2LAT = str.maketrans({
    "а": "a", "б": "b", "в": "v", "г": "g", "д": "d", "е": "e", "ж": "zh",
    "з": "z", "и": "i", "й": "i", "к": "k", "л": "l", "м": "m", "н": "n",
    "о": "o", "п": "p", "р": "r", "с": "s", "т": "t", "у": "u", "ф": "f",
    "х": "h", "ц": "ts", "ч": "ch", "ш": "sh", "щ": "sch", "ъ": "", "ы": "y",
    "ь": "", "э": "e", "ю": "yu", "я": "ya"})


def _translit(s: str) -> str:
    return s.translate(_RU2LAT)


def _pair_typeable(a: dict, b: dict) -> bool:
    if a["type"] == b["type"]:
        return True
    return a["type"] in _NONPERSON and b["type"] in _NONPERSON


def _similar(na: str, nb: str) -> bool:
    import re

    short, long_ = (na, nb) if len(na) < len(nb) else (nb, na)
    if re.search(rf"(^|\W){re.escape(short)}($|\W)", long_):
        return True
    if difflib.SequenceMatcher(None, na, nb).ratio() > 0.55:
        return True
    # «гигами» ↔ «GigaMe»: разные алфавиты сравниваем в транслите
    ta, tb = _translit(na), _translit(nb)
    return (ta, tb) != (na, nb) and difflib.SequenceMatcher(None, ta, tb).ratio() > 0.7


def _candidates(repos: Repos) -> list[tuple[dict, dict]]:
    """Пары с похожими именами: один тип, либо оба нечеловеческих
    (org/project/topic); кириллица↔латиница сравнивается в транслите."""
    entities = repos.entities.all_entities()
    pairs = []
    for a in entities:
        for b in entities:
            if a["id"] >= b["id"] or not _pair_typeable(a, b):
                continue
            if _similar(a["normalized_name"], b["normalized_name"]):
                pairs.append((a, b))
    return pairs


def llm_merge(repos: Repos) -> int:
    """GigaChat решает, какие кандидаты — действительно один объект."""
    from gigapost.llm.factory import get_llm
    from gigapost.llm.structured import structured_call

    pairs = _candidates(repos)
    if not pairs:
        print("Кандидатов на слияние нет")
        return 0
    lines = []
    for a, b in pairs:
        notes_a = len(repos.notes.for_entity(a["id"], limit=99))
        notes_b = len(repos.notes.for_entity(b["id"], limit=99))
        lines.append(f"- «{a['name']}» ({a['type']}, заметок: {notes_a}) ↔ "
                     f"«{b['name']}» ({b['type']}, заметок: {notes_b})")
    header = (
        "Ты чистишь граф знаний деловой переписки от дублей. Ниже пары похожих "
        "сущностей. Для каждой пары реши: это ОДИН И ТОТ ЖЕ объект "
        "(один человек, одна организация, один проект) или разные? Названия "
        "кириллицей и латиницей («гигами» и «GigaMe») — это один объект.\n"
        "Если один: merge=true, keep — каноническое имя (для людей — полное ФИО; "
        "для организаций и проектов — чистое короткое название без слов "
        "«проект», «бухгалтерия», ООО и кавычек), remove — второе имя.\n"
        "Если разные объекты (например, проект «Альфа» и продукт «Альфа-Склад») — "
        "merge=false.\n\nПары:\n")
    # порциями по 15 пар — корп-GigaChat режет запрос на ~4096 токенов
    decisions = []
    for i in range(0, len(lines), 15):
        batch = lines[i:i + 15]
        print(f"  порция {i // 15 + 1}: {len(batch)} пар…")
        try:
            plan = structured_call(get_llm("extract"), MergePlan,
                                   header + "\n".join(batch))
            decisions.extend(plan.decisions)
        except Exception as e:  # noqa: BLE001 — порция упала, остальные идут
            print(f"  порция пропущена ({e})")
    merged = 0
    for d in decisions:
        if not d.merge:
            print(f"  оставить раздельно: {d.remove!r} и {d.keep!r}")
            continue
        src = repos.entities.find_exact(d.remove)
        dst = repos.entities.find_exact(d.keep)
        if not src or not dst or src["id"] == dst["id"]:
            print(f"  пропуск (не найдено точно): {d.remove!r} → {d.keep!r}")
            continue
        print(f"  слито: {src['name']!r} → {dst['name']!r}")
        repos.entities.merge(src["id"], dst["id"])
        merged += 1
    return merged


def auto_merge(repos: Repos) -> int:
    """Осторожное слияние дублей ОДНОГО типа, где одно имя — слово внутри другого.

    Направление: для людей короткое сливается в полное («Козлов» → «Дмитрий Козлов»),
    для организаций/проектов/тем длинное — в короткое чистое имя
    («проект «Альфа» → «Альфа»). Разные типы не сливаются никогда.
    """
    import re

    entities = repos.entities.all_entities()
    merged = 0
    # одинаковые имена в разных нечеловеческих типах («GigaMe» проект и тема)
    # — детерминированно сливаем в сущность с бОльшим числом заметок
    for a in entities:
        for b in entities:
            if (a["id"] >= b["id"] or a["type"] == b["type"]
                    or a["type"] not in _NONPERSON or b["type"] not in _NONPERSON):
                continue
            if a["normalized_name"] != b["normalized_name"]:
                continue
            notes_a = len(repos.notes.for_entity(a["id"], limit=99))
            notes_b = len(repos.notes.for_entity(b["id"], limit=99))
            src, dst = (a, b) if notes_a <= notes_b else (b, a)
            if repos.entities.get(src["id"]) and repos.entities.get(dst["id"]):
                print(f"  {src['name']!r} ({src['type']}) → {dst['name']!r} ({dst['type']})")
                repos.entities.merge(src["id"], dst["id"])
                merged += 1
    entities = repos.entities.all_entities()
    for a in entities:
        for b in entities:
            if a["id"] >= b["id"] or a["type"] != b["type"]:
                continue
            na, nb = a["normalized_name"], b["normalized_name"]
            if na == nb:
                continue
            short, long_ = (a, b) if len(na) < len(nb) else (b, a)
            # короткое имя должно входить в длинное целым словом
            if not re.search(rf"(^|\W){re.escape(short['normalized_name'])}($|\W)",
                             long_["normalized_name"]):
                continue
            if a["type"] == "person":
                src, dst = short, long_      # Козлов → Дмитрий Козлов
            else:
                src, dst = long_, short      # проект «Альфа → Альфа
            if repos.entities.get(src["id"]) and repos.entities.get(dst["id"]):
                print(f"  {src['name']!r} → {dst['name']!r}")
                repos.entities.merge(src["id"], dst["id"])
                merged += 1
    return merged


def main() -> None:
    setup_logging()
    parser = argparse.ArgumentParser()
    parser.add_argument("names", nargs="*", help="src dst — слить первую во вторую")
    parser.add_argument("--auto", action="store_true")
    parser.add_argument("--llm", action="store_true",
                        help="решение о слиянии принимает GigaChat")
    args = parser.parse_args()

    db = Database(settings.db_path)
    db.init_schema()
    repos = Repos(db)

    if args.llm:
        n = llm_merge(repos)
        print(f"Слито дублей: {n}")
    elif args.auto:
        n = auto_merge(repos)
        print(f"Слито дублей: {n}")
    elif len(args.names) == 2:
        src = repos.entities.find_exact(args.names[0])
        dst = repos.entities.find_exact(args.names[1])
        if not src or not dst:
            print("Сущность не найдена (нужно точное имя)")
            return
        repos.entities.merge(src["id"], dst["id"])
        print(f"{src['name']!r} слита в {dst['name']!r}")
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
