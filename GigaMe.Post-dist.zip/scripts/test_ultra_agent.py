"""Проверка: тянет ли модель чата (например GigaChat-Ultra) свободную
оркестрацию инструментов — многошаговые цепочки, под которые для
GigaChat-2-Max строились обходы (intent router, кнопки, guard'ы).

Запуск (на корпе, с настроенной моделью в .env):
    python scripts\\test_ultra_agent.py

Сценарии идут НАПРЯМУЮ агенту (мимо роутера намерений). Мутирующие
инструменты требуют HITL — сценарии дожидаются interrupt и отвечают
reject, поэтому в Outlook/БД ничего не создаётся.

Критерии по сценарию: агент вызвал >=N ожидаемых инструментов, не
зациклился, дал внятный финальный ответ (или дошёл до подтверждения).
"""

import sys
import uuid
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from gigapost.config import settings, setup_logging
from gigapost.context import AppContext, set_context
from gigapost.db.database import Database
from gigapost.db.repositories import Repos
from gigapost.knowledge.graph_store import KnowledgeGraph
from gigapost.outlook.client import NullOutlookClient

SCENARIOS = [
    {
        "name": "поиск → детали",
        "prompt": "Найди письма про закупку и покажи детали самого свежего из них",
        "expect_tools": {"search_emails", "get_email_details"},
        "min_tools": 2,
    },
    {
        "name": "знания → задачи (две области)",
        "prompt": "Что мы знаем про GigaMe и есть ли открытые задачи по нему?",
        "expect_tools": {"search_knowledge", "list_tasks"},
        "min_tools": 2,
    },
    {
        "name": "поиск → создание задачи (HITL)",
        "prompt": ("Найди последнее письмо со словом «срок» и создай задачу "
                   "напомнить о нём завтра"),
        "expect_tools": {"search_emails", "create_task"},
        "min_tools": 2,
        "expect_confirm": True,
    },
]


def run_scenario(sc: dict) -> dict:
    from gigapost.agent.deep_agent import build_chat_agent, resume_chat

    agent = build_chat_agent()
    thread_id = f"ultra-test-{uuid.uuid4().hex[:8]}"
    config = {"configurable": {"thread_id": thread_id}}
    tools_called: list[str] = []
    confirmed = False
    answer = ""

    from langchain_core.messages import HumanMessage
    try:
        for chunk, meta in agent.stream(
                {"messages": [HumanMessage(content=sc["prompt"])]},
                config=config, stream_mode="messages"):
            if getattr(chunk, "tool_calls", None):
                tools_called += [tc["name"] for tc in chunk.tool_calls]
            elif getattr(chunk, "content", None) and chunk.type == "ai":
                answer += chunk.content
        state = agent.get_state(config)
        if state.interrupts or any(t.interrupts for t in state.tasks):
            confirmed = True
            # отклоняем, чтобы ничего не мутировать
            for _ in resume_chat("reject", thread_id,
                                 "тест, ничего не делай"):
                pass
    except Exception as e:  # noqa: BLE001
        return {"ok": False, "error": str(e), "tools": tools_called}

    hits = sc["expect_tools"] & set(tools_called)
    ok = (len(set(tools_called)) >= sc["min_tools"] and len(hits) >= 1
          and (confirmed if sc.get("expect_confirm") else bool(answer.strip())))
    return {"ok": ok, "tools": tools_called, "confirm": confirmed,
            "answer": answer[:200], "hits": sorted(hits)}


def main() -> None:
    setup_logging()
    db = Database(settings.db_path)
    db.init_schema()
    repos = Repos(db)
    kg = KnowledgeGraph(repos, settings.graphml_path)
    kg.rebuild()
    vectors = None
    try:
        from gigapost.knowledge.vector_store import VectorStore
        vectors = VectorStore(settings.chroma_path)
    except Exception as e:  # noqa: BLE001
        print(f"! векторы недоступны: {e}")
    set_context(AppContext(repos=repos, outlook=NullOutlookClient(), kg=kg,
                           vectors=vectors))

    print(f"Модель чата: {settings.resolve_model('chat')}\n")
    passed = 0
    for sc in SCENARIOS:
        print(f"=== {sc['name']}: {sc['prompt'][:60]}…")
        r = run_scenario(sc)
        status = "PASS" if r["ok"] else "FAIL"
        print(f"  {status}  инструменты: {r.get('tools')}"
              f"{'  (дошёл до подтверждения)' if r.get('confirm') else ''}")
        if r.get("error"):
            print(f"  ошибка: {r['error']}")
        elif r.get("answer"):
            print(f"  ответ: {r['answer'][:120]}")
        passed += r["ok"]
        print()
    print(f"Итого: {passed}/{len(SCENARIOS)}")
    if passed == len(SCENARIOS):
        print("Модель тянет свободные цепочки: можно ослаблять роутер "
              "(routers.is_action) и доверять агенту многошаговые сценарии.")
    else:
        print("Оставляем текущие обходы (роутер + кнопки) — модель "
              "оркеструет ненадёжно.")


if __name__ == "__main__":
    main()
