"""Диагностика EWS: подключение к Exchange и чтение 2 писем с телами.

Запуск:  python scripts\\diag_ews.py
Требует в .env: EWS_ENDPOINT, EWS_EMAIL, EWS_PASSWORD (+EWS_USERNAME, если
логин отличается от почты). Ничего не изменяет и не отправляет.
"""

import sys
from datetime import datetime, timedelta
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from gigapost.config import settings


def main() -> None:
    if not settings.has_ews:
        sys.exit("В .env не заполнены EWS_ENDPOINT / EWS_EMAIL / EWS_PASSWORD.\n"
                 "Пример:\n"
                 "  EWS_ENDPOINT=https://cab-vsp-mbx8114.sigma.sbrf.ru:444/EWS/Exchange.asmx\n"
                 "  EWS_EMAIL=Zheleznov.M.Yu@sberbank.ru\n"
                 "  EWS_USERNAME=SIGMA\\\\14539422   (если логин не равен почте)\n"
                 "  EWS_PASSWORD=...")

    print(f"Подключаюсь: {settings.ews_endpoint}")
    from gigapost.outlook.ews_client import EwsClient
    client = EwsClient()
    print(f"OK: {client.get_outlook_version()}")

    print("\nХранилища:", client.list_stores())
    folders = client.list_mail_folders()
    print(f"Почтовых папок: {len(folders)}; первые 10: {folders[:10]}")

    since = datetime.now() - timedelta(days=14)
    emails = client.fetch_new_emails("Inbox", since, max_items=2,
                                     save_attachments=False)
    print(f"\nПисем за 14 дней (беру 2): {len(emails)}")
    for em in emails:
        print(f"\n  Тема: {em.subject[:70]}")
        print(f"  От: {em.sender_name} <{em.sender_email}>")
        print(f"  Кому: {', '.join(em.recipients[:3])}")
        print(f"  Дата: {em.received_at}")
        print(f"  Тело[:120]: {em.body_text[:120]!r}")
        print(f"  Вложения: {em.attachment_names}")

    if emails and emails[0].body_text.strip():
        print("\nВСЁ РАБОТАЕТ: тела и адреса читаются через EWS.")
    else:
        print("\nПодключение есть, но тела пустые — пришлите вывод целиком.")


if __name__ == "__main__":
    main()
