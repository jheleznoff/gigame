"""Экспорт графа знаний в Obsidian-vault: .md файлы с [[wiki-ссылками]].

Запуск: .venv\\Scripts\\python scripts\\export_obsidian.py [папка]
По умолчанию — data/obsidian-vault. Открывается в Obsidian как vault:
заметки, страницы-хабы сущностей с backlinks через сами [[ссылки]].
"""

import argparse
import re
from pathlib import Path

from gigapost.config import settings, setup_logging
from gigapost.db.database import Database
from gigapost.db.repositories import Repos

KIND_RU = {"fact": "факт", "agreement": "договорённость", "decision": "решение",
           "event": "событие", "status": "статус"}


def safe_name(name: str) -> str:
    return re.sub(r'[<>:"/\\|?*]', "-", name).strip()[:80]


def main() -> None:
    setup_logging()
    parser = argparse.ArgumentParser()
    parser.add_argument("vault", nargs="?", default=str(settings.db_path.parent / "obsidian-vault"))
    args = parser.parse_args()
    vault = Path(args.vault)
    (vault / "Заметки").mkdir(parents=True, exist_ok=True)
    for sub in ("Люди", "Организации", "Проекты", "Темы"):
        (vault / sub).mkdir(exist_ok=True)

    db = Database(settings.db_path)
    db.init_schema()
    repos = Repos(db)

    # заметки: имя файла = заголовок, [[ссылки]] сохраняются как есть
    n_notes = 0
    for note in repos.notes.all_notes():
        fname = safe_name(note["title"]) or f"note-{note['id']}"
        front = (f"---\nkind: {note['kind']}\ncreated: {note.get('created_at') or ''}\n"
                 f"source: \"{note.get('source_message_id') or ''}\"\n---\n\n")
        (vault / "Заметки" / f"{fname}.md").write_text(
            front + f"# {note['title']}\n\n{note['body']}\n"
            f"\n> тип: {KIND_RU.get(note['kind'], note['kind'])}\n",
            encoding="utf-8")
        n_notes += 1

    # сущности-хабы: файл с именем сущности — Obsidian сам покажет backlinks
    folder_by_type = {"person": "Люди", "org": "Организации",
                      "project": "Проекты", "topic": "Темы"}
    n_ent = 0
    for e in repos.entities.all_entities():
        folder = folder_by_type.get(e["type"], "Темы")
        body = f"# {e['name']}\n\nтип: {e['type']}\n"
        if e.get("email"):
            body += f"email: {e['email']}\n"
        notes = repos.notes.for_entity(e["id"], limit=50)
        if notes:
            body += "\n## Заметки\n" + "\n".join(
                f"- [[{safe_name(n['title'])}]]" for n in notes) + "\n"
        (vault / folder / f"{safe_name(e['name'])}.md").write_text(body, encoding="utf-8")
        n_ent += 1

    print(f"Экспортировано: {n_notes} заметок, {n_ent} сущностей → {vault}")
    print("Откройте эту папку в Obsidian как vault (Open folder as vault).")


if __name__ == "__main__":
    main()
