"""Диагностика №2: повторяем действия проекта gigacheck один в один.

Запуск:  python scripts\\diag_outlook2.py
Plain Dispatch в текущем потоке (как у gigacheck), берём 2 последних письма
из Inbox ящика по умолчанию и пробуем по шагам: Subject → UnRead → SaveAs(.msg)
→ Body → SenderEmailAddress → сохранение вложения. Ничего не отправляет.

Если SaveAs работает — у нас есть обходной путь: парсить .msg-файлы,
не трогая охраняемые свойства COM.
"""

import sys
import tempfile
from pathlib import Path

import pythoncom
import win32com.client


def check(label, fn):
    try:
        value = fn()
        text = repr(value)
        if len(text) > 70:
            text = text[:70] + "..."
        print(f"  OK    {label}: {text}")
        return value
    except Exception as e:  # noqa: BLE001
        print(f"  FAIL  {label}: {e}")
        return None


def main() -> None:
    pythoncom.CoInitialize()
    tmp = Path(tempfile.mkdtemp(prefix="gigapost_diag_"))
    print(f"Временная папка: {tmp}")
    try:
        outlook = win32com.client.Dispatch("Outlook.Application")
        ns = outlook.GetNamespace("MAPI")
        inbox = ns.GetDefaultFolder(6)
        print(f"Outlook {outlook.Version}, Inbox: {inbox.Items.Count} писем")

        items = inbox.Items
        items.Sort("[ReceivedTime]", True)

        count = 0
        for message in items:
            if getattr(message, "Class", None) != 43:
                continue
            count += 1
            print(f"\nПисьмо #{count}:")
            check("Subject", lambda: message.Subject)
            check("UnRead", lambda: message.UnRead)

            msg_path = tmp / f"diag_{count}.msg"
            saved = check(f"SaveAs {msg_path.name} (olMSG)",
                          lambda: message.SaveAs(str(msg_path), 3))
            if msg_path.exists():
                print(f"        .msg сохранён, размер {msg_path.stat().st_size} байт")

            check("Body[:60]", lambda: (message.Body or "")[:60])
            check("SenderEmailAddress", lambda: message.SenderEmailAddress)
            check("Recipients.Count", lambda: message.Recipients.Count)

            att = check("Attachments.Count", lambda: message.Attachments.Count)
            if att:
                a_path = tmp / "att_test.bin"
                check("Attachment.SaveAsFile",
                      lambda: message.Attachments.Item(1).SaveAsFile(str(a_path)))
            if count >= 2:
                break

        if count == 0:
            print("Почтовых писем в Inbox не нашлось")
        print(f"\nЕсли SaveAs OK — скиньте один .msg из {tmp} для проверки парсинга.")
    finally:
        pythoncom.CoUninitialize()


if __name__ == "__main__":
    main()
