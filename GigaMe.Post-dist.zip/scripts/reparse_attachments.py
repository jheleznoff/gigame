"""Перепарсинг сохранённых вложений после расширения списка форматов.

Проходит по вложениям со статусом stored/unsupported, чьи расширения теперь
поддерживаются (rtf, xls, html, zip, ...), и извлекает текст.

Запуск:  python scripts\\reparse_attachments.py
         python scripts\\reparse_attachments.py --ocr --limit 30
                    # + распознать сканы через vision GigaChat (порциями!
                    # каждый скан = vision-вызов, тратит токены)
"""

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from gigapost.attachments.extractor import extract_text, is_supported
from gigapost.config import settings, setup_logging
from gigapost.db.database import Database
from gigapost.db.repositories import Repos


def main() -> None:
    setup_logging()
    parser = argparse.ArgumentParser()
    parser.add_argument("--ocr", action="store_true",
                        help="распознавать сканы через vision GigaChat")
    parser.add_argument("--limit", type=int, default=None,
                        help="не больше N файлов за прогон (для --ocr)")
    args = parser.parse_args()
    if args.ocr and not settings.ocr.enabled:
        raise SystemExit("OCR выключен: включите в config/settings.yaml → ocr.enabled: true")

    db = Database(settings.db_path)
    db.init_schema()
    repos = Repos(db)

    rows = [dict(r) for r in db.query(
        """SELECT * FROM attachments
           WHERE status IN ('stored', 'unsupported') AND path IS NOT NULL""")]
    todo = [r for r in rows if is_supported(r["filename"])]
    if args.limit:
        todo = todo[:args.limit]
    print(f"Кандидатов на перепарсинг: {len(todo)} (из {len(rows)} неразобранных)"
          + (" + OCR сканов" if args.ocr else ""))

    parsed = 0
    for r in todo:
        if not Path(r["path"]).exists():
            continue
        text = extract_text(r["path"], allow_ocr=args.ocr)
        if text:
            db.execute(
                "UPDATE attachments SET text=?, status='parsed' WHERE id=?",
                (text, r["id"]))
            parsed += 1
            if parsed % 25 == 0:
                print(f"  разобрано {parsed}…")
    print(f"Готово: текст извлечён из {parsed} вложений. Они попадут в реестр "
          f"фоном (или кнопкой «Разобрать ещё» на /registry).")


if __name__ == "__main__":
    main()
