"""Умный бэкфилл истории почты в базу знаний — без прожига LLM на всём архиве.

Три уровня:
  A) ingest — ВСЕ письма выбранных хранилищ → SQLite (метаданные + тексты),
     без LLM: полнотекстовый поиск по истории работает сразу;
  B) select — эвристический отбор ценных писем (без LLM): режем noreply и
     массовых отправителей, крошечные тела, письма «в большой копии»;
     поднимаем треды с вашими ответами и письма от VIP;
  C) knowledge — ОДИН дешёвый LLM-вызов на отобранное письмо (только заметки
     Zettelkasten + сущности из [[ссылок]]; без классификации и задач — старую
     почту не сортируем, дедлайны прошли) + эмбеддинги. Лимит на прогон,
     возобновляемо: прерванный бэкфилл продолжается с места остановки.

Примеры:
  python scripts/backfill.py --stores "zheleznov" "Архив" --months 12 --stage ingest
  python scripts/backfill.py --stage select --show 30
  python scripts/backfill.py --stage knowledge --max-llm 100
  python scripts/backfill.py --stores "zheleznov" --months 12   # все стадии подряд
"""

import argparse
import re
from datetime import datetime, timedelta

from gigapost.config import load_prompt, settings, setup_logging
from gigapost.db.database import Database
from gigapost.db.repositories import Repos
from gigapost.knowledge.graph_store import KnowledgeGraph
from gigapost.llm.schemas import NotesResult
from gigapost.llm.structured import structured_call
from gigapost.outlook.client import OutlookClient
from gigapost.outlook.com_worker import ComWorker
from gigapost.pipeline.nodes import clean_body

BULK_SENDER_THRESHOLD = 25     # отправитель с 25+ писем без ваших ответов = рассылка
MIN_BODY_CHARS = 150
MAX_RECIPIENTS = 15            # «в большой копии» — почти всегда информационное


# ---------- стадия A: залить письма без LLM ----------

def stage_ingest(repos: Repos, outlook: OutlookClient, stores: list[str],
                 months: int, with_attachments: bool) -> None:
    since_all = datetime.now() - timedelta(days=months * 30)
    for store in stores:
        folders = ["Inbox", "Sent"]
        try:
            extra = outlook.list_mail_folders(store)
            folders += [f for f in extra if f not in folders]
        except Exception as e:  # noqa: BLE001
            print(f"! папки {store}: {e}")
        print(f"\n[{store}] папок к обходу: {len(folders)}")
        for folder in folders:
            marker = f"backfill:{store}:{folder}"
            if repos.settings.get(marker) == "done":
                continue
            total = 0
            # окнами по 2 месяца — большие Restrict-выборки нестабильны
            window_start = since_all
            while window_start < datetime.now():
                window_end = window_start + timedelta(days=61)
                try:
                    emails = outlook.fetch_new_emails(
                        folder, window_start, max_items=2000, store=store,
                        until=window_end, save_attachments=with_attachments)
                except Exception as e:  # noqa: BLE001
                    print(f"  ! {folder} [{window_start:%Y-%m}]: {e}")
                    emails = []
                for em in emails:
                    if not repos.emails.exists(em.message_id):
                        em.folder = f"{store}:{folder}" if folder != "Sent" else "Sent"
                        repos.emails.upsert(em)
                        total += 1
                window_start = window_end
            repos.settings.set(marker, "done")
            if total:
                print(f"  {folder}: +{total}")
    row = repos.db.query_one("SELECT COUNT(*) c FROM emails")
    print(f"\nВсего писем в базе: {row['c']}")


# ---------- стадия B: отбор ценных без LLM ----------

_NOREPLY_RE = re.compile(r"no-?reply|donotreply|mailer|notification|рассылк|digest|"
                         r"newsletter|noreply", re.IGNORECASE)


def select_candidates(repos: Repos, limit: int = 100000) -> list[dict]:
    """Ценные письма для извлечения знаний, свежие первыми."""
    # отправители-массовики: много писем и ни одного вашего ответа в их тредах
    bulk = {r["sender_email"] for r in repos.db.query(
        f"""SELECT e.sender_email FROM emails e
            WHERE e.folder != 'Sent'
            GROUP BY e.sender_email
            HAVING COUNT(*) >= {BULK_SENDER_THRESHOLD}
               AND SUM(EXISTS(SELECT 1 FROM emails s WHERE s.folder='Sent'
                              AND s.conversation_id = e.conversation_id)) = 0""")}
    replied_convs = {r["conversation_id"] for r in repos.db.query(
        "SELECT DISTINCT conversation_id FROM emails WHERE folder='Sent'")}
    rows = repos.db.query(
        """SELECT e.* FROM emails e
           WHERE e.folder != 'Sent'
             AND NOT EXISTS (SELECT 1 FROM processing_log l
                             WHERE l.message_id = e.message_id
                               AND l.stage='backfill' AND l.status='ok')
           ORDER BY e.received_at DESC LIMIT ?""", (limit,))
    result = []
    for r in rows:
        e = dict(r)
        sender = e.get("sender_email") or ""
        body = e.get("body_text") or ""
        try:
            import json as _j
            n_rcpt = len(_j.loads(e.get("recipients_json") or "[]"))
        except Exception:  # noqa: BLE001
            n_rcpt = 1
        score = 0
        if _NOREPLY_RE.search(sender) or sender in bulk:
            continue
        if len(clean_body(body, 5000)) < MIN_BODY_CHARS:
            continue
        if n_rcpt > MAX_RECIPIENTS:
            score -= 2
        if e.get("conversation_id") in replied_convs:
            score += 3     # вы отвечали в треде — точно ценное
        if settings.is_vip(e.get("sender_name"), sender):
            score += 2
        if e.get("has_attachments"):
            score += 1
        if score >= 0:
            e["_score"] = score
            result.append(e)
    # высокий скор первым; внутри одного скора — свежие первыми (stable sort)
    result.sort(key=lambda x: x.get("received_at") or "", reverse=True)
    result.sort(key=lambda x: x["_score"], reverse=True)
    return result


# ---------- стадия C: знания по бюджету ----------

def stage_knowledge(repos: Repos, kg: KnowledgeGraph, vectors, max_llm: int) -> None:
    from gigachat.exceptions import RateLimitError

    from gigapost.llm.factory import get_llm

    candidates = select_candidates(repos)
    print(f"Кандидатов после отбора: {len(candidates)}; обрабатываю до {max_llm}")
    llm = get_llm("extract")
    done = 0
    for e in candidates:
        if done >= max_llm:
            break
        body = clean_body(e.get("body_text") or "")
        prompt = load_prompt("notes").format(
            owner=settings.owner.full,
            sender_name=e.get("sender_name"), sender_email=e.get("sender_email"),
            subject=e.get("subject"), received_at=e.get("received_at"), body=body)
        try:
            notes = structured_call(llm, NotesResult, prompt).notes
        except RateLimitError:
            print("! лимиты API — остановился, продолжите позже (возобновляемо)")
            break
        except Exception as ex:  # noqa: BLE001
            repos.log.log(e["message_id"], "backfill", "error", str(ex))
            continue
        for note in notes:
            kg.add_note(title=note.title, body=note.body, kind=note.kind,
                        source_message_id=e["message_id"],
                        conversation_id=e.get("conversation_id"))
        if vectors is not None:
            try:
                vectors.index_email(e)
                repos.emails.mark_indexed(e["message_id"])
                for note_row in repos.notes.for_email(e["message_id"]):
                    vectors.index_note(note_row["id"], note_row["title"], note_row["body"])
            except Exception:  # noqa: BLE001
                pass
        repos.log.log(e["message_id"], "backfill", "ok", f"заметок={len(notes)}")
        done += 1
        if done % 10 == 0:
            print(f"  {done}/{max_llm}… (заметок в графе: {repos.notes.count()})")
    kg.save_graphml()
    print(f"Обработано: {done}; заметок в графе: {repos.notes.count()}; "
          f"осталось кандидатов: {max(0, len(candidates) - done)}")


def main() -> None:
    setup_logging()
    parser = argparse.ArgumentParser()
    parser.add_argument("--stores", nargs="*", default=None,
                        help="подстроки имён хранилищ (по умолчанию основной ящик)")
    parser.add_argument("--months", type=int, default=12)
    parser.add_argument("--stage", choices=["ingest", "select", "knowledge", "all"],
                        default="all")
    parser.add_argument("--max-llm", type=int, default=100,
                        help="сколько писем обработать LLM за прогон")
    parser.add_argument("--show", type=int, default=20, help="для --stage select")
    parser.add_argument("--with-attachments", action="store_true",
                        help="сохранять вложения при заливке (диск!)")
    args = parser.parse_args()

    db = Database(settings.db_path)
    db.init_schema()
    repos = Repos(db)
    kg = KnowledgeGraph(repos, settings.graphml_path)
    kg.rebuild()
    vectors = None
    try:
        from gigapost.knowledge.vector_store import VectorStore
        vectors = VectorStore(settings.chroma_path)
    except Exception as e:  # noqa: BLE001
        print(f"! векторы недоступны: {e}")

    if args.stage in ("ingest", "all"):
        worker = ComWorker()
        worker.start()
        try:
            outlook = OutlookClient(worker, dry_run=True)  # бэкфилл только читает
            stores = args.stores
            if not stores:
                stores = [s["name"] for s in outlook.list_stores()
                          if not s["excluded"] and "@" in s["name"]][:1]
            print("Хранилища:", stores)
            excluded = [s["name"] for s in outlook.list_stores() if s["excluded"]]
            if excluded:
                print("Исключены навсегда:", excluded)
            stage_ingest(repos, outlook, stores, args.months, args.with_attachments)
        finally:
            worker.stop()

    if args.stage == "select":
        cands = select_candidates(repos)
        print(f"Кандидатов: {len(cands)}. Топ-{args.show}:")
        for e in cands[:args.show]:
            print(f"  [{e['_score']}] {e.get('received_at', '')[:10]} "
                  f"{(e.get('sender_name') or '')[:25]}: {(e.get('subject') or '')[:55]}")

    if args.stage in ("knowledge", "all"):
        stage_knowledge(repos, kg, vectors, args.max_llm)


if __name__ == "__main__":
    main()
