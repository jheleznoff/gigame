"""Умный бэкфилл истории почты в базу знаний — без прожига LLM на всём архиве.

Три уровня:
  A) ingest — ВСЕ письма выбранных хранилищ → SQLite (метаданные + тексты),
     без LLM: полнотекстовый поиск по истории работает сразу;
  B) select — эвристический отбор ценных писем (без LLM): режем noreply и
     массовых отправителей, крошечные тела, письма «в большой копии»;
     поднимаем треды с вашими ответами и письма от VIP;
  C) knowledge — ОДИН дешёвый LLM-вызов на отобранное письмо (только заметки
     Zettelkasten + сущности из [[ссылок]]; без классификации и задач — старую
     почту не сортируем, дедлайны прошли) + эмбеддинги. Лимит на прогон,
     возобновляемо: прерванный бэкфилл продолжается с места остановки.

Примеры:
  python scripts/backfill.py --stores "zheleznov" "Архив" --months 12 --stage ingest
  python scripts/backfill.py --stage select --show 30
  python scripts/backfill.py --stage knowledge --max-llm 100
  python scripts/backfill.py --stores "zheleznov" --months 12   # все стадии подряд
"""

import argparse
import re
from datetime import datetime, timedelta

from gigapost.config import load_prompt, settings, setup_logging
from gigapost.db.database import Database
from gigapost.db.repositories import Repos
from gigapost.knowledge.graph_store import KnowledgeGraph
from gigapost.llm.schemas import NotesResult
from gigapost.llm.structured import structured_call
from gigapost.outlook.client import OutlookClient
from gigapost.outlook.com_worker import ComWorker
from gigapost.pipeline.nodes import clean_body

BULK_SENDER_THRESHOLD = 25     # отправитель с 25+ писем без ваших ответов = рассылка
MIN_BODY_CHARS = 150
MAX_RECIPIENTS = 15            # «в большой копии» — почти всегда информационное


# ---------- стадия A: залить письма без LLM ----------

def _ingest_attachments(repos: Repos, em) -> None:
    """Разобрать сохранённые вложения письма в БД (текст + хеш) — как в пайплайне."""
    import hashlib
    from pathlib import Path

    from gigapost.attachments.extractor import extract_text, is_supported

    saved = {Path(p).name: p for p in em.attachment_paths}
    for fname in em.attachment_names:
        path = saved.get(fname)
        ext = Path(fname).suffix.lower()
        if path is None or not Path(path).exists():
            repos.attachments.upsert(
                em.message_id, fname, ext, None, None, None, "unsupported")
            continue
        try:
            data = Path(path).read_bytes()
            sha = hashlib.sha256(data).hexdigest()
            text = extract_text(path) if is_supported(fname) else None
            status = "parsed" if text else "stored"
            repos.attachments.upsert(
                em.message_id, fname, ext, len(data), path, text, status, sha)
        except Exception:  # noqa: BLE001 — одно битое вложение не мешает заливке
            continue


def stage_ingest(repos: Repos, outlook: OutlookClient, stores: list[str],
                 months: int, with_attachments: bool) -> None:
    since_all = datetime.now() - timedelta(days=months * 30)
    for store in stores:
        folders = ["Inbox", "Sent"]
        try:
            extra = outlook.list_mail_folders(store)
            folders += [f for f in extra if f not in folders]
        except Exception as e:  # noqa: BLE001
            print(f"! папки {store}: {e}")
        print(f"\n[{store}] папок к обходу: {len(folders)}")
        for folder in folders:
            marker = f"backfill:{store}:{folder}"
            if repos.settings.get(marker) == "done":
                continue
            total = 0
            errors = 0
            # окнами по 2 месяца — большие Restrict-выборки нестабильны
            window_start = since_all
            while window_start < datetime.now():
                window_end = window_start + timedelta(days=61)
                try:
                    emails = outlook.fetch_new_emails(
                        folder, window_start, max_items=2000, store=store,
                        until=window_end, save_attachments=with_attachments)
                except Exception as e:  # noqa: BLE001
                    print(f"  ! {folder} [{window_start:%Y-%m}]: {e}")
                    errors += 1
                    emails = []
                for em in emails:
                    if not repos.emails.exists(em.message_id):
                        em.folder = f"{store}:{folder}" if folder != "Sent" else "Sent"
                        repos.emails.upsert(em)
                        if em.attachment_names:
                            _ingest_attachments(repos, em)
                        total += 1
                window_start = window_end
            # папка «готова» только если все окна прочитались — иначе
            # повторный запуск попробует её ещё раз
            if errors == 0:
                repos.settings.set(marker, "done")
            if total or errors:
                print(f"  {folder}: +{total}" + (f" (ошибок окон: {errors})" if errors else ""))
    row = repos.db.query_one("SELECT COUNT(*) c FROM emails")
    print(f"\nВсего писем в базе: {row['c']}")


# ---------- стадия B: отбор ценных без LLM ----------

_NOREPLY_RE = re.compile(r"no-?reply|donotreply|mailer|notification|рассылк|digest|"
                         r"newsletter|noreply", re.IGNORECASE)
# приглашения на встречи: организационная механика, знаний в них нет
from gigapost.meetings import is_meeting_email  # noqa: E402


def select_candidates(repos: Repos, limit: int = 100000) -> list[dict]:
    """Ценные письма для извлечения знаний, свежие первыми.

    Корп-режим: политика Outlook может блокировать тело и отправителя —
    тогда опираемся на тему и разобранные вложения."""
    # отправители-массовики: много писем и ни одного вашего ответа в их тредах
    # (пустой sender_email не считаем массовиком — это заблокированное поле)
    bulk = {r["sender_email"] for r in repos.db.query(
        f"""SELECT e.sender_email FROM emails e
            WHERE e.folder != 'Sent' AND e.sender_email != ''
            GROUP BY e.sender_email
            HAVING COUNT(*) >= {BULK_SENDER_THRESHOLD}
               AND SUM(EXISTS(SELECT 1 FROM emails s WHERE s.folder='Sent'
                              AND s.conversation_id = e.conversation_id)) = 0""")}
    replied_convs = {r["conversation_id"] for r in repos.db.query(
        "SELECT DISTINCT conversation_id FROM emails WHERE folder='Sent'")}
    # письма, у которых есть разобранный текст вложений
    parsed_att = {r["message_id"] for r in repos.db.query(
        "SELECT DISTINCT message_id FROM attachments WHERE status='parsed'")}
    rows = repos.db.query(
        """SELECT e.* FROM emails e
           WHERE e.folder != 'Sent'
             AND NOT EXISTS (SELECT 1 FROM processing_log l
                             WHERE l.message_id = e.message_id
                               AND l.stage='backfill' AND l.status='ok')
           ORDER BY e.received_at DESC LIMIT ?""", (limit,))
    result = []
    for r in rows:
        e = dict(r)
        sender = e.get("sender_email") or ""
        body = e.get("body_text") or ""
        try:
            import json as _j
            n_rcpt = len(_j.loads(e.get("recipients_json") or "[]"))
        except Exception:  # noqa: BLE001
            n_rcpt = 1
        score = 0
        if _NOREPLY_RE.search(sender) or sender in bulk:
            continue
        if is_meeting_email(e.get("subject"), body):
            continue     # приглашения/ответы на встречи — не знания
        has_parsed_att = e["message_id"] in parsed_att
        if len(clean_body(body, 5000)) < MIN_BODY_CHARS and not has_parsed_att:
            continue     # ни текста, ни разобранных вложений — извлекать нечего
        if n_rcpt > MAX_RECIPIENTS:
            score -= 2
        if e.get("conversation_id") in replied_convs:
            score += 3     # вы отвечали в треде — точно ценное
        if settings.is_vip(e.get("sender_name"), sender):
            score += 2
        if has_parsed_att:
            score += 1
        if score >= 0:
            e["_score"] = score
            result.append(e)
    # высокий скор первым; внутри одного скора — свежие первыми (stable sort)
    result.sort(key=lambda x: x.get("received_at") or "", reverse=True)
    result.sort(key=lambda x: x["_score"], reverse=True)
    return result


# ---------- стадия C: знания по бюджету ----------

def stage_knowledge(repos: Repos, kg: KnowledgeGraph, vectors, max_llm: int) -> None:
    from gigachat.exceptions import RateLimitError

    from gigapost.llm.factory import get_llm

    candidates = select_candidates(repos)
    print(f"Кандидатов после отбора: {len(candidates)}; обрабатываю до {max_llm}")
    llm = get_llm("extract")
    done = 0
    for e in candidates:
        if done >= max_llm:
            break
        body = clean_body(e.get("body_text") or "")
        # корп-режим: тело может быть заблокировано политикой Outlook —
        # добавляем текст разобранных вложений (в пределах лимита корп-API)
        att_parts, att_used = [], 0
        for a in repos.attachments.parsed_for_email(e["message_id"]):
            if att_used >= 6000:
                break
            chunk = (a["text"] or "")[: 6000 - att_used]
            att_used += len(chunk)
            att_parts.append(f"=== Вложение: {a['filename']} ===\n{chunk}")
        if att_parts:
            body = (body + "\n\n" + "\n\n".join(att_parts)).strip()
        prompt = load_prompt("notes").format(
            owner=settings.owner.full,
            sender_name=e.get("sender_name"), sender_email=e.get("sender_email"),
            subject=e.get("subject"), received_at=e.get("received_at"), body=body)
        try:
            notes = structured_call(llm, NotesResult, prompt).notes
        except RateLimitError:
            print("! лимиты API — остановился, продолжите позже (возобновляемо)")
            break
        except Exception as ex:  # noqa: BLE001
            repos.log.log(e["message_id"], "backfill", "error", str(ex))
            continue
        for note in notes:
            kg.add_note(title=note.title, body=note.body, kind=note.kind,
                        source_message_id=e["message_id"],
                        conversation_id=e.get("conversation_id"))
        if vectors is not None:
            try:
                vectors.index_email(e)
                repos.emails.mark_indexed(e["message_id"])
                for note_row in repos.notes.for_email(e["message_id"]):
                    vectors.index_note(note_row["id"], note_row["title"], note_row["body"])
            except Exception:  # noqa: BLE001
                pass
        repos.log.log(e["message_id"], "backfill", "ok", f"заметок={len(notes)}")
        done += 1
        if done % 10 == 0:
            print(f"  {done}/{max_llm}… (заметок в графе: {repos.notes.count()})")
    kg.save_graphml()
    print(f"Обработано: {done}; заметок в графе: {repos.notes.count()}; "
          f"осталось кандидатов: {max(0, len(candidates) - done)}")


def main() -> None:
    setup_logging()
    parser = argparse.ArgumentParser()
    parser.add_argument("--stores", nargs="*", default=None,
                        help="подстроки имён хранилищ (по умолчанию основной ящик)")
    parser.add_argument("--months", type=int, default=12)
    parser.add_argument("--stage", choices=["ingest", "select", "knowledge", "all"],
                        default="all")
    parser.add_argument("--max-llm", type=int, default=100,
                        help="сколько писем обработать LLM за прогон")
    parser.add_argument("--show", type=int, default=20, help="для --stage select")
    parser.add_argument("--with-attachments", action="store_true",
                        help="сохранять вложения при заливке (диск!)")
    parser.add_argument("--source", choices=["auto", "com", "ews"], default="auto",
                        help="auto: EWS если настроен в .env, иначе COM")
    args = parser.parse_args()

    db = Database(settings.db_path)
    db.init_schema()
    repos = Repos(db)
    kg = KnowledgeGraph(repos, settings.graphml_path)
    kg.rebuild()
    vectors = None
    try:
        from gigapost.knowledge.vector_store import VectorStore
        vectors = VectorStore(settings.chroma_path)
    except Exception as e:  # noqa: BLE001
        print(f"! векторы недоступны: {e}")

    if args.stage in ("ingest", "all"):
        if args.source == "ews" and not settings.has_ews:
            raise SystemExit("--source ews: заполните EWS_ENDPOINT/EWS_EMAIL/"
                             "EWS_PASSWORD в .env")
        use_ews = settings.has_ews and args.source in ("auto", "ews")
        worker = None
        if use_ews:
            from gigapost.outlook.ews_client import EwsClient
            outlook = EwsClient()
            print(f"Источник: EWS ({outlook.get_outlook_version()})")
        else:
            worker = ComWorker()
            worker.start()
            outlook = OutlookClient(worker, dry_run=True)  # бэкфилл только читает
            print("Источник: Outlook COM")
        try:
            all_stores = outlook.list_stores()
            stores = args.stores
            if not stores:
                stores = [s["name"] for s in all_stores if not s["excluded"]
                          and ("@" in s["name"] or "архив" in s["name"].lower())]
                if not use_ews:
                    stores = stores[:1]
            print("Хранилища:", stores)
            excluded = [s["name"] for s in all_stores if s["excluded"]]
            if excluded:
                print("Исключены навсегда:", excluded)
            stage_ingest(repos, outlook, stores, args.months, args.with_attachments)
        finally:
            if worker is not None:
                worker.stop()

    if args.stage == "select":
        cands = select_candidates(repos)
        print(f"Кандидатов: {len(cands)}. Топ-{args.show}:")
        for e in cands[:args.show]:
            print(f"  [{e['_score']}] {e.get('received_at', '')[:10]} "
                  f"{(e.get('sender_name') or '')[:25]}: {(e.get('subject') or '')[:55]}")

    if args.stage in ("knowledge", "all"):
        stage_knowledge(repos, kg, vectors, args.max_llm)


if __name__ == "__main__":
    main()
