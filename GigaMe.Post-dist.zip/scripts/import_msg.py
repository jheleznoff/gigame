"""Импорт писем из .msg-файлов, выгруженных VBA-макросом Outlook.

Запуск:  python scripts\\import_msg.py            # из %USERPROFILE%\\GigaMePost_Export
         python scripts\\import_msg.py --dir D:\\export --limit 500

Письма попадают в базу (тело, адреса, вложения с разбором текста);
обработанные файлы переезжают в подпапку imported/. Дальше знания:
python scripts\\backfill.py --stage knowledge --max-llm 100
"""

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from gigapost.config import settings, setup_logging
from gigapost.db.database import Database
from gigapost.db.repositories import Repos
from gigapost.outlook.msg_import import DEFAULT_EXPORT_DIR, import_dir


def main() -> None:
    setup_logging()
    parser = argparse.ArgumentParser()
    parser.add_argument("--dir", default=None,
                        help=f"папка с .msg (по умолчанию {DEFAULT_EXPORT_DIR})")
    parser.add_argument("--limit", type=int, default=None,
                        help="обработать не больше N файлов за прогон")
    args = parser.parse_args()

    db = Database(settings.db_path)
    db.init_schema()
    repos = Repos(db)

    base = Path(args.dir) if args.dir else DEFAULT_EXPORT_DIR
    if not base.exists():
        raise SystemExit(
            f"Папка {base} не найдена. Сначала выгрузите письма макросом "
            "ExportCurrentFolder (см. vba/GigaMePost_Export.bas).")

    stats = import_dir(repos, base, limit=args.limit)
    row = repos.db.query_one("SELECT COUNT(*) c FROM emails")
    print(f"Импортировано: {stats['imported']}, пропущено (дубли): "
          f"{stats['skipped']}, ошибок: {stats['errors']}. "
          f"Всего писем в базе: {row['c']}")
    if stats["imported"]:
        print("Дальше знания: python scripts\\backfill.py --stage knowledge --max-llm 100")


if __name__ == "__main__":
    main()
