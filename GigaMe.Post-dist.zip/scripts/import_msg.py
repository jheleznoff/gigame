"""Импорт писем из .msg-файлов, выгруженных VBA-макросом Outlook.

Запуск:  python scripts\\import_msg.py            # из %USERPROFILE%\\GigaMePost_Export
         python scripts\\import_msg.py --dir D:\\export --limit 500

Письма попадают в базу (тело, адреса, вложения с разбором текста);
обработанные файлы переезжают в подпапку imported/. Дальше знания:
python scripts\\backfill.py --stage knowledge --max-llm 100
"""

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from gigapost.config import settings, setup_logging
from gigapost.db.database import Database
from gigapost.db.repositories import Repos
from gigapost.outlook.msg_import import DEFAULT_EXPORT_DIR, import_dir


def main() -> None:
    setup_logging()
    parser = argparse.ArgumentParser()
    parser.add_argument("--dir", default=None,
                        help=f"папка с .msg (по умолчанию {DEFAULT_EXPORT_DIR})")
    parser.add_argument("--limit", type=int, default=None,
                        help="обработать не больше N файлов за прогон")
    parser.add_argument("--reimport", action="store_true",
                        help="пройти и по imported/, обновив содержимое "
                             "существующих записей (после фиксов парсера)")
    parser.add_argument("--process-recent", type=int, default=0, metavar="ДНЕЙ",
                        help="письма свежее N дней прогнать через полный "
                             "пайплайн (категории, задачи-черновики); "
                             "старше — тихой заливкой. Жжёт LLM: ~2-3 вызова "
                             "на письмо. Рекомендуется 30")
    args = parser.parse_args()

    db = Database(settings.db_path)
    db.init_schema()
    repos = Repos(db)

    base = Path(args.dir) if args.dir else DEFAULT_EXPORT_DIR
    if not base.exists():
        raise SystemExit(
            f"Папка {base} не найдена. Сначала выгрузите письма макросом "
            "ExportCurrentFolder (см. vba/GigaMePost_Export.bas).")

    graph = None
    graph_since = None
    if args.process_recent > 0:
        err = settings.gigachat_config_error()
        if err:
            raise SystemExit(f"Конфигурация GigaChat сломана: {err}\n"
                             f"Исправьте .env и запустите снова — уже залитые "
                             f"письма дообработаются автоматически.")
        from datetime import datetime, timedelta

        from gigapost.config import load_taxonomy
        from gigapost.knowledge.graph_store import KnowledgeGraph
        from gigapost.outlook.client import NullOutlookClient
        from gigapost.pipeline.graph import build_ingest_graph
        from gigapost.pipeline.nodes import PipelineNodes

        kg = KnowledgeGraph(repos, settings.graphml_path)
        kg.rebuild()
        vectors = None
        try:
            from gigapost.knowledge.vector_store import VectorStore
            vectors = VectorStore(settings.chroma_path)
        except Exception as e:  # noqa: BLE001
            print(f"! векторы недоступны: {e}")
        nodes = PipelineNodes(repos, NullOutlookClient(), load_taxonomy(),
                              kg, vectors)
        graph = build_ingest_graph(nodes)
        graph_since = (datetime.now()
                       - timedelta(days=args.process_recent)).isoformat()
        print(f"Письма свежее {graph_since[:10]} пойдут через полный пайплайн "
              f"(задачи — черновиками на подтверждение)")

    stats = import_dir(repos, base, limit=args.limit, reimport=args.reimport,
                       graph=graph, graph_since=graph_since)
    if graph is not None:
        from gigapost.outlook.msg_import import process_pending
        pending = process_pending(repos, graph, graph_since)
        if pending:
            print(f"Дообработано пайплайном ранее залитых писем: {pending}")
    row = repos.db.query_one("SELECT COUNT(*) c FROM emails")
    print(f"Импортировано: {stats['imported']}, обновлено: {stats['updated']}, "
          f"пропущено (дубли): {stats['skipped']}, ошибок: {stats['errors']}. "
          f"Всего писем в базе: {row['c']}")
    if stats["imported"]:
        print("Дальше знания: python scripts\\backfill.py --stage knowledge --max-llm 100")


if __name__ == "__main__":
    main()
