"""Эмуляция: 100+ заявок на доступ к GigaMe в неструктурированном виде.

Проверяет полноту ответов-перечислений на реалистичном корпусе:
  A. чистые заявки в теле письма («прошу предоставить… ФИО, логин»)
  B. неполные заявки: ФИО без логина → моё уточнение → логин отдельным письмом
  C. списки в Word-вложении (настоящий .docx через боевой экстрактор)
  D. списки в Excel-вложении (настоящий .xlsx)
  + шумовые письма про GigaMe без заявок

Запуск:
  python scripts\\emulate_access.py            # засеять (и напечатать эталон)
  python scripts\\emulate_access.py --cleanup  # убрать всё синтетическое
Эталон пишется в data/emulation_access_truth.json.
"""

from __future__ import annotations

import argparse
import json
import random
from pathlib import Path

from gigapost.config import DATA_DIR, settings, setup_logging
from gigapost.db.database import Database
from gigapost.db.repositories import Repos
from gigapost.outlook.models import EmailMessage

PREFIX = "emu-access"
ATT_DIR = DATA_DIR / "attachments" / "emulation"
TRUTH_PATH = DATA_DIR / "emulation_access_truth.json"

_LAST = ["Волков", "Козлов", "Новиков", "Морозов", "Петухов", "Соколов", "Лебедев",
         "Комаров", "Орлов", "Киселёв", "Макаров", "Андреев", "Ершов", "Никитин",
         "Захаров", "Зайцев", "Соловьёв", "Борисов", "Яковлев", "Григорьев",
         "Романов", "Воробьёв", "Сергеев", "Кузьмин", "Фролов", "Александров",
         "Дмитриев"]
_FIRST = ["Иван", "Пётр", "Сергей", "Алексей", "Дмитрий", "Николай", "Андрей",
          "Михаил", "Владимир", "Егор"]
_MID = ["Иванович", "Петрович", "Сергеевич", "Алексеевич", "Дмитриевич",
        "Николаевич", "Андреевич"]

_SENDERS = [("Кравцова Ольга", "o.kravtsova@sberbank.ru"),
            ("Тарасов Виктор", "v.tarasov@sberbank.ru"),
            ("Мельникова Дарья", "d.melnikova@sberbank.ru"),
            ("Богданов Илья", "i.bogdanov@sberbank.ru")]

_TEMPLATES_A = [
    "Добрый день!\n\nПрошу предоставить доступ к платформе GigaMe для сотрудников:\n{people_numbered}\n\nС уважением",
    "Максим, привет.\n\nПросьба завести учётные записи в GigaMe:\n{people_dash}\nСрок — до конца недели.",
    "Коллеги, добрый день. Нужен доступ к ГигаМи для команды закупок:\n{people_comma}. Заранее спасибо.",
    "Прошу открыть доступ в GigaMe (роль «наблюдатель») следующим коллегам:\n{people_numbered}",
]


def _people(n: int, rnd: random.Random, used: set) -> list[dict]:
    out = []
    while len(out) < n:
        fio = (f"{rnd.choice(_LAST)} {rnd.choice(_FIRST)} {rnd.choice(_MID)}")
        if fio in used:
            continue
        used.add(fio)
        login = str(rnd.randint(14000000, 14999999))
        out.append({"fio": fio, "login": login})
    return out


def _mail(repos, i, subject, body, sender, conv=None, folder="Inbox",
          day=1, attach=None):
    name, addr = sender
    mid = f"<{PREFIX}-{i}@emu.local>"
    repos.emails.upsert(EmailMessage(
        message_id=mid, entry_id="", conversation_id=conv or f"{PREFIX}-conv-{i}",
        subject=subject, sender_name=name, sender_email=addr,
        recipients=["zheleznov.m.yu@sberbank.ru"],
        received_at=f"2026-07-{day:02d}T{9 + i % 9}:15:00", body_text=body,
        folder=folder, has_attachments=bool(attach),
        attachment_names=[attach] if attach else []))
    return mid


def seed() -> None:
    from gigapost.attachments.extractor import extract_text

    db = Database(settings.db_path)
    db.init_schema()
    repos = Repos(db)
    rnd = random.Random(42)
    used: set = set()
    truth: list[dict] = []
    i = 0

    # A. 25 чистых заявок по 3 человека — разные формулировки
    for k in range(25):
        people = _people(3, rnd, used)
        truth += people
        tpl = _TEMPLATES_A[k % len(_TEMPLATES_A)]
        body = tpl.format(
            people_numbered="\n".join(
                f"{j + 1}. {p['fio']}, логин {p['login']}" for j, p in enumerate(people)),
            people_dash="\n".join(f"- {p['fio']} ({p['login']})" for p in people),
            people_comma=", ".join(f"{p['fio']} — {p['login']}" for p in people))
        i += 1
        _mail(repos, i, f"Доступ к GigaMe — заявка №{k + 1}", body,
              _SENDERS[k % len(_SENDERS)], day=1 + k % 20)

    # B. 12 тредов: ФИО без логина → уточнение → логин отдельным письмом
    for k in range(12):
        p = _people(1, rnd, used)[0]
        truth.append(p)
        conv = f"{PREFIX}-thread-{k}"
        i += 1
        _mail(repos, i, f"Доступ в GigaMe для нового сотрудника ({k + 1})",
              f"Добрый день! Прошу предоставить доступ к платформе GigaMe "
              f"для сотрудника {p['fio']}.",
              _SENDERS[k % len(_SENDERS)], conv=conv, day=3 + k)
        i += 1
        _mail(repos, i, f"RE: Доступ в GigaMe для нового сотрудника ({k + 1})",
              "Добрый день! Уточните, пожалуйста, цифровой логин сотрудника — "
              "без него доступ не завести.",
              ("Железнов Максим", "zheleznov.m.yu@sberbank.ru"),
              conv=conv, folder="Sent", day=4 + k)
        i += 1
        _mail(repos, i, f"RE: RE: Доступ в GigaMe для нового сотрудника ({k + 1})",
              f"Логин — {p['login']}. Спасибо!",
              _SENDERS[k % len(_SENDERS)], conv=conv, day=5 + k)

    # C/D. Списки в Word и Excel — настоящие файлы через боевой экстрактор
    ATT_DIR.mkdir(parents=True, exist_ok=True)
    import docx as docx_lib
    import openpyxl

    for k in range(3):
        people = _people(8, rnd, used)
        truth += people
        fn = f"gigame_dostup_spisok_{k + 1}.docx"
        d = docx_lib.Document()
        d.add_paragraph("Список сотрудников для предоставления доступа "
                        "к платформе GigaMe")
        for p in people:
            d.add_paragraph(f"{p['fio']} — табельный логин {p['login']}")
        path = ATT_DIR / fn
        d.save(str(path))
        i += 1
        mid = _mail(repos, i, f"Доступ GigaMe — список подразделения {k + 1}",
                    "Коллеги, список во вложении. Прошу завести всех.",
                    _SENDERS[k % len(_SENDERS)], day=8 + k, attach=fn)
        repos.attachments.upsert(mid, fn, ".docx", path.stat().st_size,
                                 str(path), extract_text(path), "parsed")

    for k in range(3):
        people = _people(8, rnd, used)
        truth += people
        fn = f"gigame_uz_{k + 1}.xlsx"
        wb = openpyxl.Workbook()
        ws = wb.active
        ws.append(["ФИО", "Логин", "Платформа"])
        for p in people:
            ws.append([p["fio"], p["login"], "GigaMe"])
        path = ATT_DIR / fn
        wb.save(str(path))
        i += 1
        mid = _mail(repos, i, f"УЗ GigaMe для филиала {k + 1} (Excel)",
                    "Направляю таблицу с ФИО и логинами на доступ к ГигаМи.",
                    _SENDERS[k % len(_SENDERS)], day=12 + k, attach=fn)
        repos.attachments.upsert(mid, fn, ".xlsx", path.stat().st_size,
                                 str(path), extract_text(path), "parsed")

    # шум: письма про GigaMe без заявок
    for k in range(5):
        i += 1
        _mail(repos, i, f"GigaMe: обсуждение доработок ({k + 1})",
              "Коллеги, по итогам демо GigaMe предлагаю обсудить доработки "
              "дашборда и выгрузок. Доступы здесь не запрашиваем.",
              _SENDERS[k % len(_SENDERS)], day=15 + k)

    # немного заметок-знаний о доступах (третий источник для свипа)
    for k in range(6):
        p = truth[k * 5]
        repos.notes.create(
            f"Доступ к GigaMe: {p['fio']}",
            f"Запрошен доступ к платформе GigaMe для {p['fio']} "
            f"(логин {p['login']}).", "fact",
            f"<{PREFIX}-{k + 1}@emu.local>", None)

    TRUTH_PATH.write_text(json.dumps(truth, ensure_ascii=False, indent=1),
                          encoding="utf-8")
    print(f"Засеяно: {i} писем, {len(truth)} уникальных сотрудников "
          f"(A:75 B:12 C:24 D:24), эталон: {TRUTH_PATH}")


def cleanup() -> None:
    db = Database(settings.db_path)
    repos = Repos(db)
    for sql in (
            f"DELETE FROM notes WHERE source_message_id LIKE '%{PREFIX}%'",
            f"DELETE FROM attachments WHERE message_id LIKE '%{PREFIX}%'",
            f"DELETE FROM emails WHERE message_id LIKE '%{PREFIX}%'"):
        repos.db.execute(sql)
    import shutil
    shutil.rmtree(ATT_DIR, ignore_errors=True)
    TRUTH_PATH.unlink(missing_ok=True)
    print("Синтетика удалена")


if __name__ == "__main__":
    import sys
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    setup_logging()
    parser = argparse.ArgumentParser()
    parser.add_argument("--cleanup", action="store_true")
    args = parser.parse_args()
    cleanup() if args.cleanup else seed()
