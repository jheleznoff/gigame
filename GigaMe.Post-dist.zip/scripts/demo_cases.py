"""Модельный прогон: 8 писем покрывают все механики системы на РЕАЛЬНОМ GigaChat.

Сортировка по папкам (dry-run), задачи-черновики, контроль договорённостей,
просрочки/follow-up, HITL-карантин, вложения (docx/xlsx), многосвязный граф.
Outlook не затрагивается: письма подаются в пайплайн напрямую, все действия
логируются в processing_log.

Запуск:   .venv\\Scripts\\python scripts\\demo_cases.py
Очистка:  .venv\\Scripts\\python scripts\\demo_cases.py --cleanup
"""

import argparse
import sys
from datetime import datetime, timedelta
from pathlib import Path

from gigapost.config import DATA_DIR, load_taxonomy, settings, setup_logging
from gigapost.control.monitor import ControlMonitor
from gigapost.db.database import Database
from gigapost.db.repositories import Repos
from gigapost.knowledge.graph_store import KnowledgeGraph
from gigapost.outlook.client import NullOutlookClient
from gigapost.outlook.models import EmailMessage
from gigapost.pipeline.graph import build_ingest_graph
from gigapost.pipeline.nodes import PipelineNodes

TODAY = datetime(2026, 7, 20)
ATT_DIR = DATA_DIR / "attachments" / "demo"


def _docx(path: Path, paragraphs: list[str]) -> str:
    import docx

    d = docx.Document()
    for p in paragraphs:
        d.add_paragraph(p)
    path.parent.mkdir(parents=True, exist_ok=True)
    d.save(str(path))
    return str(path)


def _xlsx(path: Path, sheet: str, rows: list[list]) -> str:
    import openpyxl

    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = sheet
    for row in rows:
        ws.append(row)
    path.parent.mkdir(parents=True, exist_ok=True)
    wb.save(str(path))
    return str(path)


def build_emails() -> list[EmailMessage]:
    kp_path = _docx(ATT_DIR / "КП_Альфа.docx", [
        "Коммерческое предложение по проекту «Альфа»",
        "АО «Вектор» предлагает выполнить работы по автоматизации склада.",
        "Стоимость работ: 4 800 000 руб. с НДС.",
        "Срок выполнения: 3 месяца с даты подписания договора.",
        "Гарантия: 24 месяца. Контакт: Анна Смирнова, руководитель проекта.",
    ])
    invoice_path = _xlsx(ATT_DIR / "Счёт_145.xlsx", "Счёт", [
        ["Счёт на оплату №145 от 18.07.2026", "", ""],
        ["Поставщик: ООО «Ромашка»", "", ""],
        ["Позиция", "Кол-во", "Сумма"],
        ["Лицензии ПО «Альфа-Склад», годовая подписка", 10, 350000],
        ["Техническая поддержка (июль-декабрь)", 1, 120000],
        ["ИТОГО к оплате до 24.07.2026", "", 470000],
    ])

    def email(num, subject, sender_name, sender_email, body, received,
              conv=None, att_names=None, att_paths=None):
        return EmailMessage(
            message_id=f"<demo-{num:02d}@gigapost.demo>",
            entry_id=f"DEMO{num:02d}",
            conversation_id=conv or f"DEMO-CONV-{num:02d}",
            subject=subject, sender_name=sender_name, sender_email=sender_email,
            recipients=["m.jheleznoff@gmail.com"],
            received_at=received.isoformat(),
            body_text=body, folder="Inbox",
            has_attachments=bool(att_names),
            attachment_names=att_names or [],
            attachment_paths=att_paths or [],
        )

    return [
        # 1. Рассылка — жёсткое правило, LLM не вызывается
        email(1, "Еженедельный дайджест технологий", "Tech Digest",
              "noreply@techdigest.example.com",
              "Главные новости недели в мире технологий...\n\nЧтобы отписаться, нажмите здесь.",
              TODAY - timedelta(days=1)),
        # 2. Счёт с вложением-сметой → Финансы + задача оплатить
        email(2, "Счёт на оплату №145 — лицензии «Альфа-Склад»", "Бухгалтерия Ромашка",
              "buhgalteria@romashka.ru",
              "Добрый день!\n\nНаправляем счёт №145 на оплату лицензий ПО «Альфа-Склад» "
              "по проекту «Альфа». Просим оплатить до 24 июля 2026.\n\nДетали во вложении.\n\n"
              "С уважением, бухгалтерия ООО «Ромашка»",
              TODAY - timedelta(days=2),
              att_names=["Счёт_145.xlsx"], att_paths=[invoice_path]),
        # 3. Срочная просьба с дедлайном → флаг + задача
        email(3, "Срочно: отчёт по проекту «Альфа» к пятнице", "Пётр Иванов",
              "p.ivanov@romashka.ru",
              "Максим, добрый день!\n\nПрошу подготовить сводный отчёт по проекту «Альфа» "
              "до пятницы, 24 июля: статус внедрения, риски, бюджет.\n\nОтчёт нужен для "
              "встречи с руководством ООО «Ромашка» в понедельник.\n\nПётр Иванов, "
              "директор по развитию, ООО «Ромашка»",
              TODAY - timedelta(days=1)),
        # 4. Обещание контрагента + КП во вложении → контроль + задача «прислать ТЗ»
        email(4, "RE: Коммерческое предложение по проекту «Альфа»", "Анна Смирнова",
              "a.smirnova@vektor.ru",
              "Максим, здравствуйте!\n\nСпасибо за встречу. Как договорились, направляю "
              "предварительное КП по проекту «Альфа» (во вложении). Финальную версию с "
              "уточнённой сметой вышлем до 25 июля.\n\nСо своей стороны просим прислать "
              "техническое задание на интеграцию со складской системой.\n\n"
              "Анна Смирнова, руководитель проектов АО «Вектор»",
              TODAY - timedelta(days=3),
              att_names=["КП_Альфа.docx"], att_paths=[kp_path]),
        # 5. Просроченное обещание → overdue + follow-up
        email(5, "Договор подряда по проекту «Бета»", "Дмитрий Козлов",
              "d.kozlov@stroyinvest.ru",
              "Максим, приветствую!\n\nПо итогам переговоров: мы подготовим и пришлём "
              "проект договора подряда по проекту «Бета» до 15 июля.\n\nТакже подтверждаю, "
              "что СтройИнвест готов начать работы в августе.\n\n"
              "Дмитрий Козлов, коммерческий директор, ООО «СтройИнвест»",
              TODAY - timedelta(days=8)),
        # 6. Личное
        email(6, "Дача в выходные", "Мама",
              "mama.jheleznova@mail.ru",
              "Привет! Приедете с Олей на дачу в субботу? Папа обещал шашлыки. "
              "Захвати пожалуйста удлинитель.\n\nЦелую, мама",
              TODAY - timedelta(days=1)),
        # 7. Мутное письмо №1: смесь рекламы и личного вопроса → ждём HITL
        email(7, "и ещё кое-что...", "Валерий",
              "valeriy.consult@gmail.com",
              "здравствуйте это по поводу того о чем говорили тогда. кстати посмотрите "
              "нашу новую программу лояльности скидки до 70% только сегодня!!! так вот "
              "по тому вопросу - вы решили? жду ответа. В.",
              TODAY - timedelta(hours=5)),
        # 8. Кросс-связи для графа: Альфа+Бета, Вектор+СтройИнвест в одном письме
        email(8, "Координация по проектам «Альфа» и «Бета»", "Пётр Иванов",
              "p.ivanov@romashka.ru",
              "Максим,\n\nкороткий статус: по «Альфе» назначил созвон с Анной Смирновой "
              "из «Вектора» на четверг — обсудим интеграцию. По «Бете» СтройИнвест "
              "задерживает договор, Козлов не отвечает вторую неделю — подключись, "
              "пожалуйста.\n\nПётр",
              TODAY - timedelta(hours=8)),
    ]


def run_demo() -> None:
    db = Database(settings.db_path)
    db.init_schema()
    repos = Repos(db)
    outlook = NullOutlookClient()  # Outlook не трогаем вообще
    taxonomy = load_taxonomy()
    kg = KnowledgeGraph(repos, settings.graphml_path)
    kg.rebuild()
    try:
        from gigapost.knowledge.vector_store import VectorStore
        vectors = VectorStore(settings.chroma_path)
    except Exception:  # noqa: BLE001
        vectors = None

    nodes = PipelineNodes(repos, outlook, taxonomy, kg, vectors)
    graph = build_ingest_graph(nodes)

    for em in build_emails():
        if repos.emails.exists(em.message_id):
            print(f"— {em.subject[:50]}: уже в базе, пропускаю")
            continue
        repos.emails.upsert(em)
        try:
            graph.invoke({"email": em})
            row = repos.emails.get(em.message_id)
            review = " → НА РУЧНОЙ РАЗБОР" if row.get("needs_review") else ""
            print(f"— [{row.get('category') or '?'} conf={row.get('category_confidence')}]"
                  f"{review} {em.subject[:55]}")
        except Exception as e:  # noqa: BLE001
            print(f"— ОШИБКА {em.subject[:40]}: {e}")

    # follow-up: Козлов молчит вторую неделю
    db.execute(
        """UPDATE agreements SET last_activity_at=?
           WHERE source_message_id LIKE '<demo-05%'""",
        ((TODAY - timedelta(days=8)).isoformat(),))
    stats = ControlMonitor(repos).run()
    print(f"\nКонтроль: {stats}")
    kg.save_graphml()
    print(f"Граф: {kg.stats()}")
    print("\nГотово. Обновите дашборд: http://127.0.0.1:8765")


def cleanup() -> None:
    db = Database(settings.db_path)
    db.init_schema()
    for sql in [
        "DELETE FROM note_links WHERE note_id IN "
        "(SELECT id FROM notes WHERE source_message_id LIKE '<demo-%')",
        "DELETE FROM notes WHERE source_message_id LIKE '<demo-%'",
        "DELETE FROM alerts WHERE ref_table='agreements' AND ref_id IN "
        "(SELECT id FROM agreements WHERE source_message_id LIKE '<demo-%')",
        "DELETE FROM tasks WHERE source_message_id LIKE '<demo-%'",
        "DELETE FROM agreements WHERE source_message_id LIKE '<demo-%'",
        "DELETE FROM attachments WHERE message_id LIKE '<demo-%'",
        "DELETE FROM entity_mentions WHERE message_id LIKE '<demo-%'",
        "DELETE FROM processing_log WHERE message_id LIKE '<demo-%'",
        "DELETE FROM emails WHERE message_id LIKE '<demo-%'",
    ]:
        db.execute(sql)
    print("Демо-данные удалены (сущности графа оставлены — они дедуплицируются).")


if __name__ == "__main__":
    setup_logging()
    parser = argparse.ArgumentParser()
    parser.add_argument("--cleanup", action="store_true")
    args = parser.parse_args()
    if args.cleanup:
        cleanup()
    else:
        run_demo()
