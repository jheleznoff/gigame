"""Обработка транскриптов встреч: протокол + задачи + знания.

Запуск:  python scripts\\import_meeting.py                 # вся папка Встречи
         python scripts\\import_meeting.py путь\\к\\файлу.txt

Файлы кладите в %USERPROFILE%\\GigaMePost_Export\\Встречи\\ (txt/md/docx).
Работающее решение подхватывает их и само (раз в 5 минут, по 2 за прогон).
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from gigapost.config import settings, setup_logging
from gigapost.db.database import Database
from gigapost.db.repositories import Repos
from gigapost.knowledge.graph_store import KnowledgeGraph
from gigapost.meeting_notes import meetings_dir, process_transcript, scan_meetings


def main() -> None:
    setup_logging()
    err = settings.gigachat_config_error()
    if err:
        raise SystemExit(f"Конфигурация GigaChat сломана: {err}")

    db = Database(settings.db_path)
    db.init_schema()
    repos = Repos(db)
    kg = KnowledgeGraph(repos, settings.graphml_path)
    kg.rebuild()
    vectors = None
    try:
        from gigapost.knowledge.vector_store import VectorStore
        vectors = VectorStore(settings.chroma_path)
    except Exception as e:  # noqa: BLE001
        print(f"! векторы недоступны: {e}")

    if len(sys.argv) > 1:
        path = Path(sys.argv[1])
        if not path.exists():
            raise SystemExit(f"Файл не найден: {path}")
        result = process_transcript(repos, kg, vectors, path)
        print(result)
    else:
        base = meetings_dir()
        base.mkdir(parents=True, exist_ok=True)
        done = scan_meetings(repos, kg, vectors, limit=50)
        print(f"Обработано транскриптов: {done} (папка: {base})")
        if done:
            print("Поручения ждут подтверждения на дашборде (черновики задач), "
                  "протоколы — в разделе Письма (папка «Протоколы встреч»).")
    kg.save_graphml()


if __name__ == "__main__":
    main()
