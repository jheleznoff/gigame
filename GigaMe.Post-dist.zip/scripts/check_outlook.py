"""Smoke-тест Outlook COM: python scripts/check_outlook.py

Проверяет, что установлен классический Outlook, доступный по COM,
и показывает папки почтового ящика.
"""

import sys

from gigapost.config import setup_logging
from gigapost.outlook.com_worker import ComWorker, ComWorkerError


def main() -> int:
    setup_logging()
    worker = ComWorker()
    try:
        worker.start()
    except ComWorkerError as e:
        print(f"ОШИБКА: {e}")
        return 1
    try:
        version = worker.submit(lambda outlook, ns: str(outlook.Version))
        account = worker.submit(
            lambda outlook, ns: ns.GetDefaultFolder(6).Parent.Name)  # 6 = olFolderInbox
        inbox_count = worker.submit(
            lambda outlook, ns: ns.GetDefaultFolder(6).Items.Count)
        print(f"Outlook версии {version} доступен по COM ✓")
        print(f"Почтовый ящик: {account}")
        print(f"Писем во «Входящих»: {inbox_count}")
        return 0
    finally:
        worker.stop()


if __name__ == "__main__":
    sys.exit(main())
