"""Демо-наполнение БД: прогон реального пайплайна на тестовых фикстурах
с фейковым LLM и фейковым Outlook (не требует ни GigaChat-ключа, ни Outlook).

Запуск: .venv\\Scripts\\python scripts\\demo_seed.py
Полезно, чтобы увидеть работу UI до подключения реальной почты.
"""

import sys
from datetime import datetime, timedelta
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent / "tests"))

from conftest import FakeOutlookClient, load_email_fixture  # noqa: E402

from gigapost.config import load_taxonomy, settings, setup_logging  # noqa: E402
from gigapost.control.monitor import ControlMonitor  # noqa: E402
from gigapost.db.database import Database  # noqa: E402
from gigapost.db.repositories import Repos  # noqa: E402
from gigapost.knowledge.graph_store import KnowledgeGraph  # noqa: E402
from gigapost.llm.schemas import (EmailClassification, EntityRelation,  # noqa: E402
                                  ExtractedAgreement, ExtractedEntity, ExtractedTask,
                                  ExtractionResult)
from gigapost.pipeline.graph import build_ingest_graph  # noqa: E402
from gigapost.pipeline.nodes import PipelineNodes  # noqa: E402


class FakeStructuredLLM:
    def __init__(self, result):
        self._result = result

    def with_structured_output(self, schema):
        return self

    def invoke(self, prompt):
        return self._result


# Свои «ответы LLM» на каждую фикстуру — имитируют реальные результаты
SCENARIOS = {
    "task_request": {
        "classify": EmailClassification(
            category="Срочное/Действие", importance=4, requires_action=True,
            summary="Просят подготовить отчёт по продажам с разбивкой по регионам до пятницы"),
        "extract": ExtractionResult(
            tasks=[ExtractedTask(title="Подготовить отчёт по продажам за Q2",
                                 description="Разбивка по регионам, для встречи с руководством",
                                 deadline="2026-07-24", assignee="я")],
            agreements=[],
            entities=[
                ExtractedEntity(name="Пётр Иванов", type="person",
                                relations=[EntityRelation(target_name="Ромашка",
                                                          relation="works_at")]),
                ExtractedEntity(name="Ромашка", type="org", relations=[]),
            ]),
    },
    "agreement": {
        "classify": EmailClassification(
            category="Проекты", importance=4, requires_action=True,
            summary="Вектор вышлет КП по проекту Альфа до 25 июля; просят прислать ТЗ"),
        "extract": ExtractionResult(
            tasks=[ExtractedTask(title="Прислать ТЗ по проекту «Альфа» в АО «Вектор»",
                                 description="Просьба из письма Анны Смирновой",
                                 deadline=None, assignee="я")],
            agreements=[ExtractedAgreement(
                description="АО «Вектор» вышлет КП по проекту «Альфа»",
                counterparty="Анна Смирнова", direction="they_owe", due_date="2026-07-25")],
            entities=[
                ExtractedEntity(name="Анна Смирнова", type="person",
                                relations=[EntityRelation(target_name="Вектор",
                                                          relation="works_at"),
                                           EntityRelation(target_name="Альфа",
                                                          relation="participates_in")]),
                ExtractedEntity(name="Вектор", type="org", relations=[]),
                ExtractedEntity(name="Альфа", type="project", relations=[]),
            ]),
    },
    # newsletter уходит по hard rule — LLM не вызывается
    "newsletter": {"classify": None, "extract": None},
}


def main() -> None:
    setup_logging()
    db = Database(settings.db_path)
    db.init_schema()
    repos = Repos(db)
    kg = KnowledgeGraph(repos, settings.graphml_path)
    kg.rebuild()
    outlook = FakeOutlookClient()
    taxonomy = load_taxonomy()

    for name, scenario in SCENARIOS.items():
        email = load_email_fixture(name)
        if repos.emails.exists(email.message_id):
            print(f"— {name}: уже в базе, пропускаю")
            continue
        nodes = PipelineNodes(repos, outlook, taxonomy, kg, vectors=None,
                              classify_llm=FakeStructuredLLM(scenario["classify"]),
                              extract_llm=FakeStructuredLLM(scenario["extract"]))
        graph = build_ingest_graph(nodes)
        repos.emails.upsert(email)
        graph.invoke({"email": email})
        print(f"— {name}: обработано")

    # одна просроченная договорённость для демонстрации контроля
    if not any("демо" in (a.get("description") or "")
               for a in repos.agreements.list(limit=200)):
        aid = repos.agreements.create(
            "(демо) Партнёр обещал прислать договор", "Иван Петров", "they_owe",
            None, "DEMO-CONV", (datetime.now() - timedelta(days=2)).isoformat())
        repos.db.execute("UPDATE agreements SET last_activity_at=? WHERE id=?",
                         ((datetime.now() - timedelta(days=5)).isoformat(), aid))

    ControlMonitor(repos).run()
    kg.save_graphml()
    print("Готово. Перезапустите веб-приложение и откройте http://127.0.0.1:8765")


if __name__ == "__main__":
    main()
