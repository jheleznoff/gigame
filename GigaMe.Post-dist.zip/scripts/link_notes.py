"""Бэкфил смысловых связей заметка↔заметка для уже существующих заметок.

Запуск: .venv\\Scripts\\python scripts\\link_notes.py
"""

from gigapost.config import settings, setup_logging
from gigapost.db.database import Database
from gigapost.db.repositories import Repos
from gigapost.knowledge.vector_store import VectorStore


def main() -> None:
    setup_logging()
    db = Database(settings.db_path)
    db.init_schema()
    repos = Repos(db)
    vectors = VectorStore(settings.chroma_path)

    notes = repos.notes.all_notes()
    print(f"Заметок: {len(notes)}. Индексирую…")
    for n in notes:
        vectors.index_note(n["id"], n["title"], n["body"])
    linked = 0
    for n in notes:
        for other_id, score in vectors.similar_notes(n["id"]):
            repos.notes.add_relation(n["id"], other_id, score)
            linked += 1
    print(f"Связей записано: {linked} (уникальных: {len(repos.notes.all_relations())})")


if __name__ == "__main__":
    main()
