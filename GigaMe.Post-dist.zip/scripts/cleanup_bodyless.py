"""Удаление пустых COM-дублей писем.

Когда чтение почты шло через COM под блокирующей политикой, письма попадали
в базу без тела и с суррогатным ключом entryid:... — а потом те же письма
пришли полноценными через файловый шлюз (.msg) под настоящим Message-ID.
Скрипт удаляет пустые суррогатные записи (вместе с их строками журнала).

Запуск:  python scripts\\cleanup_bodyless.py          # показать, что удалится
         python scripts\\cleanup_bodyless.py --apply  # удалить
"""

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from gigapost.config import settings
from gigapost.db.database import Database


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--apply", action="store_true", help="действительно удалить")
    args = parser.parse_args()

    db = Database(settings.db_path)
    rows = db.query(
        """SELECT message_id, received_at, subject FROM emails
           WHERE message_id LIKE 'entryid:%'
             AND (body_text IS NULL OR body_text = '')""")
    print(f"Пустых COM-дублей: {len(rows)}")
    for r in rows[:15]:
        print(f"  {r['received_at'][:16]}  {(r['subject'] or '')[:60]}")
    if len(rows) > 15:
        print(f"  ... и ещё {len(rows) - 15}")

    if not rows:
        return
    if not args.apply:
        print("\nЭто был предпросмотр. Удалить: python scripts\\cleanup_bodyless.py --apply")
        return

    ids = [r["message_id"] for r in rows]
    ph = ",".join("?" * len(ids))
    db.execute(f"DELETE FROM processing_log WHERE message_id IN ({ph})", tuple(ids))
    db.execute(f"DELETE FROM attachments WHERE message_id IN ({ph})", tuple(ids))
    db.execute(f"DELETE FROM emails WHERE message_id IN ({ph})", tuple(ids))
    print(f"Удалено записей: {len(ids)}")


if __name__ == "__main__":
    main()
