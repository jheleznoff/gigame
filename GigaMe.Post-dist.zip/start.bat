@echo off
chcp 65001 >nul
rem ============================================================
rem  GigaMe.Post — запуск. Один процесс поднимает всё:
rem  Outlook COM-поток + планировщик почты + веб-интерфейс.
rem  UI: http://127.0.0.1:8765  (Ctrl+C в окне — остановка)
rem ============================================================
cd /d "%~dp0"

if not exist .venv\Scripts\python.exe (
    echo [ОШИБКА] Окружение не установлено — сначала запустите install.bat
    pause
    exit /b 1
)

start "" /min cmd /c "timeout /t 6 >nul & start http://127.0.0.1:8765"
.venv\Scripts\python scripts\run_web.py
pause
