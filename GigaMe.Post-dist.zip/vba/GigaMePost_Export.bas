Attribute VB_Name = "GigaMePost_Export"
' ============================================================================
'  GigaMe.Post - export writes to local disk (Object Model Guard trusts
'  code running INSIDE Outlook, unlike external programs).
'
'  Install: Alt+F11 -> right-click Project1 -> Import File -> this .bas
'
'  Usage:
'    ExportCurrentFolder - export the whole open folder (for history):
'      open a folder in Outlook, Alt+F8 -> ExportCurrentFolder -> Run.
'      Re-run skips already exported items.
'
'  Files go to  %USERPROFILE%\GigaMePost_Export\<folder name>\*.msg
'  Then on the solution side:  python scripts\import_msg.py
' ============================================================================
Option Explicit

Private Function BaseDir() As String
    BaseDir = Environ("USERPROFILE") & "\GigaMePost_Export"
End Function

Private Sub EnsureDir(ByVal p As String)
    Dim parts() As String, cur As String, i As Long
    parts = Split(p, "\")
    cur = parts(0)
    For i = 1 To UBound(parts)
        cur = cur & "\" & parts(i)
        If Dir(cur, vbDirectory) = "" Then MkDir cur
    Next
End Sub

Private Function SafeName(ByVal s As String) As String
    Dim bad As Variant, b As Variant
    bad = Array("\", "/", ":", "*", "?", """", "<", ">", "|", vbCr, vbLf, vbTab)
    For Each b In bad
        s = Replace(s, CStr(b), "_")
    Next
    If Len(s) > 60 Then s = Left(s, 60)
    SafeName = Trim(s)
End Function

' Stable file name per message (date+subject) - re-export does not duplicate
Private Function FileNameFor(ByVal itm As Object) As String
    FileNameFor = Format(itm.ReceivedTime, "yyyymmdd_hhnnss") & "_" & _
                  SafeName(itm.Subject) & ".msg"
End Function

Public Sub SaveOne(ByVal itm As Object, ByVal subFolder As String)
    On Error GoTo fail
    If itm.Class <> 43 Then Exit Sub   ' 43 = olMail
    Dim dirPath As String, filePath As String
    dirPath = BaseDir() & "\" & SafeName(subFolder)
    EnsureDir dirPath
    filePath = dirPath & "\" & FileNameFor(itm)
    If Dir(filePath) <> "" Then Exit Sub          ' already exported
    itm.SaveAs filePath, 3                        ' 3 = olMSG
    Exit Sub
fail:
    Debug.Print "SaveOne error: " & Err.Description
End Sub

Public Sub ExportCurrentFolder()
    Dim f As Outlook.MAPIFolder
    Set f = Application.ActiveExplorer.CurrentFolder
    Dim total As Long, done As Long, i As Long
    total = f.Items.Count
    If MsgBox("Export folder '" & f.Name & "' (" & total & " items) to " & _
              BaseDir() & "?", vbYesNo) <> vbYes Then Exit Sub
    For i = 1 To total
        On Error Resume Next
        SaveOne f.Items(i), f.Name
        On Error GoTo 0
        done = done + 1
        If done Mod 50 = 0 Then DoEvents
    Next
    MsgBox "Done: " & done & " items. Folder: " & _
           BaseDir() & "\" & SafeName(f.Name)
End Sub

' ============================================================================
'  AUTO-export of new mail (inbox and sent) - PASTE INTO ThisOutlookSession
'  (Alt+F11 -> Project1 -> Microsoft Outlook Objects -> ThisOutlookSession),
'  then restart Outlook:
'
'  Private WithEvents SentItems As Outlook.Items
'
'  Private Sub Application_Startup()
'      Set SentItems = Application.Session.GetDefaultFolder(5).Items ' 5=Sent
'  End Sub
'
'  Private Sub Application_NewMailEx(ByVal EntryIDCollection As String)
'      On Error Resume Next
'      Dim ids() As String, i As Long, itm As Object
'      ids = Split(EntryIDCollection, ",")
'      For i = LBound(ids) To UBound(ids)
'          Set itm = Application.Session.GetItemFromID(ids(i))
'          If Not itm Is Nothing Then GigaMePost_Export.SaveOne itm, "_inbox_stream"
'      Next
'  End Sub
'
'  Private Sub SentItems_ItemAdd(ByVal Item As Object)
'      GigaMePost_Export.SaveOne Item, "_sent_stream"
'  End Sub
' ============================================================================
