Attribute VB_Name = "GigaMePost_Export"
' ============================================================================
'  GigaMe.Post — выгрузка писем в локальную папку (обход блокировки политикой
'  Object Model Guard: внешним программам тело письма недоступно, а макросу
'  ВНУТРИ Outlook — доступно, это штатное доверие Outlook к собственному коду).
'
'  Установка: Alt+F11 → правый клик на Project1 → Import File → этот .bas
'  (или Insert → Module и вставить текст).
'
'  Использование:
'    ExportCurrentFolder — выгрузить ВСЮ открытую папку (для истории):
'      откройте нужную папку в Outlook, Alt+F8 → ExportCurrentFolder → Run.
'      Повторный запуск пропускает уже выгруженные письма.
'
'  Письма падают в  %USERPROFILE%\GigaMePost_Export\<имя папки>\*.msg
'  Дальше на стороне решения:  python scripts\import_msg.py
' ============================================================================
Option Explicit

Private Function BaseDir() As String
    BaseDir = Environ("USERPROFILE") & "\GigaMePost_Export"
End Function

Private Sub EnsureDir(ByVal p As String)
    Dim parts() As String, cur As String, i As Long
    parts = Split(p, "\")
    cur = parts(0)
    For i = 1 To UBound(parts)
        cur = cur & "\" & parts(i)
        If Dir(cur, vbDirectory) = "" Then MkDir cur
    Next
End Sub

Private Function SafeName(ByVal s As String) As String
    Dim bad As Variant, b As Variant
    bad = Array("\", "/", ":", "*", "?", """", "<", ">", "|", vbCr, vbLf, vbTab)
    For Each b In bad
        s = Replace(s, CStr(b), "_")
    Next
    If Len(s) > 60 Then s = Left(s, 60)
    SafeName = Trim(s)
End Function

' Имя файла стабильно для письма (дата+тема) — повторный экспорт не дублирует
Private Function FileNameFor(ByVal itm As Object) As String
    FileNameFor = Format(itm.ReceivedTime, "yyyymmdd_hhnnss") & "_" & _
                  SafeName(itm.Subject) & ".msg"
End Function

Public Sub SaveOne(ByVal itm As Object, ByVal subFolder As String)
    On Error GoTo fail
    If itm.Class <> 43 Then Exit Sub   ' 43 = olMail
    Dim dirPath As String, filePath As String
    dirPath = BaseDir() & "\" & SafeName(subFolder)
    EnsureDir dirPath
    filePath = dirPath & "\" & FileNameFor(itm)
    If Dir(filePath) <> "" Then Exit Sub          ' уже выгружено
    itm.SaveAs filePath, 3                        ' 3 = olMSG
    Exit Sub
fail:
    Debug.Print "SaveOne error: " & Err.Description
End Sub

Public Sub ExportCurrentFolder()
    Dim f As Outlook.MAPIFolder
    Set f = Application.ActiveExplorer.CurrentFolder
    Dim total As Long, done As Long, i As Long
    total = f.Items.Count
    If MsgBox("Выгрузить папку «" & f.Name & "» (" & total & " элементов) в " & _
              BaseDir() & "?", vbYesNo) <> vbYes Then Exit Sub
    For i = 1 To total
        On Error Resume Next
        SaveOne f.Items(i), f.Name
        On Error GoTo 0
        done = done + 1
        If done Mod 50 = 0 Then
            Application.ActiveExplorer.Caption = "Экспорт: " & done & "/" & total
            DoEvents
        End If
    Next
    MsgBox "Готово: обработано " & done & " элементов. Папка: " & _
           BaseDir() & "\" & SafeName(f.Name)
End Sub

' ============================================================================
'  АВТО-выгрузка новых писем (входящие и отправленные) — ВСТАВИТЬ В
'  ThisOutlookSession (Alt+F11 → Project1 → Microsoft Outlook Objects →
'  ThisOutlookSession), затем перезапустить Outlook:
'
'  Private WithEvents SentItems As Outlook.Items
'
'  Private Sub Application_Startup()
'      Set SentItems = Application.Session.GetDefaultFolder(5).Items ' 5=Sent
'  End Sub
'
'  Private Sub Application_NewMailEx(ByVal EntryIDCollection As String)
'      On Error Resume Next
'      Dim ids() As String, i As Long, itm As Object
'      ids = Split(EntryIDCollection, ",")
'      For i = LBound(ids) To UBound(ids)
'          Set itm = Application.Session.GetItemFromID(ids(i))
'          If Not itm Is Nothing Then GigaMePost_Export.SaveOne itm, "_inbox_stream"
'      Next
'  End Sub
'
'  Private Sub SentItems_ItemAdd(ByVal Item As Object)
'      GigaMePost_Export.SaveOne Item, "_sent_stream"
'  End Sub
' ============================================================================
