@echo off
chcp 65001 >nul
rem ============================================================
rem  GigaMe.Post — установка на новом компьютере.
rem  Требуется Python 3.12 (py -3.12) и доступ к PyPI.
rem ============================================================
cd /d "%~dp0"

py -3.12 -c "import sys" 2>nul
if errorlevel 1 (
    echo [ОШИБКА] Python 3.12 не найден. Установите Python 3.12 x64
    echo          и повторите запуск install.bat
    pause
    exit /b 1
)

echo [1/3] Создаю виртуальное окружение .venv ...
py -3.12 -m venv .venv
if errorlevel 1 ( echo [ОШИБКА] Не удалось создать .venv & pause & exit /b 1 )

echo [2/3] Ставлю зависимости (точные версии из requirements.lock.txt) ...
.venv\Scripts\python -m pip install -r requirements.lock.txt --quiet
if errorlevel 1 ( echo [ОШИБКА] Установка зависимостей не удалась & pause & exit /b 1 )
.venv\Scripts\python -m pip install --no-deps -e . --quiet
if errorlevel 1 ( echo [ОШИБКА] Установка gigapost не удалась & pause & exit /b 1 )

echo [3/3] Готовлю конфигурацию ...
if not exist .env copy .env.example .env >nul
if not exist data mkdir data

echo.
echo Установка завершена.
echo.
echo Дальше:
echo   1. Откройте .env и заполните подключение GigaChat
echo      (на корп-ноутбуке: GIGACHAT_BASE_URL + GIGACHAT_CERT_FILE + GIGACHAT_KEY_FILE).
echo   2. Проверьте config\settings.yaml: polling.store, exclude_stores, owner, vips.
echo   3. Запускайте start.bat
echo.
pause
