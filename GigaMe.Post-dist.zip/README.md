# GigaMe.Post

Локальный агентный почтовый ассистент: **GigaChat + классический Outlook (COM) + LangGraph/deepagents + Flask**.

Что делает:
- анализирует входящую почту через GigaChat и раскладывает письма по папкам/категориям/флагам прямо в Outlook;
- извлекает из писем **задачи** (создаёт их в Outlook Tasks с напоминаниями и в локальной БД) и **договорённости**;
- ставит договорённости **на контроль**: просрочки, приближающиеся дедлайны, follow-up («обещали ответить — прошло 3 дня, ответа нет»);
- строит **граф знаний** (люди, организации, проекты, темы) и **векторный индекс** писем;
- отдельный локальный веб-UI: дашборд, **чат с агентом** о письмах/задачах/договорённостях, визуализация графа, поиск.

## Требования

- Windows + **классический десктопный Outlook** («новый Outlook» не поддерживает COM-автоматизацию — проверьте, что переключатель "New Outlook" выключен);
- Python 3.11–3.12 (не 3.14 — chromadb может не иметь колёс);
- Авторизационный ключ GigaChat (developers.sber.ru).

## Установка

```powershell
py -3.12 -m venv .venv
.venv\Scripts\pip install -e ".[dev]"
copy .env.example .env      # вписать GIGACHAT_CREDENTIALS
.venv\Scripts\python scripts\init_db.py
.venv\Scripts\python scripts\check_outlook.py   # smoke-тест COM
```

### SSL-сертификаты

По умолчанию `GIGACHAT_VERIFY_SSL_CERTS=false`. Рекомендуется установить
[корневой сертификат НУЦ Минцифры](https://www.gosuslugi.ru/crt) и включить проверку (`true`).

## Запуск

```powershell
.venv\Scripts\python scripts\run_web.py
```

Откроется веб-UI на http://127.0.0.1:8765. В одном процессе работают: COM-поток Outlook,
планировщик (опрос почты каждые 5 минут, контроль договорённостей каждые 30 минут) и Flask.

Разовый прогон пайплайна без UI:

```powershell
.venv\Scripts\python scripts\run_ingest.py            # dry-run по умолчанию
.venv\Scripts\python scripts\run_ingest.py --live     # боевой режим
```

## Режим dry-run (важно!)

В `config/settings.yaml` по умолчанию `dry_run: true` — **никакие изменения в Outlook не вносятся**,
все намерения пишутся в `processing_log` (видно в data/gigapost.db). Посмотрите лог после
первых прогонов, поправьте `config/taxonomy.yaml` под свою почту и только затем ставьте `dry_run: false`.

Рекомендация для обкатки: скопируйте 15–20 писем в отдельную папку Outlook (например, `GigaPost-Test`),
укажите её в `settings.yaml → polling.folders` и гоняйте пайплайн на ней.

## Конфигурация

- `.env` — ключ GigaChat (никогда не коммитить);
- `config/settings.yaml` — модели по ролям (классификация — Lite, извлечение — Pro, чат — Max), интервалы, лимиты, dry_run;
- `config/taxonomy.yaml` — категории писем, действия в Outlook, жёсткие правила до LLM — **правьте под себя**;
- `config/prompts/*.md` — промпты (русские).

## Тесты

```powershell
.venv\Scripts\python -m pytest                # юнит-тесты (без Outlook и GigaChat)
.venv\Scripts\python -m pytest -m live        # качество извлечения на реальном GigaChat
```

## Перенос на корпоративный ноутбук и бэкфилл истории

1. Скопируйте папку проекта (без `data/` и `.venv/`), поставьте Python 3.12,
   `py -3.12 -m venv .venv && .venv\Scripts\pip install -e ".[dev]"`, заполните `.env`.
   В корпоративном контуре авторизация — по mTLS-сертификатам (как у GigaMe),
   OAuth-ключ не нужен. В `.env` вместо `GIGACHAT_CREDENTIALS` укажите:

   ```ini
   GIGACHAT_BASE_URL=https://gigachat-ift.sberdevices.delta.sbrf.ru/v1
   GIGACHAT_CERT_FILE=C:\путь\к\client.crt   # тот же файл, что GIGACHAT_SERT у GigaMe
   GIGACHAT_KEY_FILE=C:\путь\к\client.key    # тот же файл, что GIGACHAT_KEY у GigaMe
   ```

   Сертификат и ключ возьмите те же, что использует локальный запуск GigaMe
   (`GIGACHAT_SERT` / `GIGACHAT_KEY` в его окружении). `GIGACHAT_VERIFY_SSL_CERTS`
   оставьте `false` (в GigaMe это `unsafe-ssl: true`). Если ключ зашифрован паролем —
   добавьте `GIGACHAT_KEY_FILE_PASSWORD=...`. Проверка подключения:
   `.venv\Scripts\python -m pytest -m live` или кнопкой чата в UI.
2. В `config/settings.yaml`:
   - `polling.store` — подстрока имени основного ящика (например `"zheleznov"`);
   - `polling.exclude_stores` — ящики, которые нельзя трогать (например `"zakupki_dzo"`) —
     они игнорируются во всех операциях;
   - `owner` и `vips` — под себя.
3. Историю писем загружайте умным бэкфиллом (НЕ прожигает LLM на всём архиве):

```powershell
# A. Все письма (ящик + архивы) в локальную базу БЕЗ LLM — поиск работает сразу
.venv\Scripts\python scripts\backfill.py --stores "zheleznov" "Архив" --months 12 --stage ingest

# B. Посмотреть, что эвристики отобрали для LLM (рассылки/мусор уже отсеяны)
.venv\Scripts\python scripts\backfill.py --stage select --show 30

# C. Извлечь знания из отобранного — порциями, по одному вызову LLM на письмо
.venv\Scripts\python scripts\backfill.py --stage knowledge --max-llm 100
```

Стадию C можно запускать сколько угодно раз (например, по 100–200 писем в день) —
она возобновляется с места остановки и начинает с самых ценных писем: треды,
где вы отвечали, письма от руководителей, свежие. Старые письма НЕ создают задач
и не сортируются — только пополняют граф знаний и поиск.

## Приватность

Все данные (SQLite, Chroma, граф) хранятся локально в `data/`. Наружу уходят только
тексты писем в GigaChat API (это осознанное ограничение решения) — при необходимости
используйте корпоративный контур GigaChat.

## Архитектура

- `src/gigapost/outlook/` — COM-слой: единственный поток `ComWorker` владеет Outlook,
  все вызовы сериализуются через очередь (COM-объекты не покидают поток);
- `src/gigapost/pipeline/` — детерминированный LangGraph-пайплайн:
  classify → extract → apply_actions → update_kg → index_vector;
- `src/gigapost/agent/` — диалоговый агент deepagents (fallback — create_react_agent) с инструментами
  поиска по письмам/графу/задачам; память чата — SqliteSaver;
- `src/gigapost/knowledge/` — граф знаний (SQLite — источник истины, NetworkX — кэш) и Chroma;
- `src/gigapost/control/` — детерминированный контроль договорённостей без LLM;
- `src/gigapost/web/` — Flask UI (SSE-стриминг чата, vis-network для графа).
