"""Запуск GigaMe.Post: весь стек (Outlook COM + планировщик + веб-UI) — один процесс.

Запуск:  py start.py
Открывает браузер на http://127.0.0.1:8765. Остановка — Ctrl+C.
"""

import subprocess
import sys
import threading
import webbrowser
from pathlib import Path

ROOT = Path(__file__).resolve().parent
VENV_PY = ROOT / ".venv" / "Scripts" / "python.exe"


def main() -> None:
    if not VENV_PY.exists():
        sys.exit("[ОШИБКА] Окружение не установлено — сначала: py -3.12 install.py")

    threading.Timer(6.0, webbrowser.open, args=("http://127.0.0.1:8765",)).start()
    try:
        subprocess.run([str(VENV_PY), str(ROOT / "scripts" / "run_web.py")], cwd=ROOT)
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
