"""Утренний дайджест: что случилось, что горит, что ждёт решения."""

from __future__ import annotations

import logging
from datetime import datetime, timedelta

from gigapost.db.repositories import Repos

logger = logging.getLogger(__name__)


def build_digest(repos: Repos, now: datetime | None = None) -> str:
    """Собрать markdown-дайджест детерминированно + краткое резюме LLM (если доступен)."""
    now = now or datetime.now()
    day = now.strftime("%Y-%m-%d")
    since = (now - timedelta(hours=24)).isoformat()

    new_emails = [e for e in repos.emails.recent(limit=100)
                  if (e.get("received_at") or "") >= since and e.get("folder") != "Sent"]
    action_emails = [e for e in new_emails if e.get("requires_action")]
    review = repos.emails.pending_review(limit=20)
    drafts = repos.tasks.list("draft", limit=30)
    open_tasks = repos.tasks.list("open", limit=100)
    overdue = [t for t in open_tasks
               if t.get("due_date") and t["due_date"] < now.isoformat()]
    today_due = [t for t in open_tasks
                 if t.get("due_date") and t["due_date"][:10] == day]
    alerts = repos.alerts.list_active(limit=30)
    agreements = repos.agreements.list(limit=50)
    overdue_agr = [a for a in agreements if a["status"] == "overdue"]

    lines = [f"# Дайджест за {now.strftime('%d.%m.%Y')}", ""]
    lines.append(f"**Почта за сутки:** {len(new_emails)} писем, "
                 f"из них требуют действия — {len(action_emails)}.")
    if action_emails:
        for e in action_emails[:5]:
            lines.append(f"- ✉ {e.get('sender_name')}: «{e.get('subject')}» — "
                         f"{(e.get('summary') or '')[:100]}")
    lines.append("")
    if overdue or today_due:
        lines.append("**Горит:**")
        for t in overdue[:5]:
            lines.append(f"- 🔴 просрочено: {t['title']} (срок был {t['due_date'][:10]})")
        for t in today_due[:5]:
            lines.append(f"- 🟡 сегодня: {t['title']}")
        lines.append("")
    pending = len(review) + len(drafts)
    if pending:
        lines.append(f"**Ждут решения ({pending}):** "
                     f"{len(review)} писем на разбор, {len(drafts)} предложенных задач.")
        lines.append("")
    if overdue_agr:
        lines.append("**Контроль договорённостей:**")
        for a in overdue_agr[:5]:
            lines.append(f"- ⏰ {a['description'][:80]} ({a.get('counterparty')}, "
                         f"срок {str(a.get('due_date'))[:10]})")
        lines.append("")
    if alerts:
        lines.append(f"**Алертов активно:** {len(alerts)}.")
        lines.append("")
    if not (new_emails or overdue or today_due or pending or alerts):
        lines.append("Тишина: новых писем нет, ничего не горит. Хорошего дня!")

    body = "\n".join(lines)

    # краткое LLM-резюме сверху (необязательное — при лимитах пропускаем)
    try:
        from gigapost.llm.factory import get_llm
        summary = get_llm("classify").invoke(
            "Сожми этот дайджест почтового ассистента в 2-3 предложения по-русски: "
            "самое важное и что сделать в первую очередь.\n\n" + body)
        text = summary.content if hasattr(summary, "content") else str(summary)
        body = f"> {text.strip()}\n\n" + body
    except Exception as e:  # noqa: BLE001
        logger.debug("LLM-резюме дайджеста пропущено: %s", e)

    repos.digests.save(day, body)
    return body
