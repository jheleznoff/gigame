"""Утренний дайджест: что случилось, что горит, что ждёт решения."""

from __future__ import annotations

import logging
from datetime import datetime, timedelta

from gigapost.db.repositories import Repos

logger = logging.getLogger(__name__)


def build_digest(repos: Repos, now: datetime | None = None) -> str:
    """Собрать markdown-дайджест детерминированно + краткое резюме LLM (если доступен)."""
    now = now or datetime.now()
    day = now.strftime("%Y-%m-%d")
    since = (now - timedelta(hours=24)).isoformat()

    new_emails = [e for e in repos.emails.recent(limit=100)
                  if (e.get("received_at") or "") >= since and e.get("folder") != "Sent"]
    action_emails = [e for e in new_emails if e.get("requires_action")]
    review = repos.emails.pending_review(limit=20)
    drafts = repos.tasks.list("draft", limit=30)
    open_tasks = repos.tasks.list("open", limit=100)
    overdue = [t for t in open_tasks
               if t.get("due_date") and t["due_date"] < now.isoformat()]
    today_due = [t for t in open_tasks
                 if t.get("due_date") and t["due_date"][:10] == day]
    alerts = repos.alerts.list_active(limit=30)
    agreements = repos.agreements.list(limit=50)
    overdue_agr = [a for a in agreements if a["status"] == "overdue"]

    lines = [f"# Дайджест за {now.strftime('%d.%m.%Y')}", ""]
    lines.append(f"**Почта за сутки:** {len(new_emails)} писем, "
                 f"из них требуют действия — {len(action_emails)}.")
    if action_emails:
        for e in action_emails[:5]:
            lines.append(f"- ✉ {e.get('sender_name')}: «{e.get('subject')}» — "
                         f"{(e.get('summary') or '')[:100]}")
    lines.append("")
    if overdue or today_due:
        lines.append("**Горит:**")
        for t in overdue[:5]:
            lines.append(f"- 🔴 просрочено: {t['title']} (срок был {t['due_date'][:10]})")
        for t in today_due[:5]:
            lines.append(f"- 🟡 сегодня: {t['title']}")
        lines.append("")
    pending = len(review) + len(drafts)
    if pending:
        lines.append(f"**Ждут решения ({pending}):** "
                     f"{len(review)} писем на разбор, {len(drafts)} предложенных задач.")
        lines.append("")
    if overdue_agr:
        lines.append("**Контроль договорённостей:**")
        for a in overdue_agr[:5]:
            lines.append(f"- ⏰ {a['description'][:80]} ({a.get('counterparty')}, "
                         f"срок {str(a.get('due_date'))[:10]})")
        lines.append("")
    if alerts:
        lines.append(f"**Алертов активно:** {len(alerts)}.")
        lines.append("")
    if not (new_emails or overdue or today_due or pending or alerts):
        lines.append("Тишина: новых писем нет, ничего не горит. Хорошего дня!")

    body = "\n".join(lines)

    # краткое LLM-резюме сверху (необязательное — при лимитах пропускаем)
    try:
        from gigapost.llm.factory import get_llm
        summary = get_llm("classify").invoke(
            "Сожми этот дайджест почтового ассистента в 2-3 предложения по-русски: "
            "самое важное и что сделать в первую очередь.\n\n" + body)
        text = summary.content if hasattr(summary, "content") else str(summary)
        body = f"> {text.strip()}\n\n" + body
    except Exception as e:  # noqa: BLE001
        logger.debug("LLM-резюме дайджеста пропущено: %s", e)

    repos.digests.save(day, body)
    return body


def build_weekly(repos: Repos, now: datetime | None = None) -> str:
    """Еженедельный отчёт по проектам: что сдвинулось, что застряло, у кого мяч."""
    now = now or datetime.now()
    week_ago = (now - timedelta(days=7)).isoformat()
    key = now.strftime("%Y-W%W")

    lines = [f"# Неделя {now.strftime('%W')} ({(now - timedelta(days=7)).strftime('%d.%m')}"
             f"–{now.strftime('%d.%m')})", ""]

    projects = [r["project"] for r in repos.db.query(
        """SELECT DISTINCT COALESCE(NULLIF(project, ''), 'Без проекта') AS project
           FROM tasks WHERE status != 'cancelled'""")]
    for project in sorted(projects):
        cond = "COALESCE(NULLIF(project, ''), 'Без проекта') = ?"
        done = [dict(r) for r in repos.db.query(
            f"""SELECT title FROM tasks WHERE {cond} AND status='done'
                AND COALESCE(completed_at, created_at) >= ? LIMIT 8""",
            (project, week_ago))]
        created = [dict(r) for r in repos.db.query(
            f"""SELECT title FROM tasks WHERE {cond} AND created_at >= ?
                AND status != 'cancelled' LIMIT 8""", (project, week_ago))]
        stalled = [dict(r) for r in repos.db.query(
            f"""SELECT title, due_date FROM tasks WHERE {cond} AND status='open'
                AND created_at < ? LIMIT 8""", (project, week_ago))]
        if not (done or created or stalled):
            continue
        lines.append(f"## {project}")
        for t in done:
            lines.append(f"- ✅ сделано: {t['title'][:90]}")
        for t in created:
            lines.append(f"- ➕ новое: {t['title'][:90]}")
        for t in stalled:
            due = f" (срок {t['due_date'][:10]})" if t.get("due_date") else ""
            lines.append(f"- 🧊 открыта дольше недели: {t['title'][:90]}{due}")
        lines.append("")

    waiting = [dict(r) for r in repos.db.query(
        """SELECT description, counterparty, due_date FROM agreements
           WHERE direction='they_owe' AND status IN ('on_control','overdue')
           ORDER BY due_date IS NULL, due_date LIMIT 10""")]
    if waiting:
        lines.append("## Мяч у контрагентов")
        for a in waiting:
            due = f", срок {a['due_date'][:10]}" if a.get("due_date") else ""
            lines.append(f"- ⏳ {a['description'][:90]} ({a.get('counterparty') or '—'}{due})")
        lines.append("")

    we_owe = [dict(r) for r in repos.db.query(
        """SELECT description, counterparty, due_date FROM agreements
           WHERE direction='we_owe' AND status IN ('on_control','overdue')
           ORDER BY due_date IS NULL, due_date LIMIT 10""")]
    if we_owe:
        lines.append("## Мяч у нас")
        for a in we_owe:
            due = f", срок {a['due_date'][:10]}" if a.get("due_date") else ""
            lines.append(f"- 🎯 {a['description'][:90]} (для {a.get('counterparty') or '—'}{due})")
        lines.append("")

    if len(lines) <= 2:
        lines.append("За неделю движения по проектам не зафиксировано.")
    body = "\n".join(lines)

    try:
        from gigapost.llm.factory import get_llm
        summary = get_llm("classify").invoke(
            "Сожми недельный отчёт в 2-3 предложения по-русски: главные сдвиги "
            "и главные риски.\n\n" + body[:5000])
        text = summary.content if hasattr(summary, "content") else str(summary)
        body = f"> {text.strip()}\n\n" + body
    except Exception as e:  # noqa: BLE001
        logger.debug("LLM-резюме недельного отчёта пропущено: %s", e)

    repos.digests.save(key, body)
    try:
        from gigapost import notify
        notify.send("📊 Еженедельный отчёт по проектам готов: "
                    "http://127.0.0.1:8765/digest")
    except Exception:  # noqa: BLE001
        pass
    return body
