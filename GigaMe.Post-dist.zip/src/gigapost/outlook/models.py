"""Чистые Python-модели данных Outlook. COM-объекты за пределы воркера не выходят."""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class EmailMessage:
    message_id: str            # Internet Message-ID — стабильный первичный ключ
    entry_id: str              # Outlook EntryID (меняется при перемещении!)
    conversation_id: str
    subject: str
    sender_name: str
    sender_email: str
    recipients: list[str] = field(default_factory=list)
    received_at: str = ""      # ISO8601
    body_text: str = ""
    folder: str = ""
    has_attachments: bool = False
    attachment_names: list[str] = field(default_factory=list)
    attachment_paths: list[str] = field(default_factory=list)  # сохранённые на диск файлы
