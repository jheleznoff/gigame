"""Высокоуровневый клиент Outlook. Все методы — обёртки над ComWorker.submit().

При dry_run=True мутирующие методы ничего не делают в Outlook, а только
возвращают описание намерения (логируется вызывающей стороной).
Чтение работает по-настоящему всегда.
"""

from __future__ import annotations

import logging
from datetime import datetime, timedelta
from typing import Any

from bs4 import BeautifulSoup

from gigapost.outlook.com_worker import ComWorker
from gigapost.outlook.models import EmailMessage

logger = logging.getLogger(__name__)

OL_MAIL_ITEM_CLASS = 43        # olMail
OL_TASK_ITEM = 3               # olTaskItem
OL_FOLDER_INBOX = 6            # olFolderInbox
OL_FOLDER_TASKS = 13           # olFolderTasks

PR_INTERNET_MESSAGE_ID = "http://schemas.microsoft.com/mapi/proptag/0x1035001F"
PR_SMTP_ADDRESS = "http://schemas.microsoft.com/mapi/proptag/0x39FE001F"

CATEGORY_COLORS = {
    "olCategoryColorRed": 1, "olCategoryColorOrange": 2, "olCategoryColorPeach": 3,
    "olCategoryColorYellow": 4, "olCategoryColorGreen": 5, "olCategoryColorTeal": 6,
    "olCategoryColorOlive": 7, "olCategoryColorBlue": 8, "olCategoryColorPurple": 9,
    "olCategoryColorMaroon": 10,
}


def _restrict_date(dt: datetime) -> str:
    """Items.Restrict требует американский формат даты независимо от локали."""
    return dt.strftime("%m/%d/%Y %I:%M %p")


def _is_excluded_store(name: str) -> bool:
    from gigapost.config import settings

    low = (name or "").lower()
    return any(x.lower() in low for x in settings.polling.exclude_stores if x)


def _resolve_store(ns, prefer: str | None = None):
    """Выбрать хранилище: явное предпочтение → настройка polling.store →
    'auto' (первый ящик с «@» в имени). Исключённые хранилища не выбираются."""
    from gigapost.config import settings

    preference = (prefer or settings.polling.store or "auto").lower()
    stores = [s for s in ns.Stores if not _is_excluded_store(str(s.DisplayName))]
    if preference != "auto":
        for store in stores:
            if preference in str(store.DisplayName).lower():
                return store
    for store in stores:
        if "@" in str(store.DisplayName):
            return store
    return ns.DefaultStore


def _store_inbox(ns, prefer: str | None = None):
    return _resolve_store(ns, prefer).GetDefaultFolder(OL_FOLDER_INBOX)


OL_FOLDER_SENT = 5             # olFolderSentMail


def _get_folder_by_path(ns, path: str, store: str | None = None):
    """Найти папку по пути вида 'Inbox' или 'GigaPost/Проекты' (относительно корня
    ящика). store — подстрока имени хранилища (для архивов и второго ящика)."""
    if path.lower() == "inbox":
        return _store_inbox(ns, store)
    if path.lower() in ("sent", "отправленные"):
        return _resolve_store(ns, store).GetDefaultFolder(OL_FOLDER_SENT)
    root = _resolve_store(ns, store).GetRootFolder()
    folder = root
    for part in path.replace("\\", "/").split("/"):
        folder = folder.Folders[part]
    return folder


def _ensure_folder_by_path(ns, path: str):
    if path.lower() == "inbox":
        return _store_inbox(ns)
    root = _resolve_store(ns).GetRootFolder()
    folder = root
    for part in path.replace("\\", "/").split("/"):
        try:
            folder = folder.Folders[part]
        except Exception:
            folder = folder.Folders.Add(part)
    return folder


def _sender_smtp(item) -> tuple[str, str]:
    """(имя, SMTP-адрес) отправителя; для Exchange-отправителей достаём реальный SMTP.

    Доступ к адресам может блокировать Object Model Guard (корп-политика) —
    тогда возвращаем пустые строки, письмо всё равно сохраняется."""
    try:
        name = getattr(item, "SenderName", "") or ""
    except Exception:  # noqa: BLE001 — com_error E_ABORT при запрете политикой
        name = ""
    try:
        email = getattr(item, "SenderEmailAddress", "") or ""
    except Exception:  # noqa: BLE001
        email = ""
    try:
        if getattr(item, "SenderEmailType", "") == "EX":
            sender = item.Sender
            if sender is not None:
                exch = sender.GetExchangeUser()
                if exch is not None and exch.PrimarySmtpAddress:
                    email = exch.PrimarySmtpAddress
    except Exception:
        try:
            email = item.PropertyAccessor.GetProperty(PR_SMTP_ADDRESS) or email
        except Exception:
            pass
    return name, email


def _recipients_smtp(item) -> list[str]:
    result = []
    try:
        for r in item.Recipients:
            addr = r.Address or ""
            try:
                if getattr(r, "AddressEntry", None) is not None:
                    exch = r.AddressEntry.GetExchangeUser()
                    if exch is not None and exch.PrimarySmtpAddress:
                        addr = exch.PrimarySmtpAddress
            except Exception:
                pass
            result.append(addr)
    except Exception:
        pass
    return result


def _extract_body(item) -> str:
    try:
        body = getattr(item, "Body", "") or ""
    except Exception:  # noqa: BLE001 — Body может блокировать Object Model Guard
        body = ""
    if body.strip():
        return body
    try:
        html = getattr(item, "HTMLBody", "") or ""
    except Exception:  # noqa: BLE001
        html = ""
    if html:
        return BeautifulSoup(html, "html.parser").get_text(separator="\n")
    return ""


def _safe_dirname(message_id: str) -> str:
    return "".join(c if c.isalnum() or c in "-_." else "_" for c in message_id)[:120]


# мелкие картинки — почти всегда логотипы и подписи, их не храним
_JUNK_IMAGE_EXT = {".png", ".jpg", ".jpeg", ".gif", ".bmp", ".ico"}
_JUNK_IMAGE_MAX_BYTES = 150 * 1024


def _save_attachments(item, message_id: str, save_dir,
                      received_ym: str = "") -> tuple[list[str], list[str]]:
    """Сохранить вложения на диск в data/attachments/ГГГГ-ММ/<письмо>/.

    Храним все файлы (библиотека вложений), кроме мелких картинок-подписей
    и файлов больше лимита. Возвращает (имена всех, пути сохранённых)."""
    from gigapost.attachments.extractor import MAX_ATTACHMENT_MB

    names: list[str] = []
    paths: list[str] = []
    try:
        for a in item.Attachments:
            fname = a.FileName or ""
            if not fname:
                continue
            names.append(fname)
            ext = "." + fname.rsplit(".", 1)[-1].lower() if "." in fname else ""
            try:
                if a.Size > MAX_ATTACHMENT_MB * 1024 * 1024:
                    continue
                if ext in _JUNK_IMAGE_EXT and a.Size < _JUNK_IMAGE_MAX_BYTES:
                    continue
                target_dir = save_dir
                if received_ym:
                    target_dir = target_dir / received_ym
                target_dir = target_dir / _safe_dirname(message_id)
                target_dir.mkdir(parents=True, exist_ok=True)
                target = target_dir / fname
                if not target.exists():
                    a.SaveAsFile(str(target))
                paths.append(str(target))
            except Exception:  # noqa: BLE001 — одно битое вложение не мешает остальным
                continue
    except Exception:  # noqa: BLE001
        pass
    return names, paths


def _item_to_email(item, folder_name: str, attachments_dir=None) -> EmailMessage | None:
    if getattr(item, "Class", None) != OL_MAIL_ITEM_CLASS:
        return None
    try:
        message_id = item.PropertyAccessor.GetProperty(PR_INTERNET_MESSAGE_ID) or ""
    except Exception:
        message_id = ""
    if not message_id:
        # Черновики/некоторые внутренние письма без Message-ID — используем EntryID
        message_id = f"entryid:{item.EntryID}"
    name, email = _sender_smtp(item)
    received = item.ReceivedTime
    received_iso = datetime(
        received.year, received.month, received.day,
        received.hour, received.minute, received.second,
    ).isoformat()
    attachments: list[str] = []
    saved_paths: list[str] = []
    if attachments_dir is not None:
        attachments, saved_paths = _save_attachments(
            item, message_id, attachments_dir, received_ym=received_iso[:7])
    else:
        try:
            attachments = [a.FileName for a in item.Attachments]
        except Exception:
            pass
    return EmailMessage(
        message_id=message_id,
        entry_id=item.EntryID,
        conversation_id=getattr(item, "ConversationID", "") or "",
        subject=item.Subject or "",
        sender_name=name,
        sender_email=email,
        recipients=_recipients_smtp(item),
        received_at=received_iso,
        body_text=_extract_body(item),
        folder=folder_name,
        has_attachments=bool(attachments),
        attachment_names=attachments,
        attachment_paths=saved_paths,
    )


class OutlookClient:
    def __init__(self, worker: ComWorker, dry_run: bool = True):
        self.worker = worker
        self.dry_run = dry_run

    # ---------- чтение ----------

    def get_outlook_version(self) -> str:
        return self.worker.submit(lambda outlook, ns: str(outlook.Version))

    def fetch_new_emails(self, folder_path: str, since: datetime,
                         max_items: int = 200, store: str | None = None,
                         until: datetime | None = None,
                         save_attachments: bool = True) -> list[EmailMessage]:
        from gigapost.config import DATA_DIR

        attachments_dir = (DATA_DIR / "attachments") if save_attachments else None

        def fn(outlook, ns):
            folder = _get_folder_by_path(ns, folder_path, store)
            items = folder.Items
            items.Sort("[ReceivedTime]", True)
            query = f"[ReceivedTime] >= '{_restrict_date(since)}'"
            if until is not None:
                query += f" AND [ReceivedTime] < '{_restrict_date(until)}'"
            restricted = items.Restrict(query)
            result = []
            errors = 0
            first_error: Exception | None = None
            for item in restricted:
                try:
                    email = _item_to_email(item, folder_path, attachments_dir)
                except Exception as e:  # noqa: BLE001 — одно битое письмо не валит окно
                    errors += 1
                    if first_error is None:
                        first_error = e
                    continue
                if email is not None:
                    result.append(email)
                if len(result) >= max_items:
                    break
            if errors:
                logger.warning("%s: пропущено %d писем (первая ошибка: %s)",
                               folder_path, errors, first_error)
            return result

        return self.worker.submit(fn, timeout=600)

    def list_stores(self) -> list[dict]:
        """Все хранилища профиля с пометкой исключённых."""
        def fn(outlook, ns):
            result = []
            for s in ns.Stores:
                name = str(s.DisplayName)
                result.append({"name": name, "excluded": _is_excluded_store(name)})
            return result

        return self.worker.submit(fn)

    def list_mail_folders(self, store: str) -> list[str]:
        """Пути почтовых папок хранилища (для обхода при бэкфилле)."""
        skip = {"календарь", "contacts", "контакты", "задачи", "tasks", "заметки",
                "notes", "дневник", "journal", "черновики", "drafts", "исходящие",
                "outbox", "удаленные", "deleted items", "корзина", "спам",
                "нежелательная почта", "junk", "junk e-mail", "rss-каналы",
                "ошибки синхронизации", "sync issues", "conversation action settings",
                "quick step settings", "настройка действий беседы",
                "настройка быстрых действий"}

        def fn(outlook, ns):
            root = _resolve_store(ns, store).GetRootFolder()
            paths: list[str] = []

            def walk(folder, prefix):
                for sub in folder.Folders:
                    name = str(sub.Name)
                    try:
                        if sub.DefaultItemType != 0:   # 0 = olMailItem
                            continue                    # календари, контакты и т.п.
                    except Exception:  # noqa: BLE001
                        pass
                    if name.lower() in skip or any(
                            name.lower().startswith(s) for s in skip):
                        continue
                    p = f"{prefix}/{name}" if prefix else name
                    paths.append(p)
                    walk(sub, p)

            walk(root, "")
            return paths

        return self.worker.submit(fn, timeout=300)

    def list_folders(self) -> list[str]:
        def fn(outlook, ns):
            root = _resolve_store(ns).GetRootFolder()
            paths: list[str] = []

            def walk(folder, prefix):
                for sub in folder.Folders:
                    p = f"{prefix}/{sub.Name}" if prefix else sub.Name
                    paths.append(p)
                    walk(sub, p)

            walk(root, "")
            return paths

        return self.worker.submit(fn)

    # ---------- мутации (уважают dry_run) ----------

    def register_categories(self, categories: dict[str, str | None]) -> None:
        """Зарегистрировать категории Outlook с цветами. {имя: olCategoryColor*|None}"""
        if self.dry_run:
            return

        def fn(outlook, ns):
            existing = {c.Name for c in ns.Categories}
            for name, color in categories.items():
                if name and name not in existing:
                    ns.Categories.Add(name, CATEGORY_COLORS.get(color or "", 1))

        self.worker.submit(fn)

    def ensure_folder(self, folder_path: str) -> None:
        """Создать папку (и всех родителей по пути), если её нет."""
        if self.dry_run:
            return
        self.worker.submit(lambda outlook, ns: _ensure_folder_by_path(ns, folder_path) and None)

    def move_email(self, entry_id: str, folder_path: str) -> str:
        """Переместить письмо; возвращает НОВЫЙ EntryID (меняется при Move)."""
        if self.dry_run:
            return entry_id

        def fn(outlook, ns):
            item = ns.GetItemFromID(entry_id)
            target = _ensure_folder_by_path(ns, folder_path)
            moved = item.Move(target)
            return moved.EntryID

        return self.worker.submit(fn)

    def set_category(self, entry_id: str, category: str) -> None:
        if self.dry_run:
            return

        def fn(outlook, ns):
            item = ns.GetItemFromID(entry_id)
            current = [c.strip() for c in (item.Categories or "").split(",") if c.strip()]
            if category not in current:
                current.append(category)
                item.Categories = ", ".join(current)
                item.Save()

        self.worker.submit(fn)

    def set_flag(self, entry_id: str, due: datetime | None = None) -> None:
        if self.dry_run:
            return

        def fn(outlook, ns):
            item = ns.GetItemFromID(entry_id)
            item.FlagRequest = "К исполнению"
            if due is not None:
                item.TaskDueDate = due
                item.ReminderSet = True
                item.ReminderTime = due
            item.Save()

        self.worker.submit(fn)

    def create_task(self, subject: str, body: str = "", due: datetime | None = None,
                    reminder: datetime | None = None) -> str:
        """Создать задачу Outlook; возвращает EntryID ('' в dry-run)."""
        if self.dry_run:
            return ""

        def fn(outlook, ns):
            task = outlook.CreateItem(OL_TASK_ITEM)
            task.Subject = subject
            task.Body = body
            if due is not None:
                task.DueDate = due
            if reminder is not None:
                task.ReminderSet = True
                task.ReminderTime = reminder
            task.Save()
            return task.EntryID

        return self.worker.submit(fn)

    def complete_task(self, entry_id: str) -> None:
        if self.dry_run or not entry_id:
            return

        def fn(outlook, ns):
            task = ns.GetItemFromID(entry_id)
            task.MarkComplete()

        self.worker.submit(fn)

    def delete_email(self, entry_id: str) -> None:
        """Мягкое удаление: Outlook перемещает письмо в «Удалённые»."""
        if self.dry_run:
            return

        def fn(outlook, ns):
            ns.GetItemFromID(entry_id).Delete()

        self.worker.submit(fn)

    def create_reply_draft(self, entry_id: str, body: str) -> bool:
        """Создать ЧЕРНОВИК ответа на письмо (сохраняется в «Черновики»,
        НЕ отправляется). Возвращает True при успехе."""
        if self.dry_run:
            return False

        def fn(outlook, ns):
            item = ns.GetItemFromID(entry_id)
            reply = item.Reply()
            reply.Body = body + "\n\n" + (reply.Body or "")
            reply.Save()  # Save, не Send — письмо остаётся в черновиках
            return True

        return self.worker.submit(fn)

    # ---------- UI-хелперы (не мутации, dry_run не касается) ----------

    def display_email(self, entry_id: str) -> None:
        """Открыть письмо в окне Outlook (кнопка «открыть в Outlook» в UI)."""
        self.worker.submit(lambda outlook, ns: ns.GetItemFromID(entry_id).Display())


class NullOutlookClient:
    """Заглушка на случай недоступного Outlook: чтение пустое, мутации no-op.
    Позволяет запускать веб-UI и агента без Outlook (например, при разработке)."""

    dry_run = True

    def get_outlook_version(self) -> str:
        return "недоступен"

    def fetch_new_emails(self, folder_path: str, since: datetime,
                         max_items: int = 200) -> list[EmailMessage]:
        return []

    def list_folders(self) -> list[str]:
        return []

    def register_categories(self, categories) -> None:
        pass

    def ensure_folder(self, folder_path: str) -> None:
        pass

    def move_email(self, entry_id: str, folder_path: str) -> str:
        return entry_id

    def set_category(self, entry_id: str, category: str) -> None:
        pass

    def set_flag(self, entry_id: str, due: datetime | None = None) -> None:
        pass

    def create_task(self, subject: str, body: str = "", due: datetime | None = None,
                    reminder: datetime | None = None) -> str:
        return ""

    def complete_task(self, entry_id: str) -> None:
        pass

    def delete_email(self, entry_id: str) -> None:
        pass

    def create_reply_draft(self, entry_id: str, body: str) -> bool:
        return False

    def display_email(self, entry_id: str) -> None:
        raise RuntimeError("Outlook недоступен")
