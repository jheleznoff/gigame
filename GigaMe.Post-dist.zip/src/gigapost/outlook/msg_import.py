"""Импорт писем из .msg-файлов (файловый шлюз в обход Object Model Guard).

VBA-макрос внутри Outlook (vba/GigaMePost_Export.bas) выгружает письма в
%USERPROFILE%\\GigaMePost_Export\\<папка>\\*.msg — макросу политика доверяет.
Здесь эти файлы разбираются (extract-msg) и попадают в базу: либо просто
заливка (бэкфилл истории), либо через полный пайплайн (новые письма).

Обработанные файлы переезжают в подпапку imported/ рядом с исходной.
"""

from __future__ import annotations

import hashlib
import logging
import re
from datetime import datetime
from pathlib import Path

from gigapost.outlook.client import (_JUNK_IMAGE_EXT, _JUNK_IMAGE_MAX_BYTES,
                                     _safe_dirname)
from gigapost.outlook.models import EmailMessage

logger = logging.getLogger(__name__)

DEFAULT_EXPORT_DIR = Path.home() / "GigaMePost_Export"

_EMAIL_RE = re.compile(r"[\w.+-]+@[\w-]+\.[\w.-]+")

# имена подпапок из VBA-макроса → папка в нашей БД
_FOLDER_ALIASES = {
    "_inbox_stream": "Inbox",
    "_sent_stream": "Sent",
    "sent items": "Sent", "sent": "Sent", "отправленные": "Sent",
    "inbox": "Inbox", "входящие": "Inbox",
}


def _fix_mojibake(s: str) -> str:
    """Починить cp1251-текст, ошибочно прочитанный как latin-1/cp1252.

    «Ìàêñ, ïðèâåò» → «Макс, привет». Срабатывает только когда строка
    почти целиком из латиницы с диакритикой и почти без кириллицы."""
    if not s:
        return s
    sample = s[:4000]
    weird = sum(1 for ch in sample if "À" <= ch <= "ÿ")
    cyr = sum(1 for ch in sample if "Ѐ" <= ch <= "ӿ")
    if weird < 8 or weird <= 3 * (cyr + 1):
        return s
    for enc in ("latin-1", "cp1252"):
        try:
            fixed = s.encode(enc).decode("cp1251")
        except (UnicodeEncodeError, UnicodeDecodeError):
            continue
        if sum(1 for ch in fixed[:4000] if "Ѐ" <= ch <= "ӿ") > weird // 2:
            return fixed
    return s


def _split_sender(raw: str) -> tuple[str, str]:
    """'Иванов Иван <i@x.ru>' → ('Иванов Иван', 'i@x.ru')."""
    raw = (raw or "").strip()
    m = _EMAIL_RE.search(raw)
    email = m.group(0) if m else ""
    name = raw.replace(f"<{email}>", "").strip(" \"'<>") if email else raw
    return name, email


def parse_msg(path: Path, attachments_dir: Path | None) -> EmailMessage | None:
    """Разобрать .msg в EmailMessage; вложения сохраняются на диск."""
    import extract_msg

    msg = extract_msg.openMsg(str(path))
    try:
        if not hasattr(msg, "subject"):
            return None
        subject = _fix_mojibake(msg.subject or "")
        sender_name, sender_email = _split_sender(
            _fix_mojibake(getattr(msg, "sender", "") or ""))
        recipients = _EMAIL_RE.findall(
            f"{getattr(msg, 'to', '') or ''}; {getattr(msg, 'cc', '') or ''}")

        date = getattr(msg, "date", None)
        if isinstance(date, datetime):
            received_iso = date.astimezone().replace(tzinfo=None).isoformat()
        else:
            # запасной вариант: дата из имени файла yyyymmdd_hhnnss_...
            m = re.match(r"(\d{8})_(\d{6})", path.stem)
            if m:
                received_iso = datetime.strptime(
                    m.group(1) + m.group(2), "%Y%m%d%H%M%S").isoformat()
            else:
                received_iso = datetime.now().isoformat()

        message_id = (getattr(msg, "messageId", None) or "").strip("<> ")
        if not message_id:
            digest = hashlib.sha1(
                f"{received_iso}|{subject}|{sender_email}".encode()).hexdigest()
            message_id = f"msgfile:{digest}"

        body = _fix_mojibake(msg.body or "")
        if not body.strip() and getattr(msg, "htmlBody", None):
            from bs4 import BeautifulSoup
            html = msg.htmlBody
            if isinstance(html, bytes):
                m = re.search(rb"charset=[\"']?([\w-]+)", html[:4096], re.IGNORECASE)
                enc = m.group(1).decode("ascii", errors="ignore") if m else "utf-8"
                try:
                    html = html.decode(enc, errors="ignore")
                except LookupError:
                    html = html.decode("utf-8", errors="ignore")
            body = _fix_mojibake(
                BeautifulSoup(html, "html.parser").get_text(separator="\n"))

        names: list[str] = []
        paths: list[str] = []
        for a in getattr(msg, "attachments", []) or []:
            fname = _fix_mojibake(getattr(a, "longFilename", None) or getattr(
                a, "shortFilename", None) or "")
            data = getattr(a, "data", None)
            if not fname or not isinstance(data, bytes):
                continue   # вложенные письма и прочая экзотика — пропускаем
            names.append(fname)
            if attachments_dir is None:
                continue
            ext = "." + fname.rsplit(".", 1)[-1].lower() if "." in fname else ""
            from gigapost.attachments.extractor import MAX_ATTACHMENT_MB
            if len(data) > MAX_ATTACHMENT_MB * 1024 * 1024:
                continue
            if ext in _JUNK_IMAGE_EXT and len(data) < _JUNK_IMAGE_MAX_BYTES:
                continue
            try:
                target_dir = (attachments_dir / received_iso[:7]
                              / _safe_dirname(message_id))
                target_dir.mkdir(parents=True, exist_ok=True)
                target = target_dir / fname
                if not target.exists():
                    target.write_bytes(data)
                paths.append(str(target))
            except Exception:  # noqa: BLE001
                continue

        return EmailMessage(
            message_id=message_id,
            entry_id="",
            conversation_id="",
            subject=subject,
            sender_name=sender_name,
            sender_email=sender_email,
            recipients=recipients,
            received_at=received_iso,
            body_text=body,
            folder="Inbox",
            has_attachments=bool(names),
            attachment_names=names,
            attachment_paths=paths,
        )
    finally:
        try:
            msg.close()
        except Exception:  # noqa: BLE001
            pass


def _folder_for_subdir(name: str) -> str:
    return _FOLDER_ALIASES.get(name.lower(), name)


def _store_attachments(repos, em: EmailMessage) -> None:
    """Разобрать сохранённые вложения в таблицу attachments (текст + хеш)."""
    from gigapost.attachments.extractor import extract_text, is_supported

    saved = {Path(p).name: p for p in em.attachment_paths}
    for fname in em.attachment_names:
        p = saved.get(fname)
        ext = Path(fname).suffix.lower()
        if p is None or not Path(p).exists():
            repos.attachments.upsert(
                em.message_id, fname, ext, None, None, None, "unsupported")
            continue
        try:
            data = Path(p).read_bytes()
            sha = hashlib.sha256(data).hexdigest()
            text = extract_text(p) if is_supported(fname) else None
            status = "parsed" if text else "stored"
            repos.attachments.upsert(
                em.message_id, fname, ext, len(data), p, text, status, sha)
        except Exception:  # noqa: BLE001
            continue


def _update_content(repos, em: EmailMessage) -> None:
    """Обновить содержимое уже существующей записи (переимпорт после фиксов)."""
    import json

    repos.db.execute(
        """UPDATE emails SET subject=?, sender_name=?, sender_email=?,
             recipients_json=?, body_text=?, has_attachments=?, attachment_names=?
           WHERE message_id=?""",
        (em.subject, em.sender_name, em.sender_email,
         json.dumps(em.recipients, ensure_ascii=False), em.body_text,
         int(em.has_attachments),
         json.dumps(em.attachment_names, ensure_ascii=False), em.message_id))


def import_dir(repos, base_dir: Path | str | None = None, graph=None,
               limit: int | None = None, reimport: bool = False) -> dict:
    """Импортировать все .msg из base_dir (рекурсивно, кроме imported/).

    graph=None — просто заливка в БД (история, как стадия A бэкфилла);
    graph=<ingest-граф> — каждое письмо через полный пайплайн
    (классификация, задачи, знания) — для новых писем из авто-выгрузки.
    reimport=True — пройти и по imported/, обновляя содержимое существующих
    записей (после исправлений парсера, например кодировки).
    """
    from gigapost.config import DATA_DIR

    base = Path(base_dir) if base_dir else DEFAULT_EXPORT_DIR
    stats = {"imported": 0, "updated": 0, "skipped": 0, "errors": 0}
    if not base.exists():
        return stats
    attachments_dir = DATA_DIR / "attachments"

    files = sorted(base.rglob("*.msg"))
    if not reimport:
        files = [p for p in files if "imported" not in p.parts]
    if limit:
        files = files[:limit]
    for path in files:
        try:
            em = parse_msg(path, attachments_dir)
        except Exception as e:  # noqa: BLE001 — битый файл не валит импорт
            logger.warning("Не разобрался %s: %s", path.name, e)
            stats["errors"] += 1
            continue
        done_dir = path.parent if path.parent.name == "imported" \
            else path.parent / "imported"
        if em is None:
            stats["skipped"] += 1
        elif repos.emails.exists(em.message_id):
            if reimport:
                _update_content(repos, em)
                stats["updated"] += 1
            else:
                stats["skipped"] += 1
        else:
            subdir = (path.parent.parent.name if path.parent.name == "imported"
                      else path.parent.name)
            em.folder = _folder_for_subdir(subdir)
            repos.emails.upsert(em)
            if graph is not None and em.folder != "Sent":
                try:
                    graph.invoke({"email": em})
                except Exception as e:  # noqa: BLE001
                    logger.exception("Пайплайн для %s: %s", em.message_id, e)
                    repos.log.log(em.message_id, "pipeline", "error", str(e))
            else:
                if em.attachment_names:
                    _store_attachments(repos, em)
            stats["imported"] += 1
        if done_dir != path.parent:
            try:
                done_dir.mkdir(exist_ok=True)
                path.rename(done_dir / path.name)
            except Exception:  # noqa: BLE001 — файл занят? возьмём в следующий раз
                pass
    now = datetime.now().isoformat()
    repos.settings.set("msg_import:last_scan_at", now)
    if stats["imported"] or stats["updated"]:
        repos.settings.set("msg_import:last_file_at", now)
    if stats["imported"] or stats["updated"] or stats["errors"]:
        logger.info("Импорт .msg: %s", stats)
    return stats
