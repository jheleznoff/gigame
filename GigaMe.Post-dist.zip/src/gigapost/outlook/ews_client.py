"""Чтение почты через EWS (Exchange Web Services).

Корпоративная политика Outlook (Object Model Guard) блокирует COM-доступ
к телу письма и адресам (E_ABORT «Операция прервана»). EWS — серверный API
Exchange с обычной аутентификацией пользователя, на него эта политика не
распространяется. EwsClient повторяет читающий интерфейс OutlookClient
(fetch_new_emails / list_mail_folders / list_stores); мутации (папки, задачи,
черновики) остаются на COM — их политика не блокирует.

Настройка в .env: EWS_ENDPOINT, EWS_EMAIL, EWS_PASSWORD (+EWS_USERNAME,
если логин отличается от почты).
"""

from __future__ import annotations

import logging
from datetime import datetime

from gigapost.outlook.client import (_JUNK_IMAGE_EXT, _JUNK_IMAGE_MAX_BYTES,
                                     _is_excluded_store, _safe_dirname)
from gigapost.outlook.models import EmailMessage

logger = logging.getLogger(__name__)

# непочтовые/служебные папки — как в COM-клиенте
_SKIP_FOLDERS = {"календарь", "calendar", "contacts", "контакты", "задачи", "tasks",
                 "заметки", "notes", "дневник", "journal", "черновики", "drafts",
                 "исходящие", "outbox", "удаленные", "deleted items", "корзина",
                 "спам", "нежелательная почта", "junk", "junk e-mail", "rss-каналы",
                 "ошибки синхронизации", "sync issues", "conversation action settings",
                 "quick step settings", "настройка действий беседы",
                 "настройка быстрых действий", "externalcontacts"}


class EwsClient:
    """Читающий клиент Exchange. Потокобезопасен (в отличие от COM)."""

    def __init__(self):
        from exchangelib import DELEGATE, Account, Configuration, Credentials

        from gigapost.config import settings

        if not settings.ews_verify_ssl:
            import urllib3
            from exchangelib.protocol import BaseProtocol, NoVerifyHTTPAdapter
            BaseProtocol.HTTP_ADAPTER_CLS = NoVerifyHTTPAdapter
            urllib3.disable_warnings()

        creds = Credentials(settings.ews_username or settings.ews_email,
                            settings.ews_password)
        config = Configuration(service_endpoint=settings.ews_endpoint,
                               credentials=creds)
        self.account = Account(primary_smtp_address=settings.ews_email,
                               config=config, autodiscover=False,
                               access_type=DELEGATE)
        logger.info("EWS подключён: %s (%s)", settings.ews_email,
                    self.account.version)

    # ---------- интерфейс, совместимый с OutlookClient (чтение) ----------

    def get_outlook_version(self) -> str:
        return f"EWS {self.account.version}"

    def _root_for_store(self, store: str | None):
        s = (store or "").lower()
        if "арх" in s or "arch" in s:
            return self.account.archive_msg_folder_root
        return self.account.msg_folder_root

    def list_stores(self) -> list[dict]:
        primary = str(self.account.primary_smtp_address)
        stores = [{"name": primary, "excluded": _is_excluded_store(primary)}]
        try:
            self.account.archive_msg_folder_root.refresh()
            stores.append({"name": "Архив (Online)", "excluded": False})
        except Exception:  # noqa: BLE001 — онлайн-архива может не быть
            pass
        return stores

    def list_mail_folders(self, store: str | None = None) -> list[str]:
        root = self._root_for_store(store)
        paths: list[str] = []

        def walk(folder, prefix: str) -> None:
            for sub in folder.children:
                name = str(sub.name)
                low = name.lower()
                fclass = getattr(sub, "folder_class", None) or "IPF.Note"
                if not fclass.startswith("IPF.Note"):
                    continue
                if low in _SKIP_FOLDERS or any(low.startswith(s) for s in _SKIP_FOLDERS):
                    continue
                p = f"{prefix}/{name}" if prefix else name
                paths.append(p)
                walk(sub, p)

        walk(root, "")
        return paths

    def _get_folder(self, path: str, store: str | None):
        low = path.lower()
        in_archive = "арх" in (store or "").lower() or "arch" in (store or "").lower()
        if low == "inbox" and not in_archive:
            return self.account.inbox
        if low in ("sent", "отправленные", "sent items") and not in_archive:
            return self.account.sent
        folder = self._root_for_store(store)
        for part in path.replace("\\", "/").split("/"):
            folder = folder / part
        return folder

    def fetch_new_emails(self, folder_path: str, since: datetime,
                         max_items: int = 200, store: str | None = None,
                         until: datetime | None = None,
                         save_attachments: bool = True) -> list[EmailMessage]:
        from gigapost.config import DATA_DIR

        attachments_dir = (DATA_DIR / "attachments") if save_attachments else None
        folder = self._get_folder(folder_path, store)
        tz = self.account.default_timezone
        start = since.replace(tzinfo=tz) if since.tzinfo is None else since
        qs = folder.all().filter(datetime_received__gte=start)
        if until is not None:
            end = until.replace(tzinfo=tz) if until.tzinfo is None else until
            qs = qs.filter(datetime_received__lt=end)
        qs = qs.order_by("-datetime_received")

        result: list[EmailMessage] = []
        errors = 0
        first_error: Exception | None = None
        for item in qs[:max_items]:
            try:
                email = self._to_email(item, folder_path, attachments_dir)
            except Exception as e:  # noqa: BLE001 — одно битое письмо не валит окно
                errors += 1
                if first_error is None:
                    first_error = e
                continue
            if email is not None:
                result.append(email)
        if errors:
            logger.warning("EWS %s: пропущено %d писем (первая ошибка: %s)",
                           folder_path, errors, first_error)
        return result

    # ---------- преобразование ----------

    def _to_email(self, item, folder_name: str,
                  attachments_dir) -> EmailMessage | None:
        from exchangelib.items import Message

        if not isinstance(item, Message):
            return None
        message_id = item.message_id or f"ewsid:{item.id}"
        sender = item.sender or item.author
        sender_name = getattr(sender, "name", "") or ""
        sender_email = getattr(sender, "email_address", "") or ""
        recipients = [m.email_address or "" for m in
                      (item.to_recipients or []) + (item.cc_recipients or [])]
        received = item.datetime_received
        received_iso = (received.astimezone().replace(tzinfo=None).isoformat()
                        if received else datetime.now().isoformat())

        body_text = item.text_body or ""
        if not body_text.strip() and item.body:
            from bs4 import BeautifulSoup
            body_text = BeautifulSoup(str(item.body), "html.parser").get_text(
                separator="\n")

        names: list[str] = []
        paths: list[str] = []
        for a in item.attachments or []:
            fname = getattr(a, "name", None)
            content = getattr(a, "content", None)   # FileAttachment
            if not fname or content is None:
                continue
            names.append(fname)
            if attachments_dir is None:
                continue
            ext = "." + fname.rsplit(".", 1)[-1].lower() if "." in fname else ""
            size = getattr(a, "size", None) or len(content)
            from gigapost.attachments.extractor import MAX_ATTACHMENT_MB
            if size > MAX_ATTACHMENT_MB * 1024 * 1024:
                continue
            if ext in _JUNK_IMAGE_EXT and size < _JUNK_IMAGE_MAX_BYTES:
                continue
            try:
                target_dir = (attachments_dir / received_iso[:7]
                              / _safe_dirname(message_id))
                target_dir.mkdir(parents=True, exist_ok=True)
                target = target_dir / fname
                if not target.exists():
                    target.write_bytes(content)
                paths.append(str(target))
            except Exception:  # noqa: BLE001
                continue

        return EmailMessage(
            message_id=message_id,
            entry_id=str(item.id or ""),
            conversation_id=(item.conversation_id.id
                             if item.conversation_id else "") or "",
            subject=item.subject or "",
            sender_name=sender_name,
            sender_email=sender_email,
            recipients=recipients,
            received_at=received_iso,
            body_text=body_text,
            folder=folder_name,
            has_attachments=bool(names),
            attachment_names=names,
            attachment_paths=paths,
        )


class HybridClient:
    """Чтение почты — EWS (мимо Object Model Guard), всё остальное — COM.

    Прозрачно подменяет OutlookClient: читающие методы уходят в EwsClient,
    мутации (папки, перемещение, задачи, черновики) и display — в COM.
    """

    _READ_METHODS = {"fetch_new_emails", "list_mail_folders", "list_stores"}

    def __init__(self, ews: EwsClient, com):
        self._ews = ews
        self._com = com

    def __getattr__(self, name):
        if name in HybridClient._READ_METHODS:
            return getattr(self._ews, name)
        return getattr(self._com, name)
