"""Единственный поток, владеющий COM-объектами Outlook.

COM-объекты pywin32 привязаны к STA-апартаменту создавшего их потока.
Flask-треды и джобы APScheduler НИКОГДА не вызывают COM напрямую — все
обращения сериализуются через очередь команд в этот выделенный поток.
Функции-команды принимают (outlook, namespace) и обязаны возвращать только
чистые Python-объекты (dataclasses, str, list) — COM-объекты не покидают поток.
"""

from __future__ import annotations

import logging
import queue
import threading
from concurrent.futures import Future
from typing import Any, Callable

logger = logging.getLogger(__name__)


class ComWorkerError(RuntimeError):
    pass


class ComWorker:
    def __init__(self):
        self._queue: queue.Queue = queue.Queue()
        self._thread: threading.Thread | None = None
        self._started = threading.Event()
        self._startup_error: BaseException | None = None

    def start(self, timeout: float = 30) -> None:
        self._thread = threading.Thread(target=self._run, daemon=True, name="com-worker")
        self._thread.start()
        if not self._started.wait(timeout):
            raise ComWorkerError("COM worker не запустился за отведённое время")
        if self._startup_error is not None:
            raise ComWorkerError(
                f"Не удалось подключиться к Outlook: {self._startup_error}. "
                "Убедитесь, что установлен классический десктопный Outlook "
                "(«новый Outlook» не поддерживает COM-автоматизацию)."
            ) from self._startup_error

    def _run(self) -> None:
        import pythoncom
        import win32com.client

        pythoncom.CoInitialize()
        outlook = ns = None
        try:
            try:
                outlook = win32com.client.Dispatch("Outlook.Application")
                ns = outlook.GetNamespace("MAPI")
            except BaseException as e:  # noqa: BLE001 — стартовую ошибку отдаём наружу
                self._startup_error = e
                return
            finally:
                self._started.set()

            logger.info("COM worker подключился к Outlook %s", outlook.Version)
            while True:
                fn, fut = self._queue.get()
                if fn is None:  # poison pill
                    break
                if fut.set_running_or_notify_cancel():
                    try:
                        fut.set_result(fn(outlook, ns))
                    except BaseException as e:  # noqa: BLE001
                        fut.set_exception(e)
        finally:
            ns = outlook = None
            pythoncom.CoUninitialize()

    def submit(self, fn: Callable[[Any, Any], Any], timeout: float = 120) -> Any:
        """Выполнить fn(outlook, namespace) в COM-потоке; блокирует до результата."""
        if self._thread is None or not self._thread.is_alive():
            raise ComWorkerError("COM worker не запущен")
        fut: Future = Future()
        self._queue.put((fn, fut))
        return fut.result(timeout=timeout)

    def stop(self) -> None:
        if self._thread is not None and self._thread.is_alive():
            self._queue.put((None, None))
            self._thread.join(timeout=10)
