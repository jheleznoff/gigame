"""Распознавание организационных писем о встречах (приглашения, принятия,
отклонения, переносы, отмены) — общий фильтр для пайплайна, бэкфилла,
обработчика отправленных и фокуса дня.

Итоги/протоколы встреч под фильтр не попадают — это знания.
"""

from __future__ import annotations

import re

SUBJECT_RE = re.compile(
    r"^(Приглашение|Принято|Условно принято|Отклонено|Предварительно принято|"
    r"Перенесено|Перенос|Отмена( встречи)?|Отменено|Предложено новое время|"
    r"Invitation|Accepted|Declined|Tentative|Cancell?ed|Updated invitation|"
    r"New Time Proposed|Meeting Forward Notification):",
    re.IGNORECASE)

BODY_RE = re.compile(
    r"Подключиться в браузере по ссылке|Номер конференции:|jazz\.sberbank\.ru|"
    r"Microsoft Teams meeting|Присоединиться к собранию|Join the meeting",
    re.IGNORECASE)


def is_meeting_email(subject: str | None, body: str | None = "") -> bool:
    """Организационное письмо о встрече (не содержательный итог)."""
    if SUBJECT_RE.search(subject or ""):
        return True
    return bool(BODY_RE.search((body or "")[:2000]))
