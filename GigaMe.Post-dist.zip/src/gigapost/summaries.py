"""Резюме тредов («о чём переписка, на чём остановились, мяч на чьей стороне»).

Резюме кэшируется в thread_summaries и пересчитывается только когда в треде
появилось новое письмо. «Мяч на чьей стороне» — детерминированно, без LLM.
"""

from __future__ import annotations

import logging
from datetime import datetime

from pydantic import BaseModel, Field

from gigapost.config import load_prompt
from gigapost.llm.structured import structured_call

logger = logging.getLogger(__name__)

MAX_CHRONO_CHARS = 4500   # хронология в промпт (лимит корп-API)


class ThreadSummary(BaseModel):
    """Резюме переписки."""

    summary: str = Field(description="2-4 предложения: о чём тред, что решено, "
                                     "что осталось открытым")
    waiting_for: str = Field(default="", description="Чего/от кого сейчас ждём, "
                                                     "одной фразой; пусто если ничего")


def ball_side(emails: list[dict]) -> dict:
    """Мяч на чьей стороне: последнее письмо моё → ждём их, иначе — ждут нас."""
    if not emails:
        return {}
    last = emails[-1]
    try:
        days = (datetime.now() - datetime.fromisoformat(last["received_at"])).days
    except (ValueError, TypeError, KeyError):
        days = 0
    if last.get("folder") == "Sent":
        return {"side": "them", "text": f"мяч у них — вы ответили {days} дн. назад"}
    return {"side": "us", "text": f"мяч у нас — их письмо ждёт {days} дн."}


def get_cached(repos, conversation_id: str) -> dict | None:
    row = repos.db.query_one(
        "SELECT * FROM thread_summaries WHERE conversation_id=?", (conversation_id,))
    return dict(row) if row else None


def is_stale(cached: dict | None, emails: list[dict]) -> bool:
    if not cached:
        return True
    last_at = max((e.get("received_at") or "" for e in emails), default="")
    return (cached.get("last_email_at") or "") < last_at


def refresh(repos, conversation_id: str, emails: list[dict]) -> dict:
    """Пересчитать резюме треда (один LLM-вызов) и закэшировать."""
    from gigapost.llm.factory import get_llm
    from gigapost.pipeline.nodes import clean_body

    lines = []
    used = 0
    for e in emails:
        who = "Я" if e.get("folder") == "Sent" else (
            e.get("sender_name") or e.get("sender_email") or "?")
        frag = clean_body(e.get("body_text") or "", 400)[:400]
        line = f"[{(e.get('received_at') or '')[:10]}] {who}: {frag}"
        if used + len(line) > MAX_CHRONO_CHARS:
            break
        lines.append(line)
        used += len(line)

    prompt = load_prompt("threadsum").format(
        subject=(emails[-1].get("subject") or "")[:100],
        chronology="\n".join(lines))
    result = structured_call(get_llm("extract"), ThreadSummary, prompt)
    summary = result.summary
    if result.waiting_for:
        summary += f"\n\n**Ждём:** {result.waiting_for}"
    last_at = max((e.get("received_at") or "" for e in emails), default="")
    repos.db.execute(
        """INSERT INTO thread_summaries (conversation_id, summary, last_email_at, updated_at)
           VALUES (?,?,?,?)
           ON CONFLICT(conversation_id) DO UPDATE SET
             summary=excluded.summary, last_email_at=excluded.last_email_at,
             updated_at=excluded.updated_at""",
        (conversation_id, summary, last_at, datetime.now().isoformat()))
    return get_cached(repos, conversation_id)


def email_context(repos, email: dict) -> dict:
    """Панель контекста письма: всё связанное, детерминированно (без LLM)."""
    conv = email.get("conversation_id") or ""
    message_id = email["message_id"]
    ctx: dict = {"thread_count": 0, "tasks": [], "agreements": [], "notes": [],
                 "entities": [], "attachments_thread": []}
    ids = [message_id]
    if conv:
        rows = repos.db.query(
            "SELECT message_id FROM emails WHERE conversation_id=?", (conv,))
        ids = [r["message_id"] for r in rows] or ids
        ctx["thread_count"] = len(ids)
    ph = ",".join("?" * len(ids))
    ctx["tasks"] = [dict(r) for r in repos.db.query(
        f"""SELECT * FROM tasks WHERE source_message_id IN ({ph})
            AND status != 'cancelled' ORDER BY status='done' LIMIT 8""", tuple(ids))]
    ctx["agreements"] = [dict(r) for r in repos.db.query(
        f"SELECT * FROM agreements WHERE source_message_id IN ({ph}) LIMIT 6",
        tuple(ids))]
    ctx["notes"] = [dict(r) for r in repos.db.query(
        f"SELECT * FROM notes WHERE source_message_id IN ({ph}) ORDER BY id DESC LIMIT 6",
        tuple(ids))]
    ctx["attachments_thread"] = [dict(r) for r in repos.db.query(
        f"""SELECT * FROM attachments WHERE message_id IN ({ph})
            AND message_id != ? AND path IS NOT NULL LIMIT 8""",
        (*ids, message_id))]
    ctx["entities"] = [dict(r) for r in repos.db.query(
        """SELECT DISTINCT en.id, en.name, en.type FROM entity_mentions m
           JOIN entities en ON en.id = m.entity_id
           WHERE m.message_id = ? LIMIT 10""", (message_id,))]
    return ctx
