"""Flask-приложение. Сборка всего процесса — в scripts/run_web.py."""

from __future__ import annotations

import secrets

from flask import Flask

from gigapost.web.routes.attachments import bp as attachments_bp
from gigapost.web.routes.chat import bp as chat_bp
from gigapost.web.routes.decisions import bp as decisions_bp
from gigapost.web.routes.search import bp as search_bp
from gigapost.web.routes.threads import bp as threads_bp
from gigapost.web.routes.dashboard import bp as dashboard_bp
from gigapost.web.routes.emails import bp as emails_bp
from gigapost.web.routes.graph import bp as graph_bp
from gigapost.web.routes.tasks import bp as tasks_bp


def create_app() -> Flask:
    from gigapost.config import settings

    app = Flask(__name__)
    app.secret_key = secrets.token_hex(16)

    @app.context_processor
    def inject_globals():
        return {"dry_run": settings.dry_run}

    app.register_blueprint(dashboard_bp)
    app.register_blueprint(chat_bp)
    app.register_blueprint(graph_bp)
    app.register_blueprint(emails_bp)
    app.register_blueprint(tasks_bp)
    app.register_blueprint(attachments_bp)
    app.register_blueprint(decisions_bp)
    app.register_blueprint(threads_bp)
    app.register_blueprint(search_bp)
    return app
