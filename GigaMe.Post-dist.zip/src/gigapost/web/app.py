"""Flask-приложение. Сборка всего процесса — в scripts/run_web.py."""

from __future__ import annotations

import secrets

from flask import Flask

from gigapost.web.routes.attachments import bp as attachments_bp
from gigapost.web.routes.chat import bp as chat_bp
from gigapost.web.routes.decisions import bp as decisions_bp
from gigapost.web.routes.search import bp as search_bp
from gigapost.web.routes.threads import bp as threads_bp
from gigapost.web.routes.dashboard import bp as dashboard_bp
from gigapost.web.routes.emails import bp as emails_bp
from gigapost.web.routes.graph import bp as graph_bp
from gigapost.web.routes.registry import bp as registry_bp
from gigapost.web.routes.tasks import bp as tasks_bp


def create_app() -> Flask:
    from gigapost.config import settings

    app = Flask(__name__)
    app.secret_key = secrets.token_hex(16)

    @app.context_processor
    def inject_globals():
        return {"dry_run": settings.dry_run}

    @app.template_filter("simple_md")
    def simple_md(text: str) -> str:
        """Минимальный markdown → HTML: ###, **bold**, списки, переносы."""
        import html as _html
        import re as _re

        out = []
        for line in _html.escape(text or "").splitlines():
            line = _re.sub(r"\*\*(.+?)\*\*", r"<b>\1</b>", line)
            line = _re.sub(r"_(.+?)_", r"<i>\1</i>", line)
            if line.startswith("### "):
                out.append(f"<h3>{line[4:]}</h3>")
            elif line.startswith("## "):
                out.append(f"<h3>{line[3:]}</h3>")
            elif line.startswith("- "):
                out.append(f"<div class='md-li'>• {line[2:]}</div>")
            elif line.strip():
                out.append(f"<div>{line}</div>")
            else:
                out.append("<div class='md-gap'></div>")
        from markupsafe import Markup
        return Markup("".join(out))

    app.register_blueprint(dashboard_bp)
    app.register_blueprint(chat_bp)
    app.register_blueprint(graph_bp)
    app.register_blueprint(emails_bp)
    app.register_blueprint(tasks_bp)
    app.register_blueprint(attachments_bp)
    app.register_blueprint(decisions_bp)
    app.register_blueprint(threads_bp)
    app.register_blueprint(search_bp)
    app.register_blueprint(registry_bp)
    return app
