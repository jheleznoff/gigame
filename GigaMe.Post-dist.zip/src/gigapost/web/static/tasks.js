// Drag&drop карточек между колонками канбана
let draggedId = null;

document.querySelectorAll(".kcard[draggable]").forEach((card) => {
  card.addEventListener("dragstart", (e) => {
    draggedId = card.dataset.id;
    card.classList.add("dragging");
    e.dataTransfer.effectAllowed = "move";
  });
  card.addEventListener("dragend", () => {
    card.classList.remove("dragging");
    draggedId = null;
  });
});

document.querySelectorAll(".kanban-col").forEach((col) => {
  col.addEventListener("dragover", (e) => {
    e.preventDefault();
    col.classList.add("drop-target");
  });
  col.addEventListener("dragleave", () => col.classList.remove("drop-target"));
  col.addEventListener("drop", async (e) => {
    e.preventDefault();
    col.classList.remove("drop-target");
    if (!draggedId) return;
    const resp = await fetch(`/api/tasks/${draggedId}/move`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status: col.dataset.status }),
    });
    const result = await resp.json();
    if (result.ok) {
      location.reload();
    } else {
      col.classList.add("drop-denied");
      setTimeout(() => col.classList.remove("drop-denied"), 600);
    }
  });
});
