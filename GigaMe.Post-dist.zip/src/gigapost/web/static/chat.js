const messages = document.getElementById("messages");
const form = document.getElementById("chat-form");
const input = document.getElementById("chat-text");
const suggests = document.getElementById("suggests");

const TOOL_NAMES = {
  search_emails: "ищу в письмах", get_email_details: "читаю письмо",
  get_attachment_text: "читаю вложение",
  query_knowledge_graph: "смотрю граф знаний", get_entity_profile: "собираю профиль",
  list_tasks: "смотрю задачи", get_agreements_on_control: "проверяю договорённости",
  create_task: "создаю задачу", complete_task: "закрываю задачу",
  create_mail_folder: "создаю папку", move_emails_to_folder: "перемещаю письма",
  list_folder_emails: "смотрю папку", delete_emails: "удаляю письма",
  search_knowledge: "ищу в базе знаний", add_knowledge: "записываю знание",
  find_attachments: "ищу файлы", suggest_reply: "готовлю черновик ответа",
  save_reply_draft: "сохраняю черновик в Outlook", link_tasks: "связываю задачи",
};

function scrollDown() { messages.scrollTop = messages.scrollHeight; }

function addMsg(role, text) {
  const row = document.createElement("div");
  row.className = "msg-row " + (role === "user" ? "user" : "bot");
  const avatar = document.createElement("div");
  avatar.className = "msg-avatar " + (role === "user" ? "me" : "bot");
  avatar.textContent = role === "user" ? "Я" : "AI";
  const bubble = document.createElement("div");
  bubble.className = "bubble";
  bubble.textContent = text;
  row.append(avatar, bubble);
  messages.appendChild(row);
  scrollDown();
  return bubble;
}

function addTool(name) {
  const chip = document.createElement("div");
  chip.className = "tool-chip";
  chip.innerHTML = '<span class="spinner"></span>' + (TOOL_NAMES[name] || name) + "…";
  messages.appendChild(chip);
  scrollDown();
  return chip;
}

const CONFIRM_LABELS = {
  create_task: "создать задачу", complete_task: "закрыть задачу",
  create_mail_folder: "создать папку в Outlook",
  move_emails_to_folder: "переместить письма в папку",
  delete_emails: "удалить письма (в «Удалённые»)",
  add_knowledge: "добавить знание в базу",
  save_reply_draft: "сохранить черновик ответа в Outlook",
};

function addConfirm(actions) {
  const card = document.createElement("div");
  card.className = "confirm-card";
  const list = actions.map((a) => {
    const label = CONFIRM_LABELS[a.name] || a.name;
    const args = Object.entries(a.args || {})
      .filter(([, v]) => v !== "" && v !== null)
      .map(([k, v]) => `${k}: ${v}`).join(", ");
    return `<div class="confirm-action"><b>${label}</b>${args ? " — " + args : ""}</div>`;
  }).join("");
  card.innerHTML =
    `<div class="confirm-title">Агент хочет выполнить действие:</div>${list}
     <div class="confirm-buttons">
       <button class="btn btn-sm" data-decision="approve">Разрешить</button>
       <button class="btn btn-quiet btn-sm" data-decision="reject">Отклонить</button>
     </div>`;
  messages.appendChild(card);
  scrollDown();
  card.querySelectorAll("button").forEach((b) =>
    b.addEventListener("click", () => {
      card.querySelectorAll("button").forEach((x) => (x.disabled = true));
      card.classList.add("decided");
      streamRequest("/api/chat/confirm", { decision: b.dataset.decision });
    }));
  return card;
}

async function streamRequest(url, payload) {
  const bubble = addMsg("bot", "");
  bubble.innerHTML = '<span class="typing"><i></i><i></i><i></i></span>';
  let started = false;
  let lastChip = null;

  try {
    const resp = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    const reader = resp.body.getReader();
    const decoder = new TextDecoder();
    let buffer = "";
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });
      const parts = buffer.split("\n\n");
      buffer = parts.pop();
      for (const part of parts) {
        if (!part.startsWith("data: ")) continue;
        const event = JSON.parse(part.slice(6));
        if (event.type === "token") {
          if (!started) { bubble.textContent = ""; started = true; }
          if (lastChip) { lastChip.classList.add("done"); lastChip = null; }
          bubble.textContent += event.text;
        } else if (event.type === "tool") {
          if (lastChip) lastChip.classList.add("done");
          bubble.parentElement.before(lastChip = addTool(event.name));
          messages.appendChild(bubble.parentElement);
        } else if (event.type === "confirm") {
          if (!started) bubble.parentElement.remove();
          addConfirm(event.actions);
          if (lastChip) lastChip.classList.add("done");
          return;
        } else if (event.type === "links") {
          const bar = document.createElement("div");
          bar.className = "chat-links";
          for (const l of event.links) {
            const a = document.createElement("a");
            a.className = "chat-link";
            a.href = l.url;
            a.textContent = l.label + " →";
            bar.appendChild(a);
          }
          messages.appendChild(bar);
        } else if (event.type === "error") {
          if (!started) { bubble.textContent = ""; started = true; }
          bubble.textContent += "\n⚠ " + event.text;
        }
        scrollDown();
      }
    }
    if (lastChip) lastChip.classList.add("done");
    if (!started) bubble.textContent = "(пустой ответ)";
  } catch (err) {
    bubble.textContent = "⚠ Ошибка соединения: " + err;
  }
}

async function send(text) {
  if (!text) return;
  if (suggests) suggests.style.display = "none";
  input.value = "";
  addMsg("user", text);
  await streamRequest("/api/chat", { message: text });
}

form.addEventListener("submit", (e) => { e.preventDefault(); send(input.value.trim()); });
document.querySelectorAll(".suggest").forEach((b) =>
  b.addEventListener("click", () => send(b.textContent)));
document.getElementById("new-chat").addEventListener("click", async () => {
  await fetch("/chat/new", { method: "POST" });
  location.reload();
});

// восстановить висящее HITL-подтверждение после перезагрузки страницы
(async () => {
  try {
    const resp = await fetch("/api/chat/pending");
    const data = await resp.json();
    if (data.actions && data.actions.length) addConfirm(data.actions);
  } catch (e) { /* нет висящих подтверждений */ }
})();
