const container = document.getElementById("graph-canvas");
const panel = document.getElementById("node-panel");
const panelTitle = document.getElementById("panel-title");
const panelBody = document.getElementById("panel-body");
let network = null;

const GROUP_COLORS = {
  note: "#9aa0ab", person: "#5ba3f0", org: "#34c98c",
  project: "#e8a13c", topic: "#a98bf5",
};
const KIND_RU = {
  fact: "факт", agreement: "договорённость", decision: "решение",
  event: "событие", status: "статус",
};

function themeColors() {
  const dark = document.documentElement.dataset.theme === "dark";
  return {
    font: dark ? "#e8e9ec" : "#17181c",
    edge: dark ? "#4a4d58" : "#c3c6cf",
  };
}

// [[wiki-ссылки]] → кликабельные ссылки, фокусирующие граф
function renderWiki(text) {
  const esc = (s) => s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  return esc(text).replace(/\[\[([^\[\]|]+)(?:\|[^\[\]]*)?\]\]/g,
    (_, name) => `<a href="#" class="wikilink" data-name="${name.trim()}">${name.trim()}</a>`);
}

async function openNode(nodeId) {
  const resp = await fetch(`/api/graph/node/${encodeURIComponent(nodeId)}`);
  if (!resp.ok) return;
  const d = await resp.json();
  if (d.kind === "note") {
    panelTitle.textContent = d.note.title;
    let html = `<div class="note-kind pill pill-gray">${KIND_RU[d.note.kind] || d.note.kind}</div>`;
    html += `<div class="note-body">${renderWiki(d.note.body)}</div>`;
    if (d.email) {
      html += `<div class="note-source muted">Источник: <a href="/emails/${d.email.message_id}">` +
              `${d.email.subject || "(письмо)"}</a> · ${(d.email.received_at || "").slice(0, 10)}</div>`;
    }
    if (d.entities.length) {
      html += `<div class="backlinks-head">Упоминает</div>` + d.entities.map(
        (e) => `<a href="#" class="wikilink" data-name="${e.name}">${e.name}</a>`).join(" · ");
    }
    panelBody.innerHTML = html;
  } else {
    panelTitle.textContent = d.entity.name;
    let html = `<div class="note-kind pill pill-gray">${d.entity.type}</div> ` +
      `<a class="pill pill-accent" href="/entity/${d.entity.id}">полное досье →</a>`;
    if (d.entity.email) html += `<div class="muted">${d.entity.email}</div>`;
    html += `<div class="backlinks-head">Обратные ссылки — заметки (${d.notes.length})</div>`;
    html += d.notes.map((n) =>
      `<div class="backlink-note">
         <div class="backlink-title">${n.title}</div>
         <div class="backlink-body">${renderWiki(n.body)}</div>
       </div>`).join("") || '<div class="muted">пока нет заметок</div>';
    panelBody.innerHTML = html;
  }
  panel.hidden = false;
  panelBody.querySelectorAll(".wikilink").forEach((a) =>
    a.addEventListener("click", (e) => {
      e.preventDefault();
      document.getElementById("graph-entity").value = a.dataset.name;
      loadGraph(a.dataset.name);
    }));
}

async function loadGraph(entity) {
  const url = entity ? `/api/graph?entity=${encodeURIComponent(entity)}` : "/api/graph";
  const data = await (await fetch(url)).json();
  const t = themeColors();
  const nodes = data.nodes.map((n) => ({
    ...n,
    shape: "dot",
    size: n.group === "note" ? 7 : Math.min(11 + (n.value || 1) * 1.6, 30),
    color: { background: GROUP_COLORS[n.group] || "#878b95", border: "transparent",
             highlight: { background: GROUP_COLORS[n.group], border: t.font } },
    font: { size: n.group === "note" ? 10 : 14, color: t.font },
  }));
  const edges = data.edges.map((e) => ({
    ...e, arrows: e.label ? { to: { enabled: true, scaleFactor: 0.5 } } : undefined,
    color: { color: t.edge, highlight: "#5e6ad2" },
    font: { size: 10, align: "middle", color: t.edge, strokeWidth: 0 },
    smooth: { type: "continuous" },
  }));
  if (network) network.destroy();
  network = new vis.Network(container, { nodes, edges }, {
    physics: {
      solver: "forceAtlas2Based",
      forceAtlas2Based: { gravitationalConstant: -45, springLength: 100 },
      stabilization: { iterations: 180 },
    },
    interaction: { hover: true, tooltipDelay: 120 },
  });
  network.on("click", (params) => {
    if (params.nodes.length) openNode(params.nodes[0]);
  });
}

document.getElementById("graph-filter").addEventListener("submit", (e) => {
  e.preventDefault();
  loadGraph(document.getElementById("graph-entity").value.trim());
});
document.getElementById("graph-reset").addEventListener("click", () => {
  document.getElementById("graph-entity").value = "";
  loadGraph("");
});
document.getElementById("panel-close").addEventListener("click", () => { panel.hidden = true; });
document.getElementById("theme-toggle").addEventListener("click", () =>
  loadGraph(document.getElementById("graph-entity").value.trim()));

loadGraph("");
