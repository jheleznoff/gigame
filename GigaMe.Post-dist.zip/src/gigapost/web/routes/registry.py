"""Реестр документов: реквизиты из вложений (doc_facts) + экспорт в Excel."""

from __future__ import annotations

from flask import Blueprint, render_template, request, send_file

from gigapost.context import get_context
from gigapost.docs.reconcile import registry_rows

bp = Blueprint("registry", __name__)

DOC_TYPES = ["договор", "спецификация", "заявка", "акт", "УПД", "счёт",
             "форма", "протокол", "прочее"]


@bp.get("/registry")
def registry():
    ctx = get_context()
    q = (request.args.get("q") or "").strip()
    doc_type = (request.args.get("type") or "").strip()
    rows = registry_rows(ctx.repos, q=q, doc_type=doc_type)
    pending = ctx.repos.db.query_one(
        """SELECT COUNT(*) c FROM attachments a
           LEFT JOIN doc_facts f ON f.attachment_id = a.id
           WHERE a.status='parsed' AND f.attachment_id IS NULL""")["c"]
    return render_template("registry.html", rows=rows, q=q, doc_type=doc_type,
                           doc_types=DOC_TYPES, pending=pending,
                           alert_count=ctx.repos.alerts.count_active())


@bp.get("/registry.xlsx")
def registry_xlsx():
    import io

    from openpyxl import Workbook
    from openpyxl.utils import get_column_letter

    ctx = get_context()
    rows = registry_rows(ctx.repos,
                         q=(request.args.get("q") or "").strip(),
                         doc_type=(request.args.get("type") or "").strip(),
                         limit=5000)
    wb = Workbook()
    ws = wb.active
    ws.title = "Реестр документов"
    headers = ["Тип", "Номер", "Дата", "Сумма", "Контрагент", "Технология",
               "Файл", "Письмо", "Отправитель", "Получено", "Примечание"]
    ws.append(headers)
    for r in rows:
        ws.append([r.get("doc_type"), r.get("number"), r.get("doc_date"),
                   r.get("amount"), r.get("counterparty"), r.get("tech"),
                   r.get("filename"), r.get("subject"), r.get("sender_name"),
                   (r.get("received_at") or "")[:10], r.get("notes")])
    for i, width in enumerate([12, 10, 12, 14, 24, 16, 30, 34, 20, 12, 30], 1):
        ws.column_dimensions[get_column_letter(i)].width = width
    ws.freeze_panes = "A2"
    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    return send_file(buf, as_attachment=True, download_name="registry.xlsx",
                     mimetype="application/vnd.openxmlformats-officedocument"
                              ".spreadsheetml.sheet")


@bp.post("/registry/extract-now")
def extract_now():
    """Кнопка «пополнить реестр сейчас» — одна порция извлечения."""
    from flask import redirect

    from gigapost.docs.reconcile import backfill_doc_facts

    ctx = get_context()
    backfill_doc_facts(ctx.repos, limit=15)
    return redirect("/registry")
