"""Треды переписки и досье сущностей (людей/проектов/организаций)."""

from __future__ import annotations

from flask import Blueprint, render_template

from gigapost.context import get_context

bp = Blueprint("threads", __name__)


@bp.get("/threads/<path:conversation_id>")
def thread(conversation_id: str):
    """Страница треда: письма хронологически + всё, что из них извлечено."""
    ctx = get_context()
    emails = [dict(r) for r in ctx.repos.db.query(
        "SELECT * FROM emails WHERE conversation_id=? ORDER BY received_at",
        (conversation_id,))]
    if not emails:
        return "Тред не найден", 404
    ids = [e["message_id"] for e in emails]
    ph = ",".join("?" * len(ids))
    tasks = [dict(r) for r in ctx.repos.db.query(
        f"SELECT * FROM tasks WHERE source_message_id IN ({ph})", tuple(ids))]
    agreements = [dict(r) for r in ctx.repos.db.query(
        f"SELECT * FROM agreements WHERE source_message_id IN ({ph})", tuple(ids))]
    notes = [dict(r) for r in ctx.repos.db.query(
        f"SELECT * FROM notes WHERE source_message_id IN ({ph}) ORDER BY id", tuple(ids))]
    return render_template("thread.html", conversation_id=conversation_id,
                           emails=emails, tasks=tasks, agreements=agreements,
                           notes=notes, alert_count=ctx.repos.alerts.count_active())


@bp.get("/entity/<int:entity_id>")
def entity(entity_id: int):
    """Досье: заметки-backlinks, письма, задачи, договорённости сущности."""
    ctx = get_context()
    ent = ctx.repos.entities.get(entity_id)
    if not ent:
        return "Сущность не найдена", 404
    notes = ctx.repos.notes.for_entity(entity_id, limit=30)
    mentions = ctx.repos.entities.mentions_for(entity_id, limit=15)
    name_like = f"%{ent['name']}%"
    tasks = [dict(r) for r in ctx.repos.db.query(
        """SELECT t.*, e.sender_name FROM tasks t
           LEFT JOIN emails e ON e.message_id = t.source_message_id
           WHERE t.assignee LIKE ? OR t.title LIKE ? OR e.sender_name LIKE ?
           ORDER BY t.status='done', t.due_date IS NULL, t.due_date LIMIT 20""",
        (name_like, name_like, name_like))]
    agreements = [dict(r) for r in ctx.repos.db.query(
        "SELECT * FROM agreements WHERE counterparty LIKE ? OR description LIKE ? LIMIT 15",
        (name_like, name_like))]
    graph = ctx.kg.neighbors(ent["name"]) or {"related": []}
    return render_template("entity.html", entity=ent, notes=notes, mentions=mentions,
                           tasks=tasks, agreements=agreements,
                           related=graph.get("related", []),
                           alert_count=ctx.repos.alerts.count_active())