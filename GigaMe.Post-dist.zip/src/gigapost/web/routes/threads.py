"""Треды переписки и досье сущностей (людей/проектов/организаций)."""

from __future__ import annotations

from flask import Blueprint, redirect, render_template

from gigapost.context import get_context

bp = Blueprint("threads", __name__)


@bp.get("/threads/<path:conversation_id>")
def thread(conversation_id: str):
    """Страница треда: письма хронологически + всё, что из них извлечено."""
    ctx = get_context()
    emails = [dict(r) for r in ctx.repos.db.query(
        "SELECT * FROM emails WHERE conversation_id=? ORDER BY received_at",
        (conversation_id,))]
    if not emails:
        return "Тред не найден", 404
    ids = [e["message_id"] for e in emails]
    ph = ",".join("?" * len(ids))
    tasks = [dict(r) for r in ctx.repos.db.query(
        f"SELECT * FROM tasks WHERE source_message_id IN ({ph})", tuple(ids))]
    agreements = [dict(r) for r in ctx.repos.db.query(
        f"SELECT * FROM agreements WHERE source_message_id IN ({ph})", tuple(ids))]
    notes = [dict(r) for r in ctx.repos.db.query(
        f"SELECT * FROM notes WHERE source_message_id IN ({ph}) ORDER BY id", tuple(ids))]
    attachments = [dict(r) for r in ctx.repos.db.query(
        f"""SELECT a.* FROM attachments a
            WHERE a.message_id IN ({ph}) AND a.path IS NOT NULL
            ORDER BY a.id""", tuple(ids))]

    from gigapost.docs.reconcile import last_check
    doc_check = last_check(ctx.repos, conversation_id)

    from gigapost.summaries import ball_side, get_cached, is_stale
    summary = get_cached(ctx.repos, conversation_id)
    return render_template("thread.html", conversation_id=conversation_id,
                           emails=emails, tasks=tasks, agreements=agreements,
                           notes=notes, attachments=attachments,
                           doc_check=doc_check, summary=summary,
                           summary_stale=is_stale(summary, emails),
                           ball=ball_side(emails),
                           alert_count=ctx.repos.alerts.count_active())


@bp.post("/threads/<path:conversation_id>/summarize")
def summarize(conversation_id: str):
    """Пересчитать резюме треда (один LLM-вызов, кэшируется)."""
    ctx = get_context()
    emails = [dict(r) for r in ctx.repos.db.query(
        "SELECT * FROM emails WHERE conversation_id=? ORDER BY received_at",
        (conversation_id,))]
    if emails:
        from gigapost.summaries import refresh
        try:
            refresh(ctx.repos, conversation_id, emails)
        except Exception as e:  # noqa: BLE001 — 429 и т.п.
            import logging
            logging.getLogger(__name__).warning("Резюме треда: %s", e)
    return redirect(f"/threads/{conversation_id}")


@bp.post("/threads/<path:conversation_id>/doccheck")
def doccheck(conversation_id: str):
    """Сверить комплект документов треда (синхронно, с кэшем реквизитов)."""
    ctx = get_context()
    from gigapost.docs.reconcile import check_conversation
    check_conversation(ctx.repos, conversation_id)
    return redirect(f"/threads/{conversation_id}")


@bp.get("/entity/<int:entity_id>")
def entity(entity_id: int):
    """Досье: заметки-backlinks, письма, задачи, договорённости сущности."""
    ctx = get_context()
    ent = ctx.repos.entities.get(entity_id)
    if not ent:
        return "Сущность не найдена", 404
    notes = ctx.repos.notes.for_entity(entity_id, limit=30)
    mentions = ctx.repos.entities.mentions_for(entity_id, limit=15)
    name_like = f"%{ent['name']}%"
    tasks = [dict(r) for r in ctx.repos.db.query(
        """SELECT t.*, e.sender_name FROM tasks t
           LEFT JOIN emails e ON e.message_id = t.source_message_id
           WHERE t.assignee LIKE ? OR t.title LIKE ? OR e.sender_name LIKE ?
           ORDER BY t.status='done', t.due_date IS NULL, t.due_date LIMIT 20""",
        (name_like, name_like, name_like))]
    agreements = [dict(r) for r in ctx.repos.db.query(
        "SELECT * FROM agreements WHERE counterparty LIKE ? OR description LIKE ? LIMIT 15",
        (name_like, name_like))]
    graph = ctx.kg.neighbors(ent["name"]) or {"related": []}
    from gigapost.dossier import get_dossier
    return render_template("entity.html", entity=ent, notes=notes, mentions=mentions,
                           tasks=tasks, agreements=agreements,
                           related=graph.get("related", []),
                           dossier=get_dossier(ctx.repos, entity_id),
                           alert_count=ctx.repos.alerts.count_active())


@bp.post("/entity/<int:entity_id>/dossier")
def refresh_entity_dossier(entity_id: int):
    """Пересобрать досье сущности вручную."""
    ctx = get_context()
    from gigapost.dossier import refresh_dossier
    try:
        refresh_dossier(ctx.repos, entity_id)
    except Exception as e:  # noqa: BLE001
        import logging
        logging.getLogger(__name__).warning("Досье %s: %s", entity_id, e)
    return redirect(f"/entity/{entity_id}")

# ---------------------------------------------------------------------------
# Заметки как в Obsidian: карточка с кликабельными [[ссылками]], правка,
# удаление, добавление из досье, локальный граф связей глубины 2
# ---------------------------------------------------------------------------

NOTE_KINDS = ["fact", "decision", "agreement", "event", "status", "risk"]


def _render_wiki(ctx, body: str):
    """[[Имя]] → ссылка на досье сущности (точное совпадение имени)."""
    import re

    from markupsafe import Markup, escape

    def repl(m):
        name = m.group(1)
        exact = ctx.repos.entities.find_exact(name)
        if exact:
            return f'<a class="wikilink" href="/entity/{exact["id"]}">{escape(name)}</a>'
        return str(escape(name))

    return Markup(re.sub(r"\[\[([^\]]+)\]\]", repl, str(escape(body))))


def _note_local_graph(ctx, note: dict, entities: list[dict]) -> dict:
    """Локальный граф глубины 2: заметка → её сущности → их другие заметки
    + смысловые связи заметка↔заметка (пунктиром)."""
    center = f"n{note['id']}"
    nodes = [{"id": center, "label": note["title"][:40], "group": "center",
              "value": 3}]
    edges: list[dict] = []
    seen = {center}
    for e in entities:
        eid = f"e{e['id']}"
        nodes.append({"id": eid, "label": e["name"][:30], "group": e["type"],
                      "value": 2, "url": f"/entity/{e['id']}"})
        seen.add(eid)
        edges.append({"from": center, "to": eid})
        for n2 in ctx.repos.notes.for_entity(e["id"], limit=8):
            if n2["id"] == note["id"]:
                continue
            nid = f"n{n2['id']}"
            if nid not in seen:
                nodes.append({"id": nid, "label": n2["title"][:40], "group": "note",
                              "value": 1, "url": f"/notes/{n2['id']}"})
                seen.add(nid)
            edges.append({"from": eid, "to": nid})
    for r in ctx.repos.db.query(
            "SELECT * FROM note_relations WHERE src_note_id=? OR dst_note_id=?",
            (note["id"], note["id"])):
        other = r["dst_note_id"] if r["src_note_id"] == note["id"] else r["src_note_id"]
        nid = f"n{other}"
        if nid not in seen:
            n2 = ctx.repos.notes.get(other)
            if not n2:
                continue
            nodes.append({"id": nid, "label": n2["title"][:40], "group": "note",
                          "value": 1, "url": f"/notes/{other}"})
            seen.add(nid)
        edges.append({"from": center, "to": nid, "dashes": True})
    return {"nodes": nodes[:60], "edges": edges[:120]}


def _relink_note(ctx, note_id: int, body: str) -> None:
    """Пересобрать связи заметки из [[ссылок]] после правки."""
    from gigapost.knowledge.graph_store import parse_wikilinks

    ctx.repos.db.execute("DELETE FROM note_links WHERE note_id=?", (note_id,))
    for name in parse_wikilinks(body):
        exact = ctx.repos.entities.find_exact(name)
        entity_id = exact["id"] if exact else ctx.repos.entities.upsert(name, "topic")
        ctx.repos.notes.link_entity(note_id, entity_id)


def _kg_refresh(ctx) -> None:
    try:
        ctx.kg.rebuild()
    except Exception:  # noqa: BLE001 — граф в памяти пересоберётся при рестарте
        pass


@bp.get("/notes/<int:note_id>")
def note_card(note_id: int):
    ctx = get_context()
    note = ctx.repos.notes.get(note_id)
    if not note:
        return "Заметка не найдена", 404
    entities = ctx.repos.notes.entities_of(note_id)
    email = (ctx.repos.emails.get(note["source_message_id"])
             if note.get("source_message_id") else None)
    related = []
    for r in ctx.repos.db.query(
            """SELECT * FROM note_relations WHERE src_note_id=? OR dst_note_id=?
               ORDER BY score DESC LIMIT 10""", (note_id, note_id)):
        other_id = (r["dst_note_id"] if r["src_note_id"] == note_id
                    else r["src_note_id"])
        other = ctx.repos.notes.get(other_id)
        if other:
            related.append(dict(other, score=r["score"]))
    import json as _json
    return render_template(
        "note_card.html", note=note, entities=entities, email=email,
        related=related, body_html=_render_wiki(ctx, note["body"] or ""),
        kinds=NOTE_KINDS,
        local_graph=_json.dumps(_note_local_graph(ctx, note, entities),
                                ensure_ascii=False),
        alert_count=ctx.repos.alerts.count_active())


@bp.post("/notes/new")
def note_new():
    from flask import request

    ctx = get_context()
    title = (request.form.get("title") or "").strip()
    body = (request.form.get("body") or "").strip()
    kind = request.form.get("kind") or "fact"
    entity_id = request.form.get("entity_id")
    if not title or not body:
        return redirect(request.referrer or "/graph")
    # заметка из досье связывается с сущностью, даже если [[ссылку]] не написали
    if entity_id:
        ent = ctx.repos.entities.get(int(entity_id))
        if ent and f"[[{ent['name']}]]" not in body:
            body += f"\n\n[[{ent['name']}]]"
    note_id = ctx.kg.add_note(title=title, body=body, kind=kind,
                              source_message_id=None, conversation_id=None)
    if note_id is None:   # дубль по (title, body)
        return redirect(request.referrer or "/graph")
    return redirect(f"/notes/{note_id}")


@bp.post("/notes/<int:note_id>/edit")
def note_edit(note_id: int):
    from flask import request

    ctx = get_context()
    note = ctx.repos.notes.get(note_id)
    if not note:
        return "Заметка не найдена", 404
    title = (request.form.get("title") or "").strip() or note["title"]
    body = (request.form.get("body") or "").strip() or note["body"]
    kind = request.form.get("kind") or note["kind"]
    ctx.repos.db.execute("UPDATE notes SET title=?, body=?, kind=? WHERE id=?",
                         (title, body, kind, note_id))
    _relink_note(ctx, note_id, body)
    _kg_refresh(ctx)
    return redirect(f"/notes/{note_id}")


@bp.post("/notes/<int:note_id>/delete")
def note_delete(note_id: int):
    ctx = get_context()
    ctx.repos.db.execute("DELETE FROM note_links WHERE note_id=?", (note_id,))
    ctx.repos.db.execute(
        "DELETE FROM note_relations WHERE src_note_id=? OR dst_note_id=?",
        (note_id, note_id))
    ctx.repos.db.execute("DELETE FROM notes WHERE id=?", (note_id,))
    if ctx.vectors is not None:
        try:
            ctx.vectors.notes_collection.delete(ids=[str(note_id)])
        except Exception:  # noqa: BLE001
            pass
    _kg_refresh(ctx)
    return redirect("/graph")
