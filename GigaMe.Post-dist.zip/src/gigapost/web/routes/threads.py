"""Треды переписки и досье сущностей (людей/проектов/организаций)."""

from __future__ import annotations

from flask import Blueprint, redirect, render_template

from gigapost.context import get_context

bp = Blueprint("threads", __name__)


@bp.get("/threads/<path:conversation_id>")
def thread(conversation_id: str):
    """Страница треда: письма хронологически + всё, что из них извлечено."""
    ctx = get_context()
    emails = [dict(r) for r in ctx.repos.db.query(
        "SELECT * FROM emails WHERE conversation_id=? ORDER BY received_at",
        (conversation_id,))]
    if not emails:
        return "Тред не найден", 404
    ids = [e["message_id"] for e in emails]
    ph = ",".join("?" * len(ids))
    tasks = [dict(r) for r in ctx.repos.db.query(
        f"SELECT * FROM tasks WHERE source_message_id IN ({ph})", tuple(ids))]
    agreements = [dict(r) for r in ctx.repos.db.query(
        f"SELECT * FROM agreements WHERE source_message_id IN ({ph})", tuple(ids))]
    notes = [dict(r) for r in ctx.repos.db.query(
        f"SELECT * FROM notes WHERE source_message_id IN ({ph}) ORDER BY id", tuple(ids))]
    attachments = [dict(r) for r in ctx.repos.db.query(
        f"""SELECT a.* FROM attachments a
            WHERE a.message_id IN ({ph}) AND a.path IS NOT NULL
            ORDER BY a.id""", tuple(ids))]

    from gigapost.docs.reconcile import last_check
    doc_check = last_check(ctx.repos, conversation_id)

    from gigapost.summaries import ball_side, get_cached, is_stale
    summary = get_cached(ctx.repos, conversation_id)
    return render_template("thread.html", conversation_id=conversation_id,
                           emails=emails, tasks=tasks, agreements=agreements,
                           notes=notes, attachments=attachments,
                           doc_check=doc_check, summary=summary,
                           summary_stale=is_stale(summary, emails),
                           ball=ball_side(emails),
                           alert_count=ctx.repos.alerts.count_active())


@bp.post("/threads/<path:conversation_id>/summarize")
def summarize(conversation_id: str):
    """Пересчитать резюме треда (один LLM-вызов, кэшируется)."""
    ctx = get_context()
    emails = [dict(r) for r in ctx.repos.db.query(
        "SELECT * FROM emails WHERE conversation_id=? ORDER BY received_at",
        (conversation_id,))]
    if emails:
        from gigapost.summaries import refresh
        try:
            refresh(ctx.repos, conversation_id, emails)
        except Exception as e:  # noqa: BLE001 — 429 и т.п.
            import logging
            logging.getLogger(__name__).warning("Резюме треда: %s", e)
    return redirect(f"/threads/{conversation_id}")


@bp.post("/threads/<path:conversation_id>/doccheck")
def doccheck(conversation_id: str):
    """Сверить комплект документов треда (синхронно, с кэшем реквизитов)."""
    ctx = get_context()
    from gigapost.docs.reconcile import check_conversation
    check_conversation(ctx.repos, conversation_id)
    return redirect(f"/threads/{conversation_id}")


@bp.get("/entity/<int:entity_id>")
def entity(entity_id: int):
    """Досье: заметки-backlinks, письма, задачи, договорённости сущности."""
    ctx = get_context()
    ent = ctx.repos.entities.get(entity_id)
    if not ent:
        return "Сущность не найдена", 404
    notes = ctx.repos.notes.for_entity(entity_id, limit=30)
    mentions = ctx.repos.entities.mentions_for(entity_id, limit=15)
    name_like = f"%{ent['name']}%"
    tasks = [dict(r) for r in ctx.repos.db.query(
        """SELECT t.*, e.sender_name FROM tasks t
           LEFT JOIN emails e ON e.message_id = t.source_message_id
           WHERE t.assignee LIKE ? OR t.title LIKE ? OR e.sender_name LIKE ?
           ORDER BY t.status='done', t.due_date IS NULL, t.due_date LIMIT 20""",
        (name_like, name_like, name_like))]
    agreements = [dict(r) for r in ctx.repos.db.query(
        "SELECT * FROM agreements WHERE counterparty LIKE ? OR description LIKE ? LIMIT 15",
        (name_like, name_like))]
    graph = ctx.kg.neighbors(ent["name"]) or {"related": []}
    from gigapost.dossier import get_dossier
    return render_template("entity.html", entity=ent, notes=notes, mentions=mentions,
                           tasks=tasks, agreements=agreements,
                           related=graph.get("related", []),
                           dossier=get_dossier(ctx.repos, entity_id),
                           alert_count=ctx.repos.alerts.count_active())


@bp.post("/entity/<int:entity_id>/dossier")
def refresh_entity_dossier(entity_id: int):
    """Пересобрать досье сущности вручную."""
    ctx = get_context()
    from gigapost.dossier import refresh_dossier
    try:
        refresh_dossier(ctx.repos, entity_id)
    except Exception as e:  # noqa: BLE001
        import logging
        logging.getLogger(__name__).warning("Досье %s: %s", entity_id, e)
    return redirect(f"/entity/{entity_id}")