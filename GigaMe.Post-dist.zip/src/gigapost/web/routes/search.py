"""Глобальный поиск (Ctrl+K): письма + задачи + заметки + вложения + люди."""

from __future__ import annotations

from flask import Blueprint, render_template, request

from gigapost.context import get_context

bp = Blueprint("search", __name__)


@bp.get("/search")
def global_search():
    ctx = get_context()
    q = (request.args.get("q") or "").strip()
    results = {"emails": [], "tasks": [], "notes": [], "attachments": [], "entities": []}
    if q:
        results["emails"] = ctx.repos.emails.search_fts(q, limit=8)
        like = f"%{q}%"
        results["tasks"] = [dict(r) for r in ctx.repos.db.query(
            "SELECT * FROM tasks WHERE title LIKE ? OR description LIKE ? LIMIT 8",
            (like, like))]
        results["notes"] = ctx.repos.notes.search_fts(q, limit=8)
        results["attachments"] = ctx.repos.attachments.library(query=q, limit=8)
        results["entities"] = ctx.repos.entities.find_by_name(q)[:8]
        # семантика по заметкам — если полнотекст мало нашёл
        if ctx.vectors is not None and len(results["notes"]) < 3:
            try:
                vec = ctx.vectors.embeddings.embed_query(q)
                res = ctx.vectors.notes_collection.query(query_embeddings=[vec],
                                                         n_results=5)
                seen = {n["id"] for n in results["notes"]}
                for note_id in res["ids"][0]:
                    note = ctx.repos.notes.get(int(note_id))
                    if note and note["id"] not in seen:
                        results["notes"].append(note)
            except Exception:  # noqa: BLE001
                pass
    total = sum(len(v) for v in results.values())
    return render_template("search.html", q=q, r=results, total=total,
                           alert_count=ctx.repos.alerts.count_active())