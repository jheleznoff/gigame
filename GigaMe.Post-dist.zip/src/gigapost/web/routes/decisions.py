"""Единая лента «Требуют решения»: карантин писем, черновики задач, алерты —
одна очередь в стиле inbox-triage. Плюс утренний дайджест."""

from __future__ import annotations

from datetime import datetime

from flask import Blueprint, redirect, render_template, request, url_for

from gigapost.config import load_taxonomy, settings
from gigapost.context import get_context

bp = Blueprint("decisions", __name__)

KIND_RU = {"overdue": "Просрочено", "deadline_soon": "Скоро срок",
           "followup_needed": "Нужен follow-up", "task_maybe_done": "Похоже, выполнено",
           "sla_unanswered": "Ждут вашего ответа",
           "gateway_stalled": "Шлюз почты молчит",
           "knowledge_conflict": "Противоречие в знаниях"}


def decision_count(ctx) -> int:
    return (ctx.repos.emails.count_pending_review()
            + ctx.repos.tasks.count("draft")
            + ctx.repos.alerts.count_active())


@bp.get("/decisions")
def queue():
    ctx = get_context()
    taxonomy = load_taxonomy()
    items = []
    for e in ctx.repos.emails.pending_review(limit=30):
        items.append({"kind": "review", "ts": e.get("received_at") or "", "email": e,
                      "phishing": "ФИШИНГ" in (e.get("summary") or "")})
    for t in ctx.repos.tasks.list("draft", limit=30):
        t["vip"] = settings.is_vip(t.get("sender_name"), t.get("sender_email"))
        items.append({"kind": "draft_task", "ts": t.get("created_at") or "", "task": t})
    from gigapost.web.routes.dashboard import alert_url
    for a in ctx.repos.alerts.list_active(limit=30):
        items.append({"kind": "alert", "ts": a.get("created_at") or "", "alert": a,
                      "alert_kind_ru": KIND_RU.get(a["kind"], a["kind"]),
                      "alert_url": alert_url(ctx, a)})
    items.sort(key=lambda x: x["ts"], reverse=True)
    return render_template("decisions.html", items=items,
                           categories=taxonomy.category_names,
                           alert_count=decision_count(ctx))


@bp.get("/digest")
def digest_page():
    ctx = get_context()
    day = request.args.get("day") or datetime.now().strftime("%Y-%m-%d")
    digest = ctx.repos.digests.get(day) or ctx.repos.digests.latest()
    weekly = ctx.repos.db.query_one(
        "SELECT * FROM digests WHERE day LIKE '%-W%' ORDER BY id DESC LIMIT 1")
    return render_template("digest.html", digest=digest,
                           weekly=dict(weekly) if weekly else None,
                           alert_count=decision_count(ctx))


@bp.post("/digest/weekly")
def digest_weekly():
    from gigapost.digest import build_weekly

    ctx = get_context()
    build_weekly(ctx.repos)
    return redirect(url_for("decisions.digest_page"))


@bp.post("/digest/generate")
def digest_generate():
    from gigapost.digest import build_digest

    ctx = get_context()
    build_digest(ctx.repos)
    return redirect(url_for("decisions.digest_page"))