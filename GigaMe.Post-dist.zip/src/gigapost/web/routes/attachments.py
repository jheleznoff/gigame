"""Библиотека вложений: поиск, фильтры по типу, скачивание."""

from __future__ import annotations

from pathlib import Path

from flask import Blueprint, abort, render_template, request, send_file

from gigapost.context import get_context

bp = Blueprint("attachments", __name__)

EXT_ICONS = {
    ".pdf": "📄", ".docx": "📝", ".doc": "📝", ".xlsx": "📊", ".xls": "📊",
    ".pptx": "📽", ".csv": "📊", ".txt": "🗒", ".md": "🗒", ".zip": "🗜",
    ".rar": "🗜", ".7z": "🗜", ".png": "🖼", ".jpg": "🖼", ".jpeg": "🖼",
    ".msg": "✉", ".eml": "✉",
}


@bp.get("/attachments")
def library():
    ctx = get_context()
    query = (request.args.get("q") or "").strip()
    ext = (request.args.get("ext") or "").strip()
    files = ctx.repos.attachments.library(query=query, ext=ext, limit=200)
    seen_hashes: dict[str, int] = {}
    for f in files:
        f["icon"] = EXT_ICONS.get(f.get("ext") or "", "📎")
        f["size_kb"] = round((f.get("size") or 0) / 1024) or None
        sha = f.get("sha256")
        if sha:
            seen_hashes[sha] = seen_hashes.get(sha, 0) + 1
            f["dup"] = seen_hashes[sha] > 1
    return render_template("attachments.html", files=files, query=query, ext=ext,
                           extensions=ctx.repos.attachments.extensions(),
                           alert_count=ctx.repos.alerts.count_active())


@bp.get("/attachments/<int:attachment_id>/download")
def download(attachment_id: int):
    ctx = get_context()
    a = ctx.repos.attachments.get(attachment_id)
    if not a or not a.get("path") or not Path(a["path"]).exists():
        abort(404)
    return send_file(a["path"], as_attachment=True, download_name=a["filename"])
