"""Чат с агентом: страница + SSE-стриминг ответов."""

from __future__ import annotations

import json
import uuid

from flask import Blueprint, Response, render_template, request, session

from gigapost.agent.deep_agent import get_history, resume_chat, stream_chat
from gigapost.context import get_context

bp = Blueprint("chat", __name__)


def _thread_id() -> str:
    if "chat_thread_id" not in session:
        session["chat_thread_id"] = uuid.uuid4().hex
    return session["chat_thread_id"]


@bp.get("/chat")
def chat_page():
    ctx = get_context()
    history = get_history(_thread_id())
    return render_template("chat.html", history=history,
                           alert_count=ctx.repos.alerts.count_active())


@bp.get("/api/chat/pending")
def chat_pending():
    """Висящие HITL-подтверждения треда (для восстановления карточки после F5)."""
    from gigapost.agent.deep_agent import _pending_action_requests, build_chat_agent

    agent = build_chat_agent()
    pending = _pending_action_requests(
        agent, {"configurable": {"thread_id": _thread_id()}})
    return {"actions": pending}


@bp.post("/chat/new")
def chat_new():
    session["chat_thread_id"] = uuid.uuid4().hex
    return {"ok": True}


def _sse(generator) -> Response:
    def generate():
        for event in generator:
            yield f"data: {json.dumps(event, ensure_ascii=False)}\n\n"

    return Response(generate(), mimetype="text/event-stream",
                    headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})


@bp.post("/api/chat/upload")
def chat_upload():
    """Документ, приложенный пользователем для анализа: сохранить, извлечь
    текст (включая OCR сканов) и держать в контексте текущего треда чата."""
    from datetime import datetime
    from pathlib import Path

    from gigapost.attachments.extractor import extract_text
    from gigapost.config import DATA_DIR

    f = request.files.get("file")
    if f is None or not f.filename:
        return {"error": "файл не выбран"}, 400
    if request.content_length and request.content_length > 25 * 1024 * 1024:
        return {"error": "файл больше 25 МБ"}, 400
    name = Path(f.filename).name
    updir = DATA_DIR / "chat_uploads"
    updir.mkdir(parents=True, exist_ok=True)
    path = updir / f"{uuid.uuid4().hex[:8]}_{name}"
    f.save(str(path))
    try:
        text = extract_text(path, allow_ocr=True)
    except Exception:  # noqa: BLE001
        text = None
    text = (text or "").strip()
    ctx = get_context()
    ctx.repos.db.execute(
        "INSERT INTO chat_uploads (thread_id, filename, text, status, created_at) "
        "VALUES (?,?,?,?,?)",
        (_thread_id(), name, text, "parsed" if text else "empty",
         datetime.now().isoformat()))
    if not text:
        return {"ok": False, "filename": name,
                "error": "не удалось извлечь текст из файла (формат не "
                         "поддерживается или скан не распознался)"}
    return {"ok": True, "filename": name, "chars": len(text)}


@bp.post("/api/chat")
def chat_api():
    message = (request.json or {}).get("message", "").strip()
    if not message:
        return {"error": "пустое сообщение"}, 400
    return _sse(stream_chat(message, _thread_id()))


@bp.post("/api/chat/confirm")
def chat_confirm():
    """Решение пользователя по HITL-подтверждению мутации агента."""
    data = request.json or {}
    decision = data.get("decision", "reject")
    if decision not in ("approve", "reject"):
        return {"error": "decision должен быть approve или reject"}, 400
    return _sse(resume_chat(decision, _thread_id(), data.get("message", "")))
