"""Поиск и просмотр писем."""

from __future__ import annotations

import logging

from flask import Blueprint, render_template, request

from gigapost.context import get_context

bp = Blueprint("emails", __name__)
logger = logging.getLogger(__name__)

AVATAR_COLORS = ["#5e6ad2", "#12945f", "#b96e00", "#7c3aed", "#1a6fd4",
                 "#d5382f", "#0e8a8a", "#a34fa3"]
CATEGORY_CSS = {"Срочное/Действие": "pill-red", "Проекты": "pill-blue",
                "Финансы": "pill-green", "Рассылки": "pill-gray", "Личное": "pill-violet"}


def _decorate(e: dict) -> dict:
    name = (e.get("sender_name") or e.get("sender_email") or "?").strip()
    parts = [p for p in name.replace("<", " ").split() if p][:2]
    initials = "".join(p[0].upper() for p in parts) or "?"
    color = AVATAR_COLORS[sum(name.encode()) % len(AVATAR_COLORS)]
    return dict(e, avatar_initials=initials, avatar_color=color,
                category_css=CATEGORY_CSS.get(e.get("category") or "", "pill-accent"))


@bp.get("/emails")
def emails_page():
    ctx = get_context()
    query = (request.args.get("q") or "").strip()
    if request.args.get("hidden") == "1":
        return render_template(
            "emails.html", emails=[_decorate(e) for e in ctx.repos.emails.dismissed()],
            query="", hidden=True, hidden_count=ctx.repos.emails.count_dismissed(),
            alert_count=ctx.repos.alerts.count_active())
    if query:
        results = {e["message_id"]: e for e in ctx.repos.emails.search_fts(query, limit=20)}
        if ctx.vectors is not None:
            try:
                for r in ctx.vectors.search(query, k=10):
                    if r["message_id"] not in results:
                        email = ctx.repos.emails.get(r["message_id"])
                        if email:
                            results[r["message_id"]] = email
            except Exception as e:  # noqa: BLE001
                logger.warning("Векторный поиск: %s", e)
        emails = list(results.values())
    else:
        emails = ctx.repos.emails.recent(limit=50)
    return render_template("emails.html", emails=[_decorate(e) for e in emails],
                           query=query, hidden=False,
                           hidden_count=ctx.repos.emails.count_dismissed(),
                           alert_count=ctx.repos.alerts.count_active())


@bp.get("/emails/<path:message_id>")
def email_card(message_id: str):
    ctx = get_context()
    email = ctx.repos.emails.get(message_id)
    if not email:
        return "Письмо не найдено", 404
    tasks = [t for t in ctx.repos.tasks.list(limit=200)
             if t.get("source_message_id") == message_id]
    agreements = [a for a in ctx.repos.agreements.list(limit=200)
                  if a.get("source_message_id") == message_id]
    attachments = ctx.repos.attachments.for_email(message_id)
    from gigapost.summaries import email_context
    context_panel = email_context(ctx.repos, email)
    from gigapost.config import load_reply_templates
    return render_template("email_card.html", email=_decorate(email), tasks=tasks,
                           agreements=agreements, attachments=attachments,
                           context_panel=context_panel,
                           reply_templates=load_reply_templates(),
                           draft=request.args.get("draft"),
                           alert_count=ctx.repos.alerts.count_active())


@bp.post("/emails/<path:message_id>/suggest-reply")
def suggest_reply_route(message_id: str):
    """Кнопка «Предложить ответ»: генерирует черновик и показывает на карточке."""
    from flask import redirect, url_for

    from gigapost.agent.tools import build_reply_draft

    ctx = get_context()
    instruction = ""
    template_key = (request.form.get("template") or "").strip()
    if template_key:
        from gigapost.config import load_reply_templates
        tpl = next((t for t in load_reply_templates()
                    if t.get("key") == template_key), None)
        if tpl:
            instruction = tpl.get("instruction") or ""
    try:
        draft = build_reply_draft(ctx, message_id, instruction=instruction)
    except Exception as e:  # noqa: BLE001
        draft = f"[Не удалось сгенерировать черновик: {e}]"
    if draft is None:
        return "Письмо не найдено", 404
    return redirect(url_for("emails.email_card", message_id=message_id, draft=draft))


@bp.post("/emails/<path:message_id>/save-draft")
def save_draft_route(message_id: str):
    """Сохранить (возможно отредактированный) черновик в «Черновики» Outlook."""
    from flask import redirect, url_for

    ctx = get_context()
    email = ctx.repos.emails.get(message_id)
    body = (request.form.get("body") or "").strip()
    saved = False
    if email and email.get("entry_id") and body:
        try:
            saved = ctx.outlook.create_reply_draft(email["entry_id"], body)
        except Exception as e:  # noqa: BLE001
            logger.warning("Черновик не сохранён: %s", e)
    ctx.repos.log.log(message_id, "reply_draft", "ok" if saved else "error",
                      "черновик сохранён в Outlook" if saved else "не сохранён")
    return redirect(url_for("emails.email_card", message_id=message_id,
                            saved="1" if saved else "0"))


@bp.post("/emails/<path:message_id>/rate-draft")
def rate_draft(message_id: str):
    """Оценка черновика 👍/👎 — учится стилю на удачных."""
    from datetime import datetime

    from flask import redirect, url_for

    ctx = get_context()
    verdict = request.form.get("verdict")
    body = (request.form.get("body") or "").strip()
    if verdict in ("up", "down") and body:
        ctx.repos.db.execute(
            "INSERT INTO reply_feedback (message_id, draft, verdict, created_at) "
            "VALUES (?,?,?,?)",
            (message_id, body, verdict, datetime.now().isoformat()))
    return redirect(url_for("emails.email_card", message_id=message_id,
                            draft=body, rated=verdict))


@bp.post("/emails/<path:message_id>/dismiss")
def email_dismiss(message_id: str):
    """«Ознакомился, неинтересно»: скрыть письмо из списков, поиска и фокуса.
    Письмо остаётся в БД и графе знаний; в Outlook не трогаем."""
    from flask import redirect

    ctx = get_context()
    ctx.repos.emails.set_dismissed(message_id, True)
    return redirect("/emails")


@bp.post("/emails/<path:message_id>/restore")
def email_restore(message_id: str):
    from flask import redirect, url_for

    ctx = get_context()
    ctx.repos.emails.set_dismissed(message_id, False)
    return redirect(url_for("emails.email_card", message_id=message_id))


@bp.post("/emails/<path:message_id>/open-in-outlook")
def open_in_outlook(message_id: str):
    ctx = get_context()
    email = ctx.repos.emails.get(message_id)
    if email and email.get("entry_id"):
        try:
            ctx.outlook.display_email(email["entry_id"])
            return {"ok": True}
        except Exception as e:  # noqa: BLE001
            return {"ok": False, "error": str(e)}, 500
    return {"ok": False, "error": "нет entry_id"}, 404
