"""Дашборд: счётчики, задачи, договорённости на контроле, алерты."""

from __future__ import annotations

from datetime import datetime, timedelta

from flask import Blueprint, redirect, render_template, request, url_for

from gigapost.config import load_taxonomy
from gigapost.context import get_context
from gigapost.pipeline.nodes import apply_category_actions

bp = Blueprint("dashboard", __name__)

DIR_RU = {"we_owe": "должны мы", "they_owe": "должны нам", "mutual": "взаимно"}
KIND_RU = {"overdue": "Просрочено", "deadline_soon": "Скоро срок",
           "followup_needed": "Нужен follow-up",
           "task_maybe_done": "Похоже, выполнено",
           "sla_unanswered": "Ждут вашего ответа",
           "gateway_stalled": "Шлюз почты молчит",
           "knowledge_conflict": "Противоречие в знаниях"}


def _deadline_class(due_date: str | None, status: str) -> str:
    if status == "overdue":
        return "danger"
    if not due_date:
        return ""
    try:
        due = datetime.fromisoformat(due_date)
    except ValueError:
        return ""
    if due < datetime.now():
        return "danger"
    if due < datetime.now() + timedelta(days=2):
        return "warning"
    return ""


@bp.get("/")
def index():
    ctx = get_context()
    today = datetime.now().replace(hour=0, minute=0, second=0).isoformat()
    counters = {
        "emails_today": ctx.repos.emails.count_since(today),
        "open_tasks": ctx.repos.tasks.count("open"),
        "on_control": ctx.repos.agreements.count_open(),
        "alerts": ctx.repos.alerts.count_active(),
        "review": ctx.repos.emails.count_pending_review(),
        "drafts": ctx.repos.tasks.count("draft"),
    }
    taxonomy = load_taxonomy()
    review_emails = ctx.repos.emails.pending_review(limit=20)
    draft_tasks = ctx.repos.tasks.list("draft", limit=20)
    tasks = [
        dict(t, due_css={"danger": "due-late", "warning": "due-soon"}.get(
            _deadline_class(t.get("due_date"), t["status"]), "due-ok"))
        for t in ctx.repos.tasks.list("open", limit=30)
    ]
    agreements = [
        dict(a, direction_ru=DIR_RU.get(a.get("direction"), ""),
             css=_deadline_class(a.get("due_date"), a["status"]))
        for a in ctx.repos.agreements.list(limit=30)
    ]
    alerts = [dict(a, kind_ru=KIND_RU.get(a["kind"], a["kind"]))
              for a in ctx.repos.alerts.list_active(limit=20)]
    from gigapost.llm.throttle import LEDGER
    tokens_today = sum((r["p"] or 0) + (r["c"] or 0) for r in LEDGER.today())
    counters["tokens_today"] = tokens_today
    from gigapost.focus import focus_emails
    focus = focus_emails(ctx.repos, limit=5)
    from gigapost.health import snapshot
    health = snapshot(ctx.repos, ctx.vectors)
    return render_template("dashboard.html", counters=counters, tasks=tasks,
                           focus=focus, health=health,
                           agreements=agreements, alerts=alerts,
                           review_emails=review_emails, draft_tasks=draft_tasks,
                           categories=taxonomy.category_names,
                           alert_count=counters["alerts"])


@bp.post("/review/<path:message_id>/set-category")
def review_set_category(message_id: str):
    """Ручной разбор: пользователь выбрал категорию — применяем действия таксономии."""
    ctx = get_context()
    category = request.form.get("category", "")
    taxonomy = load_taxonomy()
    email = ctx.repos.emails.get(message_id)
    if category in taxonomy.category_names and email:
        # фиксируем поправку — few-shot для будущих классификаций
        if email.get("category") != category:
            ctx.repos.corrections.add(message_id, email.get("category"), category)
        ctx.repos.emails.set_review_resolved(message_id, category)
        applied = apply_category_actions(ctx.repos, ctx.outlook, taxonomy,
                                         message_id, category)
        status = "dry_run" if ctx.outlook.dry_run else "ok"
        ctx.repos.log.log(message_id, "apply", status,
                          f"ручной разбор → {category}; " + ("; ".join(applied) or "нет действий"))
    return redirect(url_for("dashboard.index"))


@bp.post("/tasks/<int:task_id>/accept")
def task_accept(task_id: int):
    """Принять черновик задачи: статус open + задача в Outlook с напоминанием."""
    from datetime import datetime as dt

    ctx = get_context()
    task = ctx.repos.tasks.get(task_id)
    if task and task["status"] == "draft":
        ctx.repos.tasks.set_status(task_id, "open")
        if (task.get("assignee") or "я") != "я":
            return redirect(request.referrer or url_for("dashboard.index"))
        email = ctx.repos.emails.get(task["source_message_id"]) if task.get("source_message_id") else None
        body = task.get("description") or ""
        if email:
            body += f"\n\nИз письма: {email.get('subject')} ({email.get('sender_name')}, {email.get('received_at')})"
        try:
            entry_id = ctx.outlook.create_task(
                subject=task["title"], body=body,
                due=dt.fromisoformat(task["due_date"]) if task.get("due_date") else None,
                reminder=dt.fromisoformat(task["reminder_at"]) if task.get("reminder_at") else None)
            if entry_id:
                ctx.repos.tasks.set_outlook_entry_id(task_id, entry_id)
        except Exception:  # noqa: BLE001 — задача остаётся open в БД
            pass
    return redirect(request.referrer or url_for("dashboard.index"))


@bp.post("/tasks/<int:task_id>/reject")
def task_reject(task_id: int):
    """Отклонить черновик задачи. Необязательная причина — двойной урок:
    few-shot для будущих извлечений + содержательная причина уходит
    фактом в граф знаний."""
    from datetime import datetime as dt

    ctx = get_context()
    task = ctx.repos.tasks.get(task_id)
    reason = (request.form.get("reason") or "").strip()
    if task and task["status"] == "draft":
        ctx.repos.tasks.set_status(task_id, "cancelled")
        if reason:
            ctx.repos.db.execute(
                "INSERT INTO task_feedback (task_id, title, reason, created_at) "
                "VALUES (?,?,?,?)",
                (task_id, task["title"], reason, dt.now().isoformat()))
            # длинная причина — это факт о процессе, а не просто «не надо»
            if len(reason) >= 30:
                try:
                    ctx.kg.add_note(
                        title=f"Как делается: {task['title'][:60]}",
                        body=reason,
                        kind="fact",
                        source_message_id=task.get("source_message_id"),
                        conversation_id=None)
                except Exception:  # noqa: BLE001
                    pass
    return redirect(request.referrer or url_for("dashboard.index"))


@bp.post("/tasks/<int:task_id>/done")
def task_done(task_id: int):
    ctx = get_context()
    task = ctx.repos.tasks.get(task_id)
    if task:
        ctx.repos.tasks.set_status(task_id, "done")
        if task.get("outlook_task_entry_id"):
            try:
                ctx.outlook.complete_task(task["outlook_task_entry_id"])
            except Exception:  # noqa: BLE001
                pass
    return redirect(request.referrer or url_for("dashboard.index"))


@bp.post("/agreements/<int:agreement_id>/done")
def agreement_done(agreement_id: int):
    ctx = get_context()
    ctx.repos.agreements.set_status(agreement_id, "done")
    return redirect(url_for("dashboard.index"))


@bp.post("/alerts/<int:alert_id>/ack")
def alert_ack(alert_id: int):
    ctx = get_context()
    ctx.repos.alerts.acknowledge(alert_id)
    return redirect(request.referrer or url_for("dashboard.index"))


@bp.post("/alerts/<int:alert_id>/close-task")
def alert_close_task(alert_id: int):
    """Алерт «похоже, выполнено»: подтверждение закрывает задачу."""
    ctx = get_context()
    alert = next((a for a in ctx.repos.alerts.list_active(limit=200)
                  if a["id"] == alert_id), None)
    if alert and alert["kind"] == "task_maybe_done":
        task = ctx.repos.tasks.get(alert["ref_id"])
        if task and task["status"] in ("open", "draft"):
            ctx.repos.tasks.set_status(task["id"], "done")
            if task.get("outlook_task_entry_id"):
                try:
                    ctx.outlook.complete_task(task["outlook_task_entry_id"])
                except Exception:  # noqa: BLE001
                    pass
        ctx.repos.alerts.acknowledge(alert_id)
    return redirect(request.referrer or url_for("dashboard.index"))


@bp.post("/actions/poll-now")
def poll_now():
    """Кнопка «проверить почту сейчас»."""
    runner = getattr(bp, "ingest_runner", None)
    if runner is not None:
        runner.run_cycle()
    return redirect(url_for("dashboard.index"))
