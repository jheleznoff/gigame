"""Граф знаний: страница + JSON-экспорт для vis-network."""

from __future__ import annotations

from flask import Blueprint, jsonify, render_template, request

from gigapost.context import get_context

bp = Blueprint("graph", __name__)


@bp.get("/graph")
def graph_page():
    ctx = get_context()
    return render_template("graph.html", stats=ctx.kg.stats(),
                           alert_count=ctx.repos.alerts.count_active())


@bp.get("/api/graph")
def graph_api():
    ctx = get_context()
    center = request.args.get("entity") or None
    depth = int(request.args.get("depth", 2))
    max_nodes = int(request.args.get("max_nodes", 150))
    return jsonify(ctx.kg.export_json(center=center, depth=depth, max_nodes=max_nodes))


@bp.get("/api/graph/node/<node_id>")
def graph_node(node_id: str):
    ctx = get_context()
    details = ctx.kg.node_details(node_id)
    if details is None:
        return jsonify({"error": "узел не найден"}), 404
    return jsonify(details)
