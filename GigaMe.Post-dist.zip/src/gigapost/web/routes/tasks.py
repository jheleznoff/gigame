"""Канбан-доска задач: проекты как доски, колонки — статусы, карточки задач."""

from __future__ import annotations

from datetime import datetime, timedelta

from flask import Blueprint, redirect, render_template, request, url_for

from gigapost.config import settings
from gigapost.context import get_context

bp = Blueprint("tasks", __name__)


def _due_css(due_date: str | None) -> str:
    if not due_date:
        return ""
    try:
        due = datetime.fromisoformat(due_date)
    except ValueError:
        return ""
    if due < datetime.now():
        return "due-late"
    if due < datetime.now() + timedelta(days=2):
        return "due-soon"
    return "due-ok"


def _annotate(t: dict) -> dict:
    t["due_css"] = _due_css(t.get("due_date"))
    t["vip"] = settings.is_vip(t.get("sender_name"), t.get("sender_email"))
    t["mine"] = (t.get("assignee") or "я") == "я"
    return t


@bp.get("/tasks")
def board():
    ctx = get_context()
    project = request.args.get("project") or None
    q = (request.args.get("q") or "").strip()
    who = request.args.get("who") or ""
    projects = ctx.repos.tasks.projects()
    board = ctx.repos.tasks.board(project, q=q, assignee_mode=who)
    sub_counts = ctx.repos.tasks.subtask_counts()
    for column in board.values():
        for t in column:
            _annotate(t)
            t["subs"] = sub_counts.get(t["id"])
        column.sort(key=lambda t: (not t["vip"],
                                   t.get("due_date") is None, t.get("due_date") or ""))
    counts = {p: sum(1 for s in ("draft", "open")
                     for t in ctx.repos.tasks.board(p)[s]) for p in projects}
    # вкладки — только проекты с активными задачами; полный список в «Проекты…»
    active_projects = [p for p in projects if counts.get(p)]
    if project and project not in active_projects:
        active_projects.append(project)
    return render_template("tasks.html", board=board, projects=projects,
                           active_projects=active_projects,
                           project=project, counts=counts, q=q, who=who,
                           alert_count=ctx.repos.alerts.count_active())


@bp.get("/tasks/archive")
def archive_page():
    """Архив: выполненные (архивированные) и отклонённые задачи."""
    ctx = get_context()
    project = request.args.get("project") or None
    tasks = ctx.repos.tasks.archived(project)
    projects = sorted({t["project"] for t in ctx.repos.tasks.archived(None, 1000)
                       if t.get("project")})
    return render_template("tasks_archive.html", tasks=tasks, project=project,
                           projects=projects,
                           alert_count=ctx.repos.alerts.count_active())


@bp.post("/tasks/<int:task_id>/archive")
def task_archive(task_id: int):
    ctx = get_context()
    task = ctx.repos.tasks.get(task_id)
    if task and task["status"] == "done":
        ctx.repos.tasks.archive(task_id)
    return redirect(request.referrer or url_for("tasks.board"))


@bp.post("/tasks/archive-done")
def archive_done():
    """Убрать в архив все выполненные (текущего проекта или все)."""
    ctx = get_context()
    project = request.form.get("project") or None
    ctx.repos.tasks.archive_done(project)
    return redirect(request.referrer or url_for("tasks.board"))


@bp.post("/tasks/<int:task_id>/restore")
def task_restore(task_id: int):
    """Из архива: архивированная → выполнено, отклонённая → черновик."""
    ctx = get_context()
    task = ctx.repos.tasks.get(task_id)
    if task and task["status"] == "archived":
        ctx.repos.tasks.set_status(task_id, "done")
    elif task and task["status"] == "cancelled":
        ctx.repos.tasks.set_status(task_id, "draft")
    return redirect(request.referrer or url_for("tasks.archive_page"))


@bp.get("/tasks/<int:task_id>")
def task_card(task_id: int):
    """Карточка задачи в духе Trello: детали, подзадачи, связи, источник."""
    ctx = get_context()
    task = ctx.repos.tasks.get(task_id)
    if not task:
        return "Задача не найдена", 404
    email = (ctx.repos.emails.get(task["source_message_id"])
             if task.get("source_message_id") else None)
    if email:
        task["sender_name"] = email.get("sender_name")
        task["sender_email"] = email.get("sender_email")
    _annotate(task)
    subtasks = [_annotate(s) for s in ctx.repos.tasks.subtasks(task_id)]
    linked = ctx.repos.tasks.linked_tasks(task_id)
    parent = ctx.repos.tasks.get(task["parent_id"]) if task.get("parent_id") else None
    # кандидаты для связывания: активные задачи, кроме себя и уже связанных
    exclude = {task_id} | {l["id"] for l in linked}
    linkable = [t for t in ctx.repos.db.query(
        """SELECT id, title, project FROM tasks
           WHERE status IN ('draft','open','done') AND parent_id IS NULL
           ORDER BY id DESC LIMIT 300""") if t["id"] not in exclude]
    return render_template("task_card.html", task=task, subtasks=subtasks,
                           linked=linked, parent=parent, email=email,
                           linkable=linkable,
                           projects=ctx.repos.tasks.projects(),
                           alert_count=ctx.repos.alerts.count_active())


@bp.post("/tasks/create")
def create_task_route():
    ctx = get_context()
    title = (request.form.get("title") or "").strip()
    if title:
        parent_id = request.form.get("parent_id")
        task_id = ctx.repos.tasks.create(
            title=title,
            description=(request.form.get("description") or "").strip(),
            due_date=(request.form.get("due_date") or "").strip() or None,
            project=(request.form.get("project") or "").strip() or None,
            assignee=(request.form.get("assignee") or "я").strip() or "я",
            status="open")
        if parent_id:
            ctx.repos.tasks.set_parent(task_id, int(parent_id))
    return redirect(request.referrer or url_for("tasks.board"))


@bp.post("/tasks/<int:task_id>/edit")
def edit_task(task_id: int):
    ctx = get_context()
    if ctx.repos.tasks.get(task_id):
        ctx.repos.tasks.update_fields(
            task_id,
            title=(request.form.get("title") or "").strip() or "(без названия)",
            description=(request.form.get("description") or "").strip(),
            due_date=(request.form.get("due_date") or "").strip(),
            project=(request.form.get("project") or "").strip(),
            assignee=(request.form.get("assignee") or "я").strip())
    return redirect(url_for("tasks.task_card", task_id=task_id))


@bp.post("/tasks/<int:task_id>/delete")
def delete_task(task_id: int):
    ctx = get_context()
    task = ctx.repos.tasks.get(task_id)
    if task:
        if task.get("outlook_task_entry_id"):
            try:
                ctx.outlook.delete_email(task["outlook_task_entry_id"])  # Delete у задач тот же
            except Exception:  # noqa: BLE001
                pass
        ctx.repos.tasks.delete(task_id)
    return redirect(url_for("tasks.board"))


@bp.post("/tasks/<int:task_id>/link")
def link_task(task_id: int):
    """Связать задачи: принимает «№12 — Название» (из подсказки), «12» или
    точное название задачи."""
    import re

    ctx = get_context()
    other = (request.form.get("other_id") or "").strip()
    other_id = None
    m = re.match(r"[№#]?\s*(\d+)", other)
    if m and ctx.repos.tasks.get(int(m.group(1))):
        other_id = int(m.group(1))
    elif other:
        row = ctx.repos.db.query_one(
            "SELECT id FROM tasks WHERE title = ? AND id != ? LIMIT 1",
            (other, task_id))
        if row:
            other_id = row["id"]
    if other_id and other_id != task_id:
        ctx.repos.tasks.add_link(task_id, other_id)
    return redirect(url_for("tasks.task_card", task_id=task_id))


@bp.post("/tasks/<int:task_id>/unlink/<int:other_id>")
def unlink_task(task_id: int, other_id: int):
    ctx = get_context()
    ctx.repos.tasks.remove_link(task_id, other_id)
    return redirect(url_for("tasks.task_card", task_id=task_id))


# ---------- проекты ----------

@bp.post("/projects/create")
def create_project():
    ctx = get_context()
    ctx.repos.tasks.create_project(request.form.get("name") or "")
    return redirect(url_for("tasks.board"))


@bp.post("/projects/rename")
def rename_project():
    ctx = get_context()
    ctx.repos.tasks.rename_project(request.form.get("old") or "",
                                   request.form.get("new") or "")
    return redirect(url_for("tasks.board"))


@bp.post("/projects/delete")
def delete_project():
    ctx = get_context()
    ctx.repos.tasks.delete_project(request.form.get("name") or "")
    return redirect(url_for("tasks.board"))


@bp.post("/tasks/<int:task_id>/set-project")
def set_project(task_id: int):
    ctx = get_context()
    ctx.repos.tasks.set_project(task_id, (request.form.get("project") or "").strip() or None)
    return redirect(request.referrer or url_for("tasks.board"))


# разрешённые перетаскивания между колонками
_ALLOWED_MOVES = {
    ("draft", "open"),   # принять черновик (создаёт задачу в Outlook, если моя)
    ("draft", "done"),   # принять и сразу закрыть
    ("open", "done"),    # выполнить
    ("done", "open"),    # вернуть в работу
}


@bp.post("/api/tasks/<int:task_id>/move")
def move_task(task_id: int):
    """Drag&drop: перенос карточки между колонками канбана."""
    ctx = get_context()
    target = (request.json or {}).get("status", "")
    task = ctx.repos.tasks.get(task_id)
    if not task:
        return {"ok": False, "error": "задача не найдена"}, 404
    current = task["status"]
    if (current, target) not in _ALLOWED_MOVES:
        return {"ok": False, "error": f"перенос {current} → {target} не поддерживается"}, 400

    if current == "draft":
        ctx.repos.tasks.set_status(task_id, "open")
        # Outlook-задача — только для моих задач
        if (task.get("assignee") or "я") == "я":
            from datetime import datetime as dt

            email = (ctx.repos.emails.get(task["source_message_id"])
                     if task.get("source_message_id") else None)
            body = task.get("description") or ""
            if email:
                body += (f"\n\nИз письма: {email.get('subject')} "
                         f"({email.get('sender_name')}, {email.get('received_at')})")
            try:
                entry_id = ctx.outlook.create_task(
                    subject=task["title"], body=body,
                    due=dt.fromisoformat(task["due_date"]) if task.get("due_date") else None,
                    reminder=dt.fromisoformat(task["reminder_at"]) if task.get("reminder_at") else None)
                if entry_id:
                    ctx.repos.tasks.set_outlook_entry_id(task_id, entry_id)
            except Exception:  # noqa: BLE001 — задача остаётся open в БД
                pass
    if target == "done":
        ctx.repos.tasks.set_status(task_id, "done")
        if task.get("outlook_task_entry_id"):
            try:
                ctx.outlook.complete_task(task["outlook_task_entry_id"])
            except Exception:  # noqa: BLE001
                pass
    elif target == "open" and current == "done":
        ctx.repos.tasks.set_status(task_id, "open")
    return {"ok": True, "status": target}