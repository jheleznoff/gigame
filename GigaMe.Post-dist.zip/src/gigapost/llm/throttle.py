"""Глобальный дроссель LLM-вызовов с приоритетами + учёт токенов.

Все вызовы GigaChat в процессе идут через одну очередь: между запросами
выдерживается минимальный интервал, а ожидающие потоки пропускаются
по приоритету (чат интерактивен — идёт первым). Это убирает каскады 429,
когда планировщик, чат и индексация толкаются на одном ключе.
"""

from __future__ import annotations

import heapq
import itertools
import logging
import threading
import time

logger = logging.getLogger(__name__)

# приоритеты: меньше = важнее
PRIORITY_CHAT = 0        # интерактивный чат и черновики ответов
PRIORITY_EXTRACT = 1     # извлечение задач/заметок
PRIORITY_CLASSIFY = 2    # классификация писем
PRIORITY_EMBED = 3       # эмбеддинги (самые терпеливые)

MIN_INTERVAL_SEC = 1.2   # минимальный зазор между запросами к API


class PriorityGate:
    """Пропускает по одному потоку за раз, в порядке приоритета.

    Реентерабелен: поток, уже держащий ворота, проходит без ожидания
    (embed_query у langchain внутри зовёт embed_documents — иначе дедлок).
    """

    def __init__(self, min_interval: float = MIN_INTERVAL_SEC):
        self._cond = threading.Condition()
        self._queue: list[tuple[int, int]] = []   # (priority, ticket)
        self._counter = itertools.count()
        self._busy = False
        self._owner: int | None = None
        self._depth = 0
        self._last_release = 0.0
        self._min_interval = min_interval

    def acquire(self, priority: int) -> None:
        me = threading.get_ident()
        with self._cond:
            if self._owner == me:      # вложенный вызов того же потока
                self._depth += 1
                return
            ticket = next(self._counter)
            heapq.heappush(self._queue, (priority, ticket))
            while self._busy or self._queue[0] != (priority, ticket):
                self._cond.wait()
            heapq.heappop(self._queue)
            self._busy = True
            self._owner = me
            self._depth = 1
        # зазор между запросами — вне блокировки очереди
        wait = self._min_interval - (time.monotonic() - self._last_release)
        if wait > 0:
            time.sleep(wait)

    def release(self) -> None:
        me = threading.get_ident()
        with self._cond:
            if self._owner != me:
                return
            self._depth -= 1
            if self._depth > 0:
                return
            self._busy = False
            self._owner = None
            self._last_release = time.monotonic()
            self._cond.notify_all()


GATE = PriorityGate()


class TokenLedger:
    """Учёт потраченных токенов по ролям (пишется в БД лениво)."""

    def __init__(self):
        self._lock = threading.Lock()
        self._db = None

    def attach_db(self, db) -> None:
        self._db = db

    def record(self, role: str, prompt_tokens: int, completion_tokens: int) -> None:
        if self._db is None:
            return
        try:
            with self._lock:
                self._db.execute(
                    "INSERT INTO llm_usage (role, prompt_tokens, completion_tokens, ts) "
                    "VALUES (?,?,?, datetime('now', 'localtime'))",
                    (role, prompt_tokens, completion_tokens))
        except Exception as e:  # noqa: BLE001 — учёт не должен ломать вызовы
            logger.debug("Учёт токенов: %s", e)

    def today(self) -> list[dict]:
        if self._db is None:
            return []
        try:
            rows = self._db.query(
                """SELECT role, SUM(prompt_tokens) p, SUM(completion_tokens) c, COUNT(*) n
                   FROM llm_usage WHERE ts >= date('now', 'localtime') GROUP BY role""")
            return [dict(r) for r in rows]
        except Exception:  # noqa: BLE001
            return []


LEDGER = TokenLedger()
