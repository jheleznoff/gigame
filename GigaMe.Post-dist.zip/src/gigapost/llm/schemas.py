"""Pydantic-схемы structured output для GigaChat."""

from __future__ import annotations

import re
from typing import Literal

from pydantic import BaseModel, Field, field_validator


def _clean_text(v: str) -> str:
    """Отрезать протёкшие фрагменты JSON и лишние кавычки из строк модели."""
    if not isinstance(v, str):
        return v
    # обрезаем всё после первой строки с "мусорными" скобками/кавычками JSON
    v = re.split(r'"\s*[\}\]],?\s*$|\n\s*[\}\]"]', v, maxsplit=1)[0]
    v = " ".join(v.split()).strip(' "')
    # непарные «ёлочки» (обрезанные кавычки) убираем совсем, парные оставляем
    if v.count("«") != v.count("»"):
        v = v.replace("«", "").replace("»", "")
    return v.strip()


class EmailClassification(BaseModel):
    """Результат классификации письма."""

    category: str = Field(description="Категория письма строго из предложенного списка")
    importance: int = Field(ge=1, le=5, description="Важность письма от 1 (мусор) до 5 (критично)")
    requires_action: bool = Field(description="Требует ли письмо ответа или действия от получателя")
    summary: str = Field(description="Краткое содержание письма, 1-2 предложения по-русски")
    confidence: int = Field(
        default=5, ge=1, le=5,
        description="Уверенность в выбранной категории: 5 — очевидно, 3 — вероятно, "
                    "1-2 — письмо неоднозначное, категория под вопросом")
    suspicious: bool = Field(
        default=False,
        description="Признаки фишинга/мошенничества: давление срочностью + ссылки/"
                    "вложения, несовпадение отправителя и подписи, домен-двойник, "
                    "запрос данных или оплаты от незнакомца")


class ExtractedTask(BaseModel):
    """Задача, которую должен выполнить получатель письма."""

    title: str = Field(description="Короткое название задачи")
    description: str = Field(default="", description="Подробности задачи")

    _clean = field_validator("title", "description", mode="after")(staticmethod(_clean_text))
    deadline: str | None = Field(
        default=None,
        description="Срок в формате YYYY-MM-DD или null; относительные даты "
                    "('до пятницы', 'к концу месяца') разрешить относительно даты письма")
    assignee: Literal["я", "отправитель", "другое"] = Field(
        default="я", description="Кто должен выполнить задачу")
    assignee_name: str | None = Field(
        default=None,
        description="Имя исполнителя, если задача не для владельца ящика (assignee != 'я')")
    project: str | None = Field(
        default=None,
        description="Название проекта, к которому относится задача (как в сущностях), или null")


class ExtractedAgreement(BaseModel):
    """Договорённость или обязательство из переписки."""

    description: str = Field(description="Суть договорённости")
    counterparty: str = Field(default="", description="Контрагент: кто обещал или с кем договорились")

    _clean = field_validator("description", "counterparty", mode="after")(staticmethod(_clean_text))
    direction: Literal["we_owe", "they_owe", "mutual"] = Field(
        description="we_owe — должны мы, they_owe — должны нам, mutual — взаимно")
    due_date: str | None = Field(default=None, description="Срок YYYY-MM-DD или null; не выдумывать")


class EntityRelation(BaseModel):
    """Связь сущности с другой сущностью."""

    target_name: str = Field(description="Имя связанной сущности")
    relation: Literal["works_at", "participates_in", "agreed_with", "discusses"] = Field(
        description="Тип связи")


class ExtractedEntity(BaseModel):
    """Сущность, упомянутая в письме."""

    name: str = Field(description="Нормализованное имя (людей — в именительном падеже)")

    _clean = field_validator("name", mode="after")(staticmethod(_clean_text))
    type: Literal["person", "org", "project", "topic"] = Field(description="Тип сущности")
    relations: list[EntityRelation] = Field(default_factory=list)


class ExtractedNote(BaseModel):
    """Атомарная заметка-знание в стиле Zettelkasten."""

    title: str = Field(description="Краткий заголовок мысли, до 10 слов")
    body: str = Field(description="Одна законченная мысль своими словами, 1-3 предложения. "
                                  "Каждое упоминание человека, организации, проекта или темы "
                                  "оберни в [[двойные скобки]]: «[[Анна Смирнова]] из [[Вектор]] "
                                  "пришлёт КП по [[Альфа]] до 25 июля»")
    kind: Literal["fact", "agreement", "decision", "event", "status"] = Field(
        default="fact",
        description="fact — факт; agreement — договорённость; decision — принятое решение; "
                    "event — событие/встреча; status — статус работ")

    _clean = field_validator("title", mode="after")(staticmethod(_clean_text))


class ClosureVerdict(BaseModel):
    """Какие открытые задачи фактически выполнены отправленным письмом."""

    done_task_ids: list[int] = Field(default_factory=list)


class NotesResult(BaseModel):
    """Результат извлечения заметок (отдельный вызов — надёжнее для GigaChat)."""

    notes: list[ExtractedNote] = Field(default_factory=list)


class DocFacts(BaseModel):
    """Ключевые реквизиты закупочного документа (из текста вложения)."""

    doc_type: Literal["договор", "спецификация", "заявка", "акт", "УПД",
                      "счёт", "форма", "протокол", "прочее"] = Field(
        default="прочее", description="Тип документа")
    number: str = Field(default="", description="Номер документа, например «10»")
    doc_date: str = Field(default="", description="Дата документа ГГГГ-ММ-ДД")
    amount: str = Field(default="", description="Сумма с копейками, например «100,50»")
    counterparty: str = Field(default="", description="Контрагент/поставщик")
    tech: str = Field(default="", description="Технологии/предмет, например «Java»")
    notes: str = Field(default="", description="Важные особенности одной фразой")

    _clean = field_validator("number", "counterparty", "tech", "notes",
                             mode="after")(staticmethod(_clean_text))


class Discrepancy(BaseModel):
    """Расхождение между документами комплекта."""

    severity: Literal["критично", "внимание", "заметка"] = "внимание"
    description: str = Field(description="Что не сходится и между какими документами")


class DocCheckResult(BaseModel):
    """Результат сверки комплекта документов."""

    summary: str = Field(default="", description="Итог одной-двумя фразами")
    discrepancies: list[Discrepancy] = Field(default_factory=list)


class ExtractionResult(BaseModel):
    """Полный результат извлечения из письма."""

    tasks: list[ExtractedTask] = Field(default_factory=list)
    agreements: list[ExtractedAgreement] = Field(default_factory=list)
    entities: list[ExtractedEntity] = Field(default_factory=list)
    notes: list[ExtractedNote] = Field(default_factory=list)
