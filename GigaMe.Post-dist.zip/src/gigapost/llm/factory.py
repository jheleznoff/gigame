"""Фабрика LLM: модель GigaChat по роли (classify / extract / chat).

Все модели проходят через глобальный дроссель (llm/throttle.py):
один запрос за раз, приоритет у интерактивного чата, учёт токенов.
"""

from __future__ import annotations

from functools import lru_cache

from gigapost.config import settings
from gigapost.llm.throttle import (GATE, LEDGER, PRIORITY_CHAT, PRIORITY_CLASSIFY,
                                   PRIORITY_EMBED, PRIORITY_EXTRACT)

_ROLE_PRIORITY = {"chat": PRIORITY_CHAT, "extract": PRIORITY_EXTRACT,
                  "classify": PRIORITY_CLASSIFY}


def _make_throttled_llm_class():
    from langchain_gigachat import GigaChat

    class ThrottledGigaChat(GigaChat):
        gigapost_role: str = "extract"

        def _generate(self, *args, **kwargs):
            GATE.acquire(_ROLE_PRIORITY.get(self.gigapost_role, PRIORITY_EXTRACT))
            try:
                result = super()._generate(*args, **kwargs)
            finally:
                GATE.release()
            try:
                usage = (result.llm_output or {}).get("token_usage") or {}
                LEDGER.record(self.gigapost_role,
                              int(usage.get("prompt_tokens") or 0),
                              int(usage.get("completion_tokens") or 0))
            except Exception:  # noqa: BLE001
                pass
            return result

    return ThrottledGigaChat


@lru_cache(maxsize=None)
def get_llm(role: str):
    cls = _make_throttled_llm_class()
    model = getattr(settings.models, role)
    llm = cls(
        model=model,
        profanity_check=False,
        temperature=0.7 if role == "chat" else 0.1,
        timeout=120,
        **settings.gigachat_auth_kwargs(),
    )
    llm.gigapost_role = role
    return llm


def _make_throttled_embeddings_class():
    from langchain_gigachat import GigaChatEmbeddings

    class ThrottledEmbeddings(GigaChatEmbeddings):
        def embed_documents(self, texts):
            GATE.acquire(PRIORITY_EMBED)
            try:
                return super().embed_documents(texts)
            finally:
                GATE.release()

        def embed_query(self, text):
            GATE.acquire(PRIORITY_EMBED)
            try:
                return super().embed_query(text)
            finally:
                GATE.release()

    return ThrottledEmbeddings


@lru_cache(maxsize=None)
def get_embeddings():
    cls = _make_throttled_embeddings_class()
    return cls(
        model=settings.models.embeddings,
        **settings.gigachat_auth_kwargs(),
    )
