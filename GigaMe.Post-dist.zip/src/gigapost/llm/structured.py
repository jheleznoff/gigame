"""structured_call: function calling с fallback на JSON-промптинг.

GigaChat поддерживает with_structured_output, но на сложных схемах может
вернуть невалидный ответ — тогда пробуем явный JSON-промптинг: схема в промпт,
вырезаем JSON между первой '{' и последней '}', валидируем Pydantic.
"""

from __future__ import annotations

import json
import logging
from typing import TypeVar

from gigachat.exceptions import GigaChatException, RateLimitError
from pydantic import BaseModel, ValidationError
from tenacity import retry, retry_if_exception_type, stop_after_attempt, wait_exponential

from gigapost.config import settings

logger = logging.getLogger(__name__)

T = TypeVar("T", bound=BaseModel)

# 429 и сетевые сбои GigaChat — ретраим с экспоненциальной паузой
RETRYABLE = (ConnectionError, RateLimitError)


class StructuredCallError(RuntimeError):
    pass


def _extract_json(text: str) -> str:
    start = text.find("{")
    end = text.rfind("}")
    if start == -1 or end <= start:
        raise ValueError(f"В ответе модели нет JSON-объекта: {text[:200]}")
    return text[start:end + 1]


def _json_prompt_fallback(llm, schema: type[T], prompt: str) -> T:
    json_schema = json.dumps(schema.model_json_schema(), ensure_ascii=False, indent=2)
    full_prompt = (
        f"{prompt}\n\n"
        f"Ответь ТОЛЬКО валидным JSON-объектом строго по этой JSON-схеме, "
        f"без пояснений и markdown:\n{json_schema}"
    )
    last_error: Exception | None = None
    for _ in range(2):
        response = llm.invoke(full_prompt)
        text = response.content if hasattr(response, "content") else str(response)
        try:
            return schema.model_validate_json(_extract_json(text))
        except (ValidationError, ValueError, json.JSONDecodeError) as e:
            last_error = e
            full_prompt = (
                f"{prompt}\n\nПредыдущий ответ не прошёл валидацию ({e}). "
                f"Ответь ТОЛЬКО валидным JSON по схеме:\n{json_schema}"
            )
    raise StructuredCallError(f"JSON-fallback не дал валидного ответа: {last_error}")


@retry(
    stop=stop_after_attempt(max(settings.limits.llm_max_retries, 5)),
    wait=wait_exponential(multiplier=5, min=5, max=60),
    retry=retry_if_exception_type(RETRYABLE),
    reraise=True,
)
def structured_call(llm, schema: type[T], prompt: str) -> T:
    try:
        result = llm.with_structured_output(schema).invoke(prompt)
        if isinstance(result, schema):
            return result
        if isinstance(result, dict):
            return schema.model_validate(result)
        raise ValidationError.from_exception_data("unexpected type", [])
    except StructuredCallError:
        raise
    except RETRYABLE:
        raise  # отдаём tenacity на ретрай, это не повод для JSON-fallback
    except Exception as e:  # noqa: BLE001 — любой сбой function calling → JSON-fallback
        logger.warning("with_structured_output не сработал (%s), пробую JSON-промптинг", e)
        return _json_prompt_fallback(llm, schema, prompt)
