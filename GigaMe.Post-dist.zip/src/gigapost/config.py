"""Единая конфигурация: секреты из .env, остальное из config/*.yaml."""

from __future__ import annotations

import logging
import re
from pathlib import Path
from typing import Any

import yaml
from pydantic import BaseModel, Field
from pydantic_settings import BaseSettings, SettingsConfigDict

PROJECT_ROOT = Path(__file__).resolve().parents[2]
CONFIG_DIR = PROJECT_ROOT / "config"
DATA_DIR = PROJECT_ROOT / "data"
PROMPTS_DIR = CONFIG_DIR / "prompts"


class ModelsConfig(BaseModel):
    classify: str = "GigaChat-2"
    extract: str = "GigaChat-2-Pro"
    chat: str = "GigaChat-2-Max"
    embeddings: str = "EmbeddingsGigaR"


class PollingConfig(BaseModel):
    interval_minutes: int = 5
    folders: list[str] = Field(default_factory=lambda: ["Inbox"])
    lookback_overlap_minutes: int = 5
    # какое хранилище Outlook читать: "auto" — первый ящик с «@» в имени
    # (или хранилище по умолчанию), либо подстрока имени, например "mail.ru"
    store: str = "auto"
    # хранилища, которые НИКОГДА не трогаем (подстроки имён; напр. чужие/общие ящики)
    exclude_stores: list[str] = Field(default_factory=list)


class LimitsConfig(BaseModel):
    max_body_chars: int = 8000
    embed_batch: int = 16
    llm_max_retries: int = 3
    chunk_chars: int = 2500


class OwnerConfig(BaseModel):
    """Владелец ящика — чтобы LLM понимал, кто «я» в письмах."""

    name: str = "Владелец ящика"
    aliases: list[str] = Field(default_factory=list)

    @property
    def full(self) -> str:
        extra = f" (обращения: {', '.join(self.aliases)})" if self.aliases else ""
        return f"{self.name}{extra}"


class ReviewConfig(BaseModel):
    # классификация с уверенностью ниже порога уходит на ручной разбор
    min_classify_confidence: int = 3


class ControlConfig(BaseModel):
    check_interval_minutes: int = 30
    default_followup_days: int = 3
    deadline_soon_hours: int = 24
    set_outlook_flag_on_followup: bool = False


class WebConfig(BaseModel):
    host: str = "127.0.0.1"
    port: int = 8765


class OutlookActionConfig(BaseModel):
    folder: str | None = None
    category: str | None = None
    flag: bool = False
    color: str | None = None


class CategoryConfig(BaseModel):
    name: str
    description: str = ""
    outlook: OutlookActionConfig = Field(default_factory=OutlookActionConfig)
    # извлекать ли из писем этой категории задачи/договорённости/сущности
    extract: bool = True


class HardRule(BaseModel):
    match: dict[str, str]
    category: str

    def matches(self, sender_email: str, subject: str, body: str = "") -> bool:
        sender_email = sender_email or ""
        subject = subject or ""
        body = body or ""
        for key, pattern in self.match.items():
            if key == "sender_email":
                if not re.search(pattern, sender_email, re.IGNORECASE):
                    return False
            elif key == "sender_domain":
                domain = sender_email.split("@")[-1] if "@" in sender_email else ""
                if not re.search(pattern, domain, re.IGNORECASE):
                    return False
            elif key == "subject":
                if not re.search(pattern, subject, re.IGNORECASE):
                    return False
            elif key == "body":
                # тело должно быть уже очищено от цитируемых хвостов
                if not re.search(pattern, body, re.IGNORECASE):
                    return False
            else:
                return False
        return True


class Taxonomy(BaseModel):
    categories: list[CategoryConfig] = Field(default_factory=list)
    hard_rules: list[HardRule] = Field(default_factory=list)

    @property
    def category_names(self) -> list[str]:
        return [c.name for c in self.categories]

    def get(self, name: str) -> CategoryConfig | None:
        for c in self.categories:
            if c.name == name:
                return c
        return None

    def apply_hard_rules(self, sender_email: str, subject: str,
                         body: str = "") -> str | None:
        for rule in self.hard_rules:
            if rule.matches(sender_email, subject, body):
                return rule.category
        return None


class Settings(BaseSettings):
    """Секреты из .env + окружения; YAML подгружается отдельно в load_settings()."""

    model_config = SettingsConfigDict(
        env_file=PROJECT_ROOT / ".env", env_file_encoding="utf-8", extra="ignore"
    )

    gigachat_credentials: str = ""
    gigachat_scope: str = "GIGACHAT_API_PERS"
    gigachat_verify_ssl_certs: bool = False
    # Корпоративный контур (mTLS, как у GigaMe): если задан cert_file —
    # авторизация по сертификатам вместо OAuth-ключа
    gigachat_base_url: str = ""          # напр. https://gigachat-ift.sberdevices.delta.sbrf.ru/v1
    gigachat_cert_file: str = ""         # клиентский сертификат (GIGACHAT_SERT)
    gigachat_key_file: str = ""          # приватный ключ (GIGACHAT_KEY)
    gigachat_key_file_password: str = ""
    # Переопределение моделей из .env (поверх config/settings.yaml):
    # GIGACHAT_MODEL — одна модель на все LLM-роли (напр. GigaChat-Ultra на корп-сегменте),
    # GIGACHAT_MODEL_<ROLE> — точечно (classify/extract/chat/embeddings)
    gigachat_model: str = ""
    gigachat_model_classify: str = ""
    gigachat_model_extract: str = ""
    gigachat_model_chat: str = ""
    gigachat_model_embeddings: str = ""

    def resolve_model(self, role: str) -> str:
        per_role = getattr(self, f"gigachat_model_{role}", "")
        if per_role:
            return per_role
        if self.gigachat_model and role != "embeddings":
            return self.gigachat_model
        return getattr(self.models, role)

    def gigachat_auth_kwargs(self) -> dict:
        """Параметры подключения GigaChat: mTLS-сертификаты (корп-контур)
        или OAuth-ключ (публичный API)."""
        kwargs: dict = {"verify_ssl_certs": self.gigachat_verify_ssl_certs}
        if self.gigachat_base_url:
            kwargs["base_url"] = self.gigachat_base_url
        if self.gigachat_cert_file:
            kwargs["cert_file"] = self.gigachat_cert_file
            kwargs["key_file"] = self.gigachat_key_file
            if self.gigachat_key_file_password:
                kwargs["key_file_password"] = self.gigachat_key_file_password
        else:
            kwargs["credentials"] = self.gigachat_credentials
            kwargs["scope"] = self.gigachat_scope
        return kwargs

    owner: OwnerConfig = Field(default_factory=OwnerConfig)
    vips: list[str] = Field(default_factory=list)  # руководители — особое выделение

    def is_vip(self, sender_name: str | None, sender_email: str | None = None) -> bool:
        haystack = f"{sender_name or ''} {sender_email or ''}".lower()
        return any(v.lower() in haystack for v in self.vips if v)
    models: ModelsConfig = Field(default_factory=ModelsConfig)
    polling: PollingConfig = Field(default_factory=PollingConfig)
    limits: LimitsConfig = Field(default_factory=LimitsConfig)
    control: ControlConfig = Field(default_factory=ControlConfig)
    review: ReviewConfig = Field(default_factory=ReviewConfig)
    web: WebConfig = Field(default_factory=WebConfig)
    dry_run: bool = True

    @property
    def db_path(self) -> Path:
        return DATA_DIR / "gigapost.db"

    @property
    def checkpoints_db_path(self) -> Path:
        return DATA_DIR / "checkpoints.db"

    @property
    def chroma_path(self) -> Path:
        return DATA_DIR / "chroma"

    @property
    def graphml_path(self) -> Path:
        return DATA_DIR / "graph.graphml"


def _load_yaml(path: Path) -> dict[str, Any]:
    if not path.exists():
        return {}
    with open(path, encoding="utf-8") as f:
        return yaml.safe_load(f) or {}


def load_settings() -> Settings:
    raw = _load_yaml(CONFIG_DIR / "settings.yaml")
    return Settings(**raw)


def load_taxonomy() -> Taxonomy:
    return Taxonomy(**_load_yaml(CONFIG_DIR / "taxonomy.yaml"))


def load_prompt(name: str) -> str:
    return (PROMPTS_DIR / f"{name}.md").read_text(encoding="utf-8")


def setup_logging(level: int = logging.INFO) -> None:
    DATA_DIR.mkdir(exist_ok=True)
    logging.basicConfig(
        level=level,
        format="%(asctime)s %(levelname)-7s %(name)s: %(message)s",
        handlers=[
            logging.StreamHandler(),
            logging.FileHandler(DATA_DIR / "gigapost.log", encoding="utf-8"),
        ],
    )
    logging.getLogger("httpx").setLevel(logging.WARNING)
    logging.getLogger("apscheduler").setLevel(logging.WARNING)


settings = load_settings()
