"""Роутер намерений чата: вопросы — детерминированным RAG-путём, действия — агенту.

Урок эксплуатации: GigaChat ненадёжен в свободных ReAct-цепочках, но отлично
отвечает по собранному контексту. Поэтому запросы-вопросы («что», «почему»,
«какой статус», «кто», «покажи», «сколько») обрабатываются без агента:
сервер сам собирает контекст (знания + письма + задачи + договорённости)
и просит модель один раз ответить. Действия (создать/удалить/переместить/
ответить/запомнить) остаются агенту с HITL-инструментами.
"""

from __future__ import annotations

import logging
import re

from gigapost.config import load_prompt, settings
from gigapost.pipeline.nodes import clean_body

logger = logging.getLogger(__name__)

# сигналы действия — такие запросы уходят агенту с инструментами
_ACTION_RE = re.compile(
    r"\b(создай|добавь|заведи|удали|перемести|перенеси|раздели|разложи|отправь|"
    r"сохрани|запомни|закрой|выполни|отметь|свяжи|подготовь|предложи ответ|"
    r"ответь|напиши ответ|черновик|сделай|поставь|назначь|переименуй)\w*",
    re.IGNORECASE)


def is_action(message: str) -> bool:
    return bool(_ACTION_RE.search(message))


def gather_context(ctx, query: str, k_notes: int = 6, k_emails: int = 5) -> str:
    """Собрать контекст для ответа на вопрос: знания, письма, задачи, контроль."""
    parts: list[str] = []
    seen_notes: set[int] = set()
    # знания: вектор + FTS
    try:
        if ctx.vectors is not None:
            vec = ctx.vectors.embeddings.embed_query(query)
            res = ctx.vectors.notes_collection.query(query_embeddings=[vec],
                                                     n_results=k_notes)
            for note_id in res["ids"][0]:
                note = ctx.repos.notes.get(int(note_id))
                if note and note["id"] not in seen_notes:
                    seen_notes.add(note["id"])
                    body = note["body"].replace("[[", "").replace("]]", "")
                    parts.append(f"[знание/{note['kind']}] {note['title']}: {body}")
    except Exception as e:  # noqa: BLE001
        logger.warning("Контекст (вектор): %s", e)
    for note in ctx.repos.notes.search_fts(query, limit=3):
        if note["id"] not in seen_notes:
            seen_notes.add(note["id"])
            body = note["body"].replace("[[", "").replace("]]", "")
            parts.append(f"[знание/{note['kind']}] {note['title']}: {body}")
    # backlinks сущностей, упомянутых в вопросе
    try:
        q_lower = query.lower()
        for e in ctx.repos.entities.all_entities():
            if len(e["name"]) >= 4 and e["name"].lower() in q_lower:
                for note in ctx.repos.notes.for_entity(e["id"], limit=3):
                    if note["id"] not in seen_notes:
                        seen_notes.add(note["id"])
                        body = note["body"].replace("[[", "").replace("]]", "")
                        parts.append(f"[знание о {e['name']}] {note['title']}: {body}")
    except Exception:  # noqa: BLE001
        pass
    # письма
    for email in ctx.repos.emails.search_fts(query, limit=k_emails):
        parts.append(f"[письмо] {email.get('received_at', '')[:10]} "
                     f"{email.get('sender_name')}: «{email.get('subject')}» — "
                     f"{(email.get('summary') or clean_body(email.get('body_text') or '', 150))}")
    # задачи и контроль — только если вопрос похож на них
    if re.search(r"задач|дел[ае]|срок|просроч|должн|обещал|контрол|договор[её]нн",
                 query, re.IGNORECASE):
        for t in ctx.repos.tasks.list(limit=25):
            if t["status"] in ("open", "draft"):
                parts.append(f"[задача/{t['status']}] {t['title']} "
                             f"(срок {t.get('due_date') or 'нет'}, "
                             f"исполнитель {t.get('assignee') or 'я'})")
        for a in ctx.repos.agreements.list(limit=15):
            parts.append(f"[контроль/{a['status']}] {a['description']} "
                         f"({a.get('counterparty')}, срок {a.get('due_date') or 'нет'})")
    return "\n".join(parts[:30])


def answer_question(ctx, message: str) -> str:
    """Детерминированный RAG-ответ: один вызов модели по собранному контексту."""
    from gigapost.llm.factory import get_llm

    context = gather_context(ctx, message)
    if not context.strip():
        return ("В базе пока нет данных по этому вопросу — ни в знаниях, ни в письмах, "
                "ни в задачах.")
    prompt = (
        f"Ты — ассистент владельца почты ({settings.owner.full}). Ответь на вопрос, "
        f"опираясь ТОЛЬКО на контекст ниже. Не выдумывай фактов. Если данных не "
        f"хватает — скажи, чего именно. Отвечай по-русски, кратко и структурно.\n\n"
        f"Вопрос: {message}\n\nКонтекст:\n{context}")
    result = get_llm("chat").invoke(prompt)
    return result.content if hasattr(result, "content") else str(result)
