"""Роутер намерений чата: вопросы — детерминированным RAG-путём, действия — агенту.

Урок эксплуатации: GigaChat ненадёжен в свободных ReAct-цепочках, но отлично
отвечает по собранному контексту. Поэтому запросы-вопросы («что», «почему»,
«какой статус», «кто», «покажи», «сколько») обрабатываются без агента:
сервер сам собирает контекст (знания + письма + задачи + договорённости)
и просит модель один раз ответить. Действия (создать/удалить/переместить/
ответить/запомнить) остаются агенту с HITL-инструментами.
"""

from __future__ import annotations

import logging
import re

from gigapost.config import load_prompt, settings
from gigapost.pipeline.nodes import clean_body

logger = logging.getLogger(__name__)

# сигналы действия — такие запросы уходят агенту с инструментами
_ACTION_RE = re.compile(
    r"\b(создай|добавь|заведи|удали|перемести|перенеси|раздели|разложи|отправь|"
    r"сохрани|запомни|закрой|выполни|отметь|свяжи|подготовь|предложи ответ|"
    r"ответь|напиши ответ|черновик|сделай|поставь|назначь|переименуй)\w*",
    re.IGNORECASE)


def is_action(message: str) -> bool:
    return bool(_ACTION_RE.search(message))


_TASK_WORDS = re.compile(r"задач|поручен|канбан|доск", re.IGNORECASE)
_AGREEMENT_WORDS = re.compile(r"договорённост|договоренност|контрол|должн|обещал|"
                              r"просроч|follow", re.IGNORECASE)
_EMAIL_WORDS = re.compile(r"письм|почт|переписк|тред", re.IGNORECASE)
_DOC_WORDS = re.compile(r"документ|акт|упд|счет|счёт|спецификац|договор\b|реестр",
                        re.IGNORECASE)


def suggest_links(repos, question: str) -> list[dict]:
    """Ссылки «открыть в разделе» к ответу: раздел уже отфильтрован по смыслу
    вопроса. Детерминированно, без LLM."""
    q = question.lower()
    links: list[dict] = []

    # упомянутый проект → доска задач с фильтром по проекту
    matched_project = None
    try:
        for p in repos.tasks.projects():
            if p and p.lower() in q:
                matched_project = p
                break
    except Exception:  # noqa: BLE001
        pass

    if _TASK_WORDS.search(q) or matched_project:
        from urllib.parse import quote
        if matched_project:
            links.append({"label": f"Доска задач: {matched_project}",
                          "url": f"/tasks?project={quote(matched_project)}"})
        else:
            links.append({"label": "Открыть доску задач", "url": "/tasks"})
    if _AGREEMENT_WORDS.search(q):
        links.append({"label": "Контроль и решения", "url": "/decisions"})
    if _DOC_WORDS.search(q):
        links.append({"label": "Реестр документов", "url": "/registry"})
    if _EMAIL_WORDS.search(q):
        from urllib.parse import quote
        words = [w for w in re.findall(r"[а-яёa-z0-9-]{4,}", q)
                 if not _EMAIL_WORDS.search(w)][:3]
        url = "/emails" + (f"?q={quote(' '.join(words))}" if words else "")
        links.append({"label": "Найти в письмах", "url": url})

    # упомянутая сущность → досье
    try:
        for e in repos.entities.all_entities():
            name = (e.get("name") or "")
            if len(name) >= 4 and name.lower() in q:
                links.append({"label": f"Досье: {name}", "url": f"/entity/{e['id']}"})
                break
    except Exception:  # noqa: BLE001
        pass
    return links[:3]


def _add_source(sources: list[dict] | None, label: str, url: str | None) -> None:
    """Копилка источников ответа (для кнопок-ссылок под ответом в чате)."""
    if sources is None or not url:
        return
    if any(s["url"] == url for s in sources):
        return
    sources.append({"label": label, "url": url})


def _note_source(sources, note, prefix="Знание") -> None:
    title = (note.get("title") or "заметка")[:45]
    if note.get("source_message_id"):
        _add_source(sources, f"{prefix}: {title}",
                    f"/emails/{note['source_message_id']}")
    elif note.get("conversation_id"):
        _add_source(sources, f"{prefix}: {title}",
                    f"/threads/{note['conversation_id']}")


def gather_context(ctx, query: str, k_notes: int = 6, k_emails: int = 5,
                   sources: list[dict] | None = None) -> str:
    """Собрать контекст для ответа на вопрос: знания, письма, задачи, контроль.

    sources — необязательная копилка: сюда складываются ссылки на карточки
    знаний (их письма-источники) и письма, попавшие в контекст."""
    parts: list[str] = []
    seen_notes: set[int] = set()
    # знания: вектор + FTS
    try:
        if ctx.vectors is not None:
            vec = ctx.vectors.embeddings.embed_query(query)
            res = ctx.vectors.notes_collection.query(query_embeddings=[vec],
                                                     n_results=k_notes)
            for note_id in res["ids"][0]:
                note = ctx.repos.notes.get(int(note_id))
                if note and note["id"] not in seen_notes:
                    seen_notes.add(note["id"])
                    body = note["body"].replace("[[", "").replace("]]", "")
                    parts.append(f"[знание/{note['kind']}] {note['title']}: {body}")
                    _note_source(sources, note)
    except Exception as e:  # noqa: BLE001
        logger.warning("Контекст (вектор): %s", e)
    for note in ctx.repos.notes.search_fts(query, limit=3):
        if note["id"] not in seen_notes:
            seen_notes.add(note["id"])
            body = note["body"].replace("[[", "").replace("]]", "")
            parts.append(f"[знание/{note['kind']}] {note['title']}: {body}")
            _note_source(sources, note)
    # backlinks сущностей, упомянутых в вопросе
    try:
        q_lower = query.lower()
        for e in ctx.repos.entities.all_entities():
            if len(e["name"]) >= 4 and e["name"].lower() in q_lower:
                for note in ctx.repos.notes.for_entity(e["id"], limit=3):
                    if note["id"] not in seen_notes:
                        seen_notes.add(note["id"])
                        body = note["body"].replace("[[", "").replace("]]", "")
                        parts.append(f"[знание о {e['name']}] {note['title']}: {body}")
                        _note_source(sources, note)
    except Exception:  # noqa: BLE001
        pass
    # письма
    for email in ctx.repos.emails.search_fts(query, limit=k_emails):
        parts.append(f"[письмо] {email.get('received_at', '')[:10]} "
                     f"{email.get('sender_name')}: «{email.get('subject')}» — "
                     f"{(email.get('summary') or clean_body(email.get('body_text') or '', 150))}")
        _add_source(sources, f"Письмо: {(email.get('subject') or 'без темы')[:45]}",
                    f"/emails/{email.get('message_id')}")
    # задачи и контроль — только если вопрос похож на них
    if re.search(r"задач|дел[ае]|срок|просроч|должн|обещал|контрол|договор[её]нн",
                 query, re.IGNORECASE):
        for t in ctx.repos.tasks.list(limit=25):
            if t["status"] in ("open", "draft"):
                parts.append(f"[задача/{t['status']}] {t['title']} "
                             f"(срок {t.get('due_date') or 'нет'}, "
                             f"исполнитель {t.get('assignee') or 'я'})")
        for a in ctx.repos.agreements.list(limit=15):
            parts.append(f"[контроль/{a['status']}] {a['description']} "
                         f"({a.get('counterparty')}, срок {a.get('due_date') or 'нет'})")
    return "\n".join(parts[:30])


def answer_question(ctx, message: str, extra_context: str = "",
                    sources: list[dict] | None = None) -> str:
    """Детерминированный RAG-ответ: один вызов модели по собранному контексту.

    extra_context — например, документ, приложенный пользователем в чат;
    sources — копилка ссылок на источники (см. gather_context)."""
    from gigapost.llm.factory import get_llm

    context = gather_context(ctx, message, sources=sources)
    if extra_context.strip():
        context = extra_context.strip() + "\n\n" + context
    if not context.strip():
        return ("В базе пока нет данных по этому вопросу — ни в знаниях, ни в письмах, "
                "ни в задачах.")
    prompt = (
        f"Ты — ассистент владельца почты ({settings.owner.full}). Ответь на вопрос, "
        f"опираясь ТОЛЬКО на контекст ниже. Не выдумывай фактов. Если данных не "
        f"хватает — скажи, чего именно. Отвечай по-русски, кратко и структурно.\n\n"
        f"Вопрос: {message}\n\nКонтекст:\n{context}")
    result = get_llm("chat").invoke(prompt)
    return result.content if hasattr(result, "content") else str(result)


# ---------------------------------------------------------------------------
# Вопросы-перечисления: «приведи ФИО и логины всех, кому запрошен доступ…»
# Обычный RAG берёт top-k фрагментов и теряет хвост (из 100 находит 5).
# Здесь — полный проход: широкий FTS-свип → извлечение элементов чанками
# (лимит GigaChat ~4096 токенов) → детерминированное слияние без потерь.
# ---------------------------------------------------------------------------

_ENUM_RE = re.compile(
    r"перечисл|привед|полный список|весь список|поимённ|поименн|"
    r"\bвсех\b|\bкажд(?:ый|ого|ому)\b|кто (?:получил|запрашивал|просил|подавал)|"
    r"кому (?:был|выда|запр|согласов)|\bфио\b|\bлогин", re.IGNORECASE)

_STOP_WORDS = {
    "приведи", "приведите", "перечисли", "перечислите", "список", "списки",
    "полный", "весь", "всех", "все", "всем", "кому", "кто", "был", "была",
    "были", "было", "для", "это", "этих", "или", "что", "как", "какие",
    "какой", "чей", "мне", "меня", "нужно", "покажи", "дай", "назови",
    "также", "еще", "ещё", "только", "есть", "каждый", "фио", "именно"}

_ENUM_MAX_CHUNKS = 30
_ENUM_CHUNK_CHARS = 3000
_ENUM_EMAIL_SNIPPET = 700


def is_enumeration(message: str) -> bool:
    return bool(_ENUM_RE.search(message))


def _keywords(message: str) -> list[str]:
    words = re.findall(r"[а-яёa-z0-9_.@-]{3,}", message.lower())
    out: list[str] = []
    for w in words:
        if w in _STOP_WORDS or w in out:
            continue
        # срезаем окончание — FTS-префикс «доступ*» найдёт «доступа/доступов»
        out.append(w[:-1] if len(w) >= 6 and re.search(r"[а-яё]$", w) else w)
    return out[:6]


def _dedupe_key(line: str) -> str:
    return re.sub(r"[\s.,;:—–-]+", " ", line.lower()).strip()


def _plural(n: int, one: str, few: str, many: str) -> str:
    if n % 10 == 1 and n % 100 != 11:
        return one
    if n % 10 in (2, 3, 4) and n % 100 not in (12, 13, 14):
        return few
    return many


def _merge_enum_items(items: list[str]) -> list[str]:
    """Слить дубли перечисления: строки «значение — уточнение» группируются
    по значению; «Максим» поглощается «Максим Железнов» (если полный вариант
    один); из уточнений берётся первое (из самого релевантного фрагмента)."""
    order: list[str] = []
    by_key: dict[str, dict] = {}
    for line in items:
        # метки источников [S7] выносим из текста и несём отдельно
        srcs = re.findall(r"\[S(\d+)\]", line)
        line = re.sub(r"\s*\[S\d+\]", "", line).strip(" ,;—–-")
        parts = re.split(r"\s+[—–:]\s+|\s+-\s+", line, maxsplit=1)
        name = parts[0].strip()
        tail = parts[1].strip() if len(parts) > 1 else ""
        # «ФИО — НЕТ»: заглушка модели вместо отсутствующего уточнения
        if re.fullmatch(r"(нет|не указан[оа]?|отсутствует|неизвестн\w*|-|—)",
                        tail, re.IGNORECASE):
            tail = ""
        key = re.sub(r"[\s.,]+", " ", name.lower()).strip()
        if not key:
            continue
        if key not in by_key:
            by_key[key] = {"name": name, "tails": [], "srcs": []}
            order.append(key)
        if tail and tail not in by_key[key]["tails"]:
            by_key[key]["tails"].append(tail)
        for s in srcs:
            if s not in by_key[key]["srcs"]:
                by_key[key]["srcs"].append(s)
    # короткое имя поглощается полным, если полный вариант ровно один
    for short in list(order):
        if short not in by_key:
            continue
        short_words = set(short.split())
        supersets = [k for k in by_key
                     if k != short and short_words <= set(k.split())]
        if len(supersets) == 1:
            target = by_key[supersets[0]]
            for t in by_key[short]["tails"]:
                if t not in target["tails"]:
                    target["tails"].append(t)
            for s in by_key[short]["srcs"]:
                if s not in target["srcs"]:
                    target["srcs"].append(s)
            del by_key[short]
            order.remove(short)
    out = []
    for k in order:
        e = by_key[k]
        tail = e["tails"][0] if e["tails"] else ""
        text = f"{e['name']} — {tail}" if tail else e["name"]
        if e["srcs"]:
            text += f" [S{e['srcs'][0]}]"
        out.append(text)
    return out


def iter_enumeration(ctx, message: str):
    """Генератор событий полного прохода. Промежуточные — {"type": "tool"},
    последнее — {"type": "answer", "text": str | None} (None → обычный RAG)."""
    from gigapost.llm.factory import get_llm

    words = _keywords(message)
    emails = ctx.repos.emails.search_fts_any(words) if words else []
    notes = ctx.repos.notes.search_fts_any(words) if words else []
    attachments = ctx.repos.attachments.search_fts_any(words) if words else []

    # источник каждой строки — чтобы в ответе у каждого факта была ссылка
    rows: list[dict] = []
    for n in notes:
        body = (n.get("body") or "").replace("[[", "").replace("]]", "")
        rows.append({"text": f"[знание] {n.get('title')}: {body[:400]}",
                     "label": f"заметка «{(n.get('title') or '')[:45]}»",
                     "conv": None})
    # письма одного треда держим рядом: «прошу доступ для Иванова» и ответ
    # «логин 14887711» из соседнего письма попадают в один фрагмент
    emails.sort(key=lambda e: (e.get("conversation_id") or e.get("message_id") or "",
                               e.get("received_at") or ""))
    for e in emails:
        body = clean_body(e.get("body_text") or "", _ENUM_EMAIL_SNIPPET)
        conv = (e.get("conversation_id") or "")[-6:]
        date = (e.get("received_at") or "")[:10]
        sender = e.get("sender_name") or e.get("sender_email") or "—"
        rows.append({"text": f"[письмо тред:{conv} {date} {sender}] "
                             f"«{e.get('subject')}» — {body}",
                     "label": f"письмо {date[5:]} {sender} "
                              f"«{(e.get('subject') or '')[:40]}»",
                     "conv": e.get("conversation_id")})
    for a in attachments:
        rows.append({"text": f"[вложение «{a.get('filename')}» к письму "
                             f"«{a.get('email_subject') or ''}» от "
                             f"{a.get('sender_name') or '—'}] "
                             f"{(a.get('text') or '')[:2800]}",
                     "label": f"вложение «{(a.get('filename') or '')[:40]}» "
                              f"({a.get('sender_name') or '—'})",
                     "conv": None, "att": True})
    if len(rows) < 8:   # мало данных — top-k обычного RAG справится лучше
        yield {"type": "answer", "text": None}
        return

    # ранжирование: строки с редкими словами запроса («gigame») — первыми,
    # чтобы при обрезке по лимиту фрагментов терялся общий шум («доступ»
    # к другим системам), а не целевой материал
    lowered = [r["text"].lower() for r in rows]
    freq = {w: max(1, sum(1 for t in lowered if w in t)) for w in words}
    for r, t in zip(rows, lowered):
        r["score"] = sum(1.0 / freq[w] for w in words if w in t)
    # треды неразрывны: всем письмам треда — максимальный балл треда
    conv_best: dict[str, float] = {}
    for r in rows:
        if r["conv"]:
            conv_best[r["conv"]] = max(conv_best.get(r["conv"], 0), r["score"])
    rows.sort(key=lambda r: (-(conv_best.get(r["conv"]) if r["conv"] else r["score"]),
                             r["conv"] or "", r["text"][:40]))

    # нарезка на чанки под лимит контекста модели; [S№] — метка источника.
    # Вложение (таблица/список) всегда идёт ОТДЕЛЬНЫМ чанком: в смеси
    # с письмами модель увлекается перепиской и пропускает строки таблицы
    chunks: list[list[dict]] = []
    current: list[dict] = []
    size = 0
    for idx, r in enumerate(rows):
        r["sid"] = idx
        if r.get("att"):
            if current:
                chunks.append(current)
                current, size = [], 0
            chunks.append([r])
            continue
        same_thread = (r["conv"] and current
                       and current[-1].get("conv") == r["conv"])
        # тред не разрезаем границей чанка: ФИО и логин из соседних писем
        # должны попасть в один фрагмент
        if (size + len(r["text"]) > _ENUM_CHUNK_CHARS and current
                and not same_thread):
            chunks.append(current)
            current, size = [], 0
        current.append(r)
        size += len(r["text"])
    if current:
        chunks.append(current)
    total_chunks = len(chunks)
    truncated = total_chunks > _ENUM_MAX_CHUNKS
    chunks = chunks[:_ENUM_MAX_CHUNKS]
    labels = {str(r["sid"]): r["label"] for c in chunks for r in c}

    llm = get_llm("extract")
    items: list[str] = []
    seen: set[str] = set()
    for i, chunk_rows in enumerate(chunks, 1):
        yield {"type": "tool",
               "name": f"полный просмотр: фрагмент {i}/{len(chunks)}"}
        chunk = "\n".join(f"[S{r['sid']}] {r['text']}" for r in chunk_rows)
        # экстрактор нарочно щедрый (полноту нельзя терять) — точность
        # обеспечивает критик следующим проходом
        prompt = (
            f"Вопрос пользователя: {message}\n\n"
            f"Ниже пронумерованные фрагменты писем и заметок. Выпиши ВСЕ "
            f"элементы, которые отвечают на вопрос — по одному в строке, "
            f"без нумерации, формат: «значение — краткое уточнение [S№]», где "
            f"[S№] — метка фрагмента-источника. Ничего не пропускай и не "
            f"обобщай. Связывай письма одного треда (метка «тред:»): например, "
            f"имя из запроса и уточнение из ответного письма — одна запись. "
            f"Не включай авторов и отправителей писем, если вопрос не о них. "
            f"Если ответа в фрагментах нет, выведи ровно одно слово: "
            f"НЕТ\n\nФрагменты:\n{chunk}")
        try:
            result = llm.invoke(prompt)
            text = result.content if hasattr(result, "content") else str(result)
        except Exception as e:  # noqa: BLE001
            logger.warning("Перечисление, чанк %d: %s", i, e)
            continue
        for line in text.splitlines():
            line = line.strip().lstrip("•*-–—· ").strip()
            if not line or line.upper().startswith("НЕТ"):
                continue
            key = _dedupe_key(re.sub(r"\s*\[S\d+\]", "", line))
            if key and key not in seen:
                seen.add(key)
                items.append(line)

    if not items:
        yield {"type": "answer", "text": None}
        return
    items = _merge_enum_items(items)

    # роль «критик»: утверждения перепроверяются по фрагменту-источнику —
    # извлекатель склонен включать всех, кто просто упомянут рядом
    # (инициаторы, согласующие, обсуждения). Критик видит ВЕСЬ чанк, а не
    # одну строку: факт треда собирается из соседних писем.
    chunk_of_sid = {str(r["sid"]): ci for ci, c in enumerate(chunks) for r in c}
    groups: dict[int, list[str]] = {}
    for it in items:
        m = re.search(r"\[S(\d+)\]", it)
        if m and m.group(1) in chunk_of_sid:
            groups.setdefault(chunk_of_sid[m.group(1)], []).append(it)
    rejected_keys: set[str] = set()
    rejected_count = 0
    gi = 0
    for ci, claims in groups.items():
        gi += 1
        yield {"type": "tool", "name": f"критик: проверка фактов {gi}/{len(groups)}"}
        numbered = "\n".join(
            "{}. {}".format(j, re.sub(r"\s*\[S\d+\]", "", c))
            for j, c in enumerate(claims, 1))
        evidence = "\n".join(r["text"] for r in chunks[ci])
        vprompt = (
            f"Вопрос пользователя: {message}\n\n"
            f"Фрагменты-источники:\n{evidence}\n\n"
            f"Утверждения, извлечённые из этих фрагментов:\n{numbered}\n\n"
            f"Для каждого утверждения ответь отдельной строкой «№ — ДА» или "
            f"«№ — НЕТ». НЕТ ставь только если утверждение явно не относится "
            f"к вопросу (это автор/отправитель письма, инициатор, человек, "
            f"упомянутый по другому поводу) или фрагменты его не содержат. "
            f"Во всех остальных случаях — ДА. Больше ничего не пиши.")
        try:
            result = llm.invoke(vprompt)
            text = result.content if hasattr(result, "content") else str(result)
        except Exception as e:  # noqa: BLE001 — критик упал, факты не теряем
            logger.warning("Критик, источник S%s: %s", sid, e)
            continue
        verdicts: dict[int, bool] = {}
        for line in text.splitlines():
            m2 = re.match(r"\s*(\d+)\s*[.—–:-]*\s*(да|нет)\b", line.strip(),
                          re.IGNORECASE)
            if m2:
                verdicts[int(m2.group(1))] = m2.group(2).lower() == "да"
        for j, c in enumerate(claims, 1):
            if not verdicts.get(j, True):   # без вердикта — не выбрасываем
                rejected_keys.add(_dedupe_key(re.sub(r"\s*\[S\d+\]", "", c)))
                rejected_count += 1
    if rejected_keys:
        items = [it for it in items
                 if _dedupe_key(re.sub(r"\s*\[S\d+\]", "", it)) not in rejected_keys]

    def _render(line: str) -> str:
        m = re.search(r"\[S(\d+)\]", line)
        clean = re.sub(r"\s*\[S\d+\]", "", line).strip()
        label = labels.get(m.group(1)) if m else None
        return f"• {clean}  〈{label}〉" if label else f"• {clean}"

    head = (f"Полный просмотр по запросу: {len(emails)} "
            f"{_plural(len(emails), 'письмо', 'письма', 'писем')}, {len(notes)} "
            f"{_plural(len(notes), 'заметка', 'заметки', 'заметок')}"
            + (f", {len(attachments)} "
               f"{_plural(len(attachments), 'вложение', 'вложения', 'вложений')}"
               if attachments else "")
            + f". Найдено записей: {len(items)}"
            + (f", отсеяно критиком: {rejected_count}" if rejected_count else "")
            + ". В 〈скобках〉 — источник факта.\n\n")
    body = "\n".join(_render(it) for it in items)
    tail = ""
    if truncated:
        tail = (f"\n\n⚠ Материала больше, чем удалось просмотреть за раз "
                f"(обработано {len(chunks)} из {total_chunks} фрагментов, "
                f"самые релевантные — первыми) — уточните запрос, чтобы "
                f"сузить поиск.")
    yield {"type": "answer", "text": head + body + tail}
