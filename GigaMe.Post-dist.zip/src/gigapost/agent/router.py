"""Роутер намерений чата: вопросы — детерминированным RAG-путём, действия — агенту.

Урок эксплуатации: GigaChat ненадёжен в свободных ReAct-цепочках, но отлично
отвечает по собранному контексту. Поэтому запросы-вопросы («что», «почему»,
«какой статус», «кто», «покажи», «сколько») обрабатываются без агента:
сервер сам собирает контекст (знания + письма + задачи + договорённости)
и просит модель один раз ответить. Действия (создать/удалить/переместить/
ответить/запомнить) остаются агенту с HITL-инструментами.
"""

from __future__ import annotations

import logging
import re

from gigapost.config import load_prompt, settings
from gigapost.pipeline.nodes import clean_body

logger = logging.getLogger(__name__)

# сигналы действия — такие запросы уходят агенту с инструментами
_ACTION_RE = re.compile(
    r"\b(создай|добавь|заведи|удали|перемести|перенеси|раздели|разложи|отправь|"
    r"сохрани|запомни|закрой|выполни|отметь|свяжи|подготовь|предложи ответ|"
    r"ответь|напиши ответ|черновик|сделай|поставь|назначь|переименуй)\w*",
    re.IGNORECASE)


def is_action(message: str) -> bool:
    return bool(_ACTION_RE.search(message))


_TASK_WORDS = re.compile(r"задач|поручен|канбан|доск", re.IGNORECASE)
_AGREEMENT_WORDS = re.compile(r"договорённост|договоренност|контрол|должн|обещал|"
                              r"просроч|follow", re.IGNORECASE)
_EMAIL_WORDS = re.compile(r"письм|почт|переписк|тред", re.IGNORECASE)
_DOC_WORDS = re.compile(r"документ|акт|упд|счет|счёт|спецификац|договор\b|реестр",
                        re.IGNORECASE)


def suggest_links(repos, question: str) -> list[dict]:
    """Ссылки «открыть в разделе» к ответу: раздел уже отфильтрован по смыслу
    вопроса. Детерминированно, без LLM."""
    q = question.lower()
    links: list[dict] = []

    # упомянутый проект → доска задач с фильтром по проекту
    matched_project = None
    try:
        for p in repos.tasks.projects():
            if p and p.lower() in q:
                matched_project = p
                break
    except Exception:  # noqa: BLE001
        pass

    if _TASK_WORDS.search(q) or matched_project:
        from urllib.parse import quote
        if matched_project:
            links.append({"label": f"Доска задач: {matched_project}",
                          "url": f"/tasks?project={quote(matched_project)}"})
        else:
            links.append({"label": "Открыть доску задач", "url": "/tasks"})
    if _AGREEMENT_WORDS.search(q):
        links.append({"label": "Контроль и решения", "url": "/decisions"})
    if _DOC_WORDS.search(q):
        links.append({"label": "Реестр документов", "url": "/registry"})
    if _EMAIL_WORDS.search(q):
        from urllib.parse import quote
        words = [w for w in re.findall(r"[а-яёa-z0-9-]{4,}", q)
                 if not _EMAIL_WORDS.search(w)][:3]
        url = "/emails" + (f"?q={quote(' '.join(words))}" if words else "")
        links.append({"label": "Найти в письмах", "url": url})

    # упомянутая сущность → досье
    try:
        for e in repos.entities.all_entities():
            name = (e.get("name") or "")
            if len(name) >= 4 and name.lower() in q:
                links.append({"label": f"Досье: {name}", "url": f"/entity/{e['id']}"})
                break
    except Exception:  # noqa: BLE001
        pass
    return links[:3]


def _add_source(sources: list[dict] | None, label: str, url: str | None) -> None:
    """Копилка источников ответа (для кнопок-ссылок под ответом в чате)."""
    if sources is None or not url:
        return
    if any(s["url"] == url for s in sources):
        return
    sources.append({"label": label, "url": url})


def _note_source(sources, note, prefix="Знание") -> None:
    title = (note.get("title") or "заметка")[:45]
    if note.get("source_message_id"):
        _add_source(sources, f"{prefix}: {title}",
                    f"/emails/{note['source_message_id']}")
    elif note.get("conversation_id"):
        _add_source(sources, f"{prefix}: {title}",
                    f"/threads/{note['conversation_id']}")


def gather_context(ctx, query: str, k_notes: int = 6, k_emails: int = 5,
                   sources: list[dict] | None = None) -> str:
    """Собрать контекст для ответа на вопрос: знания, письма, задачи, контроль.

    sources — необязательная копилка: сюда складываются ссылки на карточки
    знаний (их письма-источники) и письма, попавшие в контекст."""
    parts: list[str] = []
    seen_notes: set[int] = set()
    # знания: вектор + FTS
    try:
        if ctx.vectors is not None:
            vec = ctx.vectors.embeddings.embed_query(query)
            res = ctx.vectors.notes_collection.query(query_embeddings=[vec],
                                                     n_results=k_notes)
            for note_id in res["ids"][0]:
                note = ctx.repos.notes.get(int(note_id))
                if note and note["id"] not in seen_notes:
                    seen_notes.add(note["id"])
                    body = note["body"].replace("[[", "").replace("]]", "")
                    parts.append(f"[знание/{note['kind']}] {note['title']}: {body}")
                    _note_source(sources, note)
    except Exception as e:  # noqa: BLE001
        logger.warning("Контекст (вектор): %s", e)
    for note in ctx.repos.notes.search_fts(query, limit=3):
        if note["id"] not in seen_notes:
            seen_notes.add(note["id"])
            body = note["body"].replace("[[", "").replace("]]", "")
            parts.append(f"[знание/{note['kind']}] {note['title']}: {body}")
            _note_source(sources, note)
    # backlinks сущностей, упомянутых в вопросе
    try:
        q_lower = query.lower()
        for e in ctx.repos.entities.all_entities():
            if len(e["name"]) >= 4 and e["name"].lower() in q_lower:
                for note in ctx.repos.notes.for_entity(e["id"], limit=3):
                    if note["id"] not in seen_notes:
                        seen_notes.add(note["id"])
                        body = note["body"].replace("[[", "").replace("]]", "")
                        parts.append(f"[знание о {e['name']}] {note['title']}: {body}")
                        _note_source(sources, note)
    except Exception:  # noqa: BLE001
        pass
    # письма
    for email in ctx.repos.emails.search_fts(query, limit=k_emails):
        parts.append(f"[письмо] {email.get('received_at', '')[:10]} "
                     f"{email.get('sender_name')}: «{email.get('subject')}» — "
                     f"{(email.get('summary') or clean_body(email.get('body_text') or '', 150))}")
        _add_source(sources, f"Письмо: {(email.get('subject') or 'без темы')[:45]}",
                    f"/emails/{email.get('message_id')}")
    # задачи и контроль — только если вопрос похож на них
    if re.search(r"задач|дел[ае]|срок|просроч|должн|обещал|контрол|договор[её]нн",
                 query, re.IGNORECASE):
        for t in ctx.repos.tasks.list(limit=25):
            if t["status"] in ("open", "draft"):
                parts.append(f"[задача/{t['status']}] {t['title']} "
                             f"(срок {t.get('due_date') or 'нет'}, "
                             f"исполнитель {t.get('assignee') or 'я'})")
        for a in ctx.repos.agreements.list(limit=15):
            parts.append(f"[контроль/{a['status']}] {a['description']} "
                         f"({a.get('counterparty')}, срок {a.get('due_date') or 'нет'})")
    return "\n".join(parts[:30])


def answer_question(ctx, message: str, extra_context: str = "",
                    sources: list[dict] | None = None) -> str:
    """Детерминированный RAG-ответ: один вызов модели по собранному контексту.

    extra_context — например, документ, приложенный пользователем в чат;
    sources — копилка ссылок на источники (см. gather_context)."""
    from gigapost.llm.factory import get_llm

    context = gather_context(ctx, message, sources=sources)
    if extra_context.strip():
        context = extra_context.strip() + "\n\n" + context
    if not context.strip():
        return ("В базе пока нет данных по этому вопросу — ни в знаниях, ни в письмах, "
                "ни в задачах.")
    prompt = (
        f"Ты — ассистент владельца почты ({settings.owner.full}). Ответь на вопрос, "
        f"опираясь ТОЛЬКО на контекст ниже. Не выдумывай фактов. Если данных не "
        f"хватает — скажи, чего именно. Отвечай по-русски, кратко и структурно.\n\n"
        f"Вопрос: {message}\n\nКонтекст:\n{context}")
    result = get_llm("chat").invoke(prompt)
    return result.content if hasattr(result, "content") else str(result)


# ---------------------------------------------------------------------------
# Вопросы-перечисления: «приведи ФИО и логины всех, кому запрошен доступ…»
# Обычный RAG берёт top-k фрагментов и теряет хвост (из 100 находит 5).
# Здесь — полный проход: широкий FTS-свип → извлечение элементов чанками
# (лимит GigaChat ~4096 токенов) → детерминированное слияние без потерь.
# ---------------------------------------------------------------------------

_ENUM_RE = re.compile(
    r"перечисл|привед|полный список|весь список|поимённ|поименн|"
    r"\bвсех\b|\bкажд(?:ый|ого|ому)\b|кто (?:получил|запрашивал|просил|подавал)|"
    r"кому (?:был|выда|запр|согласов)|\bфио\b|\bлогин", re.IGNORECASE)

_STOP_WORDS = {
    "приведи", "приведите", "перечисли", "перечислите", "список", "списки",
    "полный", "весь", "всех", "все", "всем", "кому", "кто", "был", "была",
    "были", "было", "для", "это", "этих", "или", "что", "как", "какие",
    "какой", "чей", "мне", "меня", "нужно", "покажи", "дай", "назови",
    "также", "еще", "ещё", "только", "есть", "каждый", "фио", "именно"}

_ENUM_MAX_CHUNKS = 30
_ENUM_CHUNK_CHARS = 3000
_ENUM_EMAIL_SNIPPET = 700


def is_enumeration(message: str) -> bool:
    return bool(_ENUM_RE.search(message))


def _keywords(message: str) -> list[str]:
    words = re.findall(r"[а-яёa-z0-9_.@-]{3,}", message.lower())
    out: list[str] = []
    for w in words:
        if w in _STOP_WORDS or w in out:
            continue
        # срезаем окончание — FTS-префикс «доступ*» найдёт «доступа/доступов»
        out.append(w[:-1] if len(w) >= 6 and re.search(r"[а-яё]$", w) else w)
    return out[:6]


def _dedupe_key(line: str) -> str:
    return re.sub(r"[\s.,;:—–-]+", " ", line.lower()).strip()


def _plural(n: int, one: str, few: str, many: str) -> str:
    if n % 10 == 1 and n % 100 != 11:
        return one
    if n % 10 in (2, 3, 4) and n % 100 not in (12, 13, 14):
        return few
    return many


def _merge_enum_items(items: list[str]) -> list[str]:
    """Слить дубли перечисления: строки «значение — уточнение» группируются
    по значению; «Максим» поглощается «Максим Железнов» (если полный вариант
    один); из уточнений берётся первое (из самого релевантного фрагмента)."""
    order: list[str] = []
    by_key: dict[str, dict] = {}
    for line in items:
        parts = re.split(r"\s+[—–:]\s+|\s+-\s+", line, maxsplit=1)
        name = parts[0].strip()
        tail = parts[1].strip() if len(parts) > 1 else ""
        # «ФИО — НЕТ»: заглушка модели вместо отсутствующего уточнения
        if re.fullmatch(r"(нет|не указан[оа]?|отсутствует|неизвестн\w*|-|—)",
                        tail, re.IGNORECASE):
            tail = ""
        key = re.sub(r"[\s.,]+", " ", name.lower()).strip()
        if not key:
            continue
        if key not in by_key:
            by_key[key] = {"name": name, "tails": []}
            order.append(key)
        if tail and tail not in by_key[key]["tails"]:
            by_key[key]["tails"].append(tail)
    # короткое имя поглощается полным, если полный вариант ровно один
    for short in list(order):
        if short not in by_key:
            continue
        short_words = set(short.split())
        supersets = [k for k in by_key
                     if k != short and short_words <= set(k.split())]
        if len(supersets) == 1:
            target = by_key[supersets[0]]
            for t in by_key[short]["tails"]:
                if t not in target["tails"]:
                    target["tails"].append(t)
            del by_key[short]
            order.remove(short)
    out = []
    for k in order:
        e = by_key[k]
        tail = e["tails"][0] if e["tails"] else ""
        out.append(f"{e['name']} — {tail}" if tail else e["name"])
    return out


def iter_enumeration(ctx, message: str):
    """Генератор событий полного прохода. Промежуточные — {"type": "tool"},
    последнее — {"type": "answer", "text": str | None} (None → обычный RAG)."""
    from gigapost.llm.factory import get_llm

    words = _keywords(message)
    emails = ctx.repos.emails.search_fts_any(words) if words else []
    notes = ctx.repos.notes.search_fts_any(words) if words else []
    attachments = ctx.repos.attachments.search_fts_any(words) if words else []
    rows: list[str] = []
    for n in notes:
        body = (n.get("body") or "").replace("[[", "").replace("]]", "")
        rows.append(f"[знание] {n.get('title')}: {body[:400]}")
    # письма одного треда держим рядом: «прошу доступ для Иванова» и ответ
    # «логин 14887711» из соседнего письма попадают в один фрагмент
    emails.sort(key=lambda e: (e.get("conversation_id") or e.get("message_id") or "",
                               e.get("received_at") or ""))
    for e in emails:
        body = clean_body(e.get("body_text") or "", _ENUM_EMAIL_SNIPPET)
        conv = (e.get("conversation_id") or "")[-6:]
        rows.append(f"[письмо тред:{conv} {(e.get('received_at') or '')[:10]} "
                    f"{e.get('sender_name') or e.get('sender_email')}] "
                    f"«{e.get('subject')}» — {body}")
    for a in attachments:
        rows.append(f"[вложение «{a.get('filename')}» к письму "
                    f"«{a.get('email_subject') or ''}» от "
                    f"{a.get('sender_name') or '—'}] {(a.get('text') or '')[:1600]}")
    if len(rows) < 8:   # мало данных — top-k обычного RAG справится лучше
        yield {"type": "answer", "text": None}
        return

    # нарезка на чанки под лимит контекста модели
    chunks: list[str] = []
    current: list[str] = []
    size = 0
    for r in rows:
        if size + len(r) > _ENUM_CHUNK_CHARS and current:
            chunks.append("\n".join(current))
            current, size = [], 0
        current.append(r)
        size += len(r)
    if current:
        chunks.append("\n".join(current))
    total_chunks = len(chunks)
    truncated = total_chunks > _ENUM_MAX_CHUNKS
    chunks = chunks[:_ENUM_MAX_CHUNKS]

    llm = get_llm("extract")
    items: list[str] = []
    seen: set[str] = set()
    for i, chunk in enumerate(chunks, 1):
        yield {"type": "tool",
               "name": f"полный просмотр: фрагмент {i}/{len(chunks)}"}
        prompt = (
            f"Вопрос пользователя: {message}\n\n"
            f"Ниже фрагменты писем и заметок. Выпиши ВСЕ элементы, которые "
            f"отвечают на вопрос — по одному в строке, без нумерации "
            f"(формат: «значение — краткое уточнение, если есть»). Ничего не "
            f"пропускай и не обобщай. Не включай авторов и отправителей писем, "
            f"если вопрос не о них. Если ответа в фрагментах нет, выведи "
            f"ровно одно слово: НЕТ\n\nФрагменты:\n{chunk}")
        try:
            result = llm.invoke(prompt)
            text = result.content if hasattr(result, "content") else str(result)
        except Exception as e:  # noqa: BLE001
            logger.warning("Перечисление, чанк %d: %s", i, e)
            continue
        for line in text.splitlines():
            line = line.strip().lstrip("•*-–—· ").strip()
            if not line or line.upper().startswith("НЕТ"):
                continue
            key = _dedupe_key(line)
            if key and key not in seen:
                seen.add(key)
                items.append(line)

    if not items:
        yield {"type": "answer", "text": None}
        return
    items = _merge_enum_items(items)
    head = (f"Полный просмотр по запросу: {len(emails)} "
            f"{_plural(len(emails), 'письмо', 'письма', 'писем')}, {len(notes)} "
            f"{_plural(len(notes), 'заметка', 'заметки', 'заметок')}"
            + (f", {len(attachments)} "
               f"{_plural(len(attachments), 'вложение', 'вложения', 'вложений')}"
               if attachments else "")
            + f". Найдено записей: {len(items)}.\n\n")
    body = "\n".join(f"• {it}" for it in items)
    tail = ""
    if truncated:
        tail = (f"\n\n⚠ Материала больше, чем удалось просмотреть за раз "
                f"(обработано {len(chunks)} из {total_chunks} фрагментов) — "
                f"уточните запрос, чтобы сузить поиск.")
    yield {"type": "answer", "text": head + body + tail}
