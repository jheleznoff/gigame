"""Диалоговый агент: deepagents (create_deep_agent) поверх GigaChat.

План Б (если GigaChat нестабилен в многошаговом tool-calling у deepagents):
fallback на langgraph.prebuilt.create_react_agent — те же инструменты, тот же
интерфейс invoke/stream, UI не меняется.
"""

from __future__ import annotations

import logging
import sqlite3
from datetime import date

from gigapost.agent.tools import ALL_TOOLS
from gigapost.config import load_prompt, settings

logger = logging.getLogger(__name__)

_agent = None
_checkpointer = None

# GigaChat режет контекст запроса (~4096 токенов) — перед каждым вызовом модели
# обрезаем историю треда до последних сообщений, если она разрослась.
TRIM_TOKEN_THRESHOLD = 1800
TRIM_KEEP_MESSAGES = 6


def _make_history_trim_middleware_class():
    from langchain.agents.middleware.types import AgentMiddleware
    from langchain_core.messages import ToolMessage
    from langchain_core.messages.utils import count_tokens_approximately

    class HistoryTrimMiddleware(AgentMiddleware):
        name = "gigapost-history-trim"

        def before_model(self, state, runtime):
            msgs = list(state.get("messages") or [])
            if len(msgs) <= TRIM_KEEP_MESSAGES:
                return None
            if count_tokens_approximately(msgs) <= TRIM_TOKEN_THRESHOLD:
                return None
            keep = msgs[-TRIM_KEEP_MESSAGES:]
            # не начинаем окно с осиротевшего ответа инструмента
            while keep and isinstance(keep[0], ToolMessage):
                keep = keep[1:]
            if len(keep) == len(msgs) or not keep:
                return None
            from langchain_core.messages import RemoveMessage
            from langgraph.graph.message import REMOVE_ALL_MESSAGES

            logger.info("Обрезка истории чата: %d → %d сообщений", len(msgs), len(keep))
            return {"messages": [RemoveMessage(id=REMOVE_ALL_MESSAGES), *keep]}

    return HistoryTrimMiddleware


def _HistoryTrimMiddleware():
    return _make_history_trim_middleware_class()()


def _make_repeat_guard_middleware_class():
    """GigaChat склонен зацикливаться на одном вызове — обрываем повторы."""
    import json as _json
    from collections import deque

    from langchain.agents.middleware.types import AgentMiddleware
    from langchain_core.messages import ToolMessage

    class RepeatGuardMiddleware(AgentMiddleware):
        name = "gigapost-repeat-guard"

        def __init__(self):
            super().__init__()
            self._recent: deque = deque(maxlen=12)

        def wrap_tool_call(self, request, handler):
            tc = getattr(request, "tool_call", None) or {}
            key = (tc.get("name"),
                   _json.dumps(tc.get("args", {}), sort_keys=True, ensure_ascii=False))
            repeats = sum(1 for k in self._recent if k == key)
            self._recent.append(key)
            if repeats >= 2:
                logger.warning("Повторный вызов инструмента оборван: %s", key[0])
                return ToolMessage(
                    content="СТОП: этот инструмент уже дважды вызывался с теми же "
                            "аргументами — результат не изменится. Не вызывай его "
                            "снова. Ответь пользователю на основе уже полученных "
                            "данных или скажи честно, что информации нет.",
                    tool_call_id=tc.get("id", ""), name=tc.get("name", ""),
                    status="error")
            return handler(request)

    return RepeatGuardMiddleware


def _RepeatGuardMiddleware():
    return _make_repeat_guard_middleware_class()()


def _make_checkpointer():
    from langgraph.checkpoint.sqlite import SqliteSaver

    conn = sqlite3.connect(str(settings.checkpoints_db_path), check_same_thread=False)
    return SqliteSaver(conn)


def build_chat_agent():
    """Собрать агента один раз на процесс; system prompt получает текущую дату при сборке."""
    global _agent, _checkpointer
    if _agent is not None:
        return _agent

    from gigapost.llm.factory import get_llm

    _checkpointer = _make_checkpointer()
    model = get_llm("chat")
    system_prompt = load_prompt("chat_agent").format(today=date.today().isoformat())
    # мутирующие инструменты требуют подтверждения человека (HITL)
    interrupt_on = {
        "create_task": {"allowed_decisions": ["approve", "reject"]},
        "complete_task": {"allowed_decisions": ["approve", "reject"]},
        "create_mail_folder": {"allowed_decisions": ["approve", "reject"]},
        "move_emails_to_folder": {"allowed_decisions": ["approve", "reject"]},
        "delete_emails": {"allowed_decisions": ["approve", "reject"]},
        "add_knowledge": {"allowed_decisions": ["approve", "reject"]},
        "save_reply_draft": {"allowed_decisions": ["approve", "reject"]},
    }
    # Лёггкий стек вместо deepagents: у GigaChat потолок ~4096 токенов на запрос,
    # а системный промпт deepagents (todo/файлы/сабагенты) съедает больше половины.
    # HITL — та же штатная HumanInTheLoopMiddleware, что использует deepagents.
    try:
        from langchain.agents import create_agent
        from langchain.agents.middleware import HumanInTheLoopMiddleware

        _agent = create_agent(
            model, tools=ALL_TOOLS, system_prompt=system_prompt,
            middleware=[_HistoryTrimMiddleware(), _RepeatGuardMiddleware(),
                        HumanInTheLoopMiddleware(interrupt_on=interrupt_on)],
            checkpointer=_checkpointer)
        logger.info("Диалоговый агент: create_agent (HITL + обрезка истории)")
    except Exception as e:  # noqa: BLE001 — план Б: ReAct-агент LangGraph
        # ВАЖНО: у fallback нет HITL-перехвата, поэтому мутирующие инструменты
        # ему не выдаём — только чтение. Иначе одобрения молча исчезают
        # (проверено на практике: цикл create_task без подтверждений).
        logger.error("create_agent не собрался (%s) — fallback create_react_agent "
                     "БЕЗ мутирующих инструментов", e)
        from langgraph.prebuilt import create_react_agent

        from gigapost.agent.tools import READONLY_TOOLS

        _agent = create_react_agent(
            model, READONLY_TOOLS, prompt=system_prompt, checkpointer=_checkpointer)
        logger.info("Диалоговый агент: create_react_agent (fallback, только чтение)")
    return _agent


def _pending_action_requests(agent, config) -> list[dict]:
    """Запросы на подтверждение из прерванного состояния (HITL interrupt)."""
    try:
        state = agent.get_state(config)
    except Exception:  # noqa: BLE001
        return []
    interrupts = list(getattr(state, "interrupts", ()) or ())
    if not interrupts:
        for task in getattr(state, "tasks", ()) or ():
            interrupts.extend(getattr(task, "interrupts", ()) or ())
    requests: list[dict] = []
    seen: set[str] = set()
    for intr in interrupts:
        key = str(getattr(intr, "id", None) or id(intr))
        if key in seen:
            continue
        seen.add(key)
        value = getattr(intr, "value", None)
        if isinstance(value, dict):
            for req in value.get("action_requests", []):
                requests.append({"name": req.get("name", ""),
                                 "args": req.get("args", {}),
                                 "description": req.get("description", "")})
    return requests


def _stream_events(agent, inputs, config):
    """Общий цикл стриминга: токены, вызовы инструментов, HITL-подтверждения.

    429 от GigaChat ретраим (до 4 попыток), но только пока пользователю
    ещё не ушёл ни один токен ответа.
    """
    import time

    from gigachat.exceptions import RateLimitError

    for attempt in range(4):
        tokens_sent = False
        try:
            for chunk, metadata in agent.stream(inputs, config=config, stream_mode="messages"):
                node = (metadata or {}).get("langgraph_node", "")
                if getattr(chunk, "type", "") == "tool" or node == "tools":
                    name = getattr(chunk, "name", "") or "инструмент"
                    yield {"type": "tool", "name": name}
                    continue
                content = getattr(chunk, "content", "")
                if isinstance(content, str) and content:
                    tokens_sent = True
                    yield {"type": "token", "text": content}
            # агент мог остановиться на HITL-подтверждении мутации
            pending = _pending_action_requests(agent, config)
            if pending:
                yield {"type": "confirm", "actions": pending}
            else:
                yield {"type": "done"}
            return
        except RateLimitError:
            if tokens_sent or attempt == 3:
                logger.warning("429 от GigaChat, ретраи исчерпаны")
                yield {"type": "error",
                       "text": "GigaChat перегружен (лимиты API). Попробуйте ещё раз через минуту."}
                return
            wait = 8 * (attempt + 1)
            yield {"type": "tool", "name": f"жду лимиты API ({wait} с)"}
            time.sleep(wait)
        except Exception as e:  # noqa: BLE001
            logger.exception("Ошибка агента")
            yield {"type": "error", "text": f"Ошибка агента: {e}"}
            return


def _uploaded_docs(ctx, thread_id: str, cap: int = 3500) -> str:
    """Документы, приложенные пользователем в этот тред чата, — блоком контекста."""
    try:
        rows = ctx.repos.db.query(
            "SELECT filename, text FROM chat_uploads WHERE thread_id=? "
            "AND status='parsed' ORDER BY id DESC LIMIT 2", (thread_id,))
    except Exception:  # noqa: BLE001
        return ""
    parts = []
    for r in rows:
        text = (r["text"] or "").strip()
        if not text:
            continue
        note = (f" (показаны первые {cap} из {len(text)} символов)"
                if len(text) > cap else "")
        parts.append(f"[приложенный документ «{r['filename']}»{note}]\n{text[:cap]}")
    return "\n\n".join(parts)


def _save_rag_exchange(thread_id: str, message: str, answer: str) -> None:
    """Сохранить RAG-обмен в историю треда, чтобы агент видел контекст диалога."""
    try:
        agent = build_chat_agent()
        agent.update_state(
            {"configurable": {"thread_id": thread_id}},
            {"messages": [{"role": "user", "content": message},
                          {"role": "assistant", "content": answer}]})
    except Exception as e:  # noqa: BLE001
        logger.debug("Не сохранил RAG-обмен в тред: %s", e)


def stream_chat(message: str, thread_id: str):
    """Генератор событий для SSE: {type: token|tool|confirm|links|done, ...}.

    Роутер намерений: вопросы идут детерминированным RAG-путём (надёжнее
    для GigaChat), вопросы-перечисления — полным проходом map-reduce,
    действия — агенту с HITL-инструментами.
    """
    from gigapost.agent.router import (answer_question, is_action,
                                       is_enumeration, iter_enumeration,
                                       suggest_links)

    docs_block = ""
    try:
        from gigapost.context import get_context
        docs_block = _uploaded_docs(get_context(), thread_id)
    except Exception as e:  # noqa: BLE001
        logger.debug("Приложенные документы: %s", e)

    if not is_action(message):
        from gigachat.exceptions import RateLimitError

        from gigapost.context import get_context

        try:
            ctx = get_context()
            # перечисление («все», «полный список», «ФИО и логины…») —
            # полный проход по письмам и знаниям, без потери хвоста.
            # Если приложен документ, вопрос скорее о нём — обычный путь.
            if is_enumeration(message) and not docs_block:
                answer = None
                for ev in iter_enumeration(ctx, message):
                    if ev["type"] == "answer":
                        answer = ev["text"]
                    else:
                        yield ev
                if answer:
                    yield {"type": "token", "text": answer}
                    try:
                        links = suggest_links(ctx.repos, message)
                        if links:
                            yield {"type": "links", "links": links}
                    except Exception:  # noqa: BLE001
                        pass
                    yield {"type": "done"}
                    _save_rag_exchange(thread_id, message, answer)
                    return
            yield {"type": "tool", "name": "собираю контекст"}
            sources: list[dict] = []
            answer = answer_question(ctx, message, extra_context=docs_block,
                                     sources=sources)
            yield {"type": "token", "text": answer}
            try:
                links = sources[:4] + [l for l in suggest_links(ctx.repos, message)
                                       if all(l["url"] != s["url"] for s in sources)]
                if links:
                    yield {"type": "links", "links": links[:6]}
            except Exception as e:  # noqa: BLE001
                logger.debug("Ссылки к ответу: %s", e)
            yield {"type": "done"}
            _save_rag_exchange(thread_id, message, answer)
            return
        except RateLimitError:
            yield {"type": "error",
                   "text": "GigaChat перегружен (лимиты API). Попробуйте через минуту."}
            return
        except Exception as e:  # noqa: BLE001
            logger.warning("RAG-путь не сработал (%s) — передаю агенту", e)

    agent = build_chat_agent()
    config = {"configurable": {"thread_id": thread_id}}
    content = message
    if docs_block:
        content = f"{message}\n\n{docs_block[:2000]}"
    inputs = {"messages": [{"role": "user", "content": content}]}
    yield from _stream_events(agent, inputs, config)


def resume_chat(decision: str, thread_id: str, message: str = ""):
    """Продолжить после HITL-подтверждения: decision = approve | reject."""
    from langgraph.types import Command

    agent = build_chat_agent()
    config = {"configurable": {"thread_id": thread_id}}
    pending = _pending_action_requests(agent, config)
    if not pending:
        yield {"type": "error", "text": "Нет действий, ожидающих подтверждения."}
        return
    if decision == "reject":
        decisions = [{"type": "reject", **({"message": message} if message else {})}
                     for _ in pending]
    else:
        decisions = [{"type": "approve"} for _ in pending]
    yield from _stream_events(agent, Command(resume={"decisions": decisions}), config)


def get_history(thread_id: str) -> list[dict]:
    """История сообщений треда из чекпойнтера для отрисовки страницы чата."""
    agent = build_chat_agent()
    try:
        state = agent.get_state({"configurable": {"thread_id": thread_id}})
        messages = (state.values or {}).get("messages", [])
    except Exception:  # noqa: BLE001
        return []
    result = []
    for m in messages:
        mtype = getattr(m, "type", "")
        content = getattr(m, "content", "")
        if not isinstance(content, str) or not content.strip():
            continue
        if mtype == "human":
            result.append({"role": "user", "text": content})
        elif mtype == "ai":
            result.append({"role": "assistant", "text": content})
    return result
