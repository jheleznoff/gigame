"""Инструменты диалогового агента. Docstrings — на русском: GigaChat
лучше выбирает функции с русскими описаниями."""

from __future__ import annotations

import json
import logging
from datetime import datetime, timedelta

from langchain_core.tools import tool

from gigapost.context import get_context

logger = logging.getLogger(__name__)


def _plain(text: str) -> str:
    """Текст заметки без [[wiki-скобок]] — для ответов в чате."""
    return (text or "").replace("[[", "").replace("]]", "")


def _fmt_email_row(e: dict) -> dict:
    return {
        "id": e["message_id"],
        "тема": (e.get("subject") or "")[:60],
        "от": e.get("sender_name") or e.get("sender_email") or "",
        "дата": (e.get("received_at") or "")[:10],
        "кратко": (e.get("summary") or "")[:80],
    }


@tool
def search_emails(query: str, sender: str = "", k: int = 8) -> str:
    """Поиск по письмам: семантический (по смыслу) плюс полнотекстовый.
    query — что искать (тема, суть вопроса); sender — необязательный фильтр
    по email отправителя; k — сколько результатов вернуть."""
    ctx = get_context()
    results: dict[str, dict] = {}
    if ctx.vectors is not None:
        try:
            for r in ctx.vectors.search(query, k=k, sender_email=sender or None):
                email = ctx.repos.emails.get(r["message_id"])
                if email:
                    results[r["message_id"]] = _fmt_email_row(email)
        except Exception as e:  # noqa: BLE001
            logger.warning("Векторный поиск не сработал: %s", e)
    for email in ctx.repos.emails.search_fts(query, limit=k):
        if email["message_id"] not in results:
            results[email["message_id"]] = _fmt_email_row(email)
    # подмешиваем релевантные знания: модель не всегда зовёт search_knowledge сама
    knowledge = []
    try:
        if ctx.vectors is not None:
            vec = ctx.vectors.embeddings.embed_query(query)
            res = ctx.vectors.notes_collection.query(query_embeddings=[vec], n_results=3)
            for note_id in res["ids"][0]:
                note = ctx.repos.notes.get(int(note_id))
                if note:
                    knowledge.append({"заметка": note["title"],
                                      "текст": _plain(note["body"])})
    except Exception:  # noqa: BLE001
        pass
    for note in ctx.repos.notes.search_fts(query, limit=3):
        if not any(n["заметка"] == note["title"] for n in knowledge):
            knowledge.append({"заметка": note["title"], "текст": _plain(note["body"])})
    if not results and not knowledge:
        return "Ничего не найдено."
    payload: dict = {}
    if knowledge:
        payload["из_базы_знаний"] = knowledge[:3]
    if results:
        payload["письма"] = list(results.values())[:k]
    return json.dumps(payload, ensure_ascii=False)


@tool
def get_email_details(message_id: str) -> str:
    """Полный текст и метаданные письма по его message_id (из результатов поиска).
    Показывает и список вложений — их текст можно получить через get_attachment_text."""
    ctx = get_context()
    email = ctx.repos.emails.get(message_id)
    if not email:
        return "Письмо не найдено."
    attachments = [
        {"файл": a["filename"], "статус": a["status"],
         "символов_текста": len(a["text"] or "") if a.get("text") else 0}
        for a in ctx.repos.attachments.for_email(message_id)
    ]
    return json.dumps({
        "тема": email.get("subject"),
        "от": f"{email.get('sender_name')} <{email.get('sender_email')}>",
        "дата": email.get("received_at"),
        "папка": email.get("folder"),
        "категория": email.get("category"),
        "вложения": attachments,
        "текст": (email.get("body_text") or "")[:1500],
    }, ensure_ascii=False)


@tool
def find_attachments(query: str = "", ext: str = "") -> str:
    """Поиск файлов в библиотеке вложений: по имени файла, содержимому,
    отправителю или теме письма. ext — фильтр по расширению («xlsx», «pdf»…)."""
    ctx = get_context()
    files = ctx.repos.attachments.library(query=query, ext=ext, limit=15)
    if not files:
        return "Файлы не найдены."
    return json.dumps([{
        "файл": f["filename"],
        "от": f.get("sender_name") or "",
        "письмо": (f.get("subject") or "")[:50],
        "дата": (f.get("received_at") or "")[:10],
        "message_id": f["message_id"],
        "текст_извлечён": f["status"] == "parsed",
    } for f in files], ensure_ascii=False)


@tool
def get_attachment_text(message_id: str, filename: str) -> str:
    """Извлечённый текст вложения письма (docx, xlsx, pptx, pdf, txt, csv).
    message_id — из результатов поиска, filename — имя файла из get_email_details."""
    ctx = get_context()
    a = ctx.repos.attachments.get_text(message_id, filename)
    if not a:
        return f"Вложение «{filename}» не найдено у этого письма."
    if a["status"] == "unsupported":
        return f"Формат «{filename}» не поддерживается (разбираются docx/xlsx/pptx/pdf/txt/csv)."
    if not a.get("text"):
        return f"Из «{filename}» не удалось извлечь текст (возможно, скан или битый файл)."
    return (f"=== {filename} ===\n{a['text'][:6000]}"
            + ("\n… (текст обрезан)" if len(a["text"]) > 6000 else ""))


@tool
def search_knowledge(query: str, k: int = 6) -> str:
    """Поиск по базе знаний — атомарным заметкам, извлечённым из переписки
    (факты, договорённости, решения, статусы проектов). Используй ПЕРВЫМ для
    вопросов «почему», «что решили», «какой статус», «кто за что отвечает»."""
    ctx = get_context()
    results: dict[int, dict] = {}
    # семантический поиск по заметкам
    if ctx.vectors is not None:
        try:
            vec = ctx.vectors.embeddings.embed_query(query)
            res = ctx.vectors.notes_collection.query(query_embeddings=[vec],
                                                     n_results=min(k, 10))
            for note_id in res["ids"][0]:
                note = ctx.repos.notes.get(int(note_id))
                if note:
                    results[note["id"]] = note
        except Exception as e:  # noqa: BLE001
            logger.warning("Векторный поиск заметок: %s", e)
    # полнотекстовый
    for note in ctx.repos.notes.search_fts(query, limit=k):
        results.setdefault(note["id"], note)
    if not results:
        return "В базе знаний ничего не найдено по этому запросу."
    kind_ru = {"fact": "факт", "agreement": "договорённость", "decision": "решение",
               "event": "событие", "status": "статус"}
    return json.dumps([{
        "заметка": n["title"],
        "тип": kind_ru.get(n["kind"], n["kind"]),
        "текст": _plain(n["body"]),
    } for n in list(results.values())[:k]], ensure_ascii=False)


@tool
def add_knowledge(title: str, body: str, kind: str = "fact",
                  people: list[str] = [], organizations: list[str] = [],
                  projects: list[str] = []) -> str:
    """Добавить знание в базу: атомарную заметку в граф знаний.
    title — краткий заголовок; body — сама мысль, где КАЖДОЕ упоминание человека,
    организации или проекта обёрнуто в [[двойные скобки]], например:
    «[[Михаил Бунзя]] — руководитель [[Центр снабжения]]».
    kind: fact | agreement | decision | event | status.
    people/organizations/projects — списки имён из body для правильной типизации."""
    ctx = get_context()
    if kind not in ("fact", "agreement", "decision", "event", "status"):
        kind = "fact"
    known = {}
    for name in people:
        known[ctx.repos.entities.normalize(name)] = "person"
    for name in organizations:
        known[ctx.repos.entities.normalize(name)] = "org"
    for name in projects:
        known[ctx.repos.entities.normalize(name)] = "project"
    note_id = ctx.kg.add_note(title=title, body=body, kind=kind,
                              source_message_id=None, conversation_id="MANUAL",
                              known_types=known)
    if note_id is None:
        return "Такая заметка уже есть в базе знаний."
    # индексация и смысловые связи — сразу, чтобы знание находилось поиском
    if ctx.vectors is not None:
        try:
            ctx.vectors.index_note(note_id, title, body)
            for other_id, score in ctx.vectors.similar_notes(note_id):
                ctx.repos.notes.add_relation(note_id, other_id, score)
                ctx.kg.link_notes(note_id, other_id, score)
        except Exception as e:  # noqa: BLE001
            logger.warning("Индексация заметки №%s: %s", note_id, e)
    linked = ", ".join(e["name"] for e in ctx.repos.notes.entities_of(note_id))
    return (f"Заметка №{note_id} «{title}» добавлена в базу знаний"
            + (f", связана с: {linked}" if linked else "") + ".")


@tool
def query_knowledge_graph(entity_name: str) -> str:
    """Связи сущности (человека, организации, проекта, темы) в графе знаний:
    с кем работает, в чём участвует, о чём договаривался."""
    ctx = get_context()
    result = ctx.kg.neighbors(entity_name)
    if result is None:
        return f"Сущность «{entity_name}» не найдена в графе знаний."
    return json.dumps({
        "сущность": {"имя": result["entity"]["name"], "тип": result["entity"]["type"],
                     "email": result["entity"].get("email")},
        "связи": result["related"],
    }, ensure_ascii=False, indent=1)


@tool
def get_entity_profile(entity_name: str) -> str:
    """Профиль сущности: данные, последние упоминания в письмах и связанные связи."""
    ctx = get_context()
    matches = ctx.repos.entities.find_by_name(entity_name)
    if not matches:
        return f"Сущность «{entity_name}» не найдена."
    entity = matches[0]
    mentions = ctx.repos.entities.mentions_for(entity["id"], limit=8)
    graph = ctx.kg.neighbors(entity["name"]) or {"related": []}
    return json.dumps({
        "имя": entity["name"], "тип": entity["type"], "email": entity.get("email"),
        "последние_упоминания": [
            {"тема": m["subject"], "дата": (m["received_at"] or "")[:16],
             "от": m["sender_name"], "роль": m["role"]} for m in mentions],
        "связи": graph["related"],
    }, ensure_ascii=False, indent=1)


@tool
def list_tasks(status: str = "open") -> str:
    """Список задач пользователя. status: open (открытые), done (выполненные),
    all (все)."""
    ctx = get_context()
    tasks = ctx.repos.tasks.list(None if status == "all" else status)
    if not tasks:
        return "Задач нет."
    return json.dumps([
        {"id": t["id"], "задача": t["title"], "срок": t.get("due_date"),
         "статус": t["status"], "описание": (t.get("description") or "")[:200]}
        for t in tasks[:30]], ensure_ascii=False, indent=1)


@tool
def get_agreements_on_control(overdue_only: bool = False) -> str:
    """Договорённости на контроле: кто что обещал и к какому сроку.
    overdue_only=true — только просроченные."""
    ctx = get_context()
    agreements = ctx.repos.agreements.list("overdue" if overdue_only else None)
    if not agreements:
        return "Договорённостей на контроле нет."
    dir_ru = {"we_owe": "должны мы", "they_owe": "должны нам", "mutual": "взаимно"}
    return json.dumps([
        {"id": a["id"], "суть": a["description"], "контрагент": a.get("counterparty"),
         "кто_должен": dir_ru.get(a.get("direction"), a.get("direction")),
         "срок": a.get("due_date"), "статус": a["status"]}
        for a in agreements[:30]], ensure_ascii=False, indent=1)


@tool
def create_task(title: str, description: str = "", due_date: str = "",
                source_message_id: str = "", project: str = "",
                parent_task_id: int = 0, assignee: str = "я") -> str:
    """Создать задачу: в локальной базе и в Outlook (с напоминанием, если есть срок).
    due_date — YYYY-MM-DD, пустая строка если срока нет; project — название проекта;
    parent_task_id — id родительской задачи, если это подзадача (0 — обычная);
    assignee — «я» или имя другого исполнителя (задачи других людей тоже фиксируются)."""
    ctx = get_context()
    # защита от циклов и дублей: такая же открытая задача уже есть — не создаём
    existing = [t for t in ctx.repos.tasks.list(limit=200)
                if t["status"] in ("open", "draft")
                and t["title"].strip().lower() == title.strip().lower()]
    if existing:
        return (f"Задача с таким названием уже существует (№{existing[0]['id']}, "
                f"статус {existing[0]['status']}) — новую не создаю.")
    due = due_date or None
    reminder = None
    due_dt = None
    if due:
        try:
            due_dt = datetime.fromisoformat(due)
            reminder = (due_dt - timedelta(hours=3)).isoformat()
        except ValueError:
            return f"Неверный формат даты: {due_date}. Нужен YYYY-MM-DD."
    # проект не указан — пробуем узнать его по известным проектам из графа
    project_note = ""
    if not project:
        haystack = f"{title} {description}".lower()
        known_projects = [e["name"] for e in ctx.repos.entities.all_entities()
                          if e["type"] == "project"]
        hits = [p for p in known_projects if p.lower() in haystack]
        if len(hits) == 1:
            project = hits[0]
            project_note = f" Проект определён автоматически: «{project}»."
        elif len(hits) > 1:
            project_note = (f" Не смог выбрать проект (подходят: {', '.join(hits)}) — "
                            "уточните у пользователя.")
        else:
            project_note = (" Проект не определён — спроси пользователя, к какому "
                            f"проекту отнести (известные: {', '.join(known_projects[:6])}).")
    task_id = ctx.repos.tasks.create(
        title=title, description=description,
        source_message_id=source_message_id or None,
        due_date=due, reminder_at=reminder, assignee=assignee or "я",
        project=project or None)
    if parent_task_id and ctx.repos.tasks.get(parent_task_id):
        ctx.repos.tasks.set_parent(task_id, parent_task_id)
    outlook_note = "задача чужая — в Outlook не создаётся"
    if (assignee or "я") == "я":
        try:
            entry_id = ctx.outlook.create_task(
                subject=title, body=description, due=due_dt,
                reminder=datetime.fromisoformat(reminder) if reminder else None)
            if entry_id:
                ctx.repos.tasks.set_outlook_entry_id(task_id, entry_id)
                outlook_note = "создана и в Outlook"
            else:
                outlook_note = "в Outlook не создана (dry-run)"
        except Exception as e:  # noqa: BLE001
            outlook_note = f"в Outlook не создана: {e}"
    due_note = "" if due else " Срок не указан — уточни у пользователя дедлайн."
    return f"Задача №{task_id} «{title}» создана ({outlook_note}).{project_note}{due_note}"


@tool
def create_mail_folder(folder_path: str) -> str:
    """Создать папку в Outlook. folder_path — путь вида «Штрафы» или
    «GigaPost/Штрафы» (вложенность через /). Если папка уже есть — ничего не ломается."""
    ctx = get_context()
    try:
        ctx.outlook.ensure_folder(folder_path)
    except Exception as e:  # noqa: BLE001
        return f"Не удалось создать папку «{folder_path}»: {e}"
    if ctx.outlook.dry_run:
        return (f"Папка «{folder_path}» будет создана при отключении режима dry-run "
                f"(сейчас все изменения в Outlook только имитируются).")
    return f"Папка «{folder_path}» создана (или уже существовала)."


@tool
def move_emails_to_folder(message_ids: list[str], folder_path: str) -> str:
    """Переместить письма в папку Outlook. message_ids — список message_id
    из результатов search_emails; folder_path — путь папки, например «Штрафы».
    Папка создаётся автоматически, если её нет."""
    ctx = get_context()
    if not message_ids:
        return ("Список message_ids пуст — ничего не перемещено. Сначала найди письма "
                "через search_emails и передай их message_id.")
    try:
        ctx.outlook.ensure_folder(folder_path)
    except Exception as e:  # noqa: BLE001
        return f"Не удалось создать папку «{folder_path}»: {e}"
    moved, errors = [], []
    for mid in message_ids[:50]:
        email = ctx.repos.emails.get(mid)
        if not email or not email.get("entry_id"):
            errors.append(f"{mid}: письмо не найдено")
            continue
        try:
            new_entry_id = ctx.outlook.move_email(email["entry_id"], folder_path)
            if not ctx.outlook.dry_run:  # в dry-run письмо реально не двигалось
                ctx.repos.emails.set_entry_id(mid, new_entry_id or email["entry_id"], folder_path)
            moved.append(email.get("subject") or mid)
        except Exception as e:  # noqa: BLE001
            errors.append(f"{email.get('subject') or mid}: {e}")
    result = f"Перемещено писем: {len(moved)}."
    if moved:
        result += " " + "; ".join(f"«{s[:40]}»" for s in moved[:10])
    if errors:
        result += f" Ошибки ({len(errors)}): " + "; ".join(errors[:5])
    if ctx.outlook.dry_run:
        result += (" ВНИМАНИЕ: режим dry-run — в Outlook письма пока не перемещены, "
                   "перемещение выполнится по-настоящему после отключения dry_run в настройках.")
    return result


@tool
def list_folder_emails(folder_path: str, days: int = 30) -> str:
    """Список писем в конкретной папке Outlook за последние N дней.
    folder_path — «Inbox», «Штрафы», «GigaPost/Проекты» и т.п.
    Используй, когда нужно работать с содержимым папки (например, перед удалением)."""
    from datetime import datetime, timedelta

    ctx = get_context()
    try:
        emails = ctx.outlook.fetch_new_emails(
            folder_path, datetime.now() - timedelta(days=days), max_items=50)
    except Exception as e:  # noqa: BLE001
        return f"Не удалось прочитать папку «{folder_path}»: {e}"
    if not emails:
        return f"В папке «{folder_path}» нет писем за последние {days} дней."
    # письма из папки попадают в базу — дальше с ними можно работать по message_id
    for em in emails:
        ctx.repos.emails.upsert(em)
    # компактный вывод: у GigaChat маленький контекст
    return json.dumps([{
        "id": em.message_id,
        "тема": em.subject[:60],
        "дата": em.received_at[:10],
    } for em in emails[:30]], ensure_ascii=False)


@tool
def delete_emails(message_ids: list[str]) -> str:
    """Удалить письма (мягко: Outlook переместит их в папку «Удалённые»,
    откуда их можно восстановить). message_ids — из search_emails или
    list_folder_emails. Безвозвратного удаления этот инструмент не делает."""
    ctx = get_context()
    if not message_ids:
        return ("Список message_ids пуст — ничего не удалено. Сначала найди письма "
                "через search_emails или list_folder_emails.")
    deleted, errors = [], []
    for mid in message_ids[:50]:
        email = ctx.repos.emails.get(mid)
        if not email or not email.get("entry_id"):
            errors.append(f"{mid}: письмо не найдено")
            continue
        try:
            ctx.outlook.delete_email(email["entry_id"])
            if not ctx.outlook.dry_run:
                ctx.repos.emails.set_entry_id(mid, email["entry_id"], "Удаленные")
            deleted.append(email.get("subject") or mid)
        except Exception as e:  # noqa: BLE001
            errors.append(f"{email.get('subject') or mid}: {e}")
    result = f"Перемещено в «Удалённые»: {len(deleted)}."
    if deleted:
        result += " " + "; ".join(f"«{s[:40]}»" for s in deleted[:10])
    if errors:
        result += f" Ошибки ({len(errors)}): " + "; ".join(errors[:5])
    if ctx.outlook.dry_run:
        result += " (режим dry-run: в Outlook ничего не удалено)"
    return result


def build_reply_draft(ctx, message_id: str) -> str | None:
    """Собрать контекст и сгенерировать черновик ответа на письмо.
    Общая логика для инструмента агента и кнопки в UI."""
    from gigapost.config import load_prompt, settings as _settings
    from gigapost.llm.factory import get_llm
    from gigapost.pipeline.nodes import clean_body

    email = ctx.repos.emails.get(message_id)
    if not email:
        return None
    query = f"{email.get('subject') or ''} {clean_body(email.get('body_text') or '', 300)}"
    context_parts = []
    seen_notes: set[int] = set()

    def _add_note(note: dict, prefix: str = "знание") -> None:
        if note["id"] not in seen_notes:
            seen_notes.add(note["id"])
            context_parts.append(f"[{prefix}] {note['title']}: {_plain(note['body'])}")

    # знания: семантический поиск по заметкам
    try:
        if ctx.vectors is not None:
            vec = ctx.vectors.embeddings.embed_query(query)
            res = ctx.vectors.notes_collection.query(query_embeddings=[vec], n_results=6)
            for note_id in res["ids"][0]:
                note = ctx.repos.notes.get(int(note_id))
                if note:
                    _add_note(note)
    except Exception:  # noqa: BLE001
        pass
    # знания: backlinks сущностей, упомянутых в письме (хабы графа —
    # именно здесь конкретика: цифры, роли, особенности контрагентов)
    try:
        q_lower = query.lower()
        mentioned = [e for e in ctx.repos.entities.all_entities()
                     if len(e["name"]) >= 4 and e["name"].lower() in q_lower]
        for e in mentioned[:6]:
            for note in ctx.repos.notes.for_entity(e["id"], limit=3):
                _add_note(note, f"знание о {e['name']}")
    except Exception:  # noqa: BLE001
        pass
    # задачи этой переписки и завершённые по теме
    for t in ctx.repos.tasks.list(limit=200):
        if t.get("source_message_id") == message_id or (
                t["status"] == "done" and t["title"].lower() in query.lower()):
            context_parts.append(f"[задача, {t['status']}] {t['title']}")
    # вложения письма с текстом
    for a in ctx.repos.attachments.parsed_for_email(message_id):
        context_parts.append(f"[документ {a['filename']}] {(a['text'] or '')[:600]}")
    # стиль владельца: фрагменты его реальных отправленных писем
    style_examples = []
    for sent in ctx.repos.db.query(
            """SELECT body_text FROM emails WHERE folder='Sent'
               AND LENGTH(COALESCE(body_text, '')) > 80
               ORDER BY received_at DESC LIMIT 3"""):
        style_examples.append(clean_body(sent["body_text"], 350))
    if style_examples:
        context_parts.append(
            "[стиль владельца — примеры его писем, подражай тону]\n"
            + "\n---\n".join(style_examples))
    prompt = load_prompt("reply").format(
        owner=_settings.owner.full,
        sender_name=email.get("sender_name"), sender_email=email.get("sender_email"),
        subject=email.get("subject"), received_at=email.get("received_at"),
        body=clean_body(email.get("body_text") or "", 1500),
        context="\n".join(context_parts[:18]) or "(контекста не найдено)")
    draft = get_llm("chat").invoke(prompt)
    return draft.content if hasattr(draft, "content") else str(draft)


@tool
def suggest_reply(message_id: str) -> str:
    """Составить черновик ответа на письмо. Собирает контекст (база знаний,
    задачи, вложения по теме) и генерирует текст ответа. Черновик только
    ПОКАЗЫВАЕТСЯ — для сохранения в «Черновики» Outlook есть save_reply_draft."""
    ctx = get_context()
    text = build_reply_draft(ctx, message_id)
    if text is None:
        return "Письмо не найдено."
    return (f"ЧЕРНОВИК ОТВЕТА (покажи пользователю целиком и спроси, сохранить ли "
            f"в Outlook через save_reply_draft):\n\n{text}")


@tool
def save_reply_draft(message_id: str, body: str) -> str:
    """Сохранить текст как ЧЕРНОВИК ответа в Outlook (папка «Черновики»).
    Письмо НЕ отправляется — пользователь отредактирует и отправит сам."""
    ctx = get_context()
    email = ctx.repos.emails.get(message_id)
    if not email or not email.get("entry_id"):
        return "Письмо не найдено — черновик не создан."
    try:
        ok = ctx.outlook.create_reply_draft(email["entry_id"], body)
    except Exception as e:  # noqa: BLE001
        return f"Не удалось создать черновик: {e}"
    if not ok:
        return ("Черновик не создан (dry-run или Outlook недоступен) — "
                "текст можно скопировать из чата.")
    return f"Черновик ответа на «{email.get('subject')}» сохранён в «Черновики» Outlook."


@tool
def link_tasks(task_id: int, other_task_id: int) -> str:
    """Связать две задачи между собой (отношение «связана с»). Используй, когда
    задачи относятся к одной теме, блокируют друг друга или продолжают одна другую."""
    ctx = get_context()
    a, b = ctx.repos.tasks.get(task_id), ctx.repos.tasks.get(other_task_id)
    if not a or not b:
        return "Одна из задач не найдена."
    ctx.repos.tasks.add_link(task_id, other_task_id)
    return f"Задачи №{task_id} «{a['title'][:40]}» и №{other_task_id} «{b['title'][:40]}» связаны."


@tool
def complete_task(task_id: int) -> str:
    """Отметить задачу выполненной (в базе и в Outlook)."""
    ctx = get_context()
    task = ctx.repos.tasks.get(task_id)
    if not task:
        return f"Задача №{task_id} не найдена."
    ctx.repos.tasks.set_status(task_id, "done")
    if task.get("outlook_task_entry_id"):
        try:
            ctx.outlook.complete_task(task["outlook_task_entry_id"])
        except Exception as e:  # noqa: BLE001
            return f"Задача №{task_id} закрыта в базе, но в Outlook ошибка: {e}"
    return f"Задача №{task_id} «{task['title']}» выполнена."


READONLY_TOOLS = [
    search_knowledge, search_emails, get_email_details, get_attachment_text,
    find_attachments, query_knowledge_graph, get_entity_profile,
    list_tasks, get_agreements_on_control, list_folder_emails, suggest_reply,
]

MUTATING_TOOLS = [
    create_task, complete_task, link_tasks, create_mail_folder,
    move_emails_to_folder, delete_emails, add_knowledge, save_reply_draft,
]

ALL_TOOLS = READONLY_TOOLS + MUTATING_TOOLS
