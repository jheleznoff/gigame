"""Протоколы встреч: транскрипт → протокол → задачи/знания.

Вход: файлы транскриптов (txt/md/docx) в GigaMePost_Export\\Встречи\\.
Обработка map-reduce под лимит корп-API: куски → конспекты → один
структурный вызов. Выход — в существующие механизмы решения:
- протокол сохраняется как документ-«письмо» (message_id meeting:...) —
  полнотекстовый поиск, векторный индекс, доступен агенту и панелям;
- поручения → черновики задач (HITL-подтверждение на дашборде);
- решения/факты → заметки графа знаний (отдельным вызовом, как у писем).
Обработанные файлы переезжают в подпапку imported/.
"""

from __future__ import annotations

import hashlib
import logging
import re
from datetime import datetime
from pathlib import Path

from pydantic import BaseModel, Field

from gigapost.config import load_prompt, settings
from gigapost.llm.structured import structured_call
from gigapost.outlook.models import EmailMessage

logger = logging.getLogger(__name__)

MEETINGS_DIR_NAME = "Встречи"
CHUNK_CHARS = 5000          # кусок транскрипта на один конспект-вызов
DIGEST_CAP = 5500           # суммарный конспект в финальный промпт
MAX_CHUNKS = 24             # ~2 часа плотного разговора

MEETING_FOLDER = "Протоколы встреч"


class MeetingTask(BaseModel):
    """Поручение со встречи."""

    title: str = Field(description="Что сделать, коротко")
    assignee: str = Field(default="я", description="«я» или имя исполнителя")
    due_date: str = Field(default="", description="ГГГГ-ММ-ДД или пусто")


class MeetingProtocol(BaseModel):
    """Структурированный протокол встречи."""

    summary: str = ""
    decisions: list[str] = Field(default_factory=list)
    tasks: list[MeetingTask] = Field(default_factory=list)
    open_questions: list[str] = Field(default_factory=list)


def meetings_dir() -> Path:
    from gigapost.outlook.msg_import import DEFAULT_EXPORT_DIR
    return DEFAULT_EXPORT_DIR / MEETINGS_DIR_NAME


def _meeting_date_from_name(path: Path) -> str:
    m = re.search(r"(20\d{2})[-._]?(\d{2})[-._]?(\d{2})", path.stem)
    if m:
        return f"{m.group(1)}-{m.group(2)}-{m.group(3)}"
    return datetime.now().strftime("%Y-%m-%d")


def _map_reduce_digest(text: str, llm) -> str:
    """Длинный транскрипт → конспект, влезающий в один структурный вызов."""
    if len(text) <= DIGEST_CAP:
        return text
    chunks = [text[i:i + CHUNK_CHARS]
              for i in range(0, len(text), CHUNK_CHARS)][:MAX_CHUNKS]
    parts = []
    for i, chunk in enumerate(chunks, 1):
        resp = llm.invoke(
            "Это фрагмент транскрипта рабочего совещания. Сожми его в 3-6 "
            "пунктов: решения, поручения (кто/что/срок), важные факты и цифры. "
            "Без воды, каждый пункт с новой строки, начинай с «- ».\n\n" + chunk)
        parts.append(resp.content if hasattr(resp, "content") else str(resp))
    digest = "\n".join(parts)
    return digest[:DIGEST_CAP * 2]   # финальный промпт всё равно ограничим


def process_transcript(repos, kg, vectors, path: Path) -> dict:
    """Обработать один файл транскрипта. Возвращает статистику."""
    from gigapost.attachments.extractor import extract_text
    from gigapost.llm.factory import get_llm
    from gigapost.llm.schemas import NotesResult

    text = extract_text(path)
    if not text or len(text.strip()) < 100:
        return {"ok": False, "reason": "текст не извлечён или слишком короткий"}

    llm = get_llm("chat")
    meeting_date = _meeting_date_from_name(path)
    title = path.stem.replace("_", " ")

    digest = _map_reduce_digest(text, llm)
    prompt = load_prompt("meeting").format(
        owner=settings.owner.full, meeting_date=meeting_date,
        title=title, digest=digest[:DIGEST_CAP])
    protocol = structured_call(llm, MeetingProtocol, prompt)

    # протокол как документ-«письмо»: поиск, вектор, доступ агента
    message_id = "meeting:" + hashlib.sha1(
        f"{meeting_date}|{title}".encode()).hexdigest()[:16]
    body_lines = [f"Протокол встречи «{title}» от {meeting_date}", "",
                  protocol.summary, ""]
    if protocol.decisions:
        body_lines.append("Решения:")
        body_lines += [f"- {d}" for d in protocol.decisions]
        body_lines.append("")
    if protocol.tasks:
        body_lines.append("Поручения:")
        body_lines += [f"- {t.title} ({t.assignee}"
                       f"{', до ' + t.due_date if t.due_date else ''})"
                       for t in protocol.tasks]
        body_lines.append("")
    if protocol.open_questions:
        body_lines.append("Открытые вопросы:")
        body_lines += [f"- {q}" for q in protocol.open_questions]
    body = "\n".join(body_lines)

    em = EmailMessage(
        message_id=message_id, entry_id="", conversation_id=message_id,
        subject=f"Протокол: {title}", sender_name=settings.owner.name,
        sender_email="", recipients=[], received_at=f"{meeting_date}T12:00:00",
        body_text=body, folder=MEETING_FOLDER, has_attachments=False,
        attachment_names=[], attachment_paths=[])
    repos.emails.upsert(em)

    # поручения → черновики задач (подтверждение на дашборде)
    created_tasks = 0
    for t in protocol.tasks:
        if not t.title.strip():
            continue
        repos.tasks.create(
            t.title.strip(), status="draft",
            due_date=t.due_date or None,
            assignee=t.assignee if t.assignee not in ("", "я") else None,
            source_message_id=message_id,
            description=f"Со встречи «{title}» ({meeting_date})")
        created_tasks += 1

    # решения/факты → заметки графа (отдельный вызов, как у писем)
    notes_created = 0
    try:
        notes_prompt = load_prompt("notes").format(
            owner=settings.owner.full, sender_name=settings.owner.name,
            sender_email="", subject=f"Встреча: {title}",
            received_at=meeting_date, body=body[:6000])
        notes = structured_call(get_llm("extract"), NotesResult, notes_prompt).notes
        for n in notes:
            kg.add_note(title=n.title, body=n.body, kind=n.kind,
                        source_message_id=message_id, conversation_id=message_id)
            notes_created += 1
    except Exception as e:  # noqa: BLE001 — лимиты: протокол и задачи уже есть
        logger.warning("Заметки по встрече %s: %s", title, e)

    if vectors is not None:
        try:
            vectors.index_email({"message_id": message_id, "subject": em.subject,
                                 "body_text": body, "sender_email": "",
                                 "received_at": em.received_at,
                                 "category": None, "folder": MEETING_FOLDER})
            repos.emails.mark_indexed(message_id)
        except Exception:  # noqa: BLE001
            pass

    repos.log.log(message_id, "meeting", "ok",
                  f"задач={created_tasks}, заметок={notes_created}")
    return {"ok": True, "message_id": message_id, "tasks": created_tasks,
            "notes": notes_created, "decisions": len(protocol.decisions)}


def scan_meetings(repos, kg, vectors, limit: int = 2) -> int:
    """Джоб: обработать новые транскрипты из папки Встречи (порциями)."""
    base = meetings_dir()
    if not base.exists():
        return 0
    done = 0
    files = [p for p in sorted(base.iterdir())
             if p.is_file() and p.suffix.lower() in (".txt", ".md", ".docx")]
    for path in files[:limit]:
        try:
            result = process_transcript(repos, kg, vectors, path)
        except Exception as e:  # noqa: BLE001 — лимиты: возьмём в следующий заход
            logger.warning("Встреча %s: %s", path.name, e)
            break
        imported = base / "imported"
        imported.mkdir(exist_ok=True)
        try:
            path.rename(imported / path.name)
        except Exception:  # noqa: BLE001
            pass
        if result.get("ok"):
            done += 1
            logger.info("Протокол встречи %s: %s", path.name, result)
    return done
