"""Анализ ОТПРАВЛЕННЫХ писем владельца ящика.

1) Обещания («пришлю», «подготовлю», «вернусь с ответом») → задачи-черновики
   и договорённости we_owe на контроле.
2) Если в переписке (conversation_id) на владельце висят открытые задачи —
   LLM решает, закрывает ли их это письмо; закрытие предлагается алертом
   «Похоже, выполнено» с кнопкой на дашборде (не закрываем молча).
"""

from __future__ import annotations

import logging
from datetime import datetime, timedelta

from gigapost.config import load_prompt, settings
from gigapost.db.repositories import Repos
from gigapost.llm.schemas import ClosureVerdict, ExtractionResult
from gigapost.llm.structured import structured_call
from gigapost.pipeline.nodes import clean_body

logger = logging.getLogger(__name__)


class SentProcessor:
    def __init__(self, repos: Repos, outlook, extract_llm=None):
        self.repos = repos
        self.outlook = outlook
        self._extract_llm = extract_llm

    @property
    def extract_llm(self):
        if self._extract_llm is None:
            from gigapost.llm.factory import get_llm
            self._extract_llm = get_llm("extract")
        return self._extract_llm

    def _open_tasks_in_conversation(self, conversation_id: str) -> list[dict]:
        if not conversation_id:
            return []
        rows = self.repos.db.query(
            """SELECT t.* FROM tasks t JOIN emails e ON e.message_id = t.source_message_id
               WHERE e.conversation_id = ? AND t.status IN ('open', 'draft')""",
            (conversation_id,))
        return [dict(r) for r in rows]

    def process_email(self, email) -> dict:
        """Обработать одно отправленное письмо. Возвращает статистику."""
        stats = {"promises": 0, "maybe_done": 0}
        body = clean_body(email.body_text)
        if not body.strip():
            return stats

        # 1) обещания владельца → задачи и договорённости we_owe
        try:
            prompt = load_prompt("sent").format(
                owner=settings.owner.full,
                recipients=", ".join(email.recipients[:10]),
                subject=email.subject, received_at=email.received_at, body=body)
            extraction = structured_call(self.extract_llm, ExtractionResult, prompt)
            for t in extraction.tasks:
                reminder = None
                if t.deadline:
                    try:
                        due_dt = datetime.fromisoformat(t.deadline)
                        reminder = (due_dt - timedelta(hours=3)).isoformat()
                    except ValueError:
                        t.deadline = None
                self.repos.tasks.create(
                    title=f"(обещание) {t.title}", description=t.description,
                    source_message_id=email.message_id, due_date=t.deadline,
                    reminder_at=reminder, assignee="я", status="draft",
                    project=t.project)
                stats["promises"] += 1
            for a in extraction.agreements:
                if a.direction == "we_owe":
                    self.repos.agreements.create(
                        description=a.description,
                        counterparty=a.counterparty or ", ".join(email.recipients[:3]),
                        direction="we_owe", source_message_id=email.message_id,
                        conversation_id=email.conversation_id, due_date=a.due_date,
                        followup_after_days=settings.control.default_followup_days)
        except Exception as e:  # noqa: BLE001
            logger.warning("Извлечение обещаний из %s: %s", email.message_id, e)

        # 2) закрывает ли письмо открытые задачи этой переписки
        open_tasks = self._open_tasks_in_conversation(email.conversation_id)
        if open_tasks:
            try:
                tasks_text = "\n".join(
                    f"- id={t['id']}: {t['title']}" for t in open_tasks[:15])
                prompt = load_prompt("closure").format(
                    owner=settings.owner.full, tasks=tasks_text,
                    subject=email.subject, received_at=email.received_at, body=body)
                verdict = structured_call(self.extract_llm, ClosureVerdict, prompt)
                valid_ids = {t["id"] for t in open_tasks}
                for task_id in verdict.done_task_ids:
                    if task_id not in valid_ids:
                        continue
                    task = self.repos.tasks.get(task_id)
                    created = self.repos.alerts.create(
                        "task_maybe_done", "tasks", task_id,
                        f"Похоже, выполнено вашим ответом «{email.subject[:50]}»: "
                        f"{task['title']}")
                    if created:
                        stats["maybe_done"] += 1
            except Exception as e:  # noqa: BLE001
                logger.warning("Проверка закрытия задач по %s: %s", email.message_id, e)

        # обещанное письмо контрагенту = активность в треде для follow-up
        self.repos.agreements.touch_conversation(email.conversation_id, email.received_at)
        return stats

    def _sent_rows_from_db(self, since: datetime) -> list:
        """Файловый шлюз: отправленные уже в БД (из _sent_stream) — берём те,
        что ещё не проходили sent-обработку."""
        import json

        from gigapost.outlook.models import EmailMessage

        rows = self.repos.db.query(
            """SELECT e.* FROM emails e
               WHERE e.folder = 'Sent' AND e.received_at >= ?
                 AND NOT EXISTS (SELECT 1 FROM processing_log l
                                 WHERE l.message_id = e.message_id AND l.stage = 'sent')
               ORDER BY e.received_at""", (since.isoformat(),))
        result = []
        for r in rows:
            d = dict(r)
            result.append(EmailMessage(
                message_id=d["message_id"], entry_id=d.get("entry_id") or "",
                conversation_id=d.get("conversation_id") or "",
                subject=d.get("subject") or "",
                sender_name=d.get("sender_name") or "",
                sender_email=d.get("sender_email") or "",
                recipients=json.loads(d.get("recipients_json") or "[]"),
                received_at=d.get("received_at") or "",
                body_text=d.get("body_text") or "", folder="Sent",
                has_attachments=bool(d.get("has_attachments")),
                attachment_names=[], attachment_paths=[]))
        return result

    def run_cycle(self) -> dict:
        """Опрос папки «Отправленные» (инкрементально)."""
        stats = {"fetched": 0, "processed": 0, "promises": 0, "maybe_done": 0}
        key = "last_poll_ts:Sent"
        raw = self.repos.settings.get(key)
        overlap = timedelta(minutes=settings.polling.lookback_overlap_minutes)
        since = (datetime.fromisoformat(raw) - overlap) if raw \
            else datetime.now() - timedelta(days=1)
        started_at = datetime.now()
        from gigapost.outlook.msg_import import DEFAULT_EXPORT_DIR
        gateway = DEFAULT_EXPORT_DIR.exists()
        if gateway:
            emails = self._sent_rows_from_db(since)
        else:
            try:
                emails = self.outlook.fetch_new_emails("Sent", since)
            except Exception as e:  # noqa: BLE001
                logger.error("Не удалось прочитать «Отправленные»: %s", e)
                return stats
        stats["fetched"] = len(emails)
        for email in emails:
            if not gateway:
                if self.repos.emails.exists(email.message_id):
                    continue
                email.folder = "Sent"
                self.repos.emails.upsert(email)
            try:
                r = self.process_email(email)
                stats["processed"] += 1
                stats["promises"] += r["promises"]
                stats["maybe_done"] += r["maybe_done"]
                self.repos.log.log(email.message_id, "sent", "ok",
                                   f"обещаний={r['promises']} к_закрытию={r['maybe_done']}")
            except Exception as e:  # noqa: BLE001
                logger.exception("Ошибка обработки отправленного %s", email.message_id)
                self.repos.log.log(email.message_id, "sent", "error", str(e))
        self.repos.settings.set(key, started_at.isoformat())
        if stats["processed"]:
            logger.info("Цикл sent: %s", stats)
        return stats
