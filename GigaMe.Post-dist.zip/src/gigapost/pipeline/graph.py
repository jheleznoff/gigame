"""Сборка ingestion-графа LangGraph и цикл обработки почты.

Маршрут: classify → [extract если requires_action] → apply_actions → update_kg → index_vector.
Каждое письмо — отдельный graph.invoke(); ошибка одного письма не валит батч.
"""

from __future__ import annotations

import logging
from datetime import datetime, timedelta

from langgraph.graph import END, START, StateGraph

from gigapost.config import settings
from gigapost.db.repositories import Repos
from gigapost.outlook.client import OutlookClient
from gigapost.pipeline.nodes import PipelineNodes
from gigapost.pipeline.state import IngestState

logger = logging.getLogger(__name__)

MAX_ATTEMPTS = 3


def build_ingest_graph(nodes: PipelineNodes):
    g = StateGraph(IngestState)
    g.add_node("classify", nodes.classify)
    g.add_node("parse_attachments", nodes.parse_attachments)
    g.add_node("extract", nodes.extract)
    g.add_node("apply_actions", nodes.apply_actions)
    g.add_node("update_kg", nodes.update_kg)
    g.add_node("index_vector", nodes.index_vector)

    def _extract_enabled(s: IngestState) -> bool:
        """Извлечение управляется флагом extract категории (Рассылки — false)."""
        c = s.get("classification")
        if c is None:
            return False
        cat_cfg = nodes.taxonomy.get(c.category)
        if cat_cfg is not None:
            return cat_cfg.extract
        return c.requires_action  # неизвестная категория — по требованию действия

    def _route_after_classify(s: IngestState) -> str:
        if s.get("hard_rule_category"):
            return "apply_actions"
        if not _extract_enabled(s):
            return "apply_actions"
        if s["email"].attachment_names:
            return "parse_attachments"
        return "extract"

    def _route_after_attachments(s: IngestState) -> str:
        return "extract" if _extract_enabled(s) else "apply_actions"

    g.add_edge(START, "classify")
    g.add_conditional_edges("classify", _route_after_classify, {
        "parse_attachments": "parse_attachments",
        "extract": "extract",
        "apply_actions": "apply_actions",
    })
    g.add_conditional_edges("parse_attachments", _route_after_attachments, {
        "extract": "extract",
        "apply_actions": "apply_actions",
    })
    g.add_edge("extract", "apply_actions")
    g.add_edge("apply_actions", "update_kg")
    g.add_edge("update_kg", "index_vector")
    g.add_edge("index_vector", END)
    return g.compile()


class IngestRunner:
    """Инкрементальный цикл: забрать новые письма → прогнать каждое через граф."""

    def __init__(self, repos: Repos, outlook: OutlookClient, nodes: PipelineNodes):
        self.repos = repos
        self.outlook = outlook
        self.nodes = nodes
        self.graph = build_ingest_graph(nodes)

    def reindex_pending(self, limit: int = 50) -> int:
        """Доиндексировать письма, у которых не получилось с первого раза (429 и т.п.)."""
        if self.nodes.vectors is None:
            return 0
        done = 0
        for email in self.repos.emails.unindexed(limit=limit):
            try:
                n = self.nodes.vectors.index_email(email)
                meta = {"sender_email": email.get("sender_email"),
                        "received_at": email.get("received_at"),
                        "category": email.get("category"), "folder": email.get("folder")}
                for a in self.repos.attachments.parsed_for_email(email["message_id"]):
                    n += self.nodes.vectors.index_attachment(
                        email["message_id"], a["filename"], a["text"], meta)
                self.repos.emails.mark_indexed(email["message_id"])
                done += 1
            except Exception as e:  # noqa: BLE001 — доиндексируем в следующий заход
                logger.warning("Доиндексация %s: %s", email["message_id"], e)
                break  # скорее всего опять лимиты — не молотим впустую
        if done:
            logger.info("Доиндексировано писем: %d", done)
        return done

    def _poll_since(self, folder: str) -> datetime:
        key = f"last_poll_ts:{folder}"
        raw = self.repos.settings.get(key)
        overlap = timedelta(minutes=settings.polling.lookback_overlap_minutes)
        if raw:
            try:
                return datetime.fromisoformat(raw) - overlap
            except ValueError:
                pass
        return datetime.now() - timedelta(days=1)

    def run_cycle(self) -> dict:
        """Один цикл опроса всех папок. Возвращает статистику."""
        stats = {"fetched": 0, "processed": 0, "skipped": 0, "errors": 0}
        for folder in settings.polling.folders:
            since = self._poll_since(folder)
            started_at = datetime.now()
            try:
                emails = self.outlook.fetch_new_emails(folder, since)
            except Exception as e:  # noqa: BLE001
                logger.error("Не удалось прочитать папку %s: %s", folder, e)
                self.repos.log.log(None, "fetch", "error", f"{folder}: {e}")
                stats["errors"] += 1
                continue
            stats["fetched"] += len(emails)
            for email in emails:
                if self.repos.emails.exists(email.message_id):
                    row = self.repos.emails.get(email.message_id)
                    if row and row.get("processed_at"):
                        stats["skipped"] += 1
                        continue
                if self.repos.log.error_count(email.message_id, "pipeline") >= MAX_ATTEMPTS:
                    stats["skipped"] += 1
                    continue
                self.repos.emails.upsert(email)
                try:
                    self.graph.invoke({"email": email})
                    stats["processed"] += 1
                except Exception as e:  # noqa: BLE001 — одно письмо не валит батч
                    logger.exception("Ошибка обработки письма %s", email.message_id)
                    self.repos.log.log(email.message_id, "pipeline", "error", str(e))
                    stats["errors"] += 1
            self.repos.settings.set(f"last_poll_ts:{folder}", started_at.isoformat())
        logger.info("Цикл ingest: %s", stats)
        return stats
