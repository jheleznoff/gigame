"""Узлы ingestion-графа. Никакой агентности — LLM только как классификатор/экстрактор."""

from __future__ import annotations

import logging
import re
from datetime import datetime, timedelta

from gigapost.config import Taxonomy, load_prompt, settings
from gigapost.db.repositories import Repos
from gigapost.knowledge.graph_store import KnowledgeGraph
from gigapost.knowledge.vector_store import VectorStore
from gigapost.llm.schemas import EmailClassification, ExtractionResult
from gigapost.llm.structured import structured_call
from gigapost.outlook.client import OutlookClient
from gigapost.pipeline.state import IngestState

logger = logging.getLogger(__name__)

# Обрезаем цитируемые хвосты переписки перед отправкой в LLM.
# Корпоративный Outlook даёт много вариантов разделителей истории.
_QUOTE_MARKERS = [
    "-----Original Message-----",
    "-----Исходное сообщение-----",
    "-----Original Appointment-----",
    "________________________________",
]
# «От: … Отправлено:» / "From: … Sent:" — начало процитированного письма
_QUOTE_RE = re.compile(
    r"^\s*(От|From):\s.+(\r?\n)+\s*(Отправлено|Sent|Дата|Date):\s", re.MULTILINE)


def clean_body(body: str, max_chars: int | None = None) -> str:
    for marker in _QUOTE_MARKERS:
        idx = body.find(marker)
        if idx > 0:
            body = body[:idx]
    m = _QUOTE_RE.search(body)
    if m and m.start() > 0:
        body = body[:m.start()]
    body = body.strip()
    limit = max_chars or settings.limits.max_body_chars
    return body[:limit]


def apply_category_actions(repos: Repos, outlook: OutlookClient, taxonomy: Taxonomy,
                           message_id: str, category: str,
                           entry_id: str | None = None) -> list[str]:
    """Применить действия таксономии (категория/флаг/перемещение) к письму.
    Используется пайплайном и ручным разбором на дашборде."""
    applied: list[str] = []
    cat_cfg = taxonomy.get(category)
    if cat_cfg is None:
        return applied
    if entry_id is None:
        email = repos.emails.get(message_id)
        entry_id = (email or {}).get("entry_id")
    if not entry_id:
        return applied
    ol = cat_cfg.outlook
    if ol.category:
        outlook.set_category(entry_id, ol.category)
        applied.append(f"category:{ol.category}")
    if ol.flag:
        outlook.set_flag(entry_id)
        applied.append("flag")
    if ol.folder:
        new_entry_id = outlook.move_email(entry_id, ol.folder)
        if not new_entry_id:
            new_entry_id = entry_id
        repos.emails.set_entry_id(message_id, new_entry_id, ol.folder)
        applied.append(f"move:{ol.folder}")
    return applied


class PipelineNodes:
    """Узлы графа с зависимостями (репозитории, клиенты, таксономия)."""

    def __init__(self, repos: Repos, outlook: OutlookClient, taxonomy: Taxonomy,
                 kg: KnowledgeGraph, vectors: VectorStore | None,
                 classify_llm=None, extract_llm=None):
        self.repos = repos
        self.outlook = outlook
        self.taxonomy = taxonomy
        self.kg = kg
        self.vectors = vectors
        self._classify_llm = classify_llm
        self._extract_llm = extract_llm

    @property
    def classify_llm(self):
        if self._classify_llm is None:
            from gigapost.llm.factory import get_llm
            self._classify_llm = get_llm("classify")
        return self._classify_llm

    @property
    def extract_llm(self):
        if self._extract_llm is None:
            from gigapost.llm.factory import get_llm
            self._extract_llm = get_llm("extract")
        return self._extract_llm

    # ---------- узлы ----------

    def classify(self, state: IngestState) -> IngestState:
        email = state["email"]
        cleaned = clean_body(email.body_text)
        hard = self.taxonomy.apply_hard_rules(email.sender_email, email.subject, cleaned)
        if hard is not None:
            classification = EmailClassification(
                category=hard, importance=1, requires_action=False,
                summary="(hard rule, без LLM)")
            self.repos.log.log(email.message_id, "classify", "ok", f"hard_rule → {hard}")
            return {"classification": classification, "hard_rule_category": hard}

        categories_text = "\n".join(
            f"- {c.name}: {c.description}" for c in self.taxonomy.categories)
        # few-shot из ручных поправок пользователя — система учится на исправлениях
        examples = self.repos.corrections.recent_examples(limit=4)
        examples_text = ""
        if examples:
            lines = ["\nПримеры правильной классификации (поправки пользователя):"]
            for ex in examples:
                lines.append(
                    f"- «{ex['subject'][:60]}» от {ex['sender_name'] or '?'} → "
                    f"{ex['correct_category']}"
                    + (f" (НЕ {ex['wrong_category']})" if ex.get("wrong_category") else ""))
            examples_text = "\n".join(lines) + "\n"
        prompt = load_prompt("classify").format(
            categories=categories_text + "\n" + examples_text,
            sender_name=email.sender_name, sender_email=email.sender_email,
            subject=email.subject, received_at=email.received_at,
            body=cleaned,
        )
        classification = structured_call(self.classify_llm, EmailClassification, prompt)
        needs_review = classification.confidence < settings.review.min_classify_confidence
        if classification.suspicious:
            needs_review = True
            classification.summary = "⚠ ПОХОЖЕ НА ФИШИНГ. " + classification.summary
        if classification.category not in self.taxonomy.category_names:
            logger.warning("LLM вернул неизвестную категорию %r — на ручной разбор",
                           classification.category)
            classification.category = ""
            needs_review = True
        self.repos.log.log(
            email.message_id, "classify", "ok",
            f"{classification.category} imp={classification.importance} "
            f"conf={classification.confidence}" + (" → на разбор" if needs_review else ""))
        return {"classification": classification, "hard_rule_category": None,
                "needs_review": needs_review}

    def parse_attachments(self, state: IngestState) -> IngestState:
        """Извлечь текст из сохранённых вложений, посчитать хеши, записать в БД.

        Статусы: parsed — текст извлечён; stored — файл сохранён в библиотеке,
        но текст не извлекается (архив, скан, картинка); unsupported — не сохранён.
        """
        import hashlib
        from pathlib import Path

        from gigapost.attachments.extractor import extract_text, is_supported

        email = state["email"]
        if not email.attachment_names:
            return {}
        saved = {Path(p).name: p for p in email.attachment_paths}
        parsed = stored = 0
        for fname in email.attachment_names:
            path = saved.get(fname)
            ext = Path(fname).suffix.lower()
            if path is None or not Path(path).exists():
                self.repos.attachments.upsert(
                    email.message_id, fname, ext, None, None, None, "unsupported")
                continue
            data = Path(path).read_bytes()
            sha = hashlib.sha256(data).hexdigest()
            # новые письма: сканы распознаём через vision (их единицы в день)
            text = extract_text(path, allow_ocr=True) if is_supported(fname) else None
            if text:
                status = "parsed"
                parsed += 1
            else:
                status = "stored"
                stored += 1
            self.repos.attachments.upsert(
                email.message_id, fname, ext, len(data), path, text, status, sha)
        self.repos.log.log(
            email.message_id, "attachments", "ok",
            f"{parsed} разобрано, {stored} сохранено из {len(email.attachment_names)}")
        return {}

    def _attachments_prompt_block(self, message_id: str, budget_chars: int = 12000) -> str:
        """Блок текстов вложений для промпта извлечения (с общим лимитом символов)."""
        parts = []
        used = 0
        for a in self.repos.attachments.parsed_for_email(message_id):
            if used >= budget_chars:
                break
            chunk = (a["text"] or "")[: budget_chars - used]
            used += len(chunk)
            parts.append(f"=== Вложение: {a['filename']} ===\n{chunk}")
        return "\n\n".join(parts)

    def extract(self, state: IngestState) -> IngestState:
        email = state["email"]
        attachments_block = self._attachments_prompt_block(email.message_id)
        body = clean_body(email.body_text)
        if attachments_block:
            body = f"{body}\n\n{attachments_block}"
        prompt = load_prompt("extract").format(
            owner=settings.owner.full,
            sender_name=email.sender_name, sender_email=email.sender_email,
            recipients=", ".join(email.recipients[:10]),
            subject=email.subject, received_at=email.received_at,
            body=body,
        )
        # уроки из отклонённых задач: не предлагать подобное повторно
        try:
            lessons = self.repos.db.query(
                "SELECT title, reason FROM task_feedback ORDER BY id DESC LIMIT 5")
            if lessons:
                prompt += ("\n\nРанее пользователь ОТКЛОНИЛ такие задачи "
                           "(не создавай подобные, учитывай причины):\n"
                           + "\n".join(f"- «{r['title'][:80]}» — {r['reason'][:120]}"
                                       for r in lessons))
        except Exception:  # noqa: BLE001
            pass
        extraction = structured_call(self.extract_llm, ExtractionResult, prompt)

        # письмо адресовано группе, а лично владельца в тексте не позвали —
        # задача, скорее всего, «на команду», не автоматически «моя»
        if len(email.recipients) >= 3:
            body_low = body.lower()
            names = [settings.owner.name.lower()] + [
                a.lower() for a in settings.owner.aliases]
            addressed_to_me = any(n in body_low for n in names if len(n) >= 3)
            if not addressed_to_me:
                for t in extraction.tasks:
                    if t.assignee == "я":
                        t.assignee = "другое"
                        t.assignee_name = "адресовано группе — уточнить"

        # Заметки Zettelkasten — отдельным вызовом с маленькой схемой:
        # GigaChat нестабильно заполняет большие составные схемы
        try:
            from gigapost.llm.schemas import NotesResult

            notes_prompt = load_prompt("notes").format(
                owner=settings.owner.full,
                sender_name=email.sender_name, sender_email=email.sender_email,
                subject=email.subject, received_at=email.received_at,
                body=body,
            )
            notes_result = structured_call(self.extract_llm, NotesResult, notes_prompt)
            extraction.notes = notes_result.notes
        except Exception as e:  # noqa: BLE001 — заметки не блокируют пайплайн
            logger.warning("Извлечение заметок для %s не удалось: %s", email.message_id, e)

        self.repos.log.log(
            email.message_id, "extract", "ok",
            f"tasks={len(extraction.tasks)} agreements={len(extraction.agreements)} "
            f"entities={len(extraction.entities)} notes={len(extraction.notes)}")
        return {"extraction": extraction}

    def apply_actions(self, state: IngestState) -> IngestState:
        """Запись результатов в БД + действия в Outlook.

        Human-in-the-loop: при неуверенной классификации (needs_review) письмо
        не трогается в Outlook — уходит в очередь «Разобрать вручную».
        Задачи из писем создаются черновиками (draft) и попадают в Outlook
        только после подтверждения пользователем на дашборде.
        """
        email = state["email"]
        classification = state.get("classification")
        extraction = state.get("extraction")
        needs_review = bool(state.get("needs_review"))
        applied: list[str] = []
        status = "dry_run" if self.outlook.dry_run else "ok"

        if classification is not None:
            self.repos.emails.set_classification(
                email.message_id, classification.category, classification.importance,
                classification.requires_action, classification.summary,
                confidence=classification.confidence, needs_review=needs_review)
            if needs_review:
                applied.append("на ручной разбор (низкая уверенность)")
            else:
                applied += apply_category_actions(
                    self.repos, self.outlook, self.taxonomy, email.message_id,
                    classification.category, entry_id=email.entry_id)

        if extraction is not None:
            # проект по умолчанию — первая project-сущность письма
            default_project = next(
                (e.name for e in extraction.entities if e.type == "project"), None)
            for t in extraction.tasks:
                reminder = None
                if t.deadline:
                    try:
                        due_dt = datetime.fromisoformat(t.deadline)
                        reminder = (due_dt - timedelta(hours=3)).isoformat()
                    except ValueError:
                        t.deadline = None
                # чужие задачи тоже фиксируем — с именем исполнителя
                if t.assignee == "я":
                    assignee = "я"
                elif t.assignee == "отправитель":
                    assignee = t.assignee_name or email.sender_name or "отправитель"
                else:
                    assignee = t.assignee_name or "другое"
                self.repos.tasks.create(
                    title=t.title, description=t.description,
                    source_message_id=email.message_id, due_date=t.deadline,
                    reminder_at=reminder, assignee=assignee, status="draft",
                    project=t.project or default_project)
                applied.append(f"task-draft:{t.title[:40]}")

            for a in extraction.agreements:
                self.repos.agreements.create(
                    description=a.description, counterparty=a.counterparty,
                    direction=a.direction, source_message_id=email.message_id,
                    conversation_id=email.conversation_id, due_date=a.due_date,
                    followup_after_days=settings.control.default_followup_days)
                applied.append(f"agreement:{a.description[:40]}")

        # новое письмо в треде — освежить last_activity_at открытых договорённостей
        self.repos.agreements.touch_conversation(email.conversation_id, email.received_at)
        self.repos.log.log(email.message_id, "apply", status, "; ".join(applied) or "нет действий")
        return {"actions_applied": applied}

    def update_kg(self, state: IngestState) -> IngestState:
        email = state["email"]
        extraction = state.get("extraction")
        classification = state.get("classification")
        # рассылки и прочие no-extract категории граф не засоряют
        if state.get("hard_rule_category"):
            return {}
        if classification is not None:
            cat_cfg = self.taxonomy.get(classification.category)
            if cat_cfg is not None and not cat_cfg.extract:
                return {}
        # отправитель — в граф (люди из деловой переписки)
        if email.sender_name or email.sender_email:
            sid = self.kg.upsert_entity(
                email.sender_name or email.sender_email, "person", email.sender_email)
            self.repos.entities.add_mention(sid, email.message_id, "sender")
        if extraction is not None:
            name_to_id: dict[str, int] = {}
            type_by_name: dict[str, str] = {}
            for ent in extraction.entities:
                eid = self.kg.upsert_entity(ent.name, ent.type)
                name_to_id[ent.name] = eid
                type_by_name[self.repos.entities.normalize(ent.name)] = ent.type
                self.repos.entities.add_mention(eid, email.message_id, "mentioned")
            for ent in extraction.entities:
                src = name_to_id[ent.name]
                for rel in ent.relations:
                    dst = name_to_id.get(rel.target_name)
                    if dst is None:
                        dst = self.kg.upsert_entity(rel.target_name, "topic")
                        name_to_id[rel.target_name] = dst
                    self.kg.upsert_edge(src, dst, rel.relation, email.message_id)

            # Zettelkasten: атомарные заметки; [[wiki-ссылки]] из текста → связи с хабами
            for note in extraction.notes:
                self.kg.add_note(
                    title=note.title, body=note.body, kind=note.kind,
                    source_message_id=email.message_id,
                    conversation_id=email.conversation_id,
                    known_types=type_by_name)
        self.repos.log.log(email.message_id, "kg", "ok")
        return {}

    def index_vector(self, state: IngestState) -> IngestState:
        if self.vectors is None:
            return {}
        email = state["email"]
        try:
            n = self.vectors.index_email(email)
            email_meta = {"sender_email": email.sender_email,
                          "received_at": email.received_at, "folder": email.folder}
            for a in self.repos.attachments.parsed_for_email(email.message_id):
                n += self.vectors.index_attachment(
                    email.message_id, a["filename"], a["text"], email_meta)
            # заметки: эмбеддинг + смысловые связи с ближайшими заметками
            for note in self.repos.notes.for_email(email.message_id):
                self.vectors.index_note(note["id"], note["title"], note["body"])
                for other_id, score in self.vectors.similar_notes(note["id"]):
                    self.repos.notes.add_relation(note["id"], other_id, score)
                    self.kg.link_notes(note["id"], other_id, score)
            self.repos.emails.mark_indexed(email.message_id)
            self.repos.log.log(email.message_id, "index", "ok", f"{n} чанков")
        except Exception as e:  # noqa: BLE001 — индексация некритична для сортировки
            logger.warning("Индексация %s не удалась: %s", email.message_id, e)
            self.repos.log.log(email.message_id, "index", "error", str(e))
        return {}
