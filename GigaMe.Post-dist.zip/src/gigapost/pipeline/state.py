"""Состояние ingestion-графа (одно письмо на прогон)."""

from __future__ import annotations

from typing import TypedDict

from gigapost.llm.schemas import EmailClassification, ExtractionResult
from gigapost.outlook.models import EmailMessage


class IngestState(TypedDict, total=False):
    email: EmailMessage
    classification: EmailClassification | None
    hard_rule_category: str | None      # категория из hard_rules (LLM не нужен)
    extraction: ExtractionResult | None
    needs_review: bool               # классификация неуверенная — действия в Outlook не выполняются
    actions_applied: list[str]
    errors: list[str]
