"""Сверка комплектов закупочных документов по треду переписки.

Двухступенчато (под лимит корп-API ~4096 токенов):
1) по каждому вложению — маленький вызов LLM «извлеки реквизиты» (кэшируется
   в doc_facts, повторная сверка не жжёт лимиты);
2) один вызов «найди расхождения» по собранным реквизитам.
"""

from __future__ import annotations

import json
import logging
from datetime import datetime

from gigapost.config import load_prompt
from gigapost.llm.schemas import DocCheckResult, DocFacts
from gigapost.llm.structured import structured_call

logger = logging.getLogger(__name__)

MAX_DOC_CHARS = 3500   # текста документа в промпт извлечения
MAX_DOCS = 20          # документов в одну сверку


def _facts_for_attachment(repos, att: dict, llm) -> dict | None:
    """Реквизиты вложения: из кэша doc_facts или одним LLM-вызовом."""
    row = repos.db.query_one(
        "SELECT * FROM doc_facts WHERE attachment_id=?", (att["id"],))
    if row:
        return dict(row)
    text = (att.get("text") or "")[:MAX_DOC_CHARS]
    if not text.strip():
        return None
    prompt = load_prompt("docfacts").format(filename=att["filename"], text=text)
    facts = structured_call(llm, DocFacts, prompt)
    repos.db.execute(
        """INSERT OR REPLACE INTO doc_facts
             (attachment_id, doc_type, number, doc_date, amount, counterparty,
              tech, notes, extracted_at)
           VALUES (?,?,?,?,?,?,?,?,?)""",
        (att["id"], facts.doc_type, facts.number, facts.doc_date, facts.amount,
         facts.counterparty, facts.tech, facts.notes, datetime.now().isoformat()))
    return dict(repos.db.query_one(
        "SELECT * FROM doc_facts WHERE attachment_id=?", (att["id"],)))


def check_conversation(repos, conversation_id: str) -> str:
    """Сверить комплект документов треда; вернуть отчёт (markdown).

    Отчёт также сохраняется в doc_checks."""
    from gigapost.llm.factory import get_llm

    emails = [dict(r) for r in repos.db.query(
        "SELECT message_id, subject FROM emails WHERE conversation_id=? "
        "ORDER BY received_at", (conversation_id,))]
    if not emails:
        return "В треде нет писем."
    ids = [e["message_id"] for e in emails]
    ph = ",".join("?" * len(ids))
    atts = [dict(r) for r in repos.db.query(
        f"""SELECT a.* FROM attachments a
            WHERE a.message_id IN ({ph}) AND a.status='parsed'
            ORDER BY a.id""", tuple(ids))][:MAX_DOCS]
    if not atts:
        return ("В этом треде нет разобранных документов — сверять нечего. "
                "(Поддерживаются docx/xlsx/pptx/pdf/txt/csv.)")

    llm = get_llm("extract")
    doc_lines = []
    facts_for_llm = []
    for att in atts:
        try:
            f = _facts_for_attachment(repos, att, llm)
        except Exception as e:  # noqa: BLE001 — 429 и т.п.: отчёт по тому, что успели
            logger.warning("doc_facts %s: %s", att["filename"], e)
            doc_lines.append(f"- {att['filename']} — не удалось извлечь реквизиты")
            continue
        if f is None:
            continue
        facts_for_llm.append({k: f.get(k) or "" for k in
                              ("doc_type", "number", "doc_date", "amount",
                               "counterparty", "tech", "notes")}
                             | {"файл": att["filename"]})
        line = (f"- **{att['filename']}** — {f.get('doc_type') or '?'}"
                f"{' №' + f['number'] if f.get('number') else ''}"
                f"{' от ' + f['doc_date'] if f.get('doc_date') else ''}"
                f"{', ' + f['amount'] + ' руб.' if f.get('amount') else ''}"
                f"{', ' + f['counterparty'] if f.get('counterparty') else ''}")
        doc_lines.append(line)

    report = "### Документы комплекта\n" + "\n".join(doc_lines) + "\n"
    if len(facts_for_llm) >= 2:
        subjects = "; ".join(dict.fromkeys(
            (e["subject"] or "")[:60] for e in emails if e["subject"]))
        prompt = load_prompt("doccheck").format(
            subjects=subjects,
            facts=json.dumps(facts_for_llm, ensure_ascii=False))
        try:
            result = structured_call(get_llm("chat"), DocCheckResult, prompt)
            report += f"\n### Итог сверки\n{result.summary}\n"
            if result.discrepancies:
                report += "\n### Расхождения\n"
                icon = {"критично": "🔴", "внимание": "🟡", "заметка": "⚪"}
                for d in result.discrepancies:
                    report += f"- {icon.get(d.severity, '•')} **{d.severity}**: {d.description}\n"
            else:
                report += "\nРасхождений не найдено.\n"
        except Exception as e:  # noqa: BLE001
            logger.warning("doccheck %s: %s", conversation_id, e)
            report += ("\n_Сравнение не выполнено (лимиты API?) — реквизиты "
                       "извлечены и закэшированы, повторите сверку позже._\n")
    else:
        report += "\n_Меньше двух документов с реквизитами — сравнивать нечего._\n"

    repos.db.execute(
        "INSERT INTO doc_checks (conversation_id, report, created_at) VALUES (?,?,?)",
        (conversation_id, report, datetime.now().isoformat()))
    return report


def backfill_doc_facts(repos, limit: int = 15) -> int:
    """Фоновое пополнение реестра: реквизиты для вложений без doc_facts.

    Бюджетно (limit за прогон), свежие первыми; вызывается планировщиком."""
    from gigapost.llm.factory import get_llm

    rows = [dict(r) for r in repos.db.query(
        """SELECT a.* FROM attachments a
           LEFT JOIN doc_facts f ON f.attachment_id = a.id
           JOIN emails e ON e.message_id = a.message_id
           WHERE a.status='parsed' AND f.attachment_id IS NULL
           ORDER BY e.received_at DESC LIMIT ?""", (limit,))]
    if not rows:
        return 0
    llm = get_llm("extract")
    done = 0
    for att in rows:
        try:
            if _facts_for_attachment(repos, att, llm) is not None:
                done += 1
        except Exception as e:  # noqa: BLE001 — лимиты: продолжим в следующий заход
            logger.warning("Реестр, %s: %s", att["filename"], e)
            break
    if done:
        logger.info("Реестр документов: +%d", done)
    return done


def registry_rows(repos, q: str = "", doc_type: str = "", limit: int = 300) -> list[dict]:
    """Строки реестра документов с фильтрами."""
    where, params = [], []
    if doc_type:
        where.append("f.doc_type = ?")
        params.append(doc_type)
    if q:
        like = f"%{q}%"
        where.append("(f.number LIKE ? OR f.counterparty LIKE ? OR f.tech LIKE ? "
                     "OR a.filename LIKE ? OR e.subject LIKE ?)")
        params += [like] * 5
    where_sql = ("WHERE " + " AND ".join(where)) if where else ""
    rows = repos.db.query(
        f"""SELECT f.*, a.filename, a.id AS attachment_id, a.message_id,
                   e.subject, e.sender_name, e.received_at, e.conversation_id
            FROM doc_facts f
            JOIN attachments a ON a.id = f.attachment_id
            JOIN emails e ON e.message_id = a.message_id
            {where_sql}
            ORDER BY COALESCE(NULLIF(f.doc_date, ''), e.received_at) DESC
            LIMIT ?""", (*params, limit))
    return [dict(r) for r in rows]


def last_check(repos, conversation_id: str) -> dict | None:
    row = repos.db.query_one(
        "SELECT * FROM doc_checks WHERE conversation_id=? ORDER BY id DESC LIMIT 1",
        (conversation_id,))
    return dict(row) if row else None
