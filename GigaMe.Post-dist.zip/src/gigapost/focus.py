"""«Фокус дня» и SLA-мониторинг ответов — детерминированный скоринг, без LLM.

Какие входящие требуют вашей реакции: вопрос адресован вам, отправитель VIP,
в тексте дедлайн, ответа нет уже N дней. Топ — на дашборд; долгие молчания —
в алерты (sla_unanswered).
"""

from __future__ import annotations

import json
import re
from datetime import datetime, timedelta

from gigapost.config import settings

_DEADLINE_RE = re.compile(
    r"до \d{1,2}[.\s]|срок|дедлайн|deadline|к \d{1,2}\.\d{1,2}|не поздн|сегодня|"
    r"завтра|asap|срочн", re.IGNORECASE)
_QUESTION_RE = re.compile(r"\?|прош[уи]\b|просьба|направьте|пришлите|подтвердите|"
                          r"согласуйте|уточните", re.IGNORECASE)
_SKIP_CATEGORIES = {"Рассылки", "Спам", "Уведомления"}


def _candidates(repos, days: int = 14) -> list[dict]:
    """Входящие за N дней, на которые вы ещё не ответили в треде."""
    since = (datetime.now() - timedelta(days=days)).isoformat()
    rows = repos.db.query(
        """SELECT e.rowid AS rid, e.* FROM emails e
           WHERE e.folder != 'Sent' AND e.received_at >= ?
             AND NOT EXISTS (SELECT 1 FROM emails s
                             WHERE s.folder = 'Sent'
                               AND s.conversation_id = e.conversation_id
                               AND s.received_at > e.received_at)
           ORDER BY e.received_at DESC LIMIT 500""", (since,))
    return [dict(r) for r in rows]


def _score(e: dict, now: datetime) -> tuple[int, list[str]]:
    reasons: list[str] = []
    score = 0
    body = (e.get("body_text") or "")[:3000]
    if settings.is_vip(e.get("sender_name"), e.get("sender_email")):
        score += 3
        reasons.append("VIP")
    if _QUESTION_RE.search(body) or "?" in (e.get("subject") or ""):
        score += 2
        reasons.append("вопрос/просьба")
    if _DEADLINE_RE.search(body):
        score += 1
        reasons.append("упомянут срок")
    try:
        n_rcpt = len(json.loads(e.get("recipients_json") or "[]"))
        if n_rcpt <= 2:
            score += 1
            reasons.append("адресовано лично")
    except Exception:  # noqa: BLE001
        pass
    try:
        waited = (now - datetime.fromisoformat(e["received_at"])).days
    except (ValueError, KeyError, TypeError):
        waited = 0
    if waited >= 1:
        score += min(waited, 5)
        reasons.append(f"ждёт {waited} дн.")
    return score, reasons


def focus_emails(repos, limit: int = 5, days: int = 14) -> list[dict]:
    """Топ входящих, требующих реакции сегодня."""
    now = datetime.now()
    scored = []
    from gigapost.meetings import is_meeting_email
    for e in _candidates(repos, days):
        if (e.get("category") or "") in _SKIP_CATEGORIES:
            continue
        if is_meeting_email(e.get("subject"), e.get("body_text")):
            continue   # приглашения не требуют «ответа» в смысле фокуса
        score, reasons = _score(e, now)
        if score >= 3:   # ниже — не «фокус», а просто почта
            e["_score"], e["_reasons"] = score, reasons
            scored.append(e)
    scored.sort(key=lambda x: (x["_score"], x.get("received_at") or ""), reverse=True)
    return scored[:limit]


def sla_check(repos, now: datetime | None = None) -> dict:
    """Алерты «вопрос без ответа N+ дней» (дедуп через alerts UNIQUE)."""
    now = now or datetime.now()
    sla_days = settings.control.sla_answer_days
    created = 0
    from gigapost.meetings import is_meeting_email
    for e in _candidates(repos, days=30):
        if (e.get("category") or "") in _SKIP_CATEGORIES:
            continue
        if is_meeting_email(e.get("subject"), e.get("body_text")):
            continue
        body = (e.get("body_text") or "")[:3000]
        if not (_QUESTION_RE.search(body) or "?" in (e.get("subject") or "")):
            continue
        try:
            waited = (now - datetime.fromisoformat(e["received_at"])).days
        except (ValueError, TypeError):
            continue
        if waited < sla_days:
            continue
        if repos.alerts.create(
                "sla_unanswered", "emails", e["rid"],
                f"Без ответа {waited} дн.: «{(e.get('subject') or '(без темы)')[:60]}» "
                f"от {e.get('sender_name') or e.get('sender_email') or '—'}"):
            created += 1
    return {"sla_unanswered": created}
