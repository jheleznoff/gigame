"""Извлечение текста из вложений распространённых офисных форматов.

Поддержка: .docx, .xlsx, .pptx, .pdf (текстовый слой), .txt, .csv, .md.
Старые бинарные форматы (.doc/.xls/.ppt) и сканы без текстового слоя не разбираются —
для них возвращается None (файл виден в списке, но текст недоступен).
"""

from __future__ import annotations

import csv
import logging
from pathlib import Path

logger = logging.getLogger(__name__)

SUPPORTED_EXTENSIONS = {".docx", ".xlsx", ".pptx", ".pdf", ".txt", ".csv", ".md"}
MAX_ATTACHMENT_MB = 15
MAX_TEXT_CHARS = 40_000       # жёсткий предохранитель на извлечённый текст
MAX_XLSX_ROWS = 300           # строк на лист
MAX_PDF_PAGES = 40


def is_supported(filename: str) -> bool:
    return Path(filename).suffix.lower() in SUPPORTED_EXTENSIONS


def _extract_docx(path: Path) -> str:
    import docx

    doc = docx.Document(str(path))
    parts = [p.text for p in doc.paragraphs if p.text.strip()]
    for table in doc.tables:
        for row in table.rows:
            cells = [c.text.strip() for c in row.cells]
            if any(cells):
                parts.append(" | ".join(cells))
    return "\n".join(parts)


def _extract_xlsx(path: Path) -> str:
    import openpyxl

    wb = openpyxl.load_workbook(str(path), read_only=True, data_only=True)
    parts = []
    try:
        for ws in wb.worksheets:
            parts.append(f"=== Лист: {ws.title} ===")
            for i, row in enumerate(ws.iter_rows(values_only=True)):
                if i >= MAX_XLSX_ROWS:
                    parts.append(f"… (обрезано, показано {MAX_XLSX_ROWS} строк)")
                    break
                cells = ["" if v is None else str(v) for v in row]
                if any(c.strip() for c in cells):
                    parts.append(" | ".join(cells).rstrip(" |"))
    finally:
        wb.close()
    return "\n".join(parts)


def _extract_pptx(path: Path) -> str:
    from pptx import Presentation

    prs = Presentation(str(path))
    parts = []
    for i, slide in enumerate(prs.slides, 1):
        texts = []
        for shape in slide.shapes:
            if shape.has_text_frame:
                t = shape.text_frame.text.strip()
                if t:
                    texts.append(t)
        if texts:
            parts.append(f"=== Слайд {i} ===\n" + "\n".join(texts))
    return "\n\n".join(parts)


def _extract_pdf(path: Path) -> str:
    from pypdf import PdfReader

    reader = PdfReader(str(path))
    parts = []
    for i, page in enumerate(reader.pages):
        if i >= MAX_PDF_PAGES:
            parts.append(f"… (обрезано, показано {MAX_PDF_PAGES} страниц)")
            break
        text = (page.extract_text() or "").strip()
        if text:
            parts.append(text)
    return "\n\n".join(parts)


def _extract_plain(path: Path) -> str:
    raw = path.read_bytes()
    for enc in ("utf-8", "cp1251"):
        try:
            return raw.decode(enc)
        except UnicodeDecodeError:
            continue
    return raw.decode("utf-8", errors="replace")


def _extract_csv(path: Path) -> str:
    text = _extract_plain(path)
    try:
        dialect = csv.Sniffer().sniff(text[:2000])
        rows = list(csv.reader(text.splitlines()[:MAX_XLSX_ROWS], dialect))
        return "\n".join(" | ".join(r) for r in rows)
    except Exception:  # noqa: BLE001 — отдаём как есть
        return text


_EXTRACTORS = {
    ".docx": _extract_docx, ".xlsx": _extract_xlsx, ".pptx": _extract_pptx,
    ".pdf": _extract_pdf, ".txt": _extract_plain, ".md": _extract_plain,
    ".csv": _extract_csv,
}


def extract_text(path: str | Path) -> str | None:
    """Текст вложения или None, если формат не поддержан / не разобрался."""
    path = Path(path)
    ext = path.suffix.lower()
    extractor = _EXTRACTORS.get(ext)
    if extractor is None or not path.exists():
        return None
    if path.stat().st_size > MAX_ATTACHMENT_MB * 1024 * 1024:
        logger.warning("Вложение %s больше %d МБ — пропускаю", path.name, MAX_ATTACHMENT_MB)
        return None
    try:
        text = (extractor(path) or "").strip()
        if not text:
            return None
        return text[:MAX_TEXT_CHARS]
    except Exception as e:  # noqa: BLE001 — битые файлы не валят пайплайн
        logger.warning("Не удалось разобрать вложение %s: %s", path.name, e)
        return None
