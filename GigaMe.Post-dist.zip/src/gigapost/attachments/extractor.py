"""Извлечение текста из вложений распространённых офисных форматов.

Поддержка: .docx, .xlsx, .pptx, .pdf (текстовый слой), .txt, .csv, .md,
.rtf, .xls (старый Excel), .html/.htm, .zip (поддержанные файлы внутри).
Не разбираются: старые .doc/.ppt и сканы без текстового слоя (нужен OCR) —
для них возвращается None (файл виден в списке, но текст недоступен).
"""

from __future__ import annotations

import csv
import logging
from pathlib import Path

logger = logging.getLogger(__name__)

SUPPORTED_EXTENSIONS = {".docx", ".xlsx", ".pptx", ".pdf", ".txt", ".csv", ".md",
                        ".rtf", ".xls", ".html", ".htm", ".zip"}
# сканы — только при включённом OCR через vision GigaChat (ocr.enabled)
SCAN_EXTENSIONS = {".jpg", ".jpeg", ".png", ".bmp", ".tiff", ".tif"}
MAX_ATTACHMENT_MB = 15
MAX_TEXT_CHARS = 40_000       # жёсткий предохранитель на извлечённый текст
MAX_XLSX_ROWS = 300           # строк на лист
MAX_PDF_PAGES = 40


def is_supported(filename: str) -> bool:
    if Path(filename).name.startswith("._"):
        return False   # служебные AppleDouble-файлы macOS — мусор
    ext = Path(filename).suffix.lower()
    if ext in SCAN_EXTENSIONS:
        from gigapost.config import settings
        return settings.ocr.enabled
    return ext in SUPPORTED_EXTENSIONS


def _extract_docx(path: Path) -> str:
    import docx

    doc = docx.Document(str(path))
    parts = [p.text for p in doc.paragraphs if p.text.strip()]
    for table in doc.tables:
        for row in table.rows:
            cells = [c.text.strip() for c in row.cells]
            if any(cells):
                parts.append(" | ".join(cells))
    return "\n".join(parts)


def _extract_xlsx(path: Path) -> str:
    import openpyxl

    wb = openpyxl.load_workbook(str(path), read_only=True, data_only=True)
    parts = []
    try:
        for ws in wb.worksheets:
            parts.append(f"=== Лист: {ws.title} ===")
            for i, row in enumerate(ws.iter_rows(values_only=True)):
                if i >= MAX_XLSX_ROWS:
                    parts.append(f"… (обрезано, показано {MAX_XLSX_ROWS} строк)")
                    break
                cells = ["" if v is None else str(v) for v in row]
                if any(c.strip() for c in cells):
                    parts.append(" | ".join(cells).rstrip(" |"))
    finally:
        wb.close()
    return "\n".join(parts)


def _extract_pptx(path: Path) -> str:
    from pptx import Presentation

    prs = Presentation(str(path))
    parts = []
    for i, slide in enumerate(prs.slides, 1):
        texts = []
        for shape in slide.shapes:
            if shape.has_text_frame:
                t = shape.text_frame.text.strip()
                if t:
                    texts.append(t)
        if texts:
            parts.append(f"=== Слайд {i} ===\n" + "\n".join(texts))
    return "\n\n".join(parts)


def _extract_pdf(path: Path) -> str:
    from pypdf import PdfReader

    reader = PdfReader(str(path))
    parts = []
    for i, page in enumerate(reader.pages):
        if i >= MAX_PDF_PAGES:
            parts.append(f"… (обрезано, показано {MAX_PDF_PAGES} страниц)")
            break
        text = (page.extract_text() or "").strip()
        if text:
            parts.append(text)
    return "\n\n".join(parts)


def _extract_plain(path: Path) -> str:
    raw = path.read_bytes()
    for enc in ("utf-8", "cp1251"):
        try:
            return raw.decode(enc)
        except UnicodeDecodeError:
            continue
    return raw.decode("utf-8", errors="replace")


def _extract_csv(path: Path) -> str:
    text = _extract_plain(path)
    try:
        dialect = csv.Sniffer().sniff(text[:2000])
        rows = list(csv.reader(text.splitlines()[:MAX_XLSX_ROWS], dialect))
        return "\n".join(" | ".join(r) for r in rows)
    except Exception:  # noqa: BLE001 — отдаём как есть
        return text


def _extract_rtf(path: Path) -> str:
    from striprtf.striprtf import rtf_to_text

    return rtf_to_text(_extract_plain(path), errors="ignore")


def _extract_xls(path: Path) -> str:
    import xlrd

    wb = xlrd.open_workbook(str(path))
    parts = []
    for ws in wb.sheets():
        parts.append(f"=== Лист: {ws.name} ===")
        for i in range(min(ws.nrows, MAX_XLSX_ROWS)):
            cells = [str(c.value) if c.value not in ("", None) else ""
                     for c in ws.row(i)]
            if any(c.strip() for c in cells):
                parts.append(" | ".join(cells).rstrip(" |"))
        if ws.nrows > MAX_XLSX_ROWS:
            parts.append(f"… (обрезано, показано {MAX_XLSX_ROWS} строк)")
    return "\n".join(parts)


def _extract_html(path: Path) -> str:
    from bs4 import BeautifulSoup

    return BeautifulSoup(_extract_plain(path), "html.parser").get_text(separator="\n")


def _extract_zip(path: Path) -> str:
    """Тексты поддержанных файлов внутри архива (без вложенных архивов)."""
    import tempfile
    import zipfile

    parts = []
    with zipfile.ZipFile(path) as zf:
        for info in zf.infolist()[:30]:
            name = info.filename
            ext = Path(name).suffix.lower()
            if (info.is_dir() or ext == ".zip" or ext not in SUPPORTED_EXTENSIONS
                    or Path(name).name.startswith("._")
                    or info.file_size > MAX_ATTACHMENT_MB * 1024 * 1024):
                continue
            try:
                with tempfile.TemporaryDirectory() as tmp:
                    # плоское имя: защита от zip-slip (../) в путях архива
                    target = Path(tmp) / Path(name).name
                    target.write_bytes(zf.read(info))
                    inner = extract_text(target)
                if inner:
                    parts.append(f"=== Файл в архиве: {name} ===\n{inner[:8000]}")
            except Exception as e:  # noqa: BLE001 — один битый файл не мешает
                logger.debug("zip %s / %s: %s", path.name, name, e)
            if sum(len(p) for p in parts) > MAX_TEXT_CHARS:
                break
    return "\n\n".join(parts)


_EXTRACTORS = {
    ".docx": _extract_docx, ".xlsx": _extract_xlsx, ".pptx": _extract_pptx,
    ".pdf": _extract_pdf, ".txt": _extract_plain, ".md": _extract_plain,
    ".csv": _extract_csv, ".rtf": _extract_rtf, ".xls": _extract_xls,
    ".html": _extract_html, ".htm": _extract_html, ".zip": _extract_zip,
}


def extract_text(path: str | Path, allow_ocr: bool = False) -> str | None:
    """Текст вложения или None, если формат не поддержан / не разобрался.

    allow_ocr=True — сканы (картинки, PDF без текстового слоя) распознаются
    через vision GigaChat (если включено в ocr.enabled). По умолчанию False,
    чтобы массовая заливка истории не жгла токены; для истории —
    scripts/reparse_attachments.py --ocr порциями."""
    path = Path(path)
    ext = path.suffix.lower()
    if not path.exists():
        return None
    if path.stat().st_size > MAX_ATTACHMENT_MB * 1024 * 1024:
        logger.warning("Вложение %s больше %d МБ — пропускаю", path.name, MAX_ATTACHMENT_MB)
        return None

    if ext in SCAN_EXTENSIONS:
        if not allow_ocr:
            return None
        from gigapost.attachments.ocr import ocr_image
        return (ocr_image(path) or "")[:MAX_TEXT_CHARS] or None

    extractor = _EXTRACTORS.get(ext)
    if extractor is None:
        return None
    try:
        text = (extractor(path) or "").strip()
    except Exception as e:  # noqa: BLE001 — битые файлы не валят пайплайн
        logger.warning("Не удалось разобрать вложение %s: %s", path.name, e)
        return None

    # PDF почти без текста = скан → пробуем vision-распознавание страниц
    if ext == ".pdf" and allow_ocr:
        from gigapost.config import settings
        if len(text) < settings.ocr.min_pdf_chars and settings.ocr.enabled:
            from gigapost.attachments.ocr import ocr_pdf
            ocr_text = ocr_pdf(path)
            if ocr_text:
                text = ocr_text

    if not text.strip():
        return None
    return text[:MAX_TEXT_CHARS]
