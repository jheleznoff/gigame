"""Распознавание сканов через vision-модели GigaChat (как файлы в GigaMe).

Картинка (или страница PDF-скана, отрендеренная в PNG) загружается в файловое
хранилище GigaChat (upload_file) и прикладывается к запросу — модель
переписывает текст. Не нужен Tesseract и вообще ничего локального: используется
тот же API и та же авторизация (ключ или корп-сертификаты), что и для писем.

Включение: config/settings.yaml → ocr.enabled: true.
"""

from __future__ import annotations

import logging
from pathlib import Path

from gigapost.config import settings

logger = logging.getLogger(__name__)

_client = None

OCR_PROMPT = (
    "Перепиши весь текст с изображения документа дословно, сохраняя структуру "
    "(заголовки, таблицы строками «ячейка | ячейка»). Числа, номера документов, "
    "даты и суммы переноси особенно внимательно. Если текст не читается — "
    "напиши [неразборчиво]. Никаких комментариев от себя."
)

_MIME = {".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".png": "image/png",
         ".bmp": "image/bmp", ".tiff": "image/tiff", ".tif": "image/tiff"}


def _get_client():
    global _client
    if _client is None:
        from gigachat import GigaChat

        kwargs = settings.gigachat_auth_kwargs()
        model = settings.ocr.model or settings.resolve_model("chat")
        _client = GigaChat(model=model, **kwargs)
    return _client


def _vision_call(data: bytes, filename: str, mime: str) -> str | None:
    """Один vision-вызов: загрузить картинку и попросить переписать текст."""
    from gigachat.models import Chat, Messages, MessagesRole

    from gigapost.llm.throttle import GATE, LEDGER, PRIORITY_EMBED

    client = _get_client()
    GATE.acquire(PRIORITY_EMBED)   # фоновая работа — уступаем чату/пайплайну
    try:
        uploaded = client.upload_file((filename, data, mime))
        resp = client.chat(Chat(messages=[Messages(
            role=MessagesRole.USER, content=OCR_PROMPT,
            attachments=[uploaded.id_])]))
    finally:
        GATE.release()
    try:
        usage = resp.usage
        LEDGER.record("ocr", int(usage.prompt_tokens or 0),
                      int(usage.completion_tokens or 0))
    except Exception:  # noqa: BLE001
        pass
    text = (resp.choices[0].message.content or "").strip()
    return text or None


def ocr_image(path: Path) -> str | None:
    """Распознать картинку-скан. None — OCR выключен или не удалось."""
    if not settings.ocr.enabled:
        return None
    mime = _MIME.get(path.suffix.lower())
    if mime is None:
        return None
    try:
        return _vision_call(path.read_bytes(), path.name, mime)
    except Exception as e:  # noqa: BLE001 — лимиты/недоступный vision
        logger.warning("OCR %s: %s", path.name, e)
        return None


def ocr_pdf(path: Path) -> str | None:
    """Распознать PDF-скан: страницы рендерятся в PNG и уходят в vision."""
    if not settings.ocr.enabled:
        return None
    try:
        import fitz  # PyMuPDF
    except ImportError:
        logger.warning("PyMuPDF не установлен — PDF-сканы не распознаются")
        return None
    parts = []
    try:
        with fitz.open(str(path)) as doc:
            for i, page in enumerate(doc):
                if i >= settings.ocr.max_pages:
                    parts.append(f"… (распознано {settings.ocr.max_pages} страниц)")
                    break
                png = page.get_pixmap(dpi=150).tobytes("png")
                text = _vision_call(png, f"{path.stem}_p{i + 1}.png", "image/png")
                if text:
                    parts.append(f"=== Страница {i + 1} ===\n{text}")
    except Exception as e:  # noqa: BLE001
        logger.warning("OCR PDF %s: %s", path.name, e)
        return None
    return "\n\n".join(parts) or None
