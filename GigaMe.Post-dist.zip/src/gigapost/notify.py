"""Уведомления вне UI: Telegram (если задан токен) — просрочки, VIP, фишинг.

Настройка в .env:
  TELEGRAM_BOT_TOKEN=<токен от @BotFather>
  TELEGRAM_CHAT_ID=<ваш chat id (узнать: напишите боту, затем
                    https://api.telegram.org/bot<токен>/getUpdates)>
Без токена модуль молчит.
"""

from __future__ import annotations

import logging
import os

import requests

logger = logging.getLogger(__name__)


def _config() -> tuple[str, str] | None:
    token = os.environ.get("TELEGRAM_BOT_TOKEN", "")
    chat_id = os.environ.get("TELEGRAM_CHAT_ID", "")
    if token and chat_id:
        return token, chat_id
    return None


def enabled() -> bool:
    return _config() is not None


def send(text: str) -> bool:
    cfg = _config()
    if cfg is None:
        return False
    token, chat_id = cfg
    try:
        resp = requests.post(
            f"https://api.telegram.org/bot{token}/sendMessage",
            json={"chat_id": chat_id, "text": text[:4000]}, timeout=15)
        return resp.ok
    except Exception as e:  # noqa: BLE001
        logger.warning("Telegram-уведомление не ушло: %s", e)
        return False


def notify_alert(kind: str, message: str) -> None:
    icons = {"overdue": "🔴", "deadline_soon": "🟡", "followup_needed": "📮",
             "task_maybe_done": "✅", "vip_email": "⭐", "phishing": "⚠️"}
    send(f"{icons.get(kind, '🔔')} {message}")
