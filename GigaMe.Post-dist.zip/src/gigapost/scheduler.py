"""APScheduler-джобы: опрос почты, контроль договорённостей, снапшот графа."""

from __future__ import annotations

import logging

from apscheduler.schedulers.background import BackgroundScheduler

from gigapost.config import settings
from gigapost.control.monitor import ControlMonitor
from gigapost.knowledge.graph_store import KnowledgeGraph
from gigapost.pipeline.graph import IngestRunner

logger = logging.getLogger(__name__)


def build_scheduler(runner: IngestRunner, monitor: ControlMonitor,
                    kg: KnowledgeGraph, sent_processor=None) -> BackgroundScheduler:
    scheduler = BackgroundScheduler()
    if sent_processor is not None:
        scheduler.add_job(
            sent_processor.run_cycle, "interval", minutes=10,
            id="poll_sent", max_instances=1, coalesce=True, misfire_grace_time=120,
        )
    scheduler.add_job(
        runner.run_cycle, "interval",
        minutes=settings.polling.interval_minutes,
        id="poll_mailbox", max_instances=1, coalesce=True, misfire_grace_time=60,
    )
    scheduler.add_job(
        monitor.run, "interval",
        minutes=settings.control.check_interval_minutes,
        id="control_check", max_instances=1, coalesce=True, misfire_grace_time=300,
    )
    scheduler.add_job(
        kg.save_graphml, "interval", hours=1,
        id="graph_snapshot", max_instances=1, coalesce=True,
    )
    scheduler.add_job(
        runner.reindex_pending, "interval", minutes=20,
        id="reindex_pending", max_instances=1, coalesce=True,
    )

    def _doc_facts_backfill():
        from gigapost.docs.reconcile import backfill_doc_facts
        backfill_doc_facts(runner.repos, limit=15)

    scheduler.add_job(
        _doc_facts_backfill, "interval", minutes=30,
        id="doc_facts_backfill", max_instances=1, coalesce=True,
    )

    def _dossier_refresh():
        from gigapost.dossier import refresh_stale
        refresh_stale(runner.repos, limit=2)

    scheduler.add_job(
        _dossier_refresh, "interval", hours=1,
        id="dossier_refresh", max_instances=1, coalesce=True,
    )

    def _conflict_scan():
        from gigapost.conflicts import scan
        scan(runner.repos, limit=3)

    scheduler.add_job(
        _conflict_scan, "interval", hours=2,
        id="conflict_scan", max_instances=1, coalesce=True,
    )

    def _daily_digest():
        from gigapost.digest import build_digest
        build_digest(runner.repos)

    scheduler.add_job(
        _daily_digest, "cron", hour=8, minute=0,
        id="morning_digest", max_instances=1, coalesce=True, misfire_grace_time=3600,
    )

    def _weekly_report():
        from gigapost.digest import build_weekly
        build_weekly(runner.repos)

    scheduler.add_job(
        _weekly_report, "cron", day_of_week="mon", hour=9, minute=0,
        id="weekly_report", max_instances=1, coalesce=True, misfire_grace_time=7200,
    )
    return scheduler
