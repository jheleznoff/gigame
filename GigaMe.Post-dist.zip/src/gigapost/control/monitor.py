"""ControlMonitor — детерминированный контроль договорённостей (без LLM).

1) due_date прошёл → статус overdue + алерт;
2) до дедлайна < N часов → алерт deadline_soon;
3) договорённость they_owe без активности в треде дольше followup_after_days →
   алерт followup_needed (+ опционально флаг Outlook на исходное письмо).
"""

from __future__ import annotations

import logging
from datetime import datetime, timedelta

from gigapost.config import settings
from gigapost.db.repositories import Repos
from gigapost.outlook.client import OutlookClient

logger = logging.getLogger(__name__)


class ControlMonitor:
    def __init__(self, repos: Repos, outlook: OutlookClient | None = None):
        self.repos = repos
        self.outlook = outlook

    def run(self, now: datetime | None = None) -> dict:
        now = now or datetime.now()
        now_iso = now.isoformat(timespec="seconds")
        stats = {"overdue": 0, "deadline_soon": 0, "followup_needed": 0}

        for a in self.repos.agreements.overdue_candidates(now_iso):
            self.repos.agreements.set_status(a["id"], "overdue")
            created = self.repos.alerts.create(
                "overdue", "agreements", a["id"],
                f"Просрочено: {a['description']} (срок {a['due_date'][:10]}, "
                f"контрагент: {a['counterparty'] or '—'})")
            if created:
                stats["overdue"] += 1

        horizon = (now + timedelta(hours=settings.control.deadline_soon_hours)).isoformat(
            timespec="seconds")
        for a in self.repos.agreements.deadline_soon(now_iso, horizon):
            created = self.repos.alerts.create(
                "deadline_soon", "agreements", a["id"],
                f"Скоро срок: {a['description']} (до {a['due_date'][:10]})")
            if created:
                stats["deadline_soon"] += 1

        for a in self.repos.agreements.followup_candidates(now):
            days = a.get("followup_after_days") or 3
            created = self.repos.alerts.create(
                "followup_needed", "agreements", a["id"],
                f"Нет ответа {days}+ дней: {a['description']} "
                f"(контрагент: {a['counterparty'] or '—'}) — пора напомнить")
            if created:
                stats["followup_needed"] += 1
                if (settings.control.set_outlook_flag_on_followup
                        and self.outlook is not None and a.get("source_message_id")):
                    email = self.repos.emails.get(a["source_message_id"])
                    if email and email.get("entry_id"):
                        try:
                            self.outlook.set_flag(email["entry_id"])
                        except Exception as e:  # noqa: BLE001
                            logger.warning("Не удалось поставить флаг: %s", e)

        # SLA: входящие с вопросом ко мне без моего ответа N+ дней
        try:
            from gigapost.focus import sla_check
            stats.update(sla_check(self.repos, now))
        except Exception as e:  # noqa: BLE001
            logger.warning("SLA-проверка: %s", e)

        # файловый шлюз молчит сутки в рабочий день → алерт
        try:
            from gigapost.health import check_gateway_stalled
            stats["gateway_stalled"] = check_gateway_stalled(self.repos, now)
        except Exception as e:  # noqa: BLE001
            logger.warning("Проверка шлюза: %s", e)

        if any(stats.values()):
            logger.info("Контроль: %s", stats)
        return stats
