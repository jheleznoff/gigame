"""Живые досье сущностей: краткая сводка, автообновляемая при новых упоминаниях.

«Поставщик X: открыты 2 обязательства, последний контакт 12.07, ждём
спецификацию». Пересчёт — по расписанию для сущностей, у которых появились
новые письма после последнего обновления досье (бюджетно), либо кнопкой.
"""

from __future__ import annotations

import logging
from datetime import datetime

from pydantic import BaseModel, Field

from gigapost.config import load_prompt
from gigapost.llm.structured import structured_call

logger = logging.getLogger(__name__)

MIN_MENTIONS = 2       # досье имеет смысл только для повторяющихся сущностей


class DossierSummary(BaseModel):
    """Сводка по сущности."""

    summary: str = Field(description="3-5 предложений: кто/что это, текущее "
                                     "состояние дел, открытые обязательства, "
                                     "чего ждём и от кого")


def _last_mention_at(repos, entity_id: int) -> str:
    row = repos.db.query_one(
        """SELECT MAX(e.received_at) m FROM entity_mentions em
           JOIN emails e ON e.message_id = em.message_id
           WHERE em.entity_id = ?""", (entity_id,))
    return (row["m"] if row else "") or ""


def get_dossier(repos, entity_id: int) -> dict | None:
    row = repos.db.query_one("SELECT * FROM dossiers WHERE entity_id=?", (entity_id,))
    return dict(row) if row else None


def stale_entities(repos, limit: int = 3) -> list[dict]:
    """Сущности, чьё досье устарело (новые упоминания) или отсутствует."""
    rows = repos.db.query(
        f"""SELECT en.id, en.name, en.type,
                   MAX(e.received_at) AS last_at, COUNT(*) AS cnt
            FROM entities en
            JOIN entity_mentions em ON em.entity_id = en.id
            JOIN emails e ON e.message_id = em.message_id
            LEFT JOIN dossiers d ON d.entity_id = en.id
            GROUP BY en.id
            HAVING cnt >= {MIN_MENTIONS}
               AND (d.entity_id IS NULL OR d.last_mention_at < MAX(e.received_at))
            ORDER BY last_at DESC LIMIT ?""", (limit,))
    return [dict(r) for r in rows]


def refresh_dossier(repos, entity_id: int) -> dict | None:
    """Пересобрать досье сущности (один LLM-вызов)."""
    from gigapost.llm.factory import get_llm

    ent = repos.entities.get(entity_id)
    if not ent:
        return None
    notes = repos.notes.for_entity(entity_id, limit=12)
    name_like = f"%{ent['name']}%"
    tasks = [dict(r) for r in repos.db.query(
        """SELECT title, status, due_date FROM tasks
           WHERE (assignee LIKE ? OR title LIKE ?) AND status IN ('open','draft')
           LIMIT 8""", (name_like, name_like))]
    agreements = [dict(r) for r in repos.db.query(
        """SELECT description, direction, status, due_date FROM agreements
           WHERE counterparty LIKE ? OR description LIKE ? LIMIT 8""",
        (name_like, name_like))]
    mentions = [dict(r) for r in repos.db.query(
        """SELECT e.received_at, e.subject, e.folder FROM entity_mentions em
           JOIN emails e ON e.message_id = em.message_id
           WHERE em.entity_id = ?
           GROUP BY e.message_id
           ORDER BY e.received_at DESC LIMIT 10""",
        (entity_id,))]

    def block(title, lines):
        return f"{title}:\n" + ("\n".join(lines) if lines else "—")

    prompt = load_prompt("dossier").format(
        name=ent["name"], type=ent["type"],
        notes=block("Заметки", [f"- {n['title']}: {n['body'][:150]}" for n in notes]),
        tasks=block("Открытые задачи", [f"- {t['title']} ({t['status']}"
                    f"{', до ' + t['due_date'][:10] if t.get('due_date') else ''})"
                    for t in tasks]),
        agreements=block("Договорённости", [f"- {a['description'][:120]} "
                         f"({a['status']})" for a in agreements]),
        mentions=block("Последние письма", [f"- [{(m['received_at'] or '')[:10]}] "
                       f"{'→' if m['folder'] == 'Sent' else '←'} "
                       f"{(m['subject'] or '')[:80]}" for m in mentions]))
    result = structured_call(get_llm("extract"), DossierSummary, prompt[:6500])
    repos.db.execute(
        """INSERT INTO dossiers (entity_id, summary, last_mention_at, updated_at)
           VALUES (?,?,?,?)
           ON CONFLICT(entity_id) DO UPDATE SET
             summary=excluded.summary, last_mention_at=excluded.last_mention_at,
             updated_at=excluded.updated_at""",
        (entity_id, result.summary, _last_mention_at(repos, entity_id),
         datetime.now().isoformat()))
    return get_dossier(repos, entity_id)


def refresh_stale(repos, limit: int = 2) -> int:
    """Джоб: обновить пару самых «горячих» устаревших досье за прогон."""
    done = 0
    for ent in stale_entities(repos, limit=limit):
        try:
            refresh_dossier(repos, ent["id"])
            done += 1
        except Exception as e:  # noqa: BLE001 — лимиты: продолжим в следующий раз
            logger.warning("Досье %s: %s", ent["name"], e)
            break
    if done:
        logger.info("Обновлено досье: %d", done)
    return done
