"""Детектор противоречий в знаниях.

Эвристический префильтр (без LLM): у одной сущности несколько заметок с
числами/датами — кандидат. LLM подтверждает: действительно ли факты
противоречат (разные суммы одного акта, разные сроки одного обязательства).
Подтверждённое → алерт knowledge_conflict в очередь решений.
Каждая группа заметок проверяется один раз (conflict_checks).
"""

from __future__ import annotations

import hashlib
import logging
import re
from datetime import datetime

from pydantic import BaseModel, Field

from gigapost.config import load_prompt
from gigapost.llm.structured import structured_call

logger = logging.getLogger(__name__)

_NUM_RE = re.compile(r"\d[\d\s]{2,}[.,]?\d*|(\d{1,2}[./]\d{1,2}[./]\d{2,4})")


class ConflictVerdict(BaseModel):
    """Есть ли реальное противоречие между заметками."""

    is_conflict: bool = False
    description: str = Field(default="", description="Какие факты противоречат "
                                                     "и в чём, одной-двумя фразами")


def _group_hash(entity_id: int, note_ids: list[int]) -> str:
    key = f"{entity_id}:{','.join(map(str, sorted(note_ids)))}"
    return hashlib.sha1(key.encode()).hexdigest()


def candidate_groups(repos, limit: int = 3) -> list[dict]:
    """Сущности с 2+ «числовыми» заметками, ещё не проверенные этим составом."""
    rows = repos.db.query(
        """SELECT en.id AS entity_id, en.name, n.id AS note_id, n.title, n.body
           FROM entities en
           JOIN note_links nl ON nl.entity_id = en.id
           JOIN notes n ON n.id = nl.note_id
           ORDER BY en.id, n.id""")
    by_entity: dict[int, dict] = {}
    for r in rows:
        d = by_entity.setdefault(r["entity_id"],
                                 {"entity_id": r["entity_id"], "name": r["name"],
                                  "notes": []})
        if _NUM_RE.search(r["body"] or ""):
            d["notes"].append({"id": r["note_id"], "title": r["title"],
                               "body": r["body"]})
    result = []
    for d in by_entity.values():
        if len(d["notes"]) < 2:
            continue
        d["notes"] = d["notes"][:8]
        h = _group_hash(d["entity_id"], [n["id"] for n in d["notes"]])
        if repos.db.query_one(
                "SELECT 1 FROM conflict_checks WHERE group_hash=?", (h,)):
            continue
        d["hash"] = h
        result.append(d)
        if len(result) >= limit:
            break
    return result


def check_group(repos, group: dict) -> bool:
    """LLM-вердикт по группе заметок; True если найдено противоречие."""
    from gigapost.llm.factory import get_llm

    notes_block = "\n".join(
        f"- ({n['id']}) {n['title']}: {n['body'][:250]}" for n in group["notes"])
    prompt = load_prompt("conflict").format(name=group["name"], notes=notes_block)
    verdict = structured_call(get_llm("extract"), ConflictVerdict, prompt)
    repos.db.execute(
        """INSERT OR REPLACE INTO conflict_checks
             (group_hash, entity_id, is_conflict, description, checked_at)
           VALUES (?,?,?,?,?)""",
        (group["hash"], group["entity_id"], int(verdict.is_conflict),
         verdict.description, datetime.now().isoformat()))
    if verdict.is_conflict:
        repos.alerts.create(
            "knowledge_conflict", "entities", group["entity_id"],
            f"Противоречие в знаниях о «{group['name']}»: {verdict.description[:180]}")
        return True
    return False


def scan(repos, limit: int = 3) -> dict:
    """Джоб: проверить несколько групп-кандидатов за прогон."""
    stats = {"checked": 0, "conflicts": 0}
    for group in candidate_groups(repos, limit=limit):
        try:
            if check_group(repos, group):
                stats["conflicts"] += 1
            stats["checked"] += 1
        except Exception as e:  # noqa: BLE001 — лимиты API
            logger.warning("Противоречия, %s: %s", group["name"], e)
            break
    if stats["checked"]:
        logger.info("Скан противоречий: %s", stats)
    return stats
