"""AppContext — контейнер всех подсистем, собирается один раз при старте процесса."""

from __future__ import annotations

from dataclasses import dataclass

from gigapost.db.database import Database
from gigapost.db.repositories import Repos
from gigapost.knowledge.graph_store import KnowledgeGraph
from gigapost.knowledge.vector_store import VectorStore
from gigapost.outlook.client import OutlookClient


@dataclass
class AppContext:
    repos: Repos
    outlook: OutlookClient
    kg: KnowledgeGraph
    vectors: VectorStore | None


_ctx: AppContext | None = None


def set_context(ctx: AppContext) -> None:
    global _ctx
    _ctx = ctx


def get_context() -> AppContext:
    if _ctx is None:
        raise RuntimeError("AppContext не инициализирован — вызовите set_context() при старте")
    return _ctx
