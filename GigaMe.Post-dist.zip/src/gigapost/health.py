"""Здоровье решения: статусы подключений для дашборда + алерт «шлюз молчит»."""

from __future__ import annotations

from datetime import datetime


def _age_hours(iso: str | None) -> float | None:
    if not iso:
        return None
    try:
        return (datetime.now() - datetime.fromisoformat(iso)).total_seconds() / 3600
    except ValueError:
        return None


def snapshot(repos, vectors) -> list[dict]:
    """Статусы для панели: [{name, ok, detail}]."""
    from gigapost.outlook.msg_import import DEFAULT_EXPORT_DIR

    items: list[dict] = []

    outlook_state = repos.settings.get("health:outlook") or "?"
    items.append({"name": "Outlook",
                  "ok": outlook_state == "ok",
                  "detail": "COM подключён" if outlook_state == "ok"
                            else "недоступен (работаю без него)"})

    if repos.settings.get("health:ews") == "on":
        items.append({"name": "EWS", "ok": True, "detail": "чтение с сервера"})

    row = repos.db.query_one("SELECT MAX(ts) m FROM llm_usage")
    llm_age = _age_hours(row["m"] if row else None)
    items.append({"name": "GigaChat",
                  "ok": llm_age is not None,
                  "detail": (f"последний вызов {llm_age:.0f} ч назад"
                             if llm_age is not None and llm_age >= 1
                             else "работает" if llm_age is not None
                             else "ещё не вызывался")})

    items.append({"name": "Поиск (векторы)", "ok": vectors is not None,
                  "detail": "индекс доступен" if vectors is not None
                            else "недоступен — только FTS"})

    if DEFAULT_EXPORT_DIR.exists():
        last = repos.settings.get("msg_import:last_file_at")
        age = _age_hours(last)
        if age is None:
            detail, ok = "файлов ещё не было", True
        elif age < 1:
            detail, ok = "письма приходят", True
        else:
            detail, ok = f"последний файл {age:.0f} ч назад", age < 24
        items.append({"name": "Файловый шлюз", "ok": ok, "detail": detail})
    return items


def check_gateway_stalled(repos, now: datetime | None = None) -> int:
    """Алерт, если шлюз активен, но файлов нет 24ч+ в рабочий день.

    ref_id = ГГГГММДД — не чаще одного алерта в день."""
    from gigapost.outlook.msg_import import DEFAULT_EXPORT_DIR

    now = now or datetime.now()
    if not DEFAULT_EXPORT_DIR.exists() or now.weekday() >= 5:
        return 0
    last = repos.settings.get("msg_import:last_file_at")
    age = _age_hours(last)
    if age is None or age < 24:
        return 0
    created = repos.alerts.create(
        "gateway_stalled", "settings", int(now.strftime("%Y%m%d")),
        f"Файловый шлюз молчит {age:.0f} ч: новые письма не приходят из "
        f"Outlook. Проверьте макрос/перенос в {DEFAULT_EXPORT_DIR}")
    return 1 if created else 0
