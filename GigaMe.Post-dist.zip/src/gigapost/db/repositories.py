"""Репозитории поверх Database — весь SQL проекта живёт здесь."""

from __future__ import annotations

import json
from datetime import datetime, timedelta
from typing import Any

from gigapost.db.database import Database
from gigapost.outlook.models import EmailMessage


def _now() -> str:
    return datetime.now().isoformat(timespec="seconds")


class EmailRepo:
    def __init__(self, db: Database):
        self.db = db

    def exists(self, message_id: str) -> bool:
        return self.db.query_one(
            "SELECT 1 FROM emails WHERE message_id=?", (message_id,)
        ) is not None

    def upsert(self, email: EmailMessage) -> None:
        self.db.execute(
            """INSERT INTO emails (message_id, entry_id, conversation_id, subject,
                 sender_name, sender_email, recipients_json, received_at, body_text,
                 folder, has_attachments, attachment_names)
               VALUES (?,?,?,?,?,?,?,?,?,?,?,?)
               ON CONFLICT(message_id) DO UPDATE SET
                 entry_id=excluded.entry_id, folder=excluded.folder""",
            (
                email.message_id, email.entry_id, email.conversation_id, email.subject,
                email.sender_name, email.sender_email, json.dumps(email.recipients, ensure_ascii=False),
                email.received_at, email.body_text, email.folder,
                int(email.has_attachments), json.dumps(email.attachment_names, ensure_ascii=False),
            ),
        )

    def set_classification(self, message_id: str, category: str, importance: int,
                           requires_action: bool, summary: str,
                           confidence: int | None = None,
                           needs_review: bool = False) -> None:
        self.db.execute(
            """UPDATE emails SET category=?, importance=?, requires_action=?,
               summary=?, category_confidence=?, needs_review=?, processed_at=?
               WHERE message_id=?""",
            (category, importance, int(requires_action), summary, confidence,
             int(needs_review), _now(), message_id),
        )

    def set_review_resolved(self, message_id: str, category: str) -> None:
        self.db.execute(
            "UPDATE emails SET category=?, needs_review=0 WHERE message_id=?",
            (category, message_id),
        )

    def pending_review(self, limit: int = 50) -> list[dict]:
        rows = self.db.query(
            "SELECT * FROM emails WHERE needs_review=1 ORDER BY received_at DESC LIMIT ?",
            (limit,))
        return [dict(r) for r in rows]

    def count_pending_review(self) -> int:
        row = self.db.query_one("SELECT COUNT(*) AS c FROM emails WHERE needs_review=1")
        return row["c"] if row else 0

    def set_entry_id(self, message_id: str, entry_id: str, folder: str | None = None) -> None:
        if folder is not None:
            self.db.execute("UPDATE emails SET entry_id=?, folder=? WHERE message_id=?",
                            (entry_id, folder, message_id))
        else:
            self.db.execute("UPDATE emails SET entry_id=? WHERE message_id=?",
                            (entry_id, message_id))

    def mark_indexed(self, message_id: str) -> None:
        self.db.execute("UPDATE emails SET indexed_at=? WHERE message_id=?", (_now(), message_id))

    def get(self, message_id: str) -> dict | None:
        row = self.db.query_one("SELECT * FROM emails WHERE message_id=?", (message_id,))
        return dict(row) if row else None

    def latest_in_conversation(self, conversation_id: str) -> dict | None:
        row = self.db.query_one(
            "SELECT * FROM emails WHERE conversation_id=? ORDER BY received_at DESC LIMIT 1",
            (conversation_id,),
        )
        return dict(row) if row else None

    def search_fts(self, query: str, limit: int = 10) -> list[dict]:
        # FTS5-запрос: экранируем как фразу, чтобы спецсимволы пользователя не ломали синтаксис
        safe = '"' + query.replace('"', '""') + '"'
        rows = self.db.query(
            """SELECT e.* FROM emails_fts f JOIN emails e ON e.rowid = f.rowid
               WHERE emails_fts MATCH ? AND COALESCE(e.dismissed, 0) = 0
               ORDER BY rank LIMIT ?""",
            (safe, limit),
        )
        return [dict(r) for r in rows]

    def set_dismissed(self, message_id: str, flag: bool) -> None:
        self.db.execute("UPDATE emails SET dismissed=? WHERE message_id=?",
                        (1 if flag else 0, message_id))

    def dismissed(self, limit: int = 100) -> list[dict]:
        rows = self.db.query(
            "SELECT * FROM emails WHERE COALESCE(dismissed,0)=1 "
            "ORDER BY received_at DESC LIMIT ?", (limit,))
        return [dict(r) for r in rows]

    def count_dismissed(self) -> int:
        row = self.db.query_one(
            "SELECT COUNT(*) AS c FROM emails WHERE COALESCE(dismissed,0)=1")
        return row["c"] if row else 0

    def search_fts_any(self, words: list[str], limit: int = 300) -> list[dict]:
        """Широкий поиск для вопросов-перечислений: любое слово (OR),
        с префиксом — «доступ*» находит «доступа/доступов»."""
        terms = " OR ".join(f'"{w}"*' for w in words
                            if w and '"' not in w)
        if not terms:
            return []
        rows = self.db.query(
            """SELECT e.* FROM emails_fts f JOIN emails e ON e.rowid = f.rowid
               WHERE emails_fts MATCH ? ORDER BY rank LIMIT ?""",
            (terms, limit))
        return [dict(r) for r in rows]

    def recent(self, limit: int = 50) -> list[dict]:
        rows = self.db.query(
            "SELECT * FROM emails WHERE COALESCE(dismissed,0)=0 "
            "ORDER BY received_at DESC LIMIT ?", (limit,))
        return [dict(r) for r in rows]

    def count_since(self, since_iso: str) -> int:
        row = self.db.query_one(
            "SELECT COUNT(*) AS c FROM emails WHERE received_at >= ?", (since_iso,))
        return row["c"] if row else 0

    def unindexed(self, limit: int = 100) -> list[dict]:
        rows = self.db.query(
            "SELECT * FROM emails WHERE indexed_at IS NULL LIMIT ?", (limit,))
        return [dict(r) for r in rows]


class TaskRepo:
    def __init__(self, db: Database):
        self.db = db

    def create(self, title: str, description: str = "", source_message_id: str | None = None,
               due_date: str | None = None, reminder_at: str | None = None,
               assignee: str | None = None, outlook_task_entry_id: str | None = None,
               status: str = "open", project: str | None = None) -> int:
        cur = self.db.execute(
            """INSERT INTO tasks (title, description, source_message_id, outlook_task_entry_id,
                 due_date, reminder_at, assignee, status, project, created_at)
               VALUES (?,?,?,?,?,?,?,?,?,?)""",
            (title, description, source_message_id, outlook_task_entry_id,
             due_date, reminder_at, assignee, status, project, _now()),
        )
        return cur.lastrowid

    def set_project(self, task_id: int, project: str | None) -> None:
        self.db.execute("UPDATE tasks SET project=? WHERE id=?", (project, task_id))

    def update_fields(self, task_id: int, title: str, description: str,
                      due_date: str | None, project: str | None,
                      assignee: str | None) -> None:
        self.db.execute(
            """UPDATE tasks SET title=?, description=?, due_date=?, project=?, assignee=?
               WHERE id=?""",
            (title, description, due_date or None, project or None,
             assignee or "я", task_id))

    def delete(self, task_id: int) -> None:
        """Жёсткое удаление: подзадачи отвязываются, связи чистятся."""
        self.db.execute("UPDATE tasks SET parent_id=NULL WHERE parent_id=?", (task_id,))
        self.db.execute(
            "DELETE FROM task_links WHERE src_task_id=? OR dst_task_id=?",
            (task_id, task_id))
        self.db.execute("DELETE FROM tasks WHERE id=?", (task_id,))

    def set_parent(self, task_id: int, parent_id: int | None) -> None:
        if parent_id == task_id:
            return
        self.db.execute("UPDATE tasks SET parent_id=? WHERE id=?", (parent_id, task_id))

    def subtasks(self, parent_id: int) -> list[dict]:
        rows = self.db.query(
            "SELECT * FROM tasks WHERE parent_id=? ORDER BY status='done', due_date IS NULL, due_date",
            (parent_id,))
        return [dict(r) for r in rows]

    def subtask_counts(self) -> dict[int, tuple[int, int]]:
        """{parent_id: (всего, выполнено)} для карточек доски."""
        rows = self.db.query(
            """SELECT parent_id, COUNT(*) total, SUM(status='done') done
               FROM tasks WHERE parent_id IS NOT NULL GROUP BY parent_id""")
        return {r["parent_id"]: (r["total"], r["done"] or 0) for r in rows}

    def add_link(self, a: int, b: int) -> None:
        src, dst = (a, b) if a < b else (b, a)
        if src != dst:
            self.db.execute(
                "INSERT OR IGNORE INTO task_links (src_task_id, dst_task_id) VALUES (?,?)",
                (src, dst))

    def remove_link(self, a: int, b: int) -> None:
        src, dst = (a, b) if a < b else (b, a)
        self.db.execute(
            "DELETE FROM task_links WHERE src_task_id=? AND dst_task_id=?", (src, dst))

    def linked_tasks(self, task_id: int) -> list[dict]:
        rows = self.db.query(
            """SELECT t.* FROM tasks t JOIN task_links l
                 ON (t.id = l.dst_task_id AND l.src_task_id = ?)
                 OR (t.id = l.src_task_id AND l.dst_task_id = ?)""",
            (task_id, task_id))
        return [dict(r) for r in rows]

    # ---------- проекты ----------

    def create_project(self, name: str) -> None:
        name = name.strip()
        if name:
            self.db.execute(
                "INSERT OR IGNORE INTO projects (name, created_at) VALUES (?,?)",
                (name, _now()))

    def rename_project(self, old: str, new: str) -> None:
        new = new.strip()
        if not new or old == new:
            return
        self.create_project(new)
        self.db.execute("DELETE FROM projects WHERE name=?", (old,))
        self.db.execute("UPDATE tasks SET project=? WHERE project=?", (new, old))

    def delete_project(self, name: str) -> None:
        """Удалить проект; его задачи остаются без проекта."""
        self.db.execute("DELETE FROM projects WHERE name=?", (name,))
        self.db.execute("UPDATE tasks SET project=NULL WHERE project=?", (name,))

    def projects(self) -> list[str]:
        rows = self.db.query(
            """SELECT name FROM projects
               UNION SELECT DISTINCT project FROM tasks
                 WHERE project IS NOT NULL AND project != ''
               ORDER BY 1""")
        return [r["name"] for r in rows]

    def board(self, project: str | None = None, q: str = "",
              assignee_mode: str = "") -> dict[str, list[dict]]:
        """Задачи для канбан-доски (только верхнего уровня, с отправителем
        письма-источника): {draft: [...], open: [...], done: [...]}.
        assignee_mode: '' — все, 'mine' — мои, 'others' — чужие."""
        where = ["t.parent_id IS NULL"]
        params: list = []
        if project:
            where.append("t.project=?")
            params.append(project)
        if q:
            like = f"%{q}%"
            where.append("(t.title LIKE ? OR t.description LIKE ? OR t.project LIKE ?)")
            params += [like, like, like]
        if assignee_mode == "mine":
            where.append("(t.assignee IS NULL OR t.assignee='я')")
        elif assignee_mode == "others":
            where.append("t.assignee IS NOT NULL AND t.assignee != 'я'")
        rows = self.db.query(
            f"""SELECT t.*, e.sender_name, e.sender_email
                FROM tasks t LEFT JOIN emails e ON e.message_id = t.source_message_id
                WHERE {' AND '.join(where)}
                ORDER BY t.due_date IS NULL, t.due_date, t.id DESC""", tuple(params))
        board: dict[str, list[dict]] = {"draft": [], "open": [], "done": []}
        for r in rows:
            d = dict(r)
            if d["status"] in board:
                board[d["status"]].append(d)
        board["done"] = board["done"][:30]
        return board

    def set_outlook_entry_id(self, task_id: int, entry_id: str) -> None:
        self.db.execute("UPDATE tasks SET outlook_task_entry_id=? WHERE id=?", (entry_id, task_id))

    def archive(self, task_id: int) -> None:
        """В архив (completed_at сохраняется — в отличие от set_status)."""
        self.db.execute("UPDATE tasks SET status='archived' WHERE id=?", (task_id,))

    def archive_done(self, project: str | None = None, older_days: int = 0) -> int:
        """Архивировать выполненные: все или старше N дней; опционально по проекту."""
        from datetime import datetime, timedelta

        where = ["status='done'"]
        params: list = []
        if project:
            where.append("project=?")
            params.append(project)
        if older_days:
            cutoff = (datetime.now() - timedelta(days=older_days)).isoformat()
            where.append("COALESCE(completed_at, created_at) < ?")
            params.append(cutoff)
        cur = self.db.execute(
            f"UPDATE tasks SET status='archived' WHERE {' AND '.join(where)}",
            tuple(params))
        return cur.rowcount

    def archived(self, project: str | None = None, limit: int = 300) -> list[dict]:
        """Архив: архивированные и отклонённые задачи, свежие первыми."""
        where = ["t.status IN ('archived', 'cancelled')", "t.parent_id IS NULL"]
        params: list = []
        if project:
            where.append("t.project=?")
            params.append(project)
        rows = self.db.query(
            f"""SELECT t.*, e.sender_name FROM tasks t
                LEFT JOIN emails e ON e.message_id = t.source_message_id
                WHERE {' AND '.join(where)}
                ORDER BY COALESCE(t.completed_at, t.created_at) DESC LIMIT ?""",
            (*params, limit))
        return [dict(r) for r in rows]

    def set_status(self, task_id: int, status: str) -> None:
        completed = _now() if status == "done" else None
        self.db.execute("UPDATE tasks SET status=?, completed_at=? WHERE id=?",
                        (status, completed, task_id))

    def get(self, task_id: int) -> dict | None:
        row = self.db.query_one("SELECT * FROM tasks WHERE id=?", (task_id,))
        return dict(row) if row else None

    def list(self, status: str | None = None, limit: int = 100) -> list[dict]:
        if status:
            rows = self.db.query(
                "SELECT * FROM tasks WHERE status=? ORDER BY due_date IS NULL, due_date, id DESC LIMIT ?",
                (status, limit))
        else:
            rows = self.db.query(
                "SELECT * FROM tasks ORDER BY status='open' DESC, due_date IS NULL, due_date, id DESC LIMIT ?",
                (limit,))
        return [dict(r) for r in rows]

    def count(self, status: str) -> int:
        row = self.db.query_one("SELECT COUNT(*) AS c FROM tasks WHERE status=?", (status,))
        return row["c"] if row else 0


class AgreementRepo:
    def __init__(self, db: Database):
        self.db = db

    def create(self, description: str, counterparty: str | None, direction: str,
               source_message_id: str | None, conversation_id: str | None,
               due_date: str | None, followup_after_days: int = 3) -> int:
        cur = self.db.execute(
            """INSERT INTO agreements (description, counterparty, direction, source_message_id,
                 conversation_id, due_date, last_activity_at, followup_after_days, created_at)
               VALUES (?,?,?,?,?,?,?,?,?)""",
            (description, counterparty, direction, source_message_id, conversation_id,
             due_date, _now(), followup_after_days, _now()),
        )
        return cur.lastrowid

    def set_status(self, agreement_id: int, status: str) -> None:
        self.db.execute("UPDATE agreements SET status=? WHERE id=?", (status, agreement_id))

    def touch_conversation(self, conversation_id: str, ts: str | None = None) -> None:
        """Новое письмо в треде — обновить last_activity_at открытых договорённостей."""
        if not conversation_id:
            return
        self.db.execute(
            """UPDATE agreements SET last_activity_at=?
               WHERE conversation_id=? AND status IN ('on_control','overdue')""",
            (ts or _now(), conversation_id),
        )

    def get(self, agreement_id: int) -> dict | None:
        row = self.db.query_one("SELECT * FROM agreements WHERE id=?", (agreement_id,))
        return dict(row) if row else None

    def list(self, status: str | None = None, limit: int = 100) -> list[dict]:
        if status:
            rows = self.db.query(
                "SELECT * FROM agreements WHERE status=? ORDER BY due_date IS NULL, due_date LIMIT ?",
                (status, limit))
        else:
            rows = self.db.query(
                """SELECT * FROM agreements WHERE status IN ('on_control','overdue')
                   ORDER BY due_date IS NULL, due_date LIMIT ?""", (limit,))
        return [dict(r) for r in rows]

    def overdue_candidates(self, now_iso: str) -> list[dict]:
        rows = self.db.query(
            "SELECT * FROM agreements WHERE status='on_control' AND due_date IS NOT NULL AND due_date < ?",
            (now_iso,))
        return [dict(r) for r in rows]

    def deadline_soon(self, now_iso: str, horizon_iso: str) -> list[dict]:
        rows = self.db.query(
            """SELECT * FROM agreements WHERE status='on_control'
               AND due_date IS NOT NULL AND due_date >= ? AND due_date <= ?""",
            (now_iso, horizon_iso))
        return [dict(r) for r in rows]

    def followup_candidates(self, now: datetime) -> list[dict]:
        """they_owe без активности в треде дольше followup_after_days."""
        rows = self.db.query(
            "SELECT * FROM agreements WHERE status IN ('on_control','overdue') AND direction='they_owe'")
        result = []
        for r in rows:
            d = dict(r)
            last = d.get("last_activity_at") or d.get("created_at")
            if not last:
                continue
            try:
                last_dt = datetime.fromisoformat(last)
            except ValueError:
                continue
            if now - last_dt > timedelta(days=d.get("followup_after_days") or 3):
                result.append(d)
        return result

    def count_open(self) -> int:
        row = self.db.query_one(
            "SELECT COUNT(*) AS c FROM agreements WHERE status IN ('on_control','overdue')")
        return row["c"] if row else 0


class EntityRepo:
    def __init__(self, db: Database):
        self.db = db

    @staticmethod
    def normalize(name: str) -> str:
        return " ".join(name.lower().replace("ё", "е").split())

    def upsert(self, name: str, type_: str, email: str | None = None,
               attrs: dict | None = None) -> int:
        norm = self.normalize(name)
        row = self.db.query_one(
            "SELECT id, email FROM entities WHERE normalized_name=? AND type=?", (norm, type_))
        # «GigaMe» проект и «GigaME» тема — один объект: одинаковое имя среди
        # нечеловеческих типов переиспользуем, а не плодим дубль в графе
        if row is None and type_ in ("org", "project", "topic"):
            row = self.db.query_one(
                "SELECT id, email FROM entities WHERE normalized_name=? "
                "AND type IN ('org','project','topic')", (norm,))
        if row:
            if email and not row["email"]:
                self.db.execute("UPDATE entities SET email=? WHERE id=?", (email, row["id"]))
            return row["id"]
        cur = self.db.execute(
            "INSERT INTO entities (name, type, normalized_name, email, attrs_json) VALUES (?,?,?,?,?)",
            (name, type_, norm, email, json.dumps(attrs or {}, ensure_ascii=False)),
        )
        return cur.lastrowid

    def add_mention(self, entity_id: int, message_id: str, role: str) -> None:
        self.db.execute(
            "INSERT OR IGNORE INTO entity_mentions (entity_id, message_id, role) VALUES (?,?,?)",
            (entity_id, message_id, role),
        )

    def upsert_edge(self, src_id: int, dst_id: int, relation: str,
                    source_message_id: str | None = None) -> None:
        self.db.execute(
            """INSERT INTO edges (src_entity_id, dst_entity_id, relation, weight,
                 first_seen, last_seen, source_message_id)
               VALUES (?,?,?,1.0,?,?,?)
               ON CONFLICT(src_entity_id, dst_entity_id, relation) DO UPDATE SET
                 weight = weight + 1.0, last_seen = excluded.last_seen""",
            (src_id, dst_id, relation, _now(), _now(), source_message_id),
        )

    def find_by_name(self, name: str) -> list[dict]:
        """Точное совпадение — в приоритете, затем подстрока."""
        norm = self.normalize(name)
        exact = self.db.query("SELECT * FROM entities WHERE normalized_name=?", (norm,))
        if exact:
            return [dict(r) for r in exact]
        rows = self.db.query(
            "SELECT * FROM entities WHERE normalized_name LIKE ?", (f"%{norm}%",))
        return [dict(r) for r in rows]

    def find_exact(self, name: str) -> dict | None:
        row = self.db.query_one(
            "SELECT * FROM entities WHERE normalized_name=?", (self.normalize(name),))
        return dict(row) if row else None

    def merge(self, src_id: int, dst_id: int) -> None:
        """Слить дубль src в dst: перевесить ссылки, упоминания и рёбра, удалить src."""
        if src_id == dst_id:
            return
        self.db.execute("UPDATE OR IGNORE note_links SET entity_id=? WHERE entity_id=?",
                        (dst_id, src_id))
        self.db.execute("DELETE FROM note_links WHERE entity_id=?", (src_id,))
        self.db.execute("UPDATE OR IGNORE entity_mentions SET entity_id=? WHERE entity_id=?",
                        (dst_id, src_id))
        self.db.execute("DELETE FROM entity_mentions WHERE entity_id=?", (src_id,))
        self.db.execute("UPDATE OR IGNORE edges SET src_entity_id=? WHERE src_entity_id=?",
                        (dst_id, src_id))
        self.db.execute("UPDATE OR IGNORE edges SET dst_entity_id=? WHERE dst_entity_id=?",
                        (dst_id, src_id))
        self.db.execute(
            "DELETE FROM edges WHERE src_entity_id=? OR dst_entity_id=?", (src_id, src_id))
        # досье: FK на entities — у dst остаётся своё, досье src переносится,
        # только если у dst досье нет (PK по entity_id)
        self.db.execute("UPDATE OR IGNORE dossiers SET entity_id=? WHERE entity_id=?",
                        (dst_id, src_id))
        self.db.execute("DELETE FROM dossiers WHERE entity_id=?", (src_id,))
        self.db.execute("UPDATE conflict_checks SET entity_id=? WHERE entity_id=?",
                        (dst_id, src_id))
        self.db.execute("DELETE FROM entities WHERE id=?", (src_id,))

    def get(self, entity_id: int) -> dict | None:
        row = self.db.query_one("SELECT * FROM entities WHERE id=?", (entity_id,))
        return dict(row) if row else None

    def all_entities(self) -> list[dict]:
        return [dict(r) for r in self.db.query("SELECT * FROM entities")]

    def all_edges(self) -> list[dict]:
        return [dict(r) for r in self.db.query("SELECT * FROM edges")]

    def mentions_for(self, entity_id: int, limit: int = 10) -> list[dict]:
        # одно письмо = одна строка (роли sender/recipient/mentioned схлопываются)
        rows = self.db.query(
            """SELECT e.message_id, e.subject, e.received_at, e.sender_name,
                      MIN(m.role) AS role
               FROM entity_mentions m JOIN emails e ON e.message_id = m.message_id
               WHERE m.entity_id=?
               GROUP BY e.message_id
               ORDER BY e.received_at DESC LIMIT ?""",
            (entity_id, limit))
        return [dict(r) for r in rows]


class NoteRepo:
    """Атомарные заметки-знания (Zettelkasten) с [[wiki-ссылками]] на сущности."""

    def __init__(self, db: Database):
        self.db = db

    def create(self, title: str, body: str, kind: str,
               source_message_id: str | None, conversation_id: str | None) -> int | None:
        """None — если такая заметка из этого письма уже есть (дедуп)."""
        cur = self.db.execute(
            """INSERT OR IGNORE INTO notes (title, body, kind, source_message_id,
                 conversation_id, created_at)
               VALUES (?,?,?,?,?,?)""",
            (title, body, kind, source_message_id, conversation_id, _now()),
        )
        return cur.lastrowid if cur.rowcount else None

    def link_entity(self, note_id: int, entity_id: int) -> None:
        self.db.execute(
            "INSERT OR IGNORE INTO note_links (note_id, entity_id) VALUES (?,?)",
            (note_id, entity_id))

    def get(self, note_id: int) -> dict | None:
        row = self.db.query_one("SELECT * FROM notes WHERE id=?", (note_id,))
        return dict(row) if row else None

    def all_notes(self) -> list[dict]:
        return [dict(r) for r in self.db.query("SELECT * FROM notes")]

    def all_links(self) -> list[dict]:
        return [dict(r) for r in self.db.query("SELECT * FROM note_links")]

    def recent(self, limit: int = 50) -> list[dict]:
        rows = self.db.query("SELECT * FROM notes ORDER BY id DESC LIMIT ?", (limit,))
        return [dict(r) for r in rows]

    def for_entity(self, entity_id: int, limit: int = 30) -> list[dict]:
        """Backlinks: все заметки, ссылающиеся на сущность."""
        rows = self.db.query(
            """SELECT n.* FROM notes n JOIN note_links l ON l.note_id = n.id
               WHERE l.entity_id=? ORDER BY n.id DESC LIMIT ?""",
            (entity_id, limit))
        return [dict(r) for r in rows]

    def add_relation(self, a: int, b: int, score: float) -> None:
        src, dst = (a, b) if a < b else (b, a)
        if src == dst:
            return
        self.db.execute(
            """INSERT INTO note_relations (src_note_id, dst_note_id, score) VALUES (?,?,?)
               ON CONFLICT(src_note_id, dst_note_id) DO UPDATE SET
                 score = MAX(score, excluded.score)""",
            (src, dst, score))

    def all_relations(self) -> list[dict]:
        return [dict(r) for r in self.db.query("SELECT * FROM note_relations")]

    def for_email(self, message_id: str) -> list[dict]:
        rows = self.db.query(
            "SELECT * FROM notes WHERE source_message_id=?", (message_id,))
        return [dict(r) for r in rows]

    def entities_of(self, note_id: int) -> list[dict]:
        rows = self.db.query(
            """SELECT e.* FROM entities e JOIN note_links l ON l.entity_id = e.id
               WHERE l.note_id=?""", (note_id,))
        return [dict(r) for r in rows]

    def search_fts(self, query: str, limit: int = 10) -> list[dict]:
        safe = '"' + query.replace('"', '""') + '"'
        rows = self.db.query(
            """SELECT n.* FROM notes_fts f JOIN notes n ON n.id = f.rowid
               WHERE notes_fts MATCH ? ORDER BY rank LIMIT ?""",
            (safe, limit))
        return [dict(r) for r in rows]

    def search_fts_any(self, words: list[str], limit: int = 150) -> list[dict]:
        """Широкий поиск знаний: любое слово (OR) с префиксом."""
        terms = " OR ".join(f'"{w}"*' for w in words if w and '"' not in w)
        if not terms:
            return []
        rows = self.db.query(
            """SELECT n.* FROM notes_fts f JOIN notes n ON n.id = f.rowid
               WHERE notes_fts MATCH ? ORDER BY rank LIMIT ?""",
            (terms, limit))
        return [dict(r) for r in rows]

    def count(self) -> int:
        row = self.db.query_one("SELECT COUNT(*) AS c FROM notes")
        return row["c"] if row else 0


class AttachmentRepo:
    def __init__(self, db: Database):
        self.db = db

    def upsert(self, message_id: str, filename: str, ext: str, size: int | None,
               path: str | None, text: str | None, status: str,
               sha256: str | None = None) -> None:
        self.db.execute(
            """INSERT INTO attachments (message_id, filename, ext, size, path, text,
                 status, sha256, parsed_at)
               VALUES (?,?,?,?,?,?,?,?,?)
               ON CONFLICT(message_id, filename) DO UPDATE SET
                 text=excluded.text, status=excluded.status,
                 sha256=excluded.sha256, parsed_at=excluded.parsed_at""",
            (message_id, filename, ext, size, path, text, status, sha256, _now()),
        )

    def get(self, attachment_id: int) -> dict | None:
        row = self.db.query_one("SELECT * FROM attachments WHERE id=?", (attachment_id,))
        return dict(row) if row else None

    def search_fts_any(self, words: list[str], limit: int = 60) -> list[dict]:
        """Широкий поиск по текстам вложений (для вопросов-перечислений):
        любое слово (OR) с префиксом."""
        terms = " OR ".join(f'"{w}"*' for w in words if w and '"' not in w)
        if not terms:
            return []
        rows = self.db.query(
            """SELECT a.*, e.subject AS email_subject, e.sender_name, e.received_at
               FROM attachments_fts f
               JOIN attachments a ON a.id = f.rowid
               LEFT JOIN emails e ON e.message_id = a.message_id
               WHERE attachments_fts MATCH ? AND a.text IS NOT NULL
               ORDER BY rank LIMIT ?""",
            (terms, limit))
        return [dict(r) for r in rows]

    def library(self, query: str = "", ext: str = "", limit: int = 100) -> list[dict]:
        """Библиотека вложений. Поиск — нечёткий: FTS с префиксами по имени
        и содержимому + LIKE по отправителю/теме; результаты объединяются."""
        ext_clause, ext_params = "", []
        if ext:
            ext_clause = " AND a.ext = ?"
            ext_params = [ext if ext.startswith(".") else f".{ext}"]
        if not query:
            rows = self.db.query(
                f"""SELECT a.*, e.subject, e.sender_name, e.sender_email, e.received_at
                    FROM attachments a LEFT JOIN emails e ON e.message_id = a.message_id
                    WHERE a.path IS NOT NULL{ext_clause}
                    ORDER BY e.received_at DESC, a.id DESC LIMIT ?""",
                (*ext_params, limit))
            return [dict(r) for r in rows]
        results: dict[int, dict] = {}
        # FTS: каждое слово запроса — как префикс (быстрый нечёткий поиск)
        words = [w for w in query.replace('"', " ").split() if w]
        if words:
            fts_query = " ".join(f'"{w}"*' for w in words)
            try:
                rows = self.db.query(
                    f"""SELECT a.*, e.subject, e.sender_name, e.sender_email, e.received_at
                        FROM attachments_fts f
                        JOIN attachments a ON a.id = f.rowid
                        LEFT JOIN emails e ON e.message_id = a.message_id
                        WHERE attachments_fts MATCH ? AND a.path IS NOT NULL{ext_clause}
                        ORDER BY rank LIMIT ?""",
                    (fts_query, *ext_params, limit))
                for r in rows:
                    results[r["id"]] = dict(r)
            except Exception:  # noqa: BLE001 — синтаксис FTS не совпал, ниже LIKE
                pass
        like = f"%{query}%"
        rows = self.db.query(
            f"""SELECT a.*, e.subject, e.sender_name, e.sender_email, e.received_at
                FROM attachments a LEFT JOIN emails e ON e.message_id = a.message_id
                WHERE a.path IS NOT NULL{ext_clause}
                  AND (a.filename LIKE ? OR e.sender_name LIKE ? OR e.subject LIKE ?)
                ORDER BY e.received_at DESC LIMIT ?""",
            (*ext_params, like, like, like, limit))
        for r in rows:
            results.setdefault(r["id"], dict(r))
        return list(results.values())[:limit]

    def extensions(self) -> list[tuple[str, int]]:
        rows = self.db.query(
            """SELECT ext, COUNT(*) c FROM attachments
               WHERE path IS NOT NULL GROUP BY ext ORDER BY c DESC""")
        return [(r["ext"], r["c"]) for r in rows]

    def duplicates_of(self, sha256: str, exclude_id: int) -> list[dict]:
        if not sha256:
            return []
        rows = self.db.query(
            "SELECT * FROM attachments WHERE sha256=? AND id!=?", (sha256, exclude_id))
        return [dict(r) for r in rows]

    def for_email(self, message_id: str) -> list[dict]:
        rows = self.db.query(
            "SELECT * FROM attachments WHERE message_id=? ORDER BY filename", (message_id,))
        return [dict(r) for r in rows]

    def get_text(self, message_id: str, filename: str) -> dict | None:
        row = self.db.query_one(
            "SELECT * FROM attachments WHERE message_id=? AND filename=?",
            (message_id, filename))
        return dict(row) if row else None

    def parsed_for_email(self, message_id: str) -> list[dict]:
        rows = self.db.query(
            """SELECT * FROM attachments WHERE message_id=? AND status='parsed'
               AND text IS NOT NULL ORDER BY filename""", (message_id,))
        return [dict(r) for r in rows]


class LogRepo:
    def __init__(self, db: Database):
        self.db = db

    def log(self, message_id: str | None, stage: str, status: str, detail: str = "") -> None:
        self.db.execute(
            "INSERT INTO processing_log (message_id, stage, status, detail, ts) VALUES (?,?,?,?,?)",
            (message_id, stage, status, detail[:2000], _now()),
        )

    def error_count(self, message_id: str, stage: str) -> int:
        row = self.db.query_one(
            "SELECT COUNT(*) AS c FROM processing_log WHERE message_id=? AND stage=? AND status='error'",
            (message_id, stage))
        return row["c"] if row else 0

    def recent(self, limit: int = 100) -> list[dict]:
        rows = self.db.query(
            "SELECT * FROM processing_log ORDER BY id DESC LIMIT ?", (limit,))
        return [dict(r) for r in rows]


class AlertRepo:
    def __init__(self, db: Database):
        self.db = db

    def create(self, kind: str, ref_table: str, ref_id: int, message: str) -> bool:
        """True, если алерт создан впервые (дедуп по UNIQUE). Новый алерт —
        уведомление в Telegram, если настроен."""
        cur = self.db.execute(
            """INSERT OR IGNORE INTO alerts (kind, ref_table, ref_id, message, created_at)
               VALUES (?,?,?,?,?)""",
            (kind, ref_table, ref_id, message, _now()),
        )
        created = cur.rowcount > 0
        if created:
            try:
                from gigapost.notify import notify_alert
                notify_alert(kind, message)
            except Exception:  # noqa: BLE001
                pass
        return created

    def list_active(self, limit: int = 50) -> list[dict]:
        rows = self.db.query(
            "SELECT * FROM alerts WHERE acknowledged=0 ORDER BY id DESC LIMIT ?", (limit,))
        return [dict(r) for r in rows]

    def acknowledge(self, alert_id: int) -> None:
        self.db.execute("UPDATE alerts SET acknowledged=1 WHERE id=?", (alert_id,))

    def count_active(self) -> int:
        row = self.db.query_one("SELECT COUNT(*) AS c FROM alerts WHERE acknowledged=0")
        return row["c"] if row else 0


class CorrectionRepo:
    """Ручные поправки классификации — few-shot примеры для промпта."""

    def __init__(self, db: Database):
        self.db = db

    def add(self, message_id: str, wrong: str | None, correct: str) -> None:
        self.db.execute(
            "INSERT INTO corrections (message_id, wrong_category, correct_category, ts) "
            "VALUES (?,?,?,?)", (message_id, wrong, correct, _now()))

    def recent_examples(self, limit: int = 5) -> list[dict]:
        rows = self.db.query(
            """SELECT c.correct_category, c.wrong_category, e.subject, e.sender_name,
                      substr(COALESCE(e.body_text, ''), 1, 200) snippet
               FROM corrections c JOIN emails e ON e.message_id = c.message_id
               ORDER BY c.id DESC LIMIT ?""", (limit,))
        return [dict(r) for r in rows]


class DigestRepo:
    def __init__(self, db: Database):
        self.db = db

    def save(self, day: str, body: str) -> None:
        self.db.execute(
            """INSERT INTO digests (day, body, created_at) VALUES (?,?,?)
               ON CONFLICT(day) DO UPDATE SET body=excluded.body,
                 created_at=excluded.created_at""",
            (day, body, _now()))

    def get(self, day: str) -> dict | None:
        row = self.db.query_one("SELECT * FROM digests WHERE day=?", (day,))
        return dict(row) if row else None

    def latest(self) -> dict | None:
        row = self.db.query_one("SELECT * FROM digests ORDER BY day DESC LIMIT 1")
        return dict(row) if row else None


class SettingsRepo:
    def __init__(self, db: Database):
        self.db = db

    def get(self, key: str, default: str | None = None) -> str | None:
        row = self.db.query_one("SELECT value FROM settings WHERE key=?", (key,))
        return row["value"] if row else default

    def set(self, key: str, value: str) -> None:
        self.db.execute(
            "INSERT INTO settings (key, value) VALUES (?,?) "
            "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
            (key, value),
        )


class Repos:
    """Контейнер всех репозиториев над одной БД."""

    def __init__(self, db: Database):
        self.db = db
        self.emails = EmailRepo(db)
        self.notes = NoteRepo(db)
        self.attachments = AttachmentRepo(db)
        self.tasks = TaskRepo(db)
        self.agreements = AgreementRepo(db)
        self.entities = EntityRepo(db)
        self.log = LogRepo(db)
        self.alerts = AlertRepo(db)
        self.corrections = CorrectionRepo(db)
        self.digests = DigestRepo(db)
        self.settings = SettingsRepo(db)
        # подключаем учёт токенов LLM к этой БД
        from gigapost.llm.throttle import LEDGER
        LEDGER.attach_db(db)
