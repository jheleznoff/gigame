﻿-- Схема GigaMe.Post. Все даты — ISO8601 (TEXT).
PRAGMA journal_mode=WAL;

CREATE TABLE IF NOT EXISTS emails (
  message_id TEXT PRIMARY KEY,          -- Internet Message-ID (стабильный ключ)
  entry_id TEXT,                        -- последний известный Outlook EntryID (меняется при Move)
  conversation_id TEXT,
  subject TEXT,
  sender_name TEXT,
  sender_email TEXT,
  recipients_json TEXT,
  received_at TEXT,
  body_text TEXT,
  folder TEXT,
  category TEXT,
  importance INTEGER,
  requires_action INTEGER,
  category_confidence INTEGER,
  needs_review INTEGER DEFAULT 0,
  summary TEXT,
  has_attachments INTEGER DEFAULT 0,
  attachment_names TEXT,
  processed_at TEXT,
  indexed_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_emails_conversation ON emails(conversation_id);
CREATE INDEX IF NOT EXISTS idx_emails_received ON emails(received_at);

CREATE VIRTUAL TABLE IF NOT EXISTS emails_fts USING fts5(
  subject, body_text, sender_name,
  content='emails', content_rowid='rowid'
);
CREATE TRIGGER IF NOT EXISTS emails_ai AFTER INSERT ON emails BEGIN
  INSERT INTO emails_fts(rowid, subject, body_text, sender_name)
  VALUES (new.rowid, new.subject, new.body_text, new.sender_name);
END;
CREATE TRIGGER IF NOT EXISTS emails_ad AFTER DELETE ON emails BEGIN
  INSERT INTO emails_fts(emails_fts, rowid, subject, body_text, sender_name)
  VALUES ('delete', old.rowid, old.subject, old.body_text, old.sender_name);
END;
CREATE TRIGGER IF NOT EXISTS emails_au AFTER UPDATE OF subject, body_text, sender_name ON emails BEGIN
  INSERT INTO emails_fts(emails_fts, rowid, subject, body_text, sender_name)
  VALUES ('delete', old.rowid, old.subject, old.body_text, old.sender_name);
  INSERT INTO emails_fts(rowid, subject, body_text, sender_name)
  VALUES (new.rowid, new.subject, new.body_text, new.sender_name);
END;

CREATE TABLE IF NOT EXISTS tasks (
  id INTEGER PRIMARY KEY,
  title TEXT NOT NULL,
  description TEXT,
  source_message_id TEXT REFERENCES emails(message_id),
  outlook_task_entry_id TEXT,
  due_date TEXT,
  reminder_at TEXT,
  status TEXT DEFAULT 'open',           -- draft | open | done | cancelled
  project TEXT,                         -- проект (доска канбана)
  parent_id INTEGER REFERENCES tasks(id),  -- подзадачи
  assignee TEXT,
  created_at TEXT,
  completed_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_tasks_status ON tasks(status);

-- проекты (доски канбана) — как самостоятельные объекты
CREATE TABLE IF NOT EXISTS projects (
  name TEXT PRIMARY KEY,
  created_at TEXT
);

-- связи задача ↔ задача («связана с»)
CREATE TABLE IF NOT EXISTS task_links (
  src_task_id INTEGER REFERENCES tasks(id),
  dst_task_id INTEGER REFERENCES tasks(id),
  PRIMARY KEY (src_task_id, dst_task_id)
);

CREATE TABLE IF NOT EXISTS agreements (
  id INTEGER PRIMARY KEY,
  description TEXT NOT NULL,
  counterparty TEXT,
  direction TEXT,                       -- we_owe | they_owe | mutual
  source_message_id TEXT REFERENCES emails(message_id),
  conversation_id TEXT,
  due_date TEXT,
  status TEXT DEFAULT 'on_control',     -- on_control | done | overdue | cancelled
  last_activity_at TEXT,
  followup_after_days INTEGER DEFAULT 3,
  created_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_agreements_status ON agreements(status);
CREATE INDEX IF NOT EXISTS idx_agreements_conversation ON agreements(conversation_id);

CREATE TABLE IF NOT EXISTS entities (
  id INTEGER PRIMARY KEY,
  name TEXT NOT NULL,
  type TEXT NOT NULL,                   -- person | org | project | topic
  normalized_name TEXT NOT NULL,
  email TEXT,
  attrs_json TEXT,
  UNIQUE(normalized_name, type)
);

CREATE TABLE IF NOT EXISTS entity_mentions (
  entity_id INTEGER REFERENCES entities(id),
  message_id TEXT REFERENCES emails(message_id),
  role TEXT,                            -- sender | recipient | mentioned
  PRIMARY KEY (entity_id, message_id, role)
);

CREATE TABLE IF NOT EXISTS edges (
  id INTEGER PRIMARY KEY,
  src_entity_id INTEGER REFERENCES entities(id),
  dst_entity_id INTEGER REFERENCES entities(id),
  relation TEXT,                        -- works_at | participates_in | agreed_with | discusses
  weight REAL DEFAULT 1.0,
  first_seen TEXT,
  last_seen TEXT,
  source_message_id TEXT,
  UNIQUE(src_entity_id, dst_entity_id, relation)
);

-- Цеттелькастен: атомарные заметки-знания с [[wiki-ссылками]] на сущности
CREATE TABLE IF NOT EXISTS notes (
  id INTEGER PRIMARY KEY,
  title TEXT NOT NULL,                  -- краткий заголовок мысли
  body TEXT NOT NULL,                   -- текст своими словами, с [[wiki-ссылками]]
  kind TEXT DEFAULT 'fact',             -- fact | agreement | decision | event | status
  source_message_id TEXT REFERENCES emails(message_id),
  conversation_id TEXT,
  created_at TEXT,
  UNIQUE(title, source_message_id)
);
CREATE INDEX IF NOT EXISTS idx_notes_conversation ON notes(conversation_id);

CREATE VIRTUAL TABLE IF NOT EXISTS notes_fts USING fts5(
  title, body, content='notes', content_rowid='id'
);
CREATE TRIGGER IF NOT EXISTS notes_ai AFTER INSERT ON notes BEGIN
  INSERT INTO notes_fts(rowid, title, body) VALUES (new.id, new.title, new.body);
END;
CREATE TRIGGER IF NOT EXISTS notes_ad AFTER DELETE ON notes BEGIN
  INSERT INTO notes_fts(notes_fts, rowid, title, body)
  VALUES ('delete', old.id, old.title, old.body);
END;
CREATE TRIGGER IF NOT EXISTS notes_au AFTER UPDATE OF title, body ON notes BEGIN
  INSERT INTO notes_fts(notes_fts, rowid, title, body)
  VALUES ('delete', old.id, old.title, old.body);
  INSERT INTO notes_fts(rowid, title, body) VALUES (new.id, new.title, new.body);
END;

-- связи заметка → сущность (из [[ссылок]] в тексте)
CREATE TABLE IF NOT EXISTS note_links (
  note_id INTEGER REFERENCES notes(id),
  entity_id INTEGER REFERENCES entities(id),
  PRIMARY KEY (note_id, entity_id)
);

-- смысловые связи заметка ↔ заметка (по близости эмбеддингов; src < dst)
CREATE TABLE IF NOT EXISTS note_relations (
  src_note_id INTEGER REFERENCES notes(id),
  dst_note_id INTEGER REFERENCES notes(id),
  score REAL,
  PRIMARY KEY (src_note_id, dst_note_id)
);

CREATE TABLE IF NOT EXISTS attachments (
  id INTEGER PRIMARY KEY,
  message_id TEXT REFERENCES emails(message_id),
  filename TEXT NOT NULL,
  ext TEXT,
  size INTEGER,
  path TEXT,                            -- локальный путь сохранённого файла
  text TEXT,                            -- извлечённый текст (NULL = не разобрано)
  sha256 TEXT,                          -- хеш файла (дедупликация одинаковых вложений)
  status TEXT DEFAULT 'new',            -- new | parsed | stored | unsupported | error
  parsed_at TEXT,
  UNIQUE(message_id, filename)
);
CREATE INDEX IF NOT EXISTS idx_attachments_message ON attachments(message_id);

-- полнотекстовый поиск по вложениям (имя + извлечённый текст)
CREATE VIRTUAL TABLE IF NOT EXISTS attachments_fts USING fts5(
  filename, text, content='attachments', content_rowid='id'
);
CREATE TRIGGER IF NOT EXISTS attachments_ai AFTER INSERT ON attachments BEGIN
  INSERT INTO attachments_fts(rowid, filename, text)
  VALUES (new.id, new.filename, COALESCE(new.text, ''));
END;
CREATE TRIGGER IF NOT EXISTS attachments_ad AFTER DELETE ON attachments BEGIN
  INSERT INTO attachments_fts(attachments_fts, rowid, filename, text)
  VALUES ('delete', old.id, old.filename, COALESCE(old.text, ''));
END;
CREATE TRIGGER IF NOT EXISTS attachments_au AFTER UPDATE ON attachments BEGIN
  INSERT INTO attachments_fts(attachments_fts, rowid, filename, text)
  VALUES ('delete', old.id, old.filename, COALESCE(old.text, ''));
  INSERT INTO attachments_fts(rowid, filename, text)
  VALUES (new.id, new.filename, COALESCE(new.text, ''));
END;

CREATE TABLE IF NOT EXISTS processing_log (
  id INTEGER PRIMARY KEY,
  message_id TEXT,
  stage TEXT,                           -- fetch | classify | extract | apply | kg | index
  status TEXT,                          -- ok | error | dry_run
  detail TEXT,
  attempts INTEGER DEFAULT 1,
  ts TEXT
);
CREATE INDEX IF NOT EXISTS idx_plog_message ON processing_log(message_id);

CREATE TABLE IF NOT EXISTS alerts (
  id INTEGER PRIMARY KEY,
  kind TEXT,                            -- overdue | followup_needed | deadline_soon
  ref_table TEXT,
  ref_id INTEGER,
  message TEXT,
  created_at TEXT,
  acknowledged INTEGER DEFAULT 0,
  UNIQUE(kind, ref_table, ref_id)
);

CREATE TABLE IF NOT EXISTS settings (
  key TEXT PRIMARY KEY,
  value TEXT
);

-- учёт токенов LLM по ролям
CREATE TABLE IF NOT EXISTS llm_usage (
  id INTEGER PRIMARY KEY,
  role TEXT,
  prompt_tokens INTEGER,
  completion_tokens INTEGER,
  ts TEXT
);

-- ручные поправки классификации (few-shot: система учится на исправлениях)
CREATE TABLE IF NOT EXISTS corrections (
  id INTEGER PRIMARY KEY,
  message_id TEXT REFERENCES emails(message_id),
  wrong_category TEXT,
  correct_category TEXT,
  ts TEXT
);

-- утренние дайджесты
CREATE TABLE IF NOT EXISTS digests (
  id INTEGER PRIMARY KEY,
  day TEXT UNIQUE,           -- YYYY-MM-DD
  body TEXT,                 -- markdown
  created_at TEXT
);

-- ---------- умные надстройки (У1-У11) ----------

-- реквизиты документов, извлечённые из вложений (кэш LLM-извлечения)
CREATE TABLE IF NOT EXISTS doc_facts (
  attachment_id INTEGER PRIMARY KEY REFERENCES attachments(id),
  doc_type TEXT,
  number TEXT,
  doc_date TEXT,
  amount TEXT,
  counterparty TEXT,
  tech TEXT,
  notes TEXT,
  extracted_at TEXT
);

-- отчёты сверки комплектов документов по тредам
CREATE TABLE IF NOT EXISTS doc_checks (
  id INTEGER PRIMARY KEY,
  conversation_id TEXT NOT NULL,
  report TEXT NOT NULL,             -- markdown
  created_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_doc_checks_conv ON doc_checks(conversation_id);

-- кэш резюме тредов
CREATE TABLE IF NOT EXISTS thread_summaries (
  conversation_id TEXT PRIMARY KEY,
  summary TEXT,                     -- markdown
  last_email_at TEXT,               -- received_at последнего учтённого письма
  updated_at TEXT
);

-- живые досье сущностей
CREATE TABLE IF NOT EXISTS dossiers (
  entity_id INTEGER PRIMARY KEY REFERENCES entities(id),
  summary TEXT,                     -- markdown
  last_mention_at TEXT,
  updated_at TEXT
);

-- оценки черновиков ответов (обучение стилю)
CREATE TABLE IF NOT EXISTS reply_feedback (
  id INTEGER PRIMARY KEY,
  message_id TEXT,
  draft TEXT,
  verdict TEXT,                     -- up | down
  created_at TEXT
);

-- проверенные группы заметок на противоречия (чтобы не спрашивать LLM повторно)
CREATE TABLE IF NOT EXISTS conflict_checks (
  group_hash TEXT PRIMARY KEY,
  entity_id INTEGER,
  is_conflict INTEGER,
  description TEXT,
  checked_at TEXT
);

-- индексы под масштаб (фокус дня, панель контекста, sent-обработка)
CREATE INDEX IF NOT EXISTS idx_emails_folder_received ON emails(folder, received_at);
CREATE INDEX IF NOT EXISTS idx_notes_source ON notes(source_message_id);
CREATE INDEX IF NOT EXISTS idx_mentions_message ON entity_mentions(message_id);

-- обратная связь по задачам: уроки для извлечения + источник знаний
CREATE TABLE IF NOT EXISTS task_feedback (
  id INTEGER PRIMARY KEY,
  task_id INTEGER,
  title TEXT,
  reason TEXT,
  verdict TEXT DEFAULT 'rejected',   -- rejected | accepted
  created_at TEXT
);

-- документы, приложенные пользователем в чат для анализа (живут в треде диалога)
CREATE TABLE IF NOT EXISTS chat_uploads (
  id INTEGER PRIMARY KEY,
  thread_id TEXT NOT NULL,
  filename TEXT,
  text TEXT,
  status TEXT,                      -- parsed | empty
  created_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_chat_uploads_thread ON chat_uploads(thread_id);
