"""SQLite: соединение на поток, WAL, инициализация схемы."""

from __future__ import annotations

import sqlite3
import threading
from pathlib import Path

_SCHEMA_PATH = Path(__file__).parent / "schema.sql"


class Database:
    """Обёртка над sqlite3: по одному соединению на поток (threading.local)."""

    def __init__(self, db_path: str | Path):
        self.db_path = str(db_path)
        self._local = threading.local()
        if self.db_path != ":memory:":
            Path(self.db_path).parent.mkdir(parents=True, exist_ok=True)

    @property
    def conn(self) -> sqlite3.Connection:
        conn = getattr(self._local, "conn", None)
        if conn is None:
            conn = sqlite3.connect(self.db_path, timeout=30)
            conn.row_factory = sqlite3.Row
            conn.execute("PRAGMA journal_mode=WAL")
            conn.execute("PRAGMA foreign_keys=ON")
            self._local.conn = conn
        return conn

    # Догоняющие миграции для баз, созданных до появления колонок
    _MIGRATIONS = [
        "ALTER TABLE emails ADD COLUMN category_confidence INTEGER",
        "ALTER TABLE emails ADD COLUMN needs_review INTEGER DEFAULT 0",
        "ALTER TABLE tasks ADD COLUMN project TEXT",
        "ALTER TABLE attachments ADD COLUMN sha256 TEXT",
        "ALTER TABLE tasks ADD COLUMN parent_id INTEGER REFERENCES tasks(id)",
        # переиндексация FTS вложений (для баз, созданных до его появления)
        "INSERT INTO attachments_fts(attachments_fts) VALUES('rebuild')",
    ]

    def init_schema(self) -> None:
        self.conn.executescript(_SCHEMA_PATH.read_text(encoding="utf-8"))
        for migration in self._MIGRATIONS:
            try:
                self.conn.execute(migration)
            except sqlite3.OperationalError:
                pass  # колонка уже есть
        self.conn.commit()

    def execute(self, sql: str, params: tuple | dict = ()) -> sqlite3.Cursor:
        cur = self.conn.execute(sql, params)
        self.conn.commit()
        return cur

    def query(self, sql: str, params: tuple | dict = ()) -> list[sqlite3.Row]:
        return self.conn.execute(sql, params).fetchall()

    def query_one(self, sql: str, params: tuple | dict = ()) -> sqlite3.Row | None:
        return self.conn.execute(sql, params).fetchone()

    def close(self) -> None:
        conn = getattr(self._local, "conn", None)
        if conn is not None:
            conn.close()
            self._local.conn = None
