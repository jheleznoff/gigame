"""Граф знаний в духе Zettelkasten/Obsidian.

Узлы двух родов: атомарные заметки (мысль своими словами с [[wiki-ссылками]])
и сущности-хабы (люди, организации, проекты, темы — аналог MOC в Obsidian).
Рёбра рождаются из [[ссылок]] в тексте заметок; типизированные связи между
сущностями (works_at и т.п.) сохраняются как дополнительный слой.
SQLite — источник истины, NetworkX — производный кэш в памяти.
"""

from __future__ import annotations

import logging
import re
import threading
from pathlib import Path

import networkx as nx

from gigapost.db.repositories import Repos

logger = logging.getLogger(__name__)

WIKILINK_RE = re.compile(r"\[\[([^\[\]|]+)(?:\|[^\[\]]*)?\]\]")


def parse_wikilinks(text: str) -> list[str]:
    """Имена из [[двойных скобок]], без дублей, в порядке появления."""
    seen: set[str] = set()
    result = []
    for m in WIKILINK_RE.finditer(text or ""):
        name = m.group(1).strip()
        key = name.lower()
        if name and key not in seen:
            seen.add(key)
            result.append(name)
    return result


class KnowledgeGraph:
    def __init__(self, repos: Repos, graphml_path: Path | None = None):
        self.repos = repos
        self.graphml_path = graphml_path
        self._lock = threading.RLock()
        self.graph = nx.MultiDiGraph()

    # ---------- идентификаторы узлов: e<id> — сущность, n<id> — заметка ----------

    @staticmethod
    def _eid(entity_id: int) -> str:
        return f"e{entity_id}"

    @staticmethod
    def _nid(note_id: int) -> str:
        return f"n{note_id}"

    # ---------- сборка ----------

    def rebuild(self) -> None:
        with self._lock:
            g = nx.MultiDiGraph()
            for e in self.repos.entities.all_entities():
                g.add_node(self._eid(e["id"]), name=e["name"], type=e["type"],
                           kind="entity", email=e["email"] or "")
            for edge in self.repos.entities.all_edges():
                src, dst = self._eid(edge["src_entity_id"]), self._eid(edge["dst_entity_id"])
                if src in g and dst in g:
                    g.add_edge(src, dst, key=edge["relation"], relation=edge["relation"],
                               weight=edge["weight"] or 1.0)
            for n in self.repos.notes.all_notes():
                g.add_node(self._nid(n["id"]), name=n["title"], type="note",
                           kind="note", note_kind=n["kind"])
            for link in self.repos.notes.all_links():
                src, dst = self._nid(link["note_id"]), self._eid(link["entity_id"])
                if src in g and dst in g:
                    g.add_edge(src, dst, key="mentions", relation="mentions", weight=1.0)
            for rel in self.repos.notes.all_relations():
                src, dst = self._nid(rel["src_note_id"]), self._nid(rel["dst_note_id"])
                if src in g and dst in g:
                    g.add_edge(src, dst, key="related", relation="related",
                               weight=rel["score"] or 0.5)
            self.graph = g
            logger.info("Граф знаний: %d узлов (%d заметок), %d рёбер",
                        g.number_of_nodes(), self.repos.notes.count(), g.number_of_edges())

    # ---------- запись ----------

    def upsert_entity(self, name: str, type_: str, email: str | None = None) -> int:
        with self._lock:
            entity_id = self.repos.entities.upsert(name, type_, email)
            nid = self._eid(entity_id)
            if nid not in self.graph:
                self.graph.add_node(nid, name=name, type=type_, kind="entity",
                                    email=email or "")
            return entity_id

    def upsert_edge(self, src_id: int, dst_id: int, relation: str,
                    source_message_id: str | None = None) -> None:
        with self._lock:
            self.repos.entities.upsert_edge(src_id, dst_id, relation, source_message_id)
            src, dst = self._eid(src_id), self._eid(dst_id)
            if self.graph.has_edge(src, dst, key=relation):
                self.graph[src][dst][relation]["weight"] += 1.0
            else:
                self.graph.add_edge(src, dst, key=relation, relation=relation, weight=1.0)

    def add_note(self, title: str, body: str, kind: str,
                 source_message_id: str | None, conversation_id: str | None,
                 known_types: dict[str, str] | None = None) -> int | None:
        """Создать заметку; [[ссылки]] из текста превращаются в связи с сущностями.

        known_types — {normalized_name: type} из извлечения этого же письма,
        чтобы [[Анна Смирнова]] стала person, а не topic.
        """
        with self._lock:
            note_id = self.repos.notes.create(
                title, body, kind, source_message_id, conversation_id)
            if note_id is None:  # дубль
                return None
            self.graph.add_node(self._nid(note_id), name=title, type="note",
                                kind="note", note_kind=kind)
            for name in parse_wikilinks(body):
                norm = self.repos.entities.normalize(name)
                # только точное совпадение имени — подстрочный поиск линкует не туда
                exact = self.repos.entities.find_exact(name)
                if exact:
                    entity_id = exact["id"]
                    if self._eid(entity_id) not in self.graph:
                        self.graph.add_node(self._eid(entity_id), name=exact["name"],
                                            type=exact["type"], kind="entity",
                                            email=exact.get("email") or "")
                else:
                    entity_id = self.upsert_entity(
                        name, (known_types or {}).get(norm, "topic"))
                self.repos.notes.link_entity(note_id, entity_id)
                src, dst = self._nid(note_id), self._eid(entity_id)
                if not self.graph.has_edge(src, dst, key="mentions"):
                    self.graph.add_edge(src, dst, key="mentions",
                                        relation="mentions", weight=1.0)
            return note_id

    def link_notes(self, a: int, b: int, score: float) -> None:
        """Смысловое ребро заметка↔заметка (в память; в БД пишет NoteRepo)."""
        with self._lock:
            src, dst = self._nid(min(a, b)), self._nid(max(a, b))
            if src in self.graph and dst in self.graph \
                    and not self.graph.has_edge(src, dst, key="related"):
                self.graph.add_edge(src, dst, key="related", relation="related",
                                    weight=score)

    # ---------- чтение ----------

    def neighbors(self, entity_name: str) -> dict | None:
        """Связи сущности + backlinks-заметки (как панель backlinks в Obsidian)."""
        matches = self.repos.entities.find_by_name(entity_name)
        if not matches:
            return None
        entity = matches[0]
        nid = self._eid(entity["id"])
        related = []
        with self._lock:
            if nid in self.graph:
                for _, dst, data in self.graph.out_edges(nid, data=True):
                    node = self.graph.nodes[dst]
                    if node.get("kind") == "entity":
                        related.append({"name": node.get("name"), "type": node.get("type"),
                                        "relation": data.get("relation"), "direction": "out"})
                for src, _, data in self.graph.in_edges(nid, data=True):
                    node = self.graph.nodes[src]
                    if node.get("kind") == "entity":
                        related.append({"name": node.get("name"), "type": node.get("type"),
                                        "relation": data.get("relation"), "direction": "in"})
        backlinks = [
            {"id": n["id"], "title": n["title"], "kind": n["kind"], "body": n["body"]}
            for n in self.repos.notes.for_entity(entity["id"], limit=20)
        ]
        return {"entity": entity, "related": related, "notes": backlinks}

    def node_details(self, node_id: str) -> dict | None:
        """Данные узла для панели в UI: заметка с текстом или сущность с backlinks."""
        if node_id.startswith("n"):
            note = self.repos.notes.get(int(node_id[1:]))
            if not note:
                return None
            return {"kind": "note", "note": note,
                    "entities": self.repos.notes.entities_of(note["id"]),
                    "email": self.repos.emails.get(note["source_message_id"])
                    if note.get("source_message_id") else None}
        if node_id.startswith("e"):
            entity = self.repos.entities.get(int(node_id[1:]))
            if not entity:
                return None
            return {"kind": "entity", "entity": entity,
                    "notes": self.repos.notes.for_entity(entity["id"], limit=20)}
        return None

    def export_json(self, center: str | None = None, depth: int = 2,
                    max_nodes: int = 150) -> dict:
        """Экспорт для vis-network: заметки — маленькие узлы, хабы — крупные."""
        with self._lock:
            g = self.graph
            if center:
                matches = self.repos.entities.find_by_name(center)
                if matches:
                    cid = self._eid(matches[0]["id"])
                    if cid in g:
                        undirected = g.to_undirected(as_view=True)
                        keep = set(nx.ego_graph(undirected, cid, radius=depth).nodes)
                        g = g.subgraph(keep)
            if g.number_of_nodes() > max_nodes:
                top = sorted(g.degree, key=lambda x: x[1], reverse=True)[:max_nodes]
                g = g.subgraph([n for n, _ in top])
            degrees = dict(g.degree)
            nodes = []
            for n, d in g.nodes(data=True):
                if d.get("kind") == "note":
                    nodes.append({"id": n, "label": (d.get("name") or "")[:40],
                                  "group": "note", "value": 1})
                else:
                    nodes.append({"id": n, "label": d.get("name", n),
                                  "group": d.get("type", "topic"),
                                  "value": 1 + degrees.get(n, 1)})
            edges = []
            for u, v, d in g.edges(data=True):
                rel = d.get("relation", "")
                edge = {"from": u, "to": v,
                        "label": "" if rel in ("mentions", "related") else rel,
                        "value": d.get("weight", 1.0)}
                if rel == "related":       # смысловая связь заметок — пунктиром
                    edge["dashes"] = True
                edges.append(edge)
            return {"nodes": nodes, "edges": edges}

    def save_graphml(self) -> None:
        if self.graphml_path is None:
            return
        with self._lock:
            try:
                self.graphml_path.parent.mkdir(parents=True, exist_ok=True)
                nx.write_graphml(self.graph, self.graphml_path)
            except Exception as e:  # noqa: BLE001 — снапшот некритичен
                logger.warning("Не удалось сохранить graphml: %s", e)

    def stats(self) -> dict:
        with self._lock:
            return {"nodes": self.graph.number_of_nodes(),
                    "edges": self.graph.number_of_edges(),
                    "notes": self.repos.notes.count()}
