"""Векторный индекс писем: Chroma (напрямую) + GigaChat Embeddings батчами."""

from __future__ import annotations

import logging
from pathlib import Path

from gigapost.config import settings
from gigapost.outlook.models import EmailMessage

logger = logging.getLogger(__name__)


def _chunk_text(text: str, chunk_chars: int) -> list[str]:
    """Чанкование по абзацам с ограничением длины."""
    if not text:
        return []
    chunks: list[str] = []
    current = ""
    for para in text.split("\n\n"):
        if len(current) + len(para) + 2 <= chunk_chars:
            current = f"{current}\n\n{para}" if current else para
        else:
            if current:
                chunks.append(current)
            # слишком длинный абзац режем жёстко
            while len(para) > chunk_chars:
                chunks.append(para[:chunk_chars])
                para = para[chunk_chars:]
            current = para
    if current:
        chunks.append(current)
    return chunks


class VectorStore:
    def __init__(self, path: Path, embeddings=None):
        import chromadb

        self._embeddings = embeddings
        self._client = chromadb.PersistentClient(path=str(path))
        self.collection = self._client.get_or_create_collection(
            "emails", metadata={"hnsw:space": "cosine"})
        self.notes_collection = self._client.get_or_create_collection(
            "notes", metadata={"hnsw:space": "cosine"})

    @property
    def embeddings(self):
        if self._embeddings is None:
            from gigapost.llm.factory import get_embeddings
            self._embeddings = get_embeddings()
        return self._embeddings

    def index_email(self, email: EmailMessage | dict) -> int:
        """Проиндексировать письмо; возвращает число чанков."""
        if isinstance(email, EmailMessage):
            data = {
                "message_id": email.message_id, "subject": email.subject,
                "sender_name": email.sender_name, "sender_email": email.sender_email,
                "received_at": email.received_at, "body_text": email.body_text,
                "folder": email.folder, "category": None,
            }
        else:
            data = email
        body = (data.get("body_text") or "")[:settings.limits.max_body_chars]
        chunks = _chunk_text(body, settings.limits.chunk_chars)
        if not chunks:
            chunks = [""]
        docs = [
            f"Тема: {data.get('subject') or ''}\nОт: {data.get('sender_name') or ''}\n\n{c}"
            for c in chunks
        ]
        ids = [f"{data['message_id']}#{i}" for i in range(len(docs))]
        metadatas = [{
            "message_id": data["message_id"],
            "sender_email": data.get("sender_email") or "",
            "received_at": data.get("received_at") or "",
            "category": data.get("category") or "",
            "folder": data.get("folder") or "",
        } for _ in docs]

        batch = settings.limits.embed_batch
        vectors: list[list[float]] = []
        for i in range(0, len(docs), batch):
            vectors.extend(self.embeddings.embed_documents(docs[i:i + batch]))
        self.collection.upsert(ids=ids, documents=docs, embeddings=vectors, metadatas=metadatas)
        return len(docs)

    def index_attachment(self, message_id: str, filename: str, text: str,
                         email_meta: dict | None = None) -> int:
        """Проиндексировать текст вложения отдельными чанками."""
        chunks = _chunk_text(text[:settings.limits.max_body_chars * 2],
                             settings.limits.chunk_chars)
        if not chunks:
            return 0
        docs = [f"Вложение: {filename}\n\n{c}" for c in chunks]
        ids = [f"{message_id}#att:{filename}#{i}" for i in range(len(docs))]
        meta = email_meta or {}
        metadatas = [{
            "message_id": message_id,
            "attachment": filename,
            "sender_email": meta.get("sender_email") or "",
            "received_at": meta.get("received_at") or "",
            "category": meta.get("category") or "",
            "folder": meta.get("folder") or "",
        } for _ in docs]
        batch = settings.limits.embed_batch
        vectors: list[list[float]] = []
        for i in range(0, len(docs), batch):
            vectors.extend(self.embeddings.embed_documents(docs[i:i + batch]))
        self.collection.upsert(ids=ids, documents=docs, embeddings=vectors, metadatas=metadatas)
        return len(docs)

    def search(self, query: str, k: int = 8, sender_email: str | None = None) -> list[dict]:
        """Семантический поиск; возвращает [{message_id, snippet, score, metadata}]."""
        if self.collection.count() == 0:
            return []
        where = {"sender_email": sender_email} if sender_email else None
        qvec = self.embeddings.embed_query(query)
        res = self.collection.query(
            query_embeddings=[qvec], n_results=min(k * 3, 50), where=where)
        results, seen = [], set()
        for doc, meta, dist in zip(res["documents"][0], res["metadatas"][0], res["distances"][0]):
            mid = meta["message_id"]
            if mid in seen:
                continue
            seen.add(mid)
            results.append({"message_id": mid, "snippet": doc[:500],
                            "score": 1.0 - dist, "metadata": meta})
            if len(results) >= k:
                break
        return results

    def index_note(self, note_id: int, title: str, body: str) -> None:
        """Проиндексировать заметку (текст без [[скобок]])."""
        clean = (f"{title}\n{body}").replace("[[", "").replace("]]", "")
        vec = self.embeddings.embed_documents([clean])[0]
        self.notes_collection.upsert(
            ids=[str(note_id)], documents=[clean], embeddings=[vec])

    def similar_notes(self, note_id: int, k: int = 3,
                      min_score: float = 0.72) -> list[tuple[int, float]]:
        """Ближайшие по смыслу заметки: [(note_id, score)]."""
        got = self.notes_collection.get(ids=[str(note_id)], include=["embeddings"])
        if not got["ids"]:
            return []
        vec = got["embeddings"][0]
        res = self.notes_collection.query(query_embeddings=[vec], n_results=k + 1)
        result = []
        for other_id, dist in zip(res["ids"][0], res["distances"][0]):
            if other_id == str(note_id):
                continue
            score = 1.0 - dist
            if score >= min_score:
                result.append((int(other_id), round(score, 3)))
        return result

    def count(self) -> int:
        return self.collection.count()
