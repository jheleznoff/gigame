"""GigaMe.Post — локальный агентный почтовый ассистент на GigaChat + Outlook COM."""

__version__ = "0.1.0"
