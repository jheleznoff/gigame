"""Установка GigaMe.Post на новой машине (когда .bat запускать нельзя).

Запуск:  py -3.12 install.py
Создаёт .venv, ставит зависимости точных версий из requirements.lock.txt,
готовит .env из шаблона. Нужен Python 3.12 x64 и доступ к PyPI.
"""

import shutil
import subprocess
import sys
import venv
from pathlib import Path

ROOT = Path(__file__).resolve().parent
VENV_PY = ROOT / ".venv" / "Scripts" / "python.exe"


def run(*args: str) -> None:
    print("  >", " ".join(args))
    subprocess.run(args, check=True, cwd=ROOT)


def main() -> None:
    if sys.version_info[:2] != (3, 12):
        sys.exit(f"[ОШИБКА] Нужен Python 3.12, а этот скрипт запущен на "
                 f"{sys.version_info.major}.{sys.version_info.minor}. "
                 f"Запустите: py -3.12 install.py")

    print("[1/3] Создаю виртуальное окружение .venv ...")
    venv.EnvBuilder(with_pip=True).create(ROOT / ".venv")

    print("[2/3] Ставлю зависимости (точные версии из requirements.lock.txt) ...")
    run(str(VENV_PY), "-m", "pip", "install", "-r", "requirements.lock.txt", "--quiet")
    run(str(VENV_PY), "-m", "pip", "install", "--no-deps", "-e", ".", "--quiet")

    print("[3/3] Готовлю конфигурацию ...")
    if not (ROOT / ".env").exists():
        shutil.copy(ROOT / ".env.example", ROOT / ".env")
    (ROOT / "data").mkdir(exist_ok=True)

    print("""
Установка завершена.

Дальше:
  1. Откройте .env и заполните подключение GigaChat
     (на корп-ноутбуке: GIGACHAT_BASE_URL + GIGACHAT_CERT_FILE + GIGACHAT_KEY_FILE).
  2. Проверьте config\\settings.yaml: polling.store, exclude_stores, owner, vips.
  3. Запуск:  py start.py
""")


if __name__ == "__main__":
    main()
