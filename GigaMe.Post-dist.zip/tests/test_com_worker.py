"""Тесты ComWorker: сериализация вызовов в один поток (без реального Outlook —
проверяем механику очереди на подменённом _run)."""

import threading
from concurrent.futures import ThreadPoolExecutor

import pytest

from gigapost.outlook.com_worker import ComWorker, ComWorkerError


class LoopbackWorker(ComWorker):
    """Тот же цикл очереди, но без COM: фиксирует, в каком потоке исполняются команды."""

    def __init__(self):
        super().__init__()
        self.executed_in: list[str] = []

    def _run(self):
        self._started.set()
        while True:
            fn, fut = self._queue.get()
            if fn is None:
                break
            if fut.set_running_or_notify_cancel():
                try:
                    self.executed_in.append(threading.current_thread().name)
                    fut.set_result(fn("outlook", "ns"))
                except BaseException as e:  # noqa: BLE001
                    fut.set_exception(e)


def test_submit_returns_result():
    worker = LoopbackWorker()
    worker.start()
    try:
        assert worker.submit(lambda o, ns: 42) == 42
    finally:
        worker.stop()


def test_all_calls_run_in_worker_thread():
    worker = LoopbackWorker()
    worker.start()
    try:
        with ThreadPoolExecutor(max_workers=8) as pool:
            futures = [pool.submit(worker.submit, lambda o, ns: threading.current_thread().name)
                       for _ in range(50)]
            results = [f.result(timeout=10) for f in futures]
        assert set(results) == {"com-worker"}
        assert set(worker.executed_in) == {"com-worker"}
    finally:
        worker.stop()


def test_exception_propagates():
    worker = LoopbackWorker()
    worker.start()
    try:
        def boom(o, ns):
            raise ValueError("ошибка COM")
        with pytest.raises(ValueError, match="ошибка COM"):
            worker.submit(boom)
        # воркер жив после ошибки
        assert worker.submit(lambda o, ns: "ok") == "ok"
    finally:
        worker.stop()


def test_submit_without_start_raises():
    worker = ComWorker()
    with pytest.raises(ComWorkerError):
        worker.submit(lambda o, ns: 1)


def test_restrict_date_format():
    """Items.Restrict требует американский формат независимо от локали."""
    from datetime import datetime
    from gigapost.outlook.client import _restrict_date

    dt = datetime(2026, 7, 20, 14, 5, 0)
    assert _restrict_date(dt) == "07/20/2026 02:05 PM"
