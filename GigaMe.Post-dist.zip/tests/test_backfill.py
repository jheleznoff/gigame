"""Тесты умного бэкфилла: отбор ценных писем без LLM, исключение хранилищ."""

import importlib.util
import json
import pathlib
import sys

from gigapost.outlook.models import EmailMessage

_spec = importlib.util.spec_from_file_location(
    "backfill", pathlib.Path(__file__).parent.parent / "scripts" / "backfill.py")
backfill = importlib.util.module_from_spec(_spec)
sys.modules["backfill"] = backfill
_spec.loader.exec_module(backfill)


def _email(num, sender_email, body="Содержательное письмо о проекте и планах на будущее. " * 5,
           conv=None, folder="Inbox", recipients=None, sender_name=""):
    return EmailMessage(
        message_id=f"<bf-{num:03d}@x.ru>", entry_id=f"B{num}",
        conversation_id=conv or f"BF-{num}",
        subject=f"Письмо {num}", sender_name=sender_name, sender_email=sender_email,
        recipients=recipients or ["me@x.ru"],
        received_at=f"2026-06-{(num % 28) + 1:02d}T10:00:00",
        body_text=body, folder=folder)


def test_select_filters_noise(repos):
    # noreply — отсекается
    repos.emails.upsert(_email(1, "noreply@spam.ru"))
    # короткое тело — отсекается
    repos.emails.upsert(_email(2, "ivanov@x.ru", body="Ок"))
    # нормальное деловое письмо — проходит
    repos.emails.upsert(_email(3, "petrov@x.ru"))
    # письмо в огромной копии — штраф (score < 0 → отсекается)
    repos.emails.upsert(_email(4, "sidorov@x.ru",
                               recipients=[f"u{i}@x.ru" for i in range(20)]))
    cands = backfill.select_candidates(repos)
    ids = [c["message_id"] for c in cands]
    assert "<bf-003@x.ru>" in ids
    assert "<bf-001@x.ru>" not in ids
    assert "<bf-002@x.ru>" not in ids
    assert "<bf-004@x.ru>" not in ids


def test_select_boosts_replied_threads_and_vips(repos):
    repos.emails.upsert(_email(10, "someone@x.ru", conv="THREAD-R"))
    # мой ответ в том же треде
    repos.emails.upsert(_email(11, "me@x.ru", conv="THREAD-R", folder="Sent"))
    repos.emails.upsert(_email(12, "other@x.ru"))
    repos.emails.upsert(_email(13, "MDmEgorova@sberbank.ru",
                               sender_name="Егорова Мария Дмитриевна"))
    cands = backfill.select_candidates(repos)
    scores = {c["message_id"]: c["_score"] for c in cands}
    assert scores["<bf-010@x.ru>"] > scores["<bf-012@x.ru>"]   # тред с ответом выше
    assert scores["<bf-013@x.ru>"] > scores["<bf-012@x.ru>"]   # VIP выше
    # обработанные (stage=backfill ok) исчезают из кандидатов
    repos.log.log("<bf-010@x.ru>", "backfill", "ok", "")
    ids = [c["message_id"] for c in backfill.select_candidates(repos)]
    assert "<bf-010@x.ru>" not in ids


def test_bulk_sender_detection(repos):
    # 25+ писем от одного отправителя без единого моего ответа = рассылка
    for i in range(30, 30 + backfill.BULK_SENDER_THRESHOLD):
        repos.emails.upsert(_email(i, "digest@corp.ru", conv=f"D-{i}"))
    ids = [c["message_id"] for c in backfill.select_candidates(repos)]
    assert not any("digest" in i for i in ids) or all(
        c["sender_email"] != "digest@corp.ru" for c in backfill.select_candidates(repos))


def test_exclude_stores_config(monkeypatch):
    from gigapost.config import settings
    from gigapost.outlook.client import _is_excluded_store

    monkeypatch.setattr(settings.polling, "exclude_stores", ["zakupki_dzo"])
    assert _is_excluded_store("zakupki_dzo@sberbank.ru")
    assert _is_excluded_store("ZAKUPKI_DZO@SBERBANK.RU")
    assert not _is_excluded_store("Zheleznov.M.Yu@sberbank.ru")
    assert not _is_excluded_store("Архив 2024")
