"""Тесты репозиториев на in-memory SQLite."""

from datetime import datetime, timedelta


def test_email_upsert_dedup(repos, email_task_request):
    repos.emails.upsert(email_task_request)
    repos.emails.upsert(email_task_request)  # повторный — не дубль
    assert repos.emails.exists(email_task_request.message_id)
    assert len(repos.emails.recent()) == 1


def test_email_classification_and_fts(repos, email_task_request):
    repos.emails.upsert(email_task_request)
    repos.emails.set_classification(
        email_task_request.message_id, "Срочное/Действие", 4, True, "Просят отчёт")
    email = repos.emails.get(email_task_request.message_id)
    assert email["category"] == "Срочное/Действие"
    assert email["requires_action"] == 1
    results = repos.emails.search_fts("отчёт по продажам")
    assert results and results[0]["message_id"] == email_task_request.message_id


def test_fts_special_chars_do_not_crash(repos, email_task_request):
    repos.emails.upsert(email_task_request)
    assert repos.emails.search_fts('отчёт "квартал" AND (продажи)') is not None


def test_entry_id_update_after_move(repos, email_task_request):
    repos.emails.upsert(email_task_request)
    repos.emails.set_entry_id(email_task_request.message_id, "NEWENTRY", "GigaPost/Проекты")
    email = repos.emails.get(email_task_request.message_id)
    assert email["entry_id"] == "NEWENTRY"
    assert email["folder"] == "GigaPost/Проекты"


def test_task_lifecycle(repos):
    task_id = repos.tasks.create("Подготовить отчёт", due_date="2026-07-24")
    assert repos.tasks.count("open") == 1
    repos.tasks.set_status(task_id, "done")
    assert repos.tasks.count("open") == 0
    assert repos.tasks.get(task_id)["completed_at"] is not None


def test_agreement_followup_candidates(repos):
    aid = repos.agreements.create(
        "Вышлют КП", "Анна Смирнова", "they_owe", None, "CONV003", None,
        followup_after_days=3)
    now = datetime.now()
    assert repos.agreements.followup_candidates(now) == []
    # подделываем last_activity_at на 4 дня назад
    repos.db.execute("UPDATE agreements SET last_activity_at=? WHERE id=?",
                     ((now - timedelta(days=4)).isoformat(), aid))
    candidates = repos.agreements.followup_candidates(now)
    assert len(candidates) == 1 and candidates[0]["id"] == aid


def test_agreement_touch_conversation(repos):
    aid = repos.agreements.create(
        "Вышлют КП", "Анна", "they_owe", None, "CONV003", None)
    old = (datetime.now() - timedelta(days=5)).isoformat()
    repos.db.execute("UPDATE agreements SET last_activity_at=? WHERE id=?", (old, aid))
    repos.agreements.touch_conversation("CONV003")
    assert repos.agreements.get(aid)["last_activity_at"] > old


def test_entity_dedup_and_edges(repos):
    id1 = repos.entities.upsert("Пётр Иванов", "person", "p.ivanov@romashka.ru")
    id2 = repos.entities.upsert("пётр  иванов", "person")  # регистр/пробелы
    id3 = repos.entities.upsert("Петр Иванов", "person")   # ё → е
    assert id1 == id2 == id3
    org = repos.entities.upsert("Ромашка", "org")
    repos.entities.upsert_edge(id1, org, "works_at")
    repos.entities.upsert_edge(id1, org, "works_at")  # повтор — рост веса
    edges = repos.entities.all_edges()
    assert len(edges) == 1 and edges[0]["weight"] == 2.0


def test_alert_dedup(repos):
    assert repos.alerts.create("overdue", "agreements", 1, "Просрочено")
    assert not repos.alerts.create("overdue", "agreements", 1, "Просрочено (дубль)")
    assert repos.alerts.count_active() == 1


def test_settings_roundtrip(repos):
    repos.settings.set("last_poll_ts:Inbox", "2026-07-20T12:00:00")
    assert repos.settings.get("last_poll_ts:Inbox") == "2026-07-20T12:00:00"
    repos.settings.set("last_poll_ts:Inbox", "2026-07-20T13:00:00")
    assert repos.settings.get("last_poll_ts:Inbox") == "2026-07-20T13:00:00"
