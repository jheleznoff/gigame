"""Тесты Цеттелькастен-графа: заметки, [[wiki-ссылки]], backlinks, канбан."""

from gigapost.knowledge.graph_store import KnowledgeGraph, parse_wikilinks


def test_parse_wikilinks():
    text = "[[Анна Смирнова]] из [[Вектор]] пришлёт КП по [[Альфа]] до 25 июля. [[Вектор]] дубль."
    assert parse_wikilinks(text) == ["Анна Смирнова", "Вектор", "Альфа"]
    assert parse_wikilinks("[[Имя|алиас]] и текст") == ["Имя"]
    assert parse_wikilinks("без ссылок") == []


def test_add_note_creates_entities_and_links(repos):
    kg = KnowledgeGraph(repos)
    kg.rebuild()
    note_id = kg.add_note(
        title="Вектор пришлёт КП по Альфе",
        body="[[Анна Смирнова]] из [[Вектор]] пришлёт финальное КП по [[Альфа]] до 25 июля",
        kind="agreement", source_message_id=None, conversation_id="C1",
        known_types={"анна смирнова": "person", "вектор": "org", "альфа": "project"})
    assert note_id is not None
    # сущности созданы с правильными типами из контекста письма
    types = {e["name"]: e["type"] for e in repos.entities.all_entities()}
    assert types["Анна Смирнова"] == "person"
    assert types["Вектор"] == "org"
    assert types["Альфа"] == "project"
    # backlinks: заметка видна со страницы сущности
    entity = repos.entities.find_by_name("Альфа")[0]
    backlinks = repos.notes.for_entity(entity["id"])
    assert len(backlinks) == 1 and backlinks[0]["title"] == "Вектор пришлёт КП по Альфе"
    # граф: узел-заметка связан с тремя хабами
    export = kg.export_json()
    note_nodes = [n for n in export["nodes"] if n["group"] == "note"]
    assert len(note_nodes) == 1
    assert len(export["edges"]) == 3


def test_note_dedup(repos, email_task_request):
    repos.emails.upsert(email_task_request)
    kg = KnowledgeGraph(repos)
    kg.rebuild()
    kwargs = dict(title="Факт", body="[[Тема]]", kind="fact",
                  source_message_id=email_task_request.message_id, conversation_id=None)
    assert kg.add_note(**kwargs) is not None
    assert kg.add_note(**kwargs) is None  # дубль той же заметки из того же письма
    assert repos.notes.count() == 1


def test_node_details_and_neighbors(repos):
    kg = KnowledgeGraph(repos)
    kg.rebuild()
    note_id = kg.add_note(
        title="Решение по Бете", body="[[Козлов]] начнёт работы по [[Бета]] в августе",
        kind="decision", source_message_id=None, conversation_id=None,
        known_types={"козлов": "person", "бета": "project"})
    details = kg.node_details(f"n{note_id}")
    assert details["kind"] == "note"
    assert details["note"]["title"] == "Решение по Бете"
    assert {e["name"] for e in details["entities"]} == {"Козлов", "Бета"}
    neighbors = kg.neighbors("Бета")
    assert neighbors["notes"][0]["title"] == "Решение по Бете"


def test_note_relations_in_graph(repos):
    kg = KnowledgeGraph(repos)
    kg.rebuild()
    n1 = kg.add_note(title="КП по Альфе", body="[[Вектор]] пришлёт КП по [[Альфа]]",
                     kind="agreement", source_message_id=None, conversation_id=None)
    n2 = kg.add_note(title="Смета по Альфе", body="Смета по [[Альфа]] уточняется",
                     kind="status", source_message_id=None, conversation_id=None)
    repos.notes.add_relation(n1, n2, 0.83)
    repos.notes.add_relation(n2, n1, 0.79)  # обратная — не создаёт дубль, берётся max
    rels = repos.notes.all_relations()
    assert len(rels) == 1 and rels[0]["score"] == 0.83
    kg.rebuild()
    export = kg.export_json()
    dashed = [e for e in export["edges"] if e.get("dashes")]
    assert len(dashed) == 1


def test_kanban_board_and_projects(repos):
    repos.tasks.create("Задача Альфы", status="open", project="Альфа")
    repos.tasks.create("Черновик Альфы", status="draft", project="Альфа")
    repos.tasks.create("Задача Беты", status="open", project="Бета")
    repos.tasks.create("Без проекта", status="open")
    assert repos.tasks.projects() == ["Альфа", "Бета"]
    board_all = repos.tasks.board()
    assert len(board_all["open"]) == 3 and len(board_all["draft"]) == 1
    board_alpha = repos.tasks.board("Альфа")
    assert len(board_alpha["open"]) == 1 and len(board_alpha["draft"]) == 1
    assert board_alpha["open"][0]["title"] == "Задача Альфы"


def test_project_crud(repos):
    repos.tasks.create_project("Гамма")
    assert "Гамма" in repos.tasks.projects()  # пустой проект существует
    tid = repos.tasks.create("Задача", status="open", project="Гамма")
    repos.tasks.rename_project("Гамма", "Дельта")
    assert repos.tasks.get(tid)["project"] == "Дельта"
    assert "Гамма" not in repos.tasks.projects()
    repos.tasks.delete_project("Дельта")
    assert repos.tasks.get(tid)["project"] is None


def test_subtasks_links_search_and_delete(repos):
    parent = repos.tasks.create("Запустить агента", status="open", project="Альфа")
    s1 = repos.tasks.create("Написать ТЗ", status="open")
    s2 = repos.tasks.create("Согласовать доступы", status="done")
    repos.tasks.set_parent(s1, parent)
    repos.tasks.set_parent(s2, parent)
    other = repos.tasks.create("Экономическое обоснование", status="open")
    repos.tasks.add_link(parent, other)
    repos.tasks.add_link(other, parent)  # дубль не создаётся

    assert len(repos.tasks.subtasks(parent)) == 2
    assert repos.tasks.subtask_counts()[parent] == (2, 1)
    assert [t["id"] for t in repos.tasks.linked_tasks(parent)] == [other]
    # подзадачи не показываются на доске верхнего уровня
    board = repos.tasks.board()
    ids = [t["id"] for col in board.values() for t in col]
    assert s1 not in ids and parent in ids
    # поиск
    found = repos.tasks.board(q="обоснование")
    assert [t["id"] for t in found["open"]] == [other]
    # фильтр мои/чужие
    repos.tasks.create("Чужая задача", status="open", assignee="Пётр Иванов")
    others = repos.tasks.board(assignee_mode="others")
    assert [t["title"] for t in others["open"]] == ["Чужая задача"]
    # удаление: подзадачи отвязываются, связи чистятся
    repos.tasks.delete(parent)
    assert repos.tasks.get(parent) is None
    assert repos.tasks.get(s1)["parent_id"] is None
    assert repos.tasks.linked_tasks(other) == []


def test_attachment_fts_fuzzy(repos, email_task_request):
    repos.emails.upsert(email_task_request)
    repos.attachments.upsert(email_task_request.message_id, "Смета_проекта_Альфа.xlsx",
                             ".xlsx", 100, "C:/x/смета.xlsx",
                             "Позиция Сумма Работы по автоматизации склада", "parsed")
    # префиксный (нечёткий) поиск по имени и по содержимому
    assert repos.attachments.library(query="смет")
    assert repos.attachments.library(query="автоматизац")
    assert not repos.attachments.library(query="несуществующее")
