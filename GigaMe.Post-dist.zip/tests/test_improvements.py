"""Тесты улучшений: дроссель LLM, роутер намерений, дайджест, поправки."""

import threading
import time

from gigapost.agent.router import is_action
from gigapost.digest import build_digest
from gigapost.llm.throttle import PriorityGate


def test_priority_gate_orders_by_priority():
    gate = PriorityGate(min_interval=0)
    order: list[str] = []
    release_first = threading.Event()

    def holder():
        gate.acquire(1)
        release_first.wait(2)
        order.append("holder")
        gate.release()

    def worker(name, prio):
        gate.acquire(prio)
        order.append(name)
        gate.release()

    t0 = threading.Thread(target=holder)
    t0.start()
    time.sleep(0.05)
    # пока ворота заняты, встают в очередь: низкий приоритет первым по времени,
    # высокий — вторым; выйти должен высокий раньше
    t_low = threading.Thread(target=worker, args=("low", 3))
    t_low.start()
    time.sleep(0.05)
    t_high = threading.Thread(target=worker, args=("high", 0))
    t_high.start()
    time.sleep(0.05)
    release_first.set()
    for t in (t0, t_low, t_high):
        t.join(3)
    assert order == ["holder", "high", "low"]


def test_priority_gate_reentrant():
    """Вложенный захват тем же потоком не должен дедлочить
    (embed_query -> embed_documents у langchain)."""
    gate = PriorityGate(min_interval=0)
    gate.acquire(3)
    gate.acquire(3)   # вложенный — раньше здесь был вечный дедлок
    gate.release()
    gate.release()
    # ворота свободны — другой захват проходит
    done = []

    def other():
        gate.acquire(0)
        done.append(True)
        gate.release()

    t = threading.Thread(target=other)
    t.start()
    t.join(2)
    assert done == [True]


def test_gigachat_auth_kwargs(monkeypatch):
    """Публичный API — OAuth-ключ; корп-контур (cert_file задан) — mTLS без ключа."""
    from gigapost.config import settings

    monkeypatch.setattr(settings, "gigachat_cert_file", "")
    monkeypatch.setattr(settings, "gigachat_base_url", "")
    kw = settings.gigachat_auth_kwargs()
    assert "credentials" in kw and "cert_file" not in kw and "base_url" not in kw

    monkeypatch.setattr(settings, "gigachat_cert_file", "C:/certs/client.crt")
    monkeypatch.setattr(settings, "gigachat_key_file", "C:/certs/client.key")
    monkeypatch.setattr(settings, "gigachat_base_url",
                        "https://gigachat-ift.sberdevices.delta.sbrf.ru/v1")
    kw = settings.gigachat_auth_kwargs()
    assert kw["cert_file"] == "C:/certs/client.crt"
    assert kw["key_file"] == "C:/certs/client.key"
    assert kw["base_url"].endswith("/v1")
    assert "credentials" not in kw and "scope" not in kw


def test_model_env_override(monkeypatch):
    """GIGACHAT_MODEL перекрывает YAML для LLM-ролей (но не эмбеддинги),
    GIGACHAT_MODEL_<ROLE> — сильнее общего."""
    from gigapost.config import settings

    monkeypatch.setattr(settings, "gigachat_model", "")
    monkeypatch.setattr(settings, "gigachat_model_chat", "")
    assert settings.resolve_model("chat") == settings.models.chat

    monkeypatch.setattr(settings, "gigachat_model", "GigaChat-Ultra")
    assert settings.resolve_model("chat") == "GigaChat-Ultra"
    assert settings.resolve_model("classify") == "GigaChat-Ultra"
    assert settings.resolve_model("embeddings") == settings.models.embeddings

    monkeypatch.setattr(settings, "gigachat_model_chat", "GigaChat-2-Max")
    assert settings.resolve_model("chat") == "GigaChat-2-Max"
    assert settings.resolve_model("extract") == "GigaChat-Ultra"


def test_reply_templates_and_feedback(repos, email_task_request, monkeypatch):
    """Шаблоны ответов грузятся; 👍-черновики и указание шаблона попадают в промпт."""
    from types import SimpleNamespace

    from gigapost.agent.tools import build_reply_draft
    from gigapost.config import load_reply_templates

    tpls = load_reply_templates()
    assert any(t["key"] == "status_request" for t in tpls)
    assert all(t.get("instruction") for t in tpls)

    repos.emails.upsert(email_task_request)
    repos.db.execute(
        "INSERT INTO reply_feedback (message_id, draft, verdict, created_at) "
        "VALUES (?, ?, 'up', '2026-01-01')",
        (email_task_request.message_id, "Добрый день! Эталонный ответ."))

    captured = {}

    class FakeLLM:
        def invoke(self, prompt):
            captured["prompt"] = prompt
            return SimpleNamespace(content="Черновик")

    monkeypatch.setattr("gigapost.llm.factory.get_llm", lambda role: FakeLLM())
    ctx = SimpleNamespace(repos=repos, vectors=None)
    out = build_reply_draft(ctx, email_task_request.message_id,
                            instruction="Запроси статус поставки")
    assert out == "Черновик"
    assert "Эталонный ответ" in captured["prompt"]
    assert "ОСОБОЕ УКАЗАНИЕ" in captured["prompt"]
    assert "Запроси статус поставки" in captured["prompt"]


def test_health_and_gateway_alert(repos, monkeypatch, tmp_path):
    """Снапшот здоровья собирается; молчащий шлюз даёт алерт раз в день."""
    from datetime import datetime, timedelta

    import gigapost.health as h

    repos.settings.set("health:outlook", "ok")
    items = h.snapshot(repos, vectors=None)
    names = {i["name"] for i in items}
    assert "Outlook" in names and "GigaChat" in names

    monkeypatch.setattr("gigapost.outlook.msg_import.DEFAULT_EXPORT_DIR", tmp_path)
    stale = (datetime.now() - timedelta(hours=30)).isoformat()
    repos.settings.set("msg_import:last_file_at", stale)
    monday = datetime(2026, 7, 20, 12, 0)   # будний день
    assert h.check_gateway_stalled(repos, monday) == 1
    assert h.check_gateway_stalled(repos, monday) == 0   # дедуп на день
    saturday = datetime(2026, 7, 25, 12, 0)
    assert h.check_gateway_stalled(repos, saturday) == 0  # выходной — не шумим


def test_conflict_detector(repos, email_task_request, monkeypatch):
    """Кандидаты — сущности с 2+ числовыми заметками; подтверждение → алерт;
    повторно та же группа не проверяется."""
    import gigapost.conflicts as cf

    repos.emails.upsert(email_task_request)
    ent_id = repos.entities.upsert("Акт 7", "topic")
    n1 = repos.notes.create("Сумма акта 7", "Акт №7 на 100,50 руб.", "fact",
                            email_task_request.message_id,
                            email_task_request.conversation_id)
    n2 = repos.notes.create("Сумма акта 7 иная", "Акт №7 на 200,00 руб.", "fact",
                            email_task_request.message_id,
                            email_task_request.conversation_id)
    for nid in (n1, n2):
        repos.db.execute(
            "INSERT OR IGNORE INTO note_links (note_id, entity_id) VALUES (?,?)",
            (nid, ent_id))

    groups = cf.candidate_groups(repos)
    assert groups and groups[0]["entity_id"] == ent_id

    monkeypatch.setattr(cf, "structured_call",
                        lambda llm, schema, prompt: schema(
                            is_conflict=True, description="Разные суммы акта №7"))
    monkeypatch.setattr("gigapost.llm.factory.get_llm", lambda role: None)
    stats = cf.scan(repos)
    assert stats == {"checked": 1, "conflicts": 1}
    assert any(a["kind"] == "knowledge_conflict"
               for a in repos.alerts.list_active(limit=10))
    # группа помечена проверенной — второй раз не зовём LLM
    assert cf.scan(repos) == {"checked": 0, "conflicts": 0}


def test_mentions_dedup_by_message(repos, email_task_request):
    """Письмо с тремя ролями (sender/recipient/mentioned) — одна строка упоминаний."""
    repos.emails.upsert(email_task_request)
    ent_id = repos.entities.upsert("Дубров Антон", "person")
    for role in ("sender", "recipient", "mentioned"):
        repos.db.execute(
            "INSERT OR IGNORE INTO entity_mentions (entity_id, message_id, role) "
            "VALUES (?,?,?)", (ent_id, email_task_request.message_id, role))
    mentions = repos.entities.mentions_for(ent_id, limit=10)
    assert len(mentions) == 1


def test_dossier_stale_and_refresh(repos, email_task_request, monkeypatch):
    """Досье считается устаревшим при новых упоминаниях и обновляется."""
    import gigapost.dossier as dm

    repos.emails.upsert(email_task_request)
    ent_id = repos.entities.upsert("Вектор", "org")
    repos.db.execute(
        "INSERT OR IGNORE INTO entity_mentions (entity_id, message_id, role) "
        "VALUES (?,?,'mentioned')", (ent_id, email_task_request.message_id))
    repos.db.execute(
        "INSERT OR IGNORE INTO entity_mentions (entity_id, message_id, role) "
        "VALUES (?,?,'sender')", (ent_id, email_task_request.message_id))

    stale = dm.stale_entities(repos)
    assert any(s["id"] == ent_id for s in stale)

    monkeypatch.setattr(dm, "structured_call",
                        lambda llm, schema, prompt: schema(
                            summary="ООО Вектор — поставщик, ждём КП."))
    monkeypatch.setattr("gigapost.llm.factory.get_llm", lambda role: None)
    d = dm.refresh_dossier(repos, ent_id)
    assert d and "Вектор" in d["summary"]
    assert not any(s["id"] == ent_id for s in dm.stale_entities(repos))


def test_registry_backfill_and_rows(repos, email_task_request, monkeypatch):
    """Фоновое извлечение заполняет doc_facts; фильтры реестра работают."""
    import gigapost.docs.reconcile as rec
    from gigapost.llm.schemas import DocFacts

    repos.emails.upsert(email_task_request)
    repos.attachments.upsert(email_task_request.message_id, "акт_7.pdf", ".pdf",
                             10, "C:/x/акт_7.pdf", "Акт №7 ООО Вектор", "parsed")
    monkeypatch.setattr(rec, "structured_call",
                        lambda llm, schema, prompt: DocFacts(
                            doc_type="акт", number="7", amount="500,00",
                            counterparty="ООО Вектор"))
    monkeypatch.setattr("gigapost.llm.factory.get_llm", lambda role: None)

    assert rec.backfill_doc_facts(repos) == 1
    assert rec.backfill_doc_facts(repos) == 0   # всё разобрано

    rows = rec.registry_rows(repos)
    assert rows and rows[0]["number"] == "7"
    assert rec.registry_rows(repos, q="Вектор")
    assert rec.registry_rows(repos, doc_type="акт")
    assert not rec.registry_rows(repos, doc_type="договор")


def test_thread_summary_and_context(repos, email_task_request, monkeypatch):
    """Мяч на чьей стороне — детерминированно; кэш резюме инвалидируется
    новым письмом; панель контекста собирает связанное."""
    import dataclasses
    from datetime import datetime, timedelta

    import gigapost.summaries as sm

    e = email_task_request
    e.conversation_id = "conv-sum"
    e.received_at = (datetime.now() - timedelta(days=2)).isoformat()
    repos.emails.upsert(e)
    emails = [dict(r) for r in repos.db.query(
        "SELECT * FROM emails WHERE conversation_id='conv-sum' ORDER BY received_at")]

    ball = sm.ball_side(emails)
    assert ball["side"] == "us" and "2 дн" in ball["text"]

    monkeypatch.setattr(sm, "structured_call",
                        lambda llm, schema, prompt: schema(
                            summary="Обсуждаем отчёт", waiting_for="отчёт от Иванова"))
    monkeypatch.setattr("gigapost.llm.factory.get_llm", lambda role: None)
    cached = sm.refresh(repos, "conv-sum", emails)
    assert "Обсуждаем отчёт" in cached["summary"] and "Ждём" in cached["summary"]
    assert not sm.is_stale(cached, emails)

    newer = dataclasses.replace(e, message_id="m2-sum",
                                received_at=datetime.now().isoformat())
    repos.emails.upsert(newer)
    emails2 = emails + [{"received_at": newer.received_at}]
    assert sm.is_stale(cached, emails2)

    repos.tasks.create("Задача треда", status="open",
                       source_message_id=e.message_id)
    ctx = sm.email_context(repos, dict(repos.emails.get(e.message_id)))
    assert ctx["thread_count"] == 2
    assert any(t["title"] == "Задача треда" for t in ctx["tasks"])


def test_focus_and_sla(repos, email_task_request):
    """Скоринг фокуса: вопрос+ожидание поднимают письмо; ответ в треде убирает.
    SLA создаёт алерт по неотвеченному вопросу старше порога."""
    from datetime import datetime, timedelta

    from gigapost.focus import focus_emails, sla_check

    e = email_task_request
    e.conversation_id = "conv-focus"
    e.subject = "Согласуете спецификацию?"
    e.body_text = "Коллеги, прошу согласовать спецификацию до пятницы. Срок поджимает."
    e.received_at = (datetime.now() - timedelta(days=4)).isoformat()
    repos.emails.upsert(e)

    focus = focus_emails(repos)
    assert focus and focus[0]["message_id"] == e.message_id
    assert focus[0]["_score"] >= 3

    stats = sla_check(repos)
    assert stats["sla_unanswered"] == 1
    assert sla_check(repos)["sla_unanswered"] == 0  # дедуп

    # ответили в треде — из фокуса пропадает
    import dataclasses
    reply = dataclasses.replace(e, message_id="reply-1", folder="Sent",
                                received_at=datetime.now().isoformat())
    repos.emails.upsert(reply)
    assert not any(f["message_id"] == e.message_id for f in focus_emails(repos))


def test_doccheck_without_docs(repos):
    """Сверка на пустом треде и треде без документов не зовёт LLM."""
    from gigapost.docs.reconcile import check_conversation, last_check

    assert "нет писем" in check_conversation(repos, "no-such-conv")
    assert last_check(repos, "no-such-conv") is None


def test_doccheck_report_saved(repos, email_task_request, monkeypatch):
    """Реквизиты кэшируются в doc_facts, отчёт — в doc_checks."""
    import gigapost.docs.reconcile as rec
    from gigapost.llm.schemas import DocCheckResult, DocFacts

    email_task_request.conversation_id = "conv-doc"
    repos.emails.upsert(email_task_request)
    repos.attachments.upsert(email_task_request.message_id, "акт_1.docx", ".docx",
                             100, "C:/x/акт_1.docx", "Акт №1 от 2026-01-10 на 100,50",
                             "parsed")
    repos.attachments.upsert(email_task_request.message_id, "заявка_10.docx", ".docx",
                             100, "C:/x/заявка_10.docx", "Заявка №10 на 200,00",
                             "parsed")

    calls = {"n": 0}

    def fake_structured(llm, schema, prompt):
        calls["n"] += 1
        if schema is DocFacts:
            return DocFacts(doc_type="акт", number="1", amount="100,50")
        return DocCheckResult(summary="Всё сходится", discrepancies=[])

    monkeypatch.setattr(rec, "structured_call", fake_structured)
    monkeypatch.setattr("gigapost.llm.factory.get_llm", lambda role: None)

    report = check = rec.check_conversation(repos, "conv-doc")
    assert "Документы комплекта" in report and "Всё сходится" in report
    saved = rec.last_check(repos, "conv-doc")
    assert saved and "акт_1.docx" in saved["report"]
    # повторная сверка берёт реквизиты из кэша: только 1 вызов сравнения
    before = calls["n"]
    rec.check_conversation(repos, "conv-doc")
    assert calls["n"] == before + 1


def test_fix_mojibake():
    from gigapost.outlook.msg_import import _fix_mojibake

    broken = ("Ìàêñ, ïðèâåò! Ñïàñèáî, ÷òî ïðåäëîæèëà ñâîþ âåðñèþ, "
              "îíà äåéñòâèòåëüíî ìîæåò îáðàáàòûâàòü ñðàçó áîëüøîé ìàññèâ ñòðîê")
    fixed = _fix_mojibake(broken)
    assert fixed.startswith("Макс, привет!")
    assert "предложила" in fixed

    normal = "Обычное русское письмо про закупки и Форму 3, ничего чинить не надо"
    assert _fix_mojibake(normal) == normal
    english = "Regular English message about procurement, nothing to fix here"
    assert _fix_mojibake(english) == english
    assert _fix_mojibake("") == ""


def test_meeting_transcript_pipeline(repos, tmp_path, monkeypatch):
    """Транскрипт → протокол-документ в emails, поручения — черновиками задач."""
    import gigapost.meeting_notes as mn
    from gigapost.knowledge.graph_store import KnowledgeGraph
    from gigapost.llm.schemas import NotesResult

    transcript = tmp_path / "2026-07-20_статус_GigaNetwork.txt"
    transcript.write_text("Обсудили статус. " * 20, encoding="utf-8")

    def fake_structured(llm, schema, prompt):
        if schema is mn.MeetingProtocol:
            return mn.MeetingProtocol(
                summary="Обсудили статус GigaNetwork.",
                decisions=["Согласовать бюджет до конца месяца"],
                tasks=[mn.MeetingTask(title="Прислать смету", assignee="Иванов",
                                      due_date="2026-07-25"),
                       mn.MeetingTask(title="Согласовать ТЗ", assignee="я")],
                open_questions=["Сроки поставки"])
        return NotesResult(notes=[])

    class FakeLLM:
        def invoke(self, prompt):
            from types import SimpleNamespace
            return SimpleNamespace(content="- конспект")

    monkeypatch.setattr(mn, "structured_call", fake_structured)
    monkeypatch.setattr("gigapost.llm.factory.get_llm", lambda role: FakeLLM())

    kg = KnowledgeGraph(repos)
    result = mn.process_transcript(repos, kg, None, transcript)
    assert result["ok"] and result["tasks"] == 2

    row = repos.emails.get(result["message_id"])
    assert row and row["folder"] == "Протоколы встреч"
    assert "Согласовать бюджет" in row["body_text"]
    assert row["received_at"].startswith("2026-07-20")   # дата из имени файла

    drafts = repos.tasks.list("draft", limit=10)
    titles = {t["title"] for t in drafts}
    assert "Прислать смету" in titles and "Согласовать ТЗ" in titles
    ivanov = next(t for t in drafts if t["title"] == "Прислать смету")
    assert ivanov["assignee"] == "Иванов" and ivanov["due_date"] == "2026-07-25"


def test_gigachat_config_error(monkeypatch, tmp_path):
    """Понятная ошибка при битых путях сертификатов; None когда всё на месте."""
    from gigapost.config import settings

    monkeypatch.setattr(settings, "gigachat_cert_file", "C:/нет/такого.crt")
    monkeypatch.setattr(settings, "gigachat_key_file", "C:/нет/такого.key")
    err = settings.gigachat_config_error()
    assert err and "GIGACHAT_CERT_FILE" in err

    crt = tmp_path / "c.crt"
    key = tmp_path / "c.key"
    crt.write_text("x")
    key.write_text("x")
    monkeypatch.setattr(settings, "gigachat_cert_file", str(crt))
    monkeypatch.setattr(settings, "gigachat_key_file", str(key))
    assert settings.gigachat_config_error() is None

    monkeypatch.setattr(settings, "gigachat_cert_file", "")
    monkeypatch.setattr(settings, "gigachat_credentials", "")
    assert "Не задан" in settings.gigachat_config_error()


def test_process_pending(repos, email_task_request, monkeypatch):
    """Дообработка: письма без processed_at идут в пайплайн, с — нет."""
    from datetime import datetime, timedelta

    from gigapost.outlook.msg_import import process_pending

    repos.emails.upsert(email_task_request)
    repos.db.execute("UPDATE emails SET received_at=?, processed_at=NULL "
                     "WHERE message_id=?",
                     (datetime.now().isoformat(), email_task_request.message_id))

    invoked = []

    class FakeGraph:
        def invoke(self, state):
            invoked.append(state["email"].message_id)

    since = (datetime.now() - timedelta(days=30)).isoformat()
    assert process_pending(repos, FakeGraph(), since) == 1
    assert invoked == [email_task_request.message_id]


def test_import_graph_since_gates_pipeline(tmp_path, repos, monkeypatch):
    """graph_since: свежие письма идут через пайплайн, старые — тихой заливкой."""
    import dataclasses
    from datetime import datetime, timedelta

    import gigapost.outlook.msg_import as mi
    from gigapost.outlook.models import EmailMessage

    base = EmailMessage(
        message_id="", entry_id="", conversation_id="", subject="т",
        sender_name="", sender_email="a@b.c", recipients=[],
        received_at="", body_text="тело", folder="Inbox",
        has_attachments=False, attachment_names=[], attachment_paths=[])
    old = dataclasses.replace(base, message_id="old-1",
                              received_at=(datetime.now()
                                           - timedelta(days=90)).isoformat())
    new = dataclasses.replace(base, message_id="new-1",
                              received_at=datetime.now().isoformat())
    files = {}
    for em in (old, new):
        p = tmp_path / "Inbox" / f"{em.message_id}.msg"
        p.parent.mkdir(exist_ok=True)
        p.write_bytes(b"fake")
        files[str(p)] = em
    monkeypatch.setattr(mi, "parse_msg", lambda path, ad: files[str(path)])

    invoked = []

    class FakeGraph:
        def invoke(self, state):
            invoked.append(state["email"].message_id)

    cutoff = (datetime.now() - timedelta(days=30)).isoformat()
    stats = mi.import_dir(repos, tmp_path, graph=FakeGraph(), graph_since=cutoff)
    assert stats["imported"] == 2
    assert invoked == ["new-1"]   # старое письмо пайплайн не трогал


def test_sent_meeting_responses_skipped(repos, email_task_request, monkeypatch,
                                        tmp_path):
    """Отправленные принятия/приглашения не идут в анализ обещаний,
    обычные отправленные — идут."""
    import dataclasses
    from datetime import datetime

    from gigapost.pipeline.sent import SentProcessor

    now = datetime.now().isoformat()
    meet = dataclasses.replace(
        email_task_request, message_id="sent-meet-1", folder="Sent",
        subject="Принято: Статус ЦС GigaNetwork",
        body_text="Ваше приглашение принято.", received_at=now)
    normal = dataclasses.replace(
        email_task_request, message_id="sent-norm-1", folder="Sent",
        subject="Re: Комплект документов",
        body_text="Пришлю комплект до пятницы.", received_at=now)
    repos.emails.upsert(meet)
    repos.emails.upsert(normal)

    processed = []
    sp = SentProcessor(repos, outlook=None)
    monkeypatch.setattr(sp, "process_email",
                        lambda em: processed.append(em.message_id)
                        or {"promises": 0, "maybe_done": 0})
    # включаем режим файлового шлюза (отправленные берутся из БД)
    monkeypatch.setattr("gigapost.outlook.msg_import.DEFAULT_EXPORT_DIR", tmp_path)
    sp.run_cycle()
    assert processed == ["sent-norm-1"]   # встреча пропущена, обычное — обработано


def test_conversation_from_msg_headers():
    """Треды из .msg: Thread-Index склеивает ответы (общие 22 байта),
    fallback на References/In-Reply-To/своё Message-ID."""
    import base64

    from gigapost.outlook.msg_import import _conversation_from_headers

    class Hdr(dict):
        def get(self, k, default=None):
            return super().get(k, default)

    root22 = b"R" * 22
    parent = Hdr({"Thread-Index": base64.b64encode(root22).decode()})
    child = Hdr({"Thread-Index": base64.b64encode(root22 + b"CHILD").decode()})
    assert (_conversation_from_headers(parent, "a@x") ==
            _conversation_from_headers(child, "b@x"))

    other = Hdr({"Thread-Index": base64.b64encode(b"O" * 22).decode()})
    assert (_conversation_from_headers(parent, "a@x") !=
            _conversation_from_headers(other, "c@x"))

    reply = Hdr({"References": "<root@x> <mid@x>", "In-Reply-To": "<mid@x>"})
    assert _conversation_from_headers(reply, "d@x") == "ref:root@x"
    only_irt = Hdr({"In-Reply-To": "<root@x>"})
    assert _conversation_from_headers(only_irt, "e@x") == "ref:root@x"
    # корневое письмо без заголовков: ответы сошлются на него через References
    assert _conversation_from_headers(Hdr(), "root@x") == "ref:root@x"
    assert _conversation_from_headers(None, "root@x") == "ref:root@x"


def test_msg_import_folder_from_imported_subdir(tmp_path, repos, monkeypatch):
    """При заливке из imported/ метка папки берётся от родителя (_sent_stream),
    а не от служебной подпапки imported."""
    import gigapost.outlook.msg_import as mi
    from gigapost.outlook.models import EmailMessage

    src = tmp_path / "_sent_stream" / "imported" / "письмо.msg"
    src.parent.mkdir(parents=True)
    src.write_bytes(b"fake")

    def fake_parse(path, attachments_dir):
        return EmailMessage(
            message_id="msgfile:re1", entry_id="", conversation_id="",
            subject="Тест", sender_name="Я", sender_email="me@x.ru",
            recipients=[], received_at="2026-07-20T10:00:00",
            body_text="тело", folder="Inbox", has_attachments=False,
            attachment_names=[], attachment_paths=[])

    monkeypatch.setattr(mi, "parse_msg", fake_parse)
    stats = mi.import_dir(repos, tmp_path, reimport=True)
    assert stats["imported"] == 1
    row = repos.emails.get("msgfile:re1")
    assert row["folder"] == "Sent"


def test_msg_import_helpers():
    from gigapost.outlook.msg_import import _folder_for_subdir, _split_sender

    assert _split_sender("Иванов Иван <i.ivanov@sberbank.ru>") == (
        "Иванов Иван", "i.ivanov@sberbank.ru")
    assert _split_sender("noreply@mail.ru") == ("noreply@mail.ru", "noreply@mail.ru")
    assert _split_sender("") == ("", "")

    assert _folder_for_subdir("_inbox_stream") == "Inbox"
    assert _folder_for_subdir("_sent_stream") == "Sent"
    assert _folder_for_subdir("Sent Items") == "Sent"
    assert _folder_for_subdir("GigaME") == "GigaME"


def test_accepted_lessons_in_prompt(repos, email_task_request, monkeypatch):
    """Принятые задачи — позитивные примеры в промпте извлечения."""
    import dataclasses
    from datetime import datetime

    from gigapost.config import load_taxonomy
    from gigapost.knowledge.graph_store import KnowledgeGraph
    from gigapost.llm.schemas import ExtractionResult
    from gigapost.pipeline.nodes import PipelineNodes

    repos.db.execute(
        "INSERT INTO task_feedback (task_id, title, reason, verdict, created_at) "
        "VALUES (1, 'Согласовать спецификацию с Вектором', '', 'accepted', ?)",
        (datetime.now().isoformat(),))

    captured = {}

    def fake_structured(llm, schema, prompt):
        if schema is ExtractionResult:
            captured["prompt"] = prompt
            return ExtractionResult()
        raise RuntimeError("skip")

    import gigapost.pipeline.nodes as nodes_mod
    monkeypatch.setattr(nodes_mod, "structured_call", fake_structured)
    nodes = PipelineNodes(repos, None, load_taxonomy(), KnowledgeGraph(repos),
                          vectors=None, classify_llm=None, extract_llm=None)
    em = dataclasses.replace(email_task_request, message_id="acc-1")
    repos.emails.upsert(em)
    nodes.extract({"email": em})
    assert "ПРИНЯЛ" in captured["prompt"]
    assert "Согласовать спецификацию с Вектором" in captured["prompt"]


def test_failed_msg_moved_aside(tmp_path, repos, monkeypatch):
    """Битый .msg уезжает в failed/ и не роняет каждый прогон по кругу."""
    import gigapost.outlook.msg_import as mi

    bad = tmp_path / "Inbox" / "битое.msg"
    bad.parent.mkdir()
    bad.write_bytes(b"broken")
    monkeypatch.setattr(mi, "parse_msg",
                        lambda p, ad: (_ for _ in ()).throw(ValueError("codec")))
    stats = mi.import_dir(repos, tmp_path)
    assert stats["errors"] == 1
    assert not bad.exists()
    assert (tmp_path / "Inbox" / "failed" / "битое.msg").exists()
    # повторный прогон файл уже не видит
    assert mi.import_dir(repos, tmp_path)["errors"] == 0


def test_task_archive_lifecycle(repos):
    """Архив: done → archived (кнопкой/массово/по сроку), restore обратно,
    отменённые видны в архиве, cancelled → draft при восстановлении."""
    from datetime import datetime, timedelta

    t_done = repos.tasks.create("Сделана", status="open", project="P1")
    repos.tasks.set_status(t_done, "done")
    t_old = repos.tasks.create("Старая сделана", status="open", project="P1")
    repos.tasks.set_status(t_old, "done")
    old = (datetime.now() - timedelta(days=20)).isoformat()
    repos.db.execute("UPDATE tasks SET completed_at=? WHERE id=?", (old, t_old))
    t_cancelled = repos.tasks.create("Отклонена", status="draft", project="P2")
    repos.tasks.set_status(t_cancelled, "cancelled")

    # авто-архив по сроку: уходит только старая
    assert repos.tasks.archive_done(older_days=14) == 1
    assert repos.tasks.get(t_old)["status"] == "archived"
    assert repos.tasks.get(t_done)["status"] == "done"

    # ручной архив одной + массовый по проекту
    repos.tasks.archive(t_done)
    assert repos.tasks.get(t_done)["status"] == "archived"

    archived = repos.tasks.archived()
    ids = {t["id"] for t in archived}
    assert {t_done, t_old, t_cancelled} <= ids
    # completed_at сохранился при архивации
    assert repos.tasks.get(t_old)["completed_at"] == old

    # на доске их нет
    board = repos.tasks.board("P1")
    assert not board["done"] and not board["open"] and not board["draft"]

    # восстановление
    repos.tasks.set_status(t_done, "done")
    assert repos.tasks.get(t_done)["status"] == "done"


def test_reject_reason_learns(repos, email_task_request, monkeypatch):
    """Причина отклонения: урок в task_feedback, факт в граф (если содержательная),
    и попадание в промпт следующего извлечения."""
    import dataclasses
    from datetime import datetime

    from gigapost.config import load_taxonomy
    from gigapost.knowledge.graph_store import KnowledgeGraph
    from gigapost.llm.schemas import ExtractionResult
    from gigapost.pipeline.nodes import PipelineNodes

    repos.emails.upsert(email_task_request)
    kg = KnowledgeGraph(repos)
    reason = "Оценка ресурсов выполняется ИТ архитектором продукта"

    # имитируем логику task_reject (роут тонкий — проверяем составные части)
    tid = repos.tasks.create("Подготовить оценку ресурсов", status="draft",
                             source_message_id=email_task_request.message_id)
    repos.tasks.set_status(tid, "cancelled")
    repos.db.execute(
        "INSERT INTO task_feedback (task_id, title, reason, created_at) "
        "VALUES (?,?,?,?)",
        (tid, "Подготовить оценку ресурсов", reason, datetime.now().isoformat()))
    kg.add_note(title="Как делается: Подготовить оценку ресурсов", body=reason,
                kind="fact", source_message_id=email_task_request.message_id,
                conversation_id=None)

    notes = repos.notes.for_email(email_task_request.message_id)
    assert any("ИТ архитектором" in n["body"] for n in notes)

    # урок попадает в промпт извлечения
    captured = {}

    def fake_structured(llm, schema, prompt):
        if schema is ExtractionResult:
            captured["prompt"] = prompt
            return ExtractionResult()
        raise RuntimeError("skip notes")

    import gigapost.pipeline.nodes as nodes_mod
    monkeypatch.setattr(nodes_mod, "structured_call", fake_structured)
    nodes = PipelineNodes(repos, None, load_taxonomy(), kg, vectors=None,
                          classify_llm=None, extract_llm=None)
    em = dataclasses.replace(email_task_request, message_id="learn-2")
    repos.emails.upsert(em)
    nodes.extract({"email": em})
    assert "ОТКЛОНИЛ" in captured["prompt"]
    assert "ИТ архитектором продукта" in captured["prompt"]


def test_group_email_not_my_task(repos, email_task_request, monkeypatch):
    """Письмо «Коллеги, …» на 4 адресатов без личного обращения — задача
    не назначается на «я»; с личным обращением — назначается."""
    import dataclasses

    from gigapost.config import load_taxonomy
    from gigapost.knowledge.graph_store import KnowledgeGraph
    from gigapost.llm.schemas import (EmailClassification, ExtractedTask,
                                      ExtractionResult)
    from gigapost.pipeline.nodes import PipelineNodes

    def make_nodes(extraction):
        import gigapost.pipeline.nodes as nodes_mod

        calls = iter([extraction])
        monkeypatch.setattr(
            nodes_mod, "structured_call",
            lambda llm, schema, prompt: (
                next(calls) if schema is ExtractionResult
                else EmailClassification(category="Проекты", importance=3,
                                         requires_action=True, summary="s")))
        kg = KnowledgeGraph(repos)
        return PipelineNodes(repos, None, load_taxonomy(), kg, vectors=None,
                             classify_llm=None, extract_llm=None)

    group = dataclasses.replace(
        email_task_request, message_id="grp-1",
        recipients=["a@x.ru", "b@x.ru", "c@x.ru", "me@x.ru"],
        body_text="Коллеги, прошу прислать оценку ФЭ и обоснование.")
    repos.emails.upsert(group)
    extraction = ExtractionResult(tasks=[ExtractedTask(title="Оценка ФЭ")])
    nodes = make_nodes(extraction)
    out = nodes.extract({"email": group})
    task = out["extraction"].tasks[0]
    assert task.assignee == "другое"
    assert "группе" in (task.assignee_name or "")

    personal = dataclasses.replace(
        group, message_id="grp-2",
        body_text="Коллеги, прошу прислать оценку ФЭ. Максим, это на тебе.")
    repos.emails.upsert(personal)
    extraction2 = ExtractionResult(tasks=[ExtractedTask(title="Оценка ФЭ")])
    nodes2 = make_nodes(extraction2)
    out2 = nodes2.extract({"email": personal})
    assert out2["extraction"].tasks[0].assignee == "я"


def test_suggest_links(repos):
    """Ссылки-переходы к ответу чата: проект → доска с фильтром, сущность → досье."""
    from gigapost.agent.router import suggest_links

    repos.tasks.create("Задача", status="open", project="TAIra-2")
    ent_id = repos.entities.upsert("GigaNetwork", "project")

    links = suggest_links(repos, "Напиши все открытые задачи по проекту TAIra-2")
    urls = [l["url"] for l in links]
    assert any(u.startswith("/tasks?project=TAIra-2") for u in urls)

    links = suggest_links(repos, "что мы знаем про GigaNetwork?")
    assert any(u == f"/entity/{ent_id}" for u in (l["url"] for l in links))

    links = suggest_links(repos, "что просрочено и кто нам должен?")
    assert any(l["url"] == "/decisions" for l in links)

    assert suggest_links(repos, "привет") == []


def test_intent_router():
    # действия → агент
    assert is_action("Создай задачу про отчёт")
    assert is_action("удали письма из папки Штрафы")
    assert is_action("подготовь черновик ответа")
    assert is_action("запомни, что Бунзя — руководитель")
    # вопросы → RAG-путь
    assert not is_action("Какие у меня открытые задачи?")
    assert not is_action("Почему решили делать своего агента?")
    assert not is_action("кто отвечает за блок Лечение")
    assert not is_action("что мне должны прислать контрагенты")


def test_corrections_few_shot(repos, email_task_request):
    repos.emails.upsert(email_task_request)
    repos.corrections.add(email_task_request.message_id, "Личное", "Проекты")
    examples = repos.corrections.recent_examples()
    assert len(examples) == 1
    assert examples[0]["correct_category"] == "Проекты"
    assert examples[0]["wrong_category"] == "Личное"
    assert "Отчёт" in examples[0]["subject"]


def test_ocr_gating(tmp_path, monkeypatch):
    """Сканы поддерживаются только при ocr.enabled; массовые пути (allow_ocr=False)
    не зовут vision; PDF-скан уходит в OCR при allow_ocr=True."""
    from gigapost.attachments import extractor
    from gigapost.config import settings

    monkeypatch.setattr(settings.ocr, "enabled", False)
    assert not extractor.is_supported("скан.jpg")
    monkeypatch.setattr(settings.ocr, "enabled", True)
    assert extractor.is_supported("скан.jpg")

    scan = tmp_path / "скан.jpg"
    scan.write_bytes(b"\xff\xd8fake")
    called = {"n": 0}
    monkeypatch.setattr("gigapost.attachments.ocr._vision_call",
                        lambda data, name, mime: called.__setitem__("n", called["n"] + 1)
                        or "Акт №9 на 300,00")
    # без allow_ocr (история) — vision не вызывается
    assert extractor.extract_text(scan) is None and called["n"] == 0
    # с allow_ocr (новые письма) — распознаётся
    assert "Акт №9" in extractor.extract_text(scan, allow_ocr=True)
    assert called["n"] == 1


def test_extractor_new_formats(tmp_path):
    """Новые форматы: rtf, html, zip (с поддержанными файлами внутри)."""
    import zipfile

    from gigapost.attachments.extractor import extract_text, is_supported

    for ext in (".rtf", ".xls", ".html", ".zip"):
        assert is_supported(f"файл{ext}")
    assert not is_supported("старый.doc")

    rtf = tmp_path / "письмо.rtf"
    rtf.write_bytes(br"{\rtf1\ansi\ansicpg1251 Akt N7 na summu 100 rub.}")
    assert "Akt N7" in extract_text(rtf)

    html = tmp_path / "форма.html"
    html.write_text("<html><body><h1>Форма 3</h1><p>Сумма 200,00</p></body></html>",
                    encoding="utf-8")
    text = extract_text(html)
    assert "Форма 3" in text and "200,00" in text

    inner_txt = tmp_path / "спецификация.txt"
    inner_txt.write_text("Спецификация №5: Java, 300 руб.", encoding="utf-8")
    archive = tmp_path / "комплект.zip"
    with zipfile.ZipFile(archive, "w") as zf:
        zf.write(inner_txt, "спецификация.txt")
        zf.writestr("картинка.bmp", b"\x00")   # неподдержанное — пропустится
    ztext = extract_text(archive)
    assert "спецификация.txt" in ztext and "Java" in ztext


def test_meeting_invites_filtered(repos, email_task_request):
    """Приглашения на встречи не попадают в кандидаты знаний бэкфилла;
    таксономия не извлекает знания из категории «Встречи»."""
    import dataclasses
    import sys
    from pathlib import Path

    sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
    from backfill import select_candidates

    from gigapost.config import load_taxonomy

    invite = dataclasses.replace(
        email_task_request, message_id="invite-1",
        subject="Приглашение: Статус ЦС GigaNetwork",
        body_text="Когда: 25 июля 2026 г. 15:00. Подключиться в браузере по ссылке "
                  "https://jazz.sberbank.ru/xyz. Номер конференции: 123-456. " * 3)
    repos.emails.upsert(invite)
    assert not any(c["message_id"] == "invite-1" for c in select_candidates(repos))

    tax = load_taxonomy()
    meetings = tax.get("Встречи")
    assert meetings is not None and meetings.extract is False
    for subj in ("Принято: Статус проекта", "Отменено: Статус ЦС",
                 "Отмена: синк по бюджету", "Cancelled: Weekly sync",
                 "Перенос: обсуждение Формы 3", "Отклонено: демо GigaMe",
                 "Предварительно принято: синк", "Условно принято: статус",
                 "Предложено новое время: встреча по СЗЗ",
                 "Declined: budget review", "New Time Proposed: sync"):
        assert tax.apply_hard_rules("x@sberbank.ru", subj, "") == "Встречи", subj
    assert tax.apply_hard_rules("x@sberbank.ru", "Комплект документов",
                                "Направляю акт №7") is None


def test_weekly_report(repos, monkeypatch):
    """Недельный отчёт: сделанное/новое/застрявшее по проектам + мяч сторон."""
    from datetime import datetime, timedelta

    from gigapost.digest import build_weekly

    monkeypatch.setattr("gigapost.llm.factory.get_llm",
                        lambda role: (_ for _ in ()).throw(RuntimeError("нет LLM")))
    old = (datetime.now() - timedelta(days=10)).isoformat()
    tid = repos.tasks.create("Старая застрявшая", status="open", project="Тайга")
    repos.db.execute("UPDATE tasks SET created_at=? WHERE id=?", (old, tid))
    repos.tasks.create("Свежая задача", status="open", project="Тайга")
    did = repos.tasks.create("Сделанная", status="done", project="Тайга")
    repos.db.execute("UPDATE tasks SET completed_at=? WHERE id=?",
                     (datetime.now().isoformat(), did))
    repos.agreements.create("Прислать КП", counterparty="Вектор",
                            direction="they_owe", source_message_id=None,
                            conversation_id=None, due_date=None)

    body = build_weekly(repos)
    assert "Тайга" in body
    assert "Сделанная" in body and "Свежая задача" in body
    assert "Старая застрявшая" in body
    assert "Мяч у контрагентов" in body and "Прислать КП" in body
    saved = repos.db.query_one(
        "SELECT * FROM digests WHERE day LIKE '%-W%' ORDER BY id DESC LIMIT 1")
    assert saved is not None


def test_digest_builds_without_llm(repos, email_task_request, monkeypatch):
    # без GigaChat (роняем LLM-резюме) дайджест всё равно собирается
    monkeypatch.setattr("gigapost.llm.factory.get_llm",
                        lambda role: (_ for _ in ()).throw(RuntimeError("нет LLM")))
    repos.emails.upsert(email_task_request)
    repos.tasks.create("Просроченная", status="open", due_date="2020-01-01")
    body = build_digest(repos)
    assert "Дайджест" in body
    assert "просрочено" in body
    saved = repos.digests.latest()
    assert saved and "Дайджест" in saved["body"]


# ---------------------------------------------------------------------------
# Перекрёстные ссылки алертов, полные перечисления, документ в чате, источники
# ---------------------------------------------------------------------------

def _ctx(repos):
    from types import SimpleNamespace
    return SimpleNamespace(repos=repos, vectors=None)


def test_alert_url_targets(repos, email_task_request):
    """Алерт ведёт к своему объекту: задача, письмо (rowid), тред, досье."""
    from gigapost.web.routes.dashboard import alert_url

    ctx = _ctx(repos)
    assert alert_url(ctx, {"kind": "task_maybe_done", "ref_table": "tasks",
                           "ref_id": 7}) == "/tasks/7"
    assert alert_url(ctx, {"kind": "knowledge_conflict", "ref_table": "entities",
                           "ref_id": 3}) == "/entity/3"

    repos.emails.upsert(email_task_request)
    row = repos.db.query_one("SELECT rowid FROM emails WHERE message_id=?",
                             (email_task_request.message_id,))
    url = alert_url(ctx, {"kind": "sla_unanswered", "ref_table": "emails",
                          "ref_id": row["rowid"]})
    assert url == f"/emails/{email_task_request.message_id}"

    aid = repos.agreements.create(
        "Прислать акт", counterparty="Вектор", direction="they_owe",
        source_message_id=email_task_request.message_id,
        conversation_id="conv-42", due_date=None)
    assert alert_url(ctx, {"kind": "followup_needed", "ref_table": "agreements",
                           "ref_id": aid}) == "/threads/conv-42"
    # неизвестное — просто без ссылки, не падаем
    assert alert_url(ctx, {"kind": "gateway_stalled", "ref_table": None,
                           "ref_id": None}) is None


def test_enumeration_detection():
    from gigapost.agent.router import is_enumeration

    assert is_enumeration("приведи ФИО и логины кому был запрошен доступ к GigaMe")
    assert is_enumeration("перечисли всех контрагентов по проекту")
    assert is_enumeration("полный список писем от Смирнова")
    assert not is_enumeration("что просрочено?")
    assert not is_enumeration("какой статус по Тайге?")


def test_enumeration_full_sweep(repos, email_task_request, monkeypatch):
    """Из 12 писем-заявок в ответ попадают все 12 человек, а не top-k."""
    import dataclasses
    import re as _re

    from gigapost.agent.router import iter_enumeration

    for i in range(12):
        repos.emails.upsert(dataclasses.replace(
            email_task_request, message_id=f"acc-{i}", conversation_id=f"c-{i}",
            subject=f"Заявка на доступ №{i}",
            body_text=f"Прошу предоставить доступ к системе GigaMe для "
                      f"Иванов Иван {i} (логин ivanov{i})."))

    class FakeLLM:
        def invoke(self, prompt):
            from types import SimpleNamespace
            found = _re.findall(r"для (Иванов Иван \d+) \(логин (\w+)\)", prompt)
            lines = [f"{fio} — {login}" for fio, login in found] or ["НЕТ"]
            return SimpleNamespace(content="\n".join(lines))

    monkeypatch.setattr("gigapost.llm.factory.get_llm", lambda role: FakeLLM())

    events = list(iter_enumeration(
        _ctx(repos), "приведи ФИО и логины всех, кому запрошен доступ к GigaMe"))
    answer = events[-1]["text"]
    assert answer is not None
    for i in range(12):
        assert f"ivanov{i}" in answer
    assert "Найдено записей: 12" in answer


def test_answer_question_sources_and_uploaded_doc(repos, email_task_request,
                                                  monkeypatch):
    """Ответ RAG собирает ссылки-источники, приложенный документ попадает в промпт."""
    from gigapost.agent.router import answer_question

    repos.emails.upsert(email_task_request)
    repos.notes.create("Факт о ГигаМе", "Доступ выдаёт СБ", "fact",
                       email_task_request.message_id, None)

    captured = {}

    class FakeLLM:
        def invoke(self, prompt):
            from types import SimpleNamespace
            captured["prompt"] = prompt
            return SimpleNamespace(content="ответ")

    monkeypatch.setattr("gigapost.llm.factory.get_llm", lambda role: FakeLLM())

    sources: list[dict] = []
    # вопрос фразово находит заметку через FTS (поиск - точной фразой)
    answer = answer_question(
        _ctx(repos), "Доступ выдаёт СБ",
        extra_context="[приложенный документ «план.docx»]\nСодержимое плана",
        sources=sources)
    assert answer == "ответ"
    assert "приложенный документ" in captured["prompt"]
    assert "Содержимое плана" in captured["prompt"]
    urls = [s["url"] for s in sources]
    assert f"/emails/{email_task_request.message_id}" in urls


def test_uploaded_docs_block(repos):
    """Документ из chat_uploads попадает в контекст своего треда (и только его)."""
    from gigapost.agent.deep_agent import _uploaded_docs

    repos.db.execute(
        "INSERT INTO chat_uploads (thread_id, filename, text, status, created_at) "
        "VALUES ('t1', 'смета.xlsx', 'Итого: 500 000 руб.', 'parsed', '2026-07-23')")
    repos.db.execute(
        "INSERT INTO chat_uploads (thread_id, filename, text, status, created_at) "
        "VALUES ('t2', 'другое.docx', 'чужой тред', 'parsed', '2026-07-23')")

    block = _uploaded_docs(_ctx(repos), "t1")
    assert "смета.xlsx" in block and "500 000" in block
    assert "чужой" not in block
    assert _uploaded_docs(_ctx(repos), "t3") == ""


def test_enum_merge_duplicates():
    """«Максим» + «Максим Железнов» + «… — гендиректор» → одна строка с ролью;
    у повторов с разными уточнениями остаётся первое (самое релевантное)."""
    from gigapost.agent.router import _merge_enum_items

    merged = _merge_enum_items([
        "Алексей Тихомиров",
        "Тимур Зорин",
        "Максим",
        "Тимур Зорин — руководитель HR",
        "Алексей Тихомиров — руководитель блока Лечение",
        "Максим Железнов — генеральный директор центра ТАЙГА",
        "Владимир Рюмин — руководитель службы безопасности",
        "Максим Железнов",
        "Владимир Рюмин — фиксирует кибератаки",
        "Тимур",
    ])
    assert merged == [
        "Алексей Тихомиров — руководитель блока Лечение",
        "Тимур Зорин — руководитель HR",
        "Максим Железнов — генеральный директор центра ТАЙГА",
        "Владимир Рюмин — руководитель службы безопасности",
    ]

    # неоднозначное короткое имя (два кандидата) не сливается наугад
    assert _merge_enum_items([
        "Иванов", "Иванов Пётр — логист", "Иванов Сидор — юрист",
    ]) == ["Иванов", "Иванов Пётр — логист", "Иванов Сидор — юрист"]


def test_email_dismiss(repos, email_task_request):
    """Скрытое письмо уходит из recent/поиска/фокуса, но остаётся в БД."""
    import dataclasses

    from gigapost.focus import _candidates

    repos.emails.upsert(email_task_request)
    repos.emails.upsert(dataclasses.replace(
        email_task_request, message_id="keep-1", conversation_id="c-keep",
        subject="Оставить это письмо"))
    mid = email_task_request.message_id
    repos.emails.set_dismissed(mid, True)

    assert mid not in [e["message_id"] for e in repos.emails.recent()]
    assert mid not in [e["message_id"] for e in repos.emails.search_fts(
        email_task_request.subject)]
    assert mid not in [e["message_id"] for e in _candidates(repos, days=3650)]
    assert repos.emails.get(mid) is not None          # в БД и графе живо
    assert repos.emails.count_dismissed() == 1
    assert [e["message_id"] for e in repos.emails.dismissed()] == [mid]

    repos.emails.set_dismissed(mid, False)
    assert mid in [e["message_id"] for e in repos.emails.recent()]


def test_note_crud_relink(repos):
    """Правка заметки пересобирает [[связи]]; удаление чистит links/relations."""
    from types import SimpleNamespace

    from gigapost.web.routes.threads import _relink_note

    ctx = SimpleNamespace(repos=repos, vectors=None)
    e1 = repos.entities.upsert("Тайга", "project")
    e2 = repos.entities.upsert("Огнева", "person")
    nid = repos.notes.create("Мысль", "Про [[Тайга]] и планы", "fact", None, None)
    repos.notes.link_entity(nid, e1)

    _relink_note(ctx, nid, "Теперь про [[Огнева]] только")
    linked = [x["id"] for x in repos.notes.entities_of(nid)]
    assert linked == [e2]

    # неизвестное [[имя]] создаёт topic-сущность
    _relink_note(ctx, nid, "Про [[Новая Тема]]")
    names = [x["name"] for x in repos.notes.entities_of(nid)]
    assert names == ["Новая Тема"]


def test_entity_upsert_no_crosstype_dupes(repos):
    """«GigaMe» проект и «GigaME» тема — одна сущность, а не дубль графа."""
    a = repos.entities.upsert("GigaMe", "project")
    b = repos.entities.upsert("GigaME", "topic")
    c = repos.entities.upsert("гигами", "topic")   # кириллица — отдельная, ждёт merge --llm
    assert a == b
    assert c != a
    # люди не сливаются с проектами
    p = repos.entities.upsert("Тайга", "person")
    pr = repos.entities.upsert("Тайга", "project")
    assert p != pr


def test_merge_candidates_translit(repos):
    """merge_entities: «гигами» ↔ «GigaMe» становятся кандидатами через транслит."""
    import importlib.util
    from pathlib import Path

    spec = importlib.util.spec_from_file_location(
        "merge_entities", Path(__file__).parent.parent / "scripts" / "merge_entities.py")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)

    repos.entities.upsert("GigaMe", "project")
    repos.entities.upsert("гигами", "topic")
    repos.entities.upsert("Совершенно Другое", "org")
    pairs = mod._candidates(repos)
    names = {tuple(sorted((a["name"], b["name"]))) for a, b in pairs}
    assert ("GigaMe", "гигами") in names


def test_enum_merge_net_placeholder():
    """«ФИО — НЕТ» из фрагмента без логина вливается в полную запись."""
    from gigapost.agent.router import _merge_enum_items

    assert _merge_enum_items([
        "Александров Михаил Сергеевич — НЕТ",
        "Александров Михаил Сергеевич, логин 14043860",
    ]) == ["Александров Михаил Сергеевич, логин 14043860"]


def test_entity_merge_with_dossier(repos):
    """Слияние сущности с досье не падает на FOREIGN KEY (кейс с корпа)."""
    from datetime import datetime

    # дубли времён до защиты в upsert: имена нормализуются по-разному
    src = repos.entities.upsert("Сбер Друг", "topic")
    dst = repos.entities.upsert("СберДруг", "org")
    assert src != dst
    now = datetime.now().isoformat()
    for eid, text in ((src, "досье-src"), (dst, "досье-dst")):
        repos.db.execute(
            "INSERT INTO dossiers (entity_id, summary, updated_at) VALUES (?,?,?)",
            (eid, text, now))
    repos.db.execute(
        "INSERT INTO conflict_checks (group_hash, entity_id, is_conflict, "
        "description, checked_at) VALUES ('h1', ?, 0, '', ?)", (src, now))

    repos.entities.merge(src, dst)   # не должно упасть
    assert repos.entities.get(src) is None
    row = repos.db.query_one("SELECT summary FROM dossiers WHERE entity_id=?", (dst,))
    assert row["summary"] == "досье-dst"          # своё досье dst сохранилось
    assert repos.db.query_one(
        "SELECT COUNT(*) c FROM dossiers WHERE entity_id=?", (src,))["c"] == 0
    assert repos.db.query_one(
        "SELECT entity_id FROM conflict_checks WHERE group_hash='h1'")["entity_id"] == dst

    # и вариант, когда досье есть только у src — оно переезжает к dst
    src2 = repos.entities.upsert("Закуп AI", "org")
    dst2 = repos.entities.upsert("ЗакупAI", "project")
    repos.db.execute(
        "INSERT INTO dossiers (entity_id, summary, updated_at) VALUES (?,?,?)",
        (src2, "единственное досье", now))
    repos.entities.merge(src2, dst2)
    row = repos.db.query_one("SELECT summary FROM dossiers WHERE entity_id=?", (dst2,))
    assert row and row["summary"] == "единственное досье"


def _load_script(name):
    import importlib.util
    from pathlib import Path

    spec = importlib.util.spec_from_file_location(
        name, Path(__file__).parent.parent / "scripts" / f"{name}.py")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def test_auto_merge_is_safe(repos):
    """--auto больше не сливает вложенные имена (авария корпа 2026-07-23)."""
    mod = _load_script("merge_entities")

    repos.entities.upsert("Максим", "person")
    repos.entities.upsert("Гранкин Максим Павлович", "person")
    repos.entities.upsert("AI", "topic")
    repos.entities.upsert("AI-агент Исполнитель", "project")
    a = repos.entities.upsert("GigaMe", "project")

    merged = mod.auto_merge(repos)
    assert merged == 0                       # ничего «похожего» не слито
    assert repos.entities.find_exact("Гранкин Максим Павлович") is not None
    assert repos.entities.find_exact("AI-агент Исполнитель") is not None

    # а одинаковые имена разных типов (легитимный дубль из старой базы)
    repos.db.execute(
        "INSERT INTO entities (name, type, normalized_name, attrs_json) "
        "VALUES ('GigaME', 'topic', 'gigame', '{}')")
    assert mod.auto_merge(repos) == 1
    assert repos.entities.get(a) is not None


def test_repair_merged_entities(repos, tmp_path, monkeypatch):
    """Восстановление: сущности из лога, связи — из [[ссылок]] в заметках."""
    repair = _load_script("repair_merged_entities")

    # до аварии: два Максима, у каждого своя заметка
    hub = repos.entities.upsert("Максим", "person")
    e1 = repos.entities.upsert("Гранкин Максим Павлович", "person")
    n1 = repos.notes.create("Задача Гранкина",
                            "Поручение для [[Гранкин Максим Павлович]]",
                            "fact", None, None)
    repos.notes.link_entity(n1, e1)
    # авария: Гранкина слили в хаб «Максим»
    repos.entities.merge(e1, hub)
    assert repos.entities.find_exact("Гранкин Максим Павлович") is None
    assert [x["id"] for x in repos.notes.entities_of(n1)] == [hub]

    log = tmp_path / "merge_log.txt"
    log.write_text("  'Гранкин Максим Павлович' → 'Максим'\n", encoding="utf-8")

    monkeypatch.setattr(repair, "Database", lambda _: repos.db)
    monkeypatch.setattr(repair.shutil, "copy2", lambda *a, **k: None)
    repair.repair(log, None, dry_run=False)

    e1b = repos.entities.find_exact("Гранкин Максим Павлович")
    assert e1b and e1b["type"] == "person"     # тип угадан по ФИО-паттерну
    assert [x["name"] for x in repos.notes.entities_of(n1)] == [
        "Гранкин Максим Павлович"]             # связь вернулась от хаба к человеку


def test_enumeration_source_labels(repos, email_task_request, monkeypatch):
    """У каждого факта в ответе — источник в 〈скобках〉 (метки [S№])."""
    import dataclasses
    import re as _re

    from gigapost.agent.router import iter_enumeration

    for i in range(10):
        repos.emails.upsert(dataclasses.replace(
            email_task_request, message_id=f"src-{i}", conversation_id=f"sc-{i}",
            subject=f"Доступ GigaMe {i}", sender_name="Кравцова Ольга",
            body_text=f"Прошу предоставить доступ к GigaMe для "
                      f"Петров Пётр {i} (логин 1477{i:04d})."))

    class FakeLLM:
        def invoke(self, prompt):
            from types import SimpleNamespace
            out = []
            for m in _re.finditer(
                    r"\[S(\d+)\][^\n]*?для (Петров Пётр \d+) \(логин (\w+)\)",
                    prompt):
                out.append(f"{m.group(2)} — логин {m.group(3)} [S{m.group(1)}]")
            return SimpleNamespace(content="\n".join(out) or "НЕТ")

    monkeypatch.setattr("gigapost.llm.factory.get_llm", lambda role: FakeLLM())
    events = list(iter_enumeration(
        _ctx(repos), "приведи ФИО и логины всех, кому запрошен доступ к GigaMe"))
    answer = events[-1]["text"]
    assert answer and "Найдено записей: 10" in answer
    # у каждой строки-факта есть читаемый источник
    fact_lines = [l for l in answer.splitlines() if l.startswith("•")]
    assert len(fact_lines) == 10
    assert all("〈письмо" in l and "Кравцова" in l for l in fact_lines)


def test_enumeration_critic_rejects(repos, email_task_request, monkeypatch):
    """Критик отсеивает факты, не подтверждённые фрагментом-источником."""
    import dataclasses
    import re as _re

    from gigapost.agent.router import iter_enumeration

    for i in range(10):
        repos.emails.upsert(dataclasses.replace(
            email_task_request, message_id=f"cr-{i}", conversation_id=f"cc-{i}",
            subject=f"Доступ GigaMe {i}",
            body_text=f"Прошу предоставить доступ к GigaMe для "
                      f"Сидоров Иван {i} (логин 1488{i:04d})."))

    class FakeLLM:
        def invoke(self, prompt):
            from types import SimpleNamespace
            if "Утверждения, извлечённые" in prompt:   # роль критика
                n = len(_re.findall(r"^\d+\. ", prompt, _re.M))
                # подтверждаем всех, кроме «Шахмин» (мусор извлекателя)
                lines = []
                for j in range(1, n + 1):
                    claim = _re.search(rf"^{j}\. (.+)$", prompt, _re.M).group(1)
                    lines.append(f"{j} — {'НЕТ' if 'Шахмин' in claim else 'ДА'}")
                return SimpleNamespace(content="\n".join(lines))
            out = []                                   # роль извлекателя
            for m in _re.finditer(
                    r"\[S(\d+)\][^\n]*?для (Сидоров Иван \d+) \(логин (\w+)\)",
                    prompt):
                out.append(f"{m.group(2)} — логин {m.group(3)} [S{m.group(1)}]")
                if m.group(2).endswith(" 0"):          # извлекатель добавил мусор
                    out.append(f"Шахмин Виталий — архитектор [S{m.group(1)}]")
            return SimpleNamespace(content="\n".join(out) or "НЕТ")

    monkeypatch.setattr("gigapost.llm.factory.get_llm", lambda role: FakeLLM())
    events = list(iter_enumeration(
        _ctx(repos), "приведи ФИО и логины всех, кому запрошен доступ к GigaMe"))
    answer = events[-1]["text"]
    assert "Шахмин" not in answer
    assert "отсеяно критиком: 1" in answer
    assert "Найдено записей: 10" in answer
    assert any("критик" in e.get("name", "") for e in events if e["type"] == "tool")
