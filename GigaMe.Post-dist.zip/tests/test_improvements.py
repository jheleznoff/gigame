"""Тесты улучшений: дроссель LLM, роутер намерений, дайджест, поправки."""

import threading
import time

from gigapost.agent.router import is_action
from gigapost.digest import build_digest
from gigapost.llm.throttle import PriorityGate


def test_priority_gate_orders_by_priority():
    gate = PriorityGate(min_interval=0)
    order: list[str] = []
    release_first = threading.Event()

    def holder():
        gate.acquire(1)
        release_first.wait(2)
        order.append("holder")
        gate.release()

    def worker(name, prio):
        gate.acquire(prio)
        order.append(name)
        gate.release()

    t0 = threading.Thread(target=holder)
    t0.start()
    time.sleep(0.05)
    # пока ворота заняты, встают в очередь: низкий приоритет первым по времени,
    # высокий — вторым; выйти должен высокий раньше
    t_low = threading.Thread(target=worker, args=("low", 3))
    t_low.start()
    time.sleep(0.05)
    t_high = threading.Thread(target=worker, args=("high", 0))
    t_high.start()
    time.sleep(0.05)
    release_first.set()
    for t in (t0, t_low, t_high):
        t.join(3)
    assert order == ["holder", "high", "low"]


def test_priority_gate_reentrant():
    """Вложенный захват тем же потоком не должен дедлочить
    (embed_query -> embed_documents у langchain)."""
    gate = PriorityGate(min_interval=0)
    gate.acquire(3)
    gate.acquire(3)   # вложенный — раньше здесь был вечный дедлок
    gate.release()
    gate.release()
    # ворота свободны — другой захват проходит
    done = []

    def other():
        gate.acquire(0)
        done.append(True)
        gate.release()

    t = threading.Thread(target=other)
    t.start()
    t.join(2)
    assert done == [True]


def test_gigachat_auth_kwargs(monkeypatch):
    """Публичный API — OAuth-ключ; корп-контур (cert_file задан) — mTLS без ключа."""
    from gigapost.config import settings

    monkeypatch.setattr(settings, "gigachat_cert_file", "")
    monkeypatch.setattr(settings, "gigachat_base_url", "")
    kw = settings.gigachat_auth_kwargs()
    assert "credentials" in kw and "cert_file" not in kw and "base_url" not in kw

    monkeypatch.setattr(settings, "gigachat_cert_file", "C:/certs/client.crt")
    monkeypatch.setattr(settings, "gigachat_key_file", "C:/certs/client.key")
    monkeypatch.setattr(settings, "gigachat_base_url",
                        "https://gigachat-ift.sberdevices.delta.sbrf.ru/v1")
    kw = settings.gigachat_auth_kwargs()
    assert kw["cert_file"] == "C:/certs/client.crt"
    assert kw["key_file"] == "C:/certs/client.key"
    assert kw["base_url"].endswith("/v1")
    assert "credentials" not in kw and "scope" not in kw


def test_model_env_override(monkeypatch):
    """GIGACHAT_MODEL перекрывает YAML для LLM-ролей (но не эмбеддинги),
    GIGACHAT_MODEL_<ROLE> — сильнее общего."""
    from gigapost.config import settings

    monkeypatch.setattr(settings, "gigachat_model", "")
    monkeypatch.setattr(settings, "gigachat_model_chat", "")
    assert settings.resolve_model("chat") == settings.models.chat

    monkeypatch.setattr(settings, "gigachat_model", "GigaChat-Ultra")
    assert settings.resolve_model("chat") == "GigaChat-Ultra"
    assert settings.resolve_model("classify") == "GigaChat-Ultra"
    assert settings.resolve_model("embeddings") == settings.models.embeddings

    monkeypatch.setattr(settings, "gigachat_model_chat", "GigaChat-2-Max")
    assert settings.resolve_model("chat") == "GigaChat-2-Max"
    assert settings.resolve_model("extract") == "GigaChat-Ultra"


def test_reply_templates_and_feedback(repos, email_task_request, monkeypatch):
    """Шаблоны ответов грузятся; 👍-черновики и указание шаблона попадают в промпт."""
    from types import SimpleNamespace

    from gigapost.agent.tools import build_reply_draft
    from gigapost.config import load_reply_templates

    tpls = load_reply_templates()
    assert any(t["key"] == "status_request" for t in tpls)
    assert all(t.get("instruction") for t in tpls)

    repos.emails.upsert(email_task_request)
    repos.db.execute(
        "INSERT INTO reply_feedback (message_id, draft, verdict, created_at) "
        "VALUES (?, ?, 'up', '2026-01-01')",
        (email_task_request.message_id, "Добрый день! Эталонный ответ."))

    captured = {}

    class FakeLLM:
        def invoke(self, prompt):
            captured["prompt"] = prompt
            return SimpleNamespace(content="Черновик")

    monkeypatch.setattr("gigapost.llm.factory.get_llm", lambda role: FakeLLM())
    ctx = SimpleNamespace(repos=repos, vectors=None)
    out = build_reply_draft(ctx, email_task_request.message_id,
                            instruction="Запроси статус поставки")
    assert out == "Черновик"
    assert "Эталонный ответ" in captured["prompt"]
    assert "ОСОБОЕ УКАЗАНИЕ" in captured["prompt"]
    assert "Запроси статус поставки" in captured["prompt"]


def test_health_and_gateway_alert(repos, monkeypatch, tmp_path):
    """Снапшот здоровья собирается; молчащий шлюз даёт алерт раз в день."""
    from datetime import datetime, timedelta

    import gigapost.health as h

    repos.settings.set("health:outlook", "ok")
    items = h.snapshot(repos, vectors=None)
    names = {i["name"] for i in items}
    assert "Outlook" in names and "GigaChat" in names

    monkeypatch.setattr("gigapost.outlook.msg_import.DEFAULT_EXPORT_DIR", tmp_path)
    stale = (datetime.now() - timedelta(hours=30)).isoformat()
    repos.settings.set("msg_import:last_file_at", stale)
    monday = datetime(2026, 7, 20, 12, 0)   # будний день
    assert h.check_gateway_stalled(repos, monday) == 1
    assert h.check_gateway_stalled(repos, monday) == 0   # дедуп на день
    saturday = datetime(2026, 7, 25, 12, 0)
    assert h.check_gateway_stalled(repos, saturday) == 0  # выходной — не шумим


def test_conflict_detector(repos, email_task_request, monkeypatch):
    """Кандидаты — сущности с 2+ числовыми заметками; подтверждение → алерт;
    повторно та же группа не проверяется."""
    import gigapost.conflicts as cf

    repos.emails.upsert(email_task_request)
    ent_id = repos.entities.upsert("Акт 7", "topic")
    n1 = repos.notes.create("Сумма акта 7", "Акт №7 на 100,50 руб.", "fact",
                            email_task_request.message_id,
                            email_task_request.conversation_id)
    n2 = repos.notes.create("Сумма акта 7 иная", "Акт №7 на 200,00 руб.", "fact",
                            email_task_request.message_id,
                            email_task_request.conversation_id)
    for nid in (n1, n2):
        repos.db.execute(
            "INSERT OR IGNORE INTO note_links (note_id, entity_id) VALUES (?,?)",
            (nid, ent_id))

    groups = cf.candidate_groups(repos)
    assert groups and groups[0]["entity_id"] == ent_id

    monkeypatch.setattr(cf, "structured_call",
                        lambda llm, schema, prompt: schema(
                            is_conflict=True, description="Разные суммы акта №7"))
    monkeypatch.setattr("gigapost.llm.factory.get_llm", lambda role: None)
    stats = cf.scan(repos)
    assert stats == {"checked": 1, "conflicts": 1}
    assert any(a["kind"] == "knowledge_conflict"
               for a in repos.alerts.list_active(limit=10))
    # группа помечена проверенной — второй раз не зовём LLM
    assert cf.scan(repos) == {"checked": 0, "conflicts": 0}


def test_dossier_stale_and_refresh(repos, email_task_request, monkeypatch):
    """Досье считается устаревшим при новых упоминаниях и обновляется."""
    import gigapost.dossier as dm

    repos.emails.upsert(email_task_request)
    ent_id = repos.entities.upsert("Вектор", "org")
    repos.db.execute(
        "INSERT OR IGNORE INTO entity_mentions (entity_id, message_id, role) "
        "VALUES (?,?,'mentioned')", (ent_id, email_task_request.message_id))
    repos.db.execute(
        "INSERT OR IGNORE INTO entity_mentions (entity_id, message_id, role) "
        "VALUES (?,?,'sender')", (ent_id, email_task_request.message_id))

    stale = dm.stale_entities(repos)
    assert any(s["id"] == ent_id for s in stale)

    monkeypatch.setattr(dm, "structured_call",
                        lambda llm, schema, prompt: schema(
                            summary="ООО Вектор — поставщик, ждём КП."))
    monkeypatch.setattr("gigapost.llm.factory.get_llm", lambda role: None)
    d = dm.refresh_dossier(repos, ent_id)
    assert d and "Вектор" in d["summary"]
    assert not any(s["id"] == ent_id for s in dm.stale_entities(repos))


def test_registry_backfill_and_rows(repos, email_task_request, monkeypatch):
    """Фоновое извлечение заполняет doc_facts; фильтры реестра работают."""
    import gigapost.docs.reconcile as rec
    from gigapost.llm.schemas import DocFacts

    repos.emails.upsert(email_task_request)
    repos.attachments.upsert(email_task_request.message_id, "акт_7.pdf", ".pdf",
                             10, "C:/x/акт_7.pdf", "Акт №7 ООО Вектор", "parsed")
    monkeypatch.setattr(rec, "structured_call",
                        lambda llm, schema, prompt: DocFacts(
                            doc_type="акт", number="7", amount="500,00",
                            counterparty="ООО Вектор"))
    monkeypatch.setattr("gigapost.llm.factory.get_llm", lambda role: None)

    assert rec.backfill_doc_facts(repos) == 1
    assert rec.backfill_doc_facts(repos) == 0   # всё разобрано

    rows = rec.registry_rows(repos)
    assert rows and rows[0]["number"] == "7"
    assert rec.registry_rows(repos, q="Вектор")
    assert rec.registry_rows(repos, doc_type="акт")
    assert not rec.registry_rows(repos, doc_type="договор")


def test_thread_summary_and_context(repos, email_task_request, monkeypatch):
    """Мяч на чьей стороне — детерминированно; кэш резюме инвалидируется
    новым письмом; панель контекста собирает связанное."""
    import dataclasses
    from datetime import datetime, timedelta

    import gigapost.summaries as sm

    e = email_task_request
    e.conversation_id = "conv-sum"
    e.received_at = (datetime.now() - timedelta(days=2)).isoformat()
    repos.emails.upsert(e)
    emails = [dict(r) for r in repos.db.query(
        "SELECT * FROM emails WHERE conversation_id='conv-sum' ORDER BY received_at")]

    ball = sm.ball_side(emails)
    assert ball["side"] == "us" and "2 дн" in ball["text"]

    monkeypatch.setattr(sm, "structured_call",
                        lambda llm, schema, prompt: schema(
                            summary="Обсуждаем отчёт", waiting_for="отчёт от Иванова"))
    monkeypatch.setattr("gigapost.llm.factory.get_llm", lambda role: None)
    cached = sm.refresh(repos, "conv-sum", emails)
    assert "Обсуждаем отчёт" in cached["summary"] and "Ждём" in cached["summary"]
    assert not sm.is_stale(cached, emails)

    newer = dataclasses.replace(e, message_id="m2-sum",
                                received_at=datetime.now().isoformat())
    repos.emails.upsert(newer)
    emails2 = emails + [{"received_at": newer.received_at}]
    assert sm.is_stale(cached, emails2)

    repos.tasks.create("Задача треда", status="open",
                       source_message_id=e.message_id)
    ctx = sm.email_context(repos, dict(repos.emails.get(e.message_id)))
    assert ctx["thread_count"] == 2
    assert any(t["title"] == "Задача треда" for t in ctx["tasks"])


def test_focus_and_sla(repos, email_task_request):
    """Скоринг фокуса: вопрос+ожидание поднимают письмо; ответ в треде убирает.
    SLA создаёт алерт по неотвеченному вопросу старше порога."""
    from datetime import datetime, timedelta

    from gigapost.focus import focus_emails, sla_check

    e = email_task_request
    e.conversation_id = "conv-focus"
    e.subject = "Согласуете спецификацию?"
    e.body_text = "Коллеги, прошу согласовать спецификацию до пятницы. Срок поджимает."
    e.received_at = (datetime.now() - timedelta(days=4)).isoformat()
    repos.emails.upsert(e)

    focus = focus_emails(repos)
    assert focus and focus[0]["message_id"] == e.message_id
    assert focus[0]["_score"] >= 3

    stats = sla_check(repos)
    assert stats["sla_unanswered"] == 1
    assert sla_check(repos)["sla_unanswered"] == 0  # дедуп

    # ответили в треде — из фокуса пропадает
    import dataclasses
    reply = dataclasses.replace(e, message_id="reply-1", folder="Sent",
                                received_at=datetime.now().isoformat())
    repos.emails.upsert(reply)
    assert not any(f["message_id"] == e.message_id for f in focus_emails(repos))


def test_doccheck_without_docs(repos):
    """Сверка на пустом треде и треде без документов не зовёт LLM."""
    from gigapost.docs.reconcile import check_conversation, last_check

    assert "нет писем" in check_conversation(repos, "no-such-conv")
    assert last_check(repos, "no-such-conv") is None


def test_doccheck_report_saved(repos, email_task_request, monkeypatch):
    """Реквизиты кэшируются в doc_facts, отчёт — в doc_checks."""
    import gigapost.docs.reconcile as rec
    from gigapost.llm.schemas import DocCheckResult, DocFacts

    email_task_request.conversation_id = "conv-doc"
    repos.emails.upsert(email_task_request)
    repos.attachments.upsert(email_task_request.message_id, "акт_1.docx", ".docx",
                             100, "C:/x/акт_1.docx", "Акт №1 от 2026-01-10 на 100,50",
                             "parsed")
    repos.attachments.upsert(email_task_request.message_id, "заявка_10.docx", ".docx",
                             100, "C:/x/заявка_10.docx", "Заявка №10 на 200,00",
                             "parsed")

    calls = {"n": 0}

    def fake_structured(llm, schema, prompt):
        calls["n"] += 1
        if schema is DocFacts:
            return DocFacts(doc_type="акт", number="1", amount="100,50")
        return DocCheckResult(summary="Всё сходится", discrepancies=[])

    monkeypatch.setattr(rec, "structured_call", fake_structured)
    monkeypatch.setattr("gigapost.llm.factory.get_llm", lambda role: None)

    report = check = rec.check_conversation(repos, "conv-doc")
    assert "Документы комплекта" in report and "Всё сходится" in report
    saved = rec.last_check(repos, "conv-doc")
    assert saved and "акт_1.docx" in saved["report"]
    # повторная сверка берёт реквизиты из кэша: только 1 вызов сравнения
    before = calls["n"]
    rec.check_conversation(repos, "conv-doc")
    assert calls["n"] == before + 1


def test_fix_mojibake():
    from gigapost.outlook.msg_import import _fix_mojibake

    broken = ("Ìàêñ, ïðèâåò! Ñïàñèáî, ÷òî ïðåäëîæèëà ñâîþ âåðñèþ, "
              "îíà äåéñòâèòåëüíî ìîæåò îáðàáàòûâàòü ñðàçó áîëüøîé ìàññèâ ñòðîê")
    fixed = _fix_mojibake(broken)
    assert fixed.startswith("Макс, привет!")
    assert "предложила" in fixed

    normal = "Обычное русское письмо про закупки и Форму 3, ничего чинить не надо"
    assert _fix_mojibake(normal) == normal
    english = "Regular English message about procurement, nothing to fix here"
    assert _fix_mojibake(english) == english
    assert _fix_mojibake("") == ""


def test_import_graph_since_gates_pipeline(tmp_path, repos, monkeypatch):
    """graph_since: свежие письма идут через пайплайн, старые — тихой заливкой."""
    import dataclasses
    from datetime import datetime, timedelta

    import gigapost.outlook.msg_import as mi
    from gigapost.outlook.models import EmailMessage

    base = EmailMessage(
        message_id="", entry_id="", conversation_id="", subject="т",
        sender_name="", sender_email="a@b.c", recipients=[],
        received_at="", body_text="тело", folder="Inbox",
        has_attachments=False, attachment_names=[], attachment_paths=[])
    old = dataclasses.replace(base, message_id="old-1",
                              received_at=(datetime.now()
                                           - timedelta(days=90)).isoformat())
    new = dataclasses.replace(base, message_id="new-1",
                              received_at=datetime.now().isoformat())
    files = {}
    for em in (old, new):
        p = tmp_path / "Inbox" / f"{em.message_id}.msg"
        p.parent.mkdir(exist_ok=True)
        p.write_bytes(b"fake")
        files[str(p)] = em
    monkeypatch.setattr(mi, "parse_msg", lambda path, ad: files[str(path)])

    invoked = []

    class FakeGraph:
        def invoke(self, state):
            invoked.append(state["email"].message_id)

    cutoff = (datetime.now() - timedelta(days=30)).isoformat()
    stats = mi.import_dir(repos, tmp_path, graph=FakeGraph(), graph_since=cutoff)
    assert stats["imported"] == 2
    assert invoked == ["new-1"]   # старое письмо пайплайн не трогал


def test_sent_meeting_responses_skipped(repos, email_task_request, monkeypatch,
                                        tmp_path):
    """Отправленные принятия/приглашения не идут в анализ обещаний,
    обычные отправленные — идут."""
    import dataclasses
    from datetime import datetime

    from gigapost.pipeline.sent import SentProcessor

    now = datetime.now().isoformat()
    meet = dataclasses.replace(
        email_task_request, message_id="sent-meet-1", folder="Sent",
        subject="Принято: Статус ЦС GigaNetwork",
        body_text="Ваше приглашение принято.", received_at=now)
    normal = dataclasses.replace(
        email_task_request, message_id="sent-norm-1", folder="Sent",
        subject="Re: Комплект документов",
        body_text="Пришлю комплект до пятницы.", received_at=now)
    repos.emails.upsert(meet)
    repos.emails.upsert(normal)

    processed = []
    sp = SentProcessor(repos, outlook=None)
    monkeypatch.setattr(sp, "process_email",
                        lambda em: processed.append(em.message_id)
                        or {"promises": 0, "maybe_done": 0})
    # включаем режим файлового шлюза (отправленные берутся из БД)
    monkeypatch.setattr("gigapost.outlook.msg_import.DEFAULT_EXPORT_DIR", tmp_path)
    sp.run_cycle()
    assert processed == ["sent-norm-1"]   # встреча пропущена, обычное — обработано


def test_conversation_from_msg_headers():
    """Треды из .msg: Thread-Index склеивает ответы (общие 22 байта),
    fallback на References/In-Reply-To/своё Message-ID."""
    import base64

    from gigapost.outlook.msg_import import _conversation_from_headers

    class Hdr(dict):
        def get(self, k, default=None):
            return super().get(k, default)

    root22 = b"R" * 22
    parent = Hdr({"Thread-Index": base64.b64encode(root22).decode()})
    child = Hdr({"Thread-Index": base64.b64encode(root22 + b"CHILD").decode()})
    assert (_conversation_from_headers(parent, "a@x") ==
            _conversation_from_headers(child, "b@x"))

    other = Hdr({"Thread-Index": base64.b64encode(b"O" * 22).decode()})
    assert (_conversation_from_headers(parent, "a@x") !=
            _conversation_from_headers(other, "c@x"))

    reply = Hdr({"References": "<root@x> <mid@x>", "In-Reply-To": "<mid@x>"})
    assert _conversation_from_headers(reply, "d@x") == "ref:root@x"
    only_irt = Hdr({"In-Reply-To": "<root@x>"})
    assert _conversation_from_headers(only_irt, "e@x") == "ref:root@x"
    # корневое письмо без заголовков: ответы сошлются на него через References
    assert _conversation_from_headers(Hdr(), "root@x") == "ref:root@x"
    assert _conversation_from_headers(None, "root@x") == "ref:root@x"


def test_msg_import_folder_from_imported_subdir(tmp_path, repos, monkeypatch):
    """При заливке из imported/ метка папки берётся от родителя (_sent_stream),
    а не от служебной подпапки imported."""
    import gigapost.outlook.msg_import as mi
    from gigapost.outlook.models import EmailMessage

    src = tmp_path / "_sent_stream" / "imported" / "письмо.msg"
    src.parent.mkdir(parents=True)
    src.write_bytes(b"fake")

    def fake_parse(path, attachments_dir):
        return EmailMessage(
            message_id="msgfile:re1", entry_id="", conversation_id="",
            subject="Тест", sender_name="Я", sender_email="me@x.ru",
            recipients=[], received_at="2026-07-20T10:00:00",
            body_text="тело", folder="Inbox", has_attachments=False,
            attachment_names=[], attachment_paths=[])

    monkeypatch.setattr(mi, "parse_msg", fake_parse)
    stats = mi.import_dir(repos, tmp_path, reimport=True)
    assert stats["imported"] == 1
    row = repos.emails.get("msgfile:re1")
    assert row["folder"] == "Sent"


def test_msg_import_helpers():
    from gigapost.outlook.msg_import import _folder_for_subdir, _split_sender

    assert _split_sender("Иванов Иван <i.ivanov@sberbank.ru>") == (
        "Иванов Иван", "i.ivanov@sberbank.ru")
    assert _split_sender("noreply@mail.ru") == ("noreply@mail.ru", "noreply@mail.ru")
    assert _split_sender("") == ("", "")

    assert _folder_for_subdir("_inbox_stream") == "Inbox"
    assert _folder_for_subdir("_sent_stream") == "Sent"
    assert _folder_for_subdir("Sent Items") == "Sent"
    assert _folder_for_subdir("GigaME") == "GigaME"


def test_intent_router():
    # действия → агент
    assert is_action("Создай задачу про отчёт")
    assert is_action("удали письма из папки Штрафы")
    assert is_action("подготовь черновик ответа")
    assert is_action("запомни, что Бунзя — руководитель")
    # вопросы → RAG-путь
    assert not is_action("Какие у меня открытые задачи?")
    assert not is_action("Почему решили делать своего агента?")
    assert not is_action("кто отвечает за блок Лечение")
    assert not is_action("что мне должны прислать контрагенты")


def test_corrections_few_shot(repos, email_task_request):
    repos.emails.upsert(email_task_request)
    repos.corrections.add(email_task_request.message_id, "Личное", "Проекты")
    examples = repos.corrections.recent_examples()
    assert len(examples) == 1
    assert examples[0]["correct_category"] == "Проекты"
    assert examples[0]["wrong_category"] == "Личное"
    assert "Отчёт" in examples[0]["subject"]


def test_ocr_gating(tmp_path, monkeypatch):
    """Сканы поддерживаются только при ocr.enabled; массовые пути (allow_ocr=False)
    не зовут vision; PDF-скан уходит в OCR при allow_ocr=True."""
    from gigapost.attachments import extractor
    from gigapost.config import settings

    monkeypatch.setattr(settings.ocr, "enabled", False)
    assert not extractor.is_supported("скан.jpg")
    monkeypatch.setattr(settings.ocr, "enabled", True)
    assert extractor.is_supported("скан.jpg")

    scan = tmp_path / "скан.jpg"
    scan.write_bytes(b"\xff\xd8fake")
    called = {"n": 0}
    monkeypatch.setattr("gigapost.attachments.ocr._vision_call",
                        lambda data, name, mime: called.__setitem__("n", called["n"] + 1)
                        or "Акт №9 на 300,00")
    # без allow_ocr (история) — vision не вызывается
    assert extractor.extract_text(scan) is None and called["n"] == 0
    # с allow_ocr (новые письма) — распознаётся
    assert "Акт №9" in extractor.extract_text(scan, allow_ocr=True)
    assert called["n"] == 1


def test_extractor_new_formats(tmp_path):
    """Новые форматы: rtf, html, zip (с поддержанными файлами внутри)."""
    import zipfile

    from gigapost.attachments.extractor import extract_text, is_supported

    for ext in (".rtf", ".xls", ".html", ".zip"):
        assert is_supported(f"файл{ext}")
    assert not is_supported("старый.doc")

    rtf = tmp_path / "письмо.rtf"
    rtf.write_bytes(br"{\rtf1\ansi\ansicpg1251 Akt N7 na summu 100 rub.}")
    assert "Akt N7" in extract_text(rtf)

    html = tmp_path / "форма.html"
    html.write_text("<html><body><h1>Форма 3</h1><p>Сумма 200,00</p></body></html>",
                    encoding="utf-8")
    text = extract_text(html)
    assert "Форма 3" in text and "200,00" in text

    inner_txt = tmp_path / "спецификация.txt"
    inner_txt.write_text("Спецификация №5: Java, 300 руб.", encoding="utf-8")
    archive = tmp_path / "комплект.zip"
    with zipfile.ZipFile(archive, "w") as zf:
        zf.write(inner_txt, "спецификация.txt")
        zf.writestr("картинка.bmp", b"\x00")   # неподдержанное — пропустится
    ztext = extract_text(archive)
    assert "спецификация.txt" in ztext and "Java" in ztext


def test_meeting_invites_filtered(repos, email_task_request):
    """Приглашения на встречи не попадают в кандидаты знаний бэкфилла;
    таксономия не извлекает знания из категории «Встречи»."""
    import dataclasses
    import sys
    from pathlib import Path

    sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
    from backfill import select_candidates

    from gigapost.config import load_taxonomy

    invite = dataclasses.replace(
        email_task_request, message_id="invite-1",
        subject="Приглашение: Статус ЦС GigaNetwork",
        body_text="Когда: 25 июля 2026 г. 15:00. Подключиться в браузере по ссылке "
                  "https://jazz.sberbank.ru/xyz. Номер конференции: 123-456. " * 3)
    repos.emails.upsert(invite)
    assert not any(c["message_id"] == "invite-1" for c in select_candidates(repos))

    tax = load_taxonomy()
    meetings = tax.get("Встречи")
    assert meetings is not None and meetings.extract is False
    for subj in ("Принято: Статус проекта", "Отменено: Статус ЦС",
                 "Отмена: синк по бюджету", "Cancelled: Weekly sync",
                 "Перенос: обсуждение Формы 3", "Отклонено: демо GigaMe",
                 "Предварительно принято: синк", "Условно принято: статус",
                 "Предложено новое время: встреча по СЗЗ",
                 "Declined: budget review", "New Time Proposed: sync"):
        assert tax.apply_hard_rules("x@sberbank.ru", subj, "") == "Встречи", subj
    assert tax.apply_hard_rules("x@sberbank.ru", "Комплект документов",
                                "Направляю акт №7") is None


def test_weekly_report(repos, monkeypatch):
    """Недельный отчёт: сделанное/новое/застрявшее по проектам + мяч сторон."""
    from datetime import datetime, timedelta

    from gigapost.digest import build_weekly

    monkeypatch.setattr("gigapost.llm.factory.get_llm",
                        lambda role: (_ for _ in ()).throw(RuntimeError("нет LLM")))
    old = (datetime.now() - timedelta(days=10)).isoformat()
    tid = repos.tasks.create("Старая застрявшая", status="open", project="Тайга")
    repos.db.execute("UPDATE tasks SET created_at=? WHERE id=?", (old, tid))
    repos.tasks.create("Свежая задача", status="open", project="Тайга")
    did = repos.tasks.create("Сделанная", status="done", project="Тайга")
    repos.db.execute("UPDATE tasks SET completed_at=? WHERE id=?",
                     (datetime.now().isoformat(), did))
    repos.agreements.create("Прислать КП", counterparty="Вектор",
                            direction="they_owe", source_message_id=None,
                            conversation_id=None, due_date=None)

    body = build_weekly(repos)
    assert "Тайга" in body
    assert "Сделанная" in body and "Свежая задача" in body
    assert "Старая застрявшая" in body
    assert "Мяч у контрагентов" in body and "Прислать КП" in body
    saved = repos.db.query_one(
        "SELECT * FROM digests WHERE day LIKE '%-W%' ORDER BY id DESC LIMIT 1")
    assert saved is not None


def test_digest_builds_without_llm(repos, email_task_request, monkeypatch):
    # без GigaChat (роняем LLM-резюме) дайджест всё равно собирается
    monkeypatch.setattr("gigapost.llm.factory.get_llm",
                        lambda role: (_ for _ in ()).throw(RuntimeError("нет LLM")))
    repos.emails.upsert(email_task_request)
    repos.tasks.create("Просроченная", status="open", due_date="2020-01-01")
    body = build_digest(repos)
    assert "Дайджест" in body
    assert "просрочено" in body
    saved = repos.digests.latest()
    assert saved and "Дайджест" in saved["body"]
