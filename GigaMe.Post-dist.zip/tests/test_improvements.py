"""Тесты улучшений: дроссель LLM, роутер намерений, дайджест, поправки."""

import threading
import time

from gigapost.agent.router import is_action
from gigapost.digest import build_digest
from gigapost.llm.throttle import PriorityGate


def test_priority_gate_orders_by_priority():
    gate = PriorityGate(min_interval=0)
    order: list[str] = []
    release_first = threading.Event()

    def holder():
        gate.acquire(1)
        release_first.wait(2)
        order.append("holder")
        gate.release()

    def worker(name, prio):
        gate.acquire(prio)
        order.append(name)
        gate.release()

    t0 = threading.Thread(target=holder)
    t0.start()
    time.sleep(0.05)
    # пока ворота заняты, встают в очередь: низкий приоритет первым по времени,
    # высокий — вторым; выйти должен высокий раньше
    t_low = threading.Thread(target=worker, args=("low", 3))
    t_low.start()
    time.sleep(0.05)
    t_high = threading.Thread(target=worker, args=("high", 0))
    t_high.start()
    time.sleep(0.05)
    release_first.set()
    for t in (t0, t_low, t_high):
        t.join(3)
    assert order == ["holder", "high", "low"]


def test_priority_gate_reentrant():
    """Вложенный захват тем же потоком не должен дедлочить
    (embed_query -> embed_documents у langchain)."""
    gate = PriorityGate(min_interval=0)
    gate.acquire(3)
    gate.acquire(3)   # вложенный — раньше здесь был вечный дедлок
    gate.release()
    gate.release()
    # ворота свободны — другой захват проходит
    done = []

    def other():
        gate.acquire(0)
        done.append(True)
        gate.release()

    t = threading.Thread(target=other)
    t.start()
    t.join(2)
    assert done == [True]


def test_gigachat_auth_kwargs(monkeypatch):
    """Публичный API — OAuth-ключ; корп-контур (cert_file задан) — mTLS без ключа."""
    from gigapost.config import settings

    monkeypatch.setattr(settings, "gigachat_cert_file", "")
    monkeypatch.setattr(settings, "gigachat_base_url", "")
    kw = settings.gigachat_auth_kwargs()
    assert "credentials" in kw and "cert_file" not in kw and "base_url" not in kw

    monkeypatch.setattr(settings, "gigachat_cert_file", "C:/certs/client.crt")
    monkeypatch.setattr(settings, "gigachat_key_file", "C:/certs/client.key")
    monkeypatch.setattr(settings, "gigachat_base_url",
                        "https://gigachat-ift.sberdevices.delta.sbrf.ru/v1")
    kw = settings.gigachat_auth_kwargs()
    assert kw["cert_file"] == "C:/certs/client.crt"
    assert kw["key_file"] == "C:/certs/client.key"
    assert kw["base_url"].endswith("/v1")
    assert "credentials" not in kw and "scope" not in kw


def test_model_env_override(monkeypatch):
    """GIGACHAT_MODEL перекрывает YAML для LLM-ролей (но не эмбеддинги),
    GIGACHAT_MODEL_<ROLE> — сильнее общего."""
    from gigapost.config import settings

    monkeypatch.setattr(settings, "gigachat_model", "")
    monkeypatch.setattr(settings, "gigachat_model_chat", "")
    assert settings.resolve_model("chat") == settings.models.chat

    monkeypatch.setattr(settings, "gigachat_model", "GigaChat-Ultra")
    assert settings.resolve_model("chat") == "GigaChat-Ultra"
    assert settings.resolve_model("classify") == "GigaChat-Ultra"
    assert settings.resolve_model("embeddings") == settings.models.embeddings

    monkeypatch.setattr(settings, "gigachat_model_chat", "GigaChat-2-Max")
    assert settings.resolve_model("chat") == "GigaChat-2-Max"
    assert settings.resolve_model("extract") == "GigaChat-Ultra"


def test_intent_router():
    # действия → агент
    assert is_action("Создай задачу про отчёт")
    assert is_action("удали письма из папки Штрафы")
    assert is_action("подготовь черновик ответа")
    assert is_action("запомни, что Бунзя — руководитель")
    # вопросы → RAG-путь
    assert not is_action("Какие у меня открытые задачи?")
    assert not is_action("Почему решили делать своего агента?")
    assert not is_action("кто отвечает за блок Лечение")
    assert not is_action("что мне должны прислать контрагенты")


def test_corrections_few_shot(repos, email_task_request):
    repos.emails.upsert(email_task_request)
    repos.corrections.add(email_task_request.message_id, "Личное", "Проекты")
    examples = repos.corrections.recent_examples()
    assert len(examples) == 1
    assert examples[0]["correct_category"] == "Проекты"
    assert examples[0]["wrong_category"] == "Личное"
    assert "Отчёт" in examples[0]["subject"]


def test_digest_builds_without_llm(repos, email_task_request, monkeypatch):
    # без GigaChat (роняем LLM-резюме) дайджест всё равно собирается
    monkeypatch.setattr("gigapost.llm.factory.get_llm",
                        lambda role: (_ for _ in ()).throw(RuntimeError("нет LLM")))
    repos.emails.upsert(email_task_request)
    repos.tasks.create("Просроченная", status="open", due_date="2020-01-01")
    body = build_digest(repos)
    assert "Дайджест" in body
    assert "просрочено" in body
    saved = repos.digests.latest()
    assert saved and "Дайджест" in saved["body"]
