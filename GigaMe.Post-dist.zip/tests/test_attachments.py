"""Тесты извлечения текста из вложений и их участия в пайплайне."""

from pathlib import Path

from gigapost.attachments.extractor import extract_text, is_supported
from gigapost.config import load_taxonomy
from gigapost.knowledge.graph_store import KnowledgeGraph
from gigapost.llm.schemas import EmailClassification, ExtractionResult
from gigapost.outlook.models import EmailMessage
from gigapost.pipeline.graph import build_ingest_graph
from gigapost.pipeline.nodes import PipelineNodes


def _make_docx(path: Path, paragraphs: list[str]) -> None:
    import docx

    d = docx.Document()
    for p in paragraphs:
        d.add_paragraph(p)
    d.save(str(path))


def _make_xlsx(path: Path, rows: list[list]) -> None:
    import openpyxl

    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Смета"
    for row in rows:
        ws.append(row)
    wb.save(str(path))


def test_is_supported():
    assert is_supported("смета.xlsx")
    assert is_supported("КП.docx")
    assert is_supported("presentation.PPTX")
    assert not is_supported("старый.doc")
    assert not is_supported("фото.jpg")


def test_extract_docx(tmp_path):
    f = tmp_path / "кп.docx"
    _make_docx(f, ["Коммерческое предложение", "Срок поставки: до 25 июля 2026",
                   "Сумма: 1 500 000 руб."])
    text = extract_text(f)
    assert "Коммерческое предложение" in text
    assert "1 500 000" in text


def test_extract_xlsx(tmp_path):
    f = tmp_path / "смета.xlsx"
    _make_xlsx(f, [["Позиция", "Сумма"], ["Работы по проекту Альфа", 500000],
                   ["Оборудование", 1000000]])
    text = extract_text(f)
    assert "Лист: Смета" in text
    assert "Альфа" in text and "500000" in text


def test_extract_txt_cp1251(tmp_path):
    f = tmp_path / "заметка.txt"
    f.write_bytes("Договор аренды офиса".encode("cp1251"))
    assert "Договор аренды" in extract_text(f)


def test_extract_unsupported_and_broken(tmp_path):
    assert extract_text(tmp_path / "нет.docx") is None
    broken = tmp_path / "битый.docx"
    broken.write_bytes(b"this is not a docx")
    assert extract_text(broken) is None


class FakeStructuredLLM:
    def __init__(self, result):
        self._result = result
        self.prompts: list[str] = []

    def with_structured_output(self, schema):
        return self

    def invoke(self, prompt):
        self.prompts.append(prompt)
        return self._result


def test_pipeline_uses_attachment_text(repos, fake_outlook, tmp_path):
    """Вложение разбирается, попадает в промпт извлечения и в БД."""
    f = tmp_path / "кп_альфа.docx"
    _make_docx(f, ["КП по проекту Альфа", "Вышлем договор до 2026-08-01"])
    email = EmailMessage(
        message_id="<att-test-001@x.ru>", entry_id="E1", conversation_id="C1",
        subject="КП во вложении", sender_name="Анна", sender_email="a@vektor.ru",
        recipients=["me@x.ru"], received_at="2026-07-20T10:00:00",
        body_text="Добрый день! КП во вложении, просьба посмотреть.",
        folder="Inbox", has_attachments=True,
        attachment_names=["кп_альфа.docx", "фото.jpg"],
        attachment_paths=[str(f)],
    )
    classify_llm = FakeStructuredLLM(EmailClassification(
        category="Проекты", importance=4, requires_action=True, summary="КП во вложении"))
    extract_llm = FakeStructuredLLM(ExtractionResult())
    kg = KnowledgeGraph(repos)
    nodes = PipelineNodes(repos, fake_outlook, load_taxonomy(), kg, vectors=None,
                          classify_llm=classify_llm, extract_llm=extract_llm)
    graph = build_ingest_graph(nodes)
    repos.emails.upsert(email)
    graph.invoke({"email": email})

    # вложение в БД: docx разобран, jpg — unsupported
    atts = {a["filename"]: a for a in repos.attachments.for_email(email.message_id)}
    assert atts["кп_альфа.docx"]["status"] == "parsed"
    assert "проекту Альфа" in atts["кп_альфа.docx"]["text"]
    assert atts["фото.jpg"]["status"] == "unsupported"
    # текст вложения попал в промпт извлечения
    assert extract_llm.prompts, "extract не вызывался"
    assert "=== Вложение: кп_альфа.docx ===" in extract_llm.prompts[0]
    assert "проекту Альфа" in extract_llm.prompts[0]


def test_stored_attachment_gets_hash(repos, fake_outlook, tmp_path):
    """Неразбираемый файл (архив) сохраняется в библиотеке со статусом stored и хешем."""
    import zipfile

    f = tmp_path / "архив_проекта.zip"
    with zipfile.ZipFile(f, "w") as z:
        z.writestr("readme.txt", "содержимое")
    email = EmailMessage(
        message_id="<att-zip-001@x.ru>", entry_id="E9", conversation_id="C9",
        subject="Архив", sender_name="Пётр", sender_email="p@r.ru",
        recipients=["me@x.ru"], received_at="2026-07-21T10:00:00",
        body_text="Архив во вложении, посмотри пожалуйста.", folder="Inbox",
        has_attachments=True, attachment_names=["архив_проекта.zip"],
        attachment_paths=[str(f)],
    )
    classify_llm = FakeStructuredLLM(EmailClassification(
        category="Проекты", importance=3, requires_action=True, summary="Архив"))
    extract_llm = FakeStructuredLLM(ExtractionResult())
    kg = KnowledgeGraph(repos)
    nodes = PipelineNodes(repos, fake_outlook, load_taxonomy(), kg, vectors=None,
                          classify_llm=classify_llm, extract_llm=extract_llm)
    graph = build_ingest_graph(nodes)
    repos.emails.upsert(email)
    graph.invoke({"email": email})

    a = repos.attachments.get_text(email.message_id, "архив_проекта.zip")
    assert a["status"] == "stored"
    assert a["sha256"] and len(a["sha256"]) == 64
    # файл виден в библиотеке с метаданными письма
    lib = repos.attachments.library(query="архив")
    assert len(lib) == 1 and lib[0]["sender_name"] == "Пётр"
    assert repos.attachments.extensions()[0][0] == ".zip"


def test_pipeline_attachment_triggers_extract_without_requires_action(
        repos, fake_outlook, tmp_path):
    """Письмо «не требует действия», но вложение с текстом всё равно анализируется."""
    f = tmp_path / "отчёт.docx"
    _make_docx(f, ["Отчёт по проекту Бета за июнь"])
    email = EmailMessage(
        message_id="<att-test-002@x.ru>", entry_id="E2", conversation_id="C2",
        subject="Отчёт для сведения", sender_name="Пётр", sender_email="p@r.ru",
        recipients=["me@x.ru"], received_at="2026-07-20T11:00:00",
        body_text="Для сведения.", folder="Inbox", has_attachments=True,
        attachment_names=["отчёт.docx"], attachment_paths=[str(f)],
    )
    classify_llm = FakeStructuredLLM(EmailClassification(
        category="Проекты", importance=3, requires_action=False, summary="Отчёт"))
    extract_llm = FakeStructuredLLM(ExtractionResult())
    kg = KnowledgeGraph(repos)
    nodes = PipelineNodes(repos, fake_outlook, load_taxonomy(), kg, vectors=None,
                          classify_llm=classify_llm, extract_llm=extract_llm)
    graph = build_ingest_graph(nodes)
    repos.emails.upsert(email)
    graph.invoke({"email": email})
    assert extract_llm.prompts, "extract должен вызываться из-за вложения"
    assert "Бета" in extract_llm.prompts[0]
