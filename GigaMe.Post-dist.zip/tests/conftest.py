"""Фикстуры: in-memory БД, FakeOutlookClient, фейковые LLM."""

from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path

import pytest

from gigapost.db.database import Database
from gigapost.db.repositories import Repos
from gigapost.outlook.models import EmailMessage

FIXTURES_DIR = Path(__file__).parent / "fixtures" / "emails"


@pytest.fixture
def db() -> Database:
    database = Database(":memory:")
    database.init_schema()
    return database


@pytest.fixture
def repos(db) -> Repos:
    return Repos(db)


class FakeOutlookClient:
    """In-memory реализация интерфейса OutlookClient для тестов пайплайна."""

    def __init__(self, dry_run: bool = False):
        self.dry_run = dry_run
        self.moved: list[tuple[str, str]] = []
        self.categories: list[tuple[str, str]] = []
        self.flags: list[str] = []
        self.tasks: list[dict] = []
        self.deleted: list[str] = []
        self._task_seq = 0

    def register_categories(self, categories):
        pass

    def ensure_folder(self, folder_path: str) -> None:
        pass

    def move_email(self, entry_id: str, folder_path: str) -> str:
        if self.dry_run:
            return entry_id
        self.moved.append((entry_id, folder_path))
        return f"{entry_id}-moved"

    def set_category(self, entry_id: str, category: str) -> None:
        if not self.dry_run:
            self.categories.append((entry_id, category))

    def set_flag(self, entry_id: str, due=None) -> None:
        if not self.dry_run:
            self.flags.append(entry_id)

    def create_task(self, subject: str, body: str = "", due=None, reminder=None) -> str:
        if self.dry_run:
            return ""
        self._task_seq += 1
        entry_id = f"task-{self._task_seq}"
        self.tasks.append({"entry_id": entry_id, "subject": subject,
                           "due": due, "reminder": reminder})
        return entry_id

    def complete_task(self, entry_id: str) -> None:
        pass

    def delete_email(self, entry_id: str) -> None:
        if not self.dry_run:
            self.deleted.append(entry_id)

    def display_email(self, entry_id: str) -> None:
        pass


@pytest.fixture
def fake_outlook() -> FakeOutlookClient:
    return FakeOutlookClient()


def load_email_fixture(name: str) -> EmailMessage:
    data = json.loads((FIXTURES_DIR / f"{name}.json").read_text(encoding="utf-8"))
    return EmailMessage(**data)


@pytest.fixture
def email_task_request() -> EmailMessage:
    return load_email_fixture("task_request")


@pytest.fixture
def email_newsletter() -> EmailMessage:
    return load_email_fixture("newsletter")


@pytest.fixture
def email_agreement() -> EmailMessage:
    return load_email_fixture("agreement")
