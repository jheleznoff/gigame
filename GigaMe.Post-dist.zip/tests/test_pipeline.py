"""Тесты ingestion-пайплайна с фейковыми LLM и FakeOutlookClient."""

from datetime import datetime, timedelta

from gigapost.config import load_taxonomy
from gigapost.control.monitor import ControlMonitor
from gigapost.knowledge.graph_store import KnowledgeGraph
from gigapost.llm.schemas import (EmailClassification, EntityRelation, ExtractedAgreement,
                                  ExtractedEntity, ExtractedTask, ExtractionResult)
from gigapost.pipeline.graph import build_ingest_graph
from gigapost.pipeline.nodes import PipelineNodes, clean_body


class FakeStructuredLLM:
    """Подменяет structured_call: with_structured_output(...).invoke → готовый объект."""

    def __init__(self, result):
        self._result = result

    def with_structured_output(self, schema):
        return self

    def invoke(self, prompt):
        return self._result


CLASSIFY_ACTION = EmailClassification(
    category="Срочное/Действие", importance=4, requires_action=True,
    summary="Просят отчёт по продажам до пятницы")

EXTRACTION = ExtractionResult(
    tasks=[ExtractedTask(title="Подготовить отчёт по продажам",
                         description="Разбивка по регионам", deadline="2026-07-24",
                         assignee="я")],
    agreements=[ExtractedAgreement(description="Вышлют КП по проекту Альфа",
                                   counterparty="Анна Смирнова", direction="they_owe",
                                   due_date="2026-07-25")],
    entities=[
        ExtractedEntity(name="Пётр Иванов", type="person",
                        relations=[EntityRelation(target_name="Ромашка", relation="works_at")]),
        ExtractedEntity(name="Ромашка", type="org", relations=[]),
    ],
)


def make_nodes(repos, fake_outlook, classify=CLASSIFY_ACTION, extraction=EXTRACTION):
    taxonomy = load_taxonomy()
    kg = KnowledgeGraph(repos)
    kg.rebuild()
    return PipelineNodes(
        repos, fake_outlook, taxonomy, kg, vectors=None,
        classify_llm=FakeStructuredLLM(classify),
        extract_llm=FakeStructuredLLM(extraction)), kg


def test_full_pipeline_action_email(repos, fake_outlook, email_task_request):
    nodes, kg = make_nodes(repos, fake_outlook)
    graph = build_ingest_graph(nodes)
    repos.emails.upsert(email_task_request)
    result = graph.invoke({"email": email_task_request})

    # классификация записана
    email = repos.emails.get(email_task_request.message_id)
    assert email["category"] == "Срочное/Действие"
    assert email["needs_review"] == 0
    # действия в Outlook: категория + флаг (folder=null у Срочное/Действие)
    assert ("ENTRY001", "GigaPost/Действие") in fake_outlook.categories
    assert "ENTRY001" in fake_outlook.flags
    assert fake_outlook.moved == []
    # задача в БД — черновик, в Outlook НЕ создаётся до подтверждения (HITL)
    tasks = repos.tasks.list("draft")
    assert len(tasks) == 1 and tasks[0]["due_date"] == "2026-07-24"
    assert tasks[0]["outlook_task_entry_id"] is None
    assert fake_outlook.tasks == []
    # договорённость на контроле
    agreements = repos.agreements.list()
    assert len(agreements) == 1 and agreements[0]["direction"] == "they_owe"
    # граф знаний: Иванов --works_at--> Ромашка
    neighbors = kg.neighbors("Пётр Иванов")
    assert any(r["name"] == "Ромашка" and r["relation"] == "works_at"
               for r in neighbors["related"])


def test_hard_rule_skips_llm(repos, fake_outlook, email_newsletter):
    class ExplodingLLM:
        def with_structured_output(self, schema):
            raise AssertionError("LLM не должен вызываться для hard rule")

    taxonomy = load_taxonomy()
    kg = KnowledgeGraph(repos)
    nodes = PipelineNodes(repos, fake_outlook, taxonomy, kg, vectors=None,
                          classify_llm=ExplodingLLM(), extract_llm=ExplodingLLM())
    graph = build_ingest_graph(nodes)
    repos.emails.upsert(email_newsletter)
    graph.invoke({"email": email_newsletter})

    email = repos.emails.get(email_newsletter.message_id)
    assert email["category"] == "Рассылки"
    # рассылка перемещена, extract не вызывался (нет задач)
    assert ("ENTRY002", "GigaPost/Рассылки") in fake_outlook.moved
    assert repos.tasks.list() == []


def test_move_updates_entry_id(repos, fake_outlook, email_newsletter):
    nodes, _ = make_nodes(repos, fake_outlook)
    graph = build_ingest_graph(nodes)
    repos.emails.upsert(email_newsletter)
    graph.invoke({"email": email_newsletter})
    email = repos.emails.get(email_newsletter.message_id)
    assert email["entry_id"] == "ENTRY002-moved"
    assert email["folder"] == "GigaPost/Рассылки"


def test_dry_run_no_outlook_actions(repos, email_task_request):
    from tests.conftest import FakeOutlookClient

    fake = FakeOutlookClient(dry_run=True)
    nodes, _ = make_nodes(repos, fake)
    graph = build_ingest_graph(nodes)
    repos.emails.upsert(email_task_request)
    graph.invoke({"email": email_task_request})
    # мутаций в Outlook нет
    assert fake.moved == [] and fake.categories == [] and fake.tasks == []
    # но задача-черновик в БД создана (без outlook_task_entry_id)
    tasks = repos.tasks.list("draft")
    assert len(tasks) == 1 and tasks[0]["outlook_task_entry_id"] is None
    # и в логе видны dry_run-действия
    log = repos.log.recent()
    assert any(r["stage"] == "apply" and r["status"] == "dry_run" for r in log)


def test_control_monitor_overdue_and_followup(repos):
    monitor = ControlMonitor(repos)
    now = datetime.now()
    overdue_id = repos.agreements.create(
        "Просроченная договорённость", "Иван", "they_owe", None, "C1",
        (now - timedelta(days=1)).isoformat())
    stale_id = repos.agreements.create(
        "Обещали ответить", "Анна", "they_owe", None, "C2", None, followup_after_days=3)
    repos.db.execute("UPDATE agreements SET last_activity_at=? WHERE id=?",
                     ((now - timedelta(days=5)).isoformat(), stale_id))

    stats = monitor.run(now)
    assert stats["overdue"] == 1
    assert stats["followup_needed"] >= 1
    assert repos.agreements.get(overdue_id)["status"] == "overdue"
    kinds = {a["kind"] for a in repos.alerts.list_active()}
    assert {"overdue", "followup_needed"} <= kinds
    # повторный прогон — алерты не дублируются
    stats2 = monitor.run(now)
    assert stats2["overdue"] == 0 and stats2["followup_needed"] == 0


def test_clean_body_cuts_quotes():
    body = "Свежий ответ.\n\n-----Original Message-----\nFrom: x\nстарая переписка"
    assert clean_body(body) == "Свежий ответ."
    body_ru = "Ответ.\n\nОт: Иванов\nОтправлено: вчера\nстарое"
    assert clean_body(body_ru) == "Ответ."


def test_clean_body_corporate_outlook_variants():
    # английский Outlook: From:/Sent:
    body = "Привет! Доступы предоставлены.\n\nFrom: Крин Анастасия <k@x.ru> \nSent: Wednesday, July 1, 2026\nстарое письмо"
    assert clean_body(body) == "Привет! Доступы предоставлены."
    # разделитель-подчёркивание + табличная шапка «От/Дата»
    body2 = ("завтра вернусь с обратной связью по этому комплекту.\n\n"
             "________________________________________\n"
             "От\tЖелезнов Максим Юрьевич\n\nДата\tпонедельник\nстарый хвост")
    assert clean_body(body2) == "завтра вернусь с обратной связью по этому комплекту."
    # приглашение, процитированное в «итогах встречи»
    body3 = "Коллеги, итоги встречи:\n1. Организуем встречу\n\n-----Original Appointment-----\nFrom: x\njazz.sberbank.ru"
    cleaned3 = clean_body(body3)
    assert "итоги встречи" in cleaned3 and "jazz" not in cleaned3


def test_hard_rule_body_match_meeting_invite():
    from gigapost.config import load_taxonomy

    taxonomy = load_taxonomy()
    invite = ("Тема: демо ГигаМи\n\nПодключиться в браузере по ссылке:\n"
              "https://jazz.sberbank.ru/sber-f1axjc\nНомер конференции: 876332120")
    assert taxonomy.apply_hard_rules("Krin.A.A@sberbank.ru", "демо ГигаМи", invite) == "Встречи"
    # «итоги встречи» с вырезанной цитатой — правило не срабатывает, решает LLM
    summary = "Коллеги, итоги встречи:\n1. Организуем отдельную встречу с DA"
    assert taxonomy.apply_hard_rules("x@sberbank.ru", "RE: Миграция", summary) is None


def test_low_confidence_goes_to_review(repos, fake_outlook, email_task_request):
    """Неуверенная классификация → карантин: никаких действий в Outlook."""
    unsure = EmailClassification(
        category="Проекты", importance=3, requires_action=False,
        summary="Непонятное письмо", confidence=2)
    nodes, _ = make_nodes(repos, fake_outlook, classify=unsure)
    graph = build_ingest_graph(nodes)
    repos.emails.upsert(email_task_request)
    graph.invoke({"email": email_task_request})

    email = repos.emails.get(email_task_request.message_id)
    assert email["needs_review"] == 1
    assert email["category_confidence"] == 2
    assert fake_outlook.moved == [] and fake_outlook.categories == []
    assert repos.emails.count_pending_review() == 1
    # ручной разбор: выбор категории применяет действия
    from gigapost.pipeline.nodes import apply_category_actions
    repos.emails.set_review_resolved(email_task_request.message_id, "Проекты")
    applied = apply_category_actions(repos, fake_outlook, load_taxonomy(),
                                     email_task_request.message_id, "Проекты")
    assert any(a.startswith("move:") for a in applied)
    assert repos.emails.count_pending_review() == 0


def test_unknown_category_goes_to_review(repos, fake_outlook, email_task_request):
    bad = EmailClassification(category="Выдуманная", importance=3,
                              requires_action=False, summary="х", confidence=5)
    nodes, _ = make_nodes(repos, fake_outlook, classify=bad)
    graph = build_ingest_graph(nodes)
    repos.emails.upsert(email_task_request)
    graph.invoke({"email": email_task_request})
    assert repos.emails.get(email_task_request.message_id)["needs_review"] == 1


def test_draft_task_accept_flow(repos):
    """Черновик → принятие: статус open (Outlook-часть живёт в роуте)."""
    task_id = repos.tasks.create("Проверить КП", status="draft", due_date="2026-08-01")
    assert repos.tasks.count("draft") == 1 and repos.tasks.count("open") == 0
    repos.tasks.set_status(task_id, "open")
    assert repos.tasks.count("open") == 1
    task_id2 = repos.tasks.create("Лишняя задача", status="draft")
    repos.tasks.set_status(task_id2, "cancelled")
    assert repos.tasks.count("draft") == 0


def test_extracted_task_title_sanitized():
    """Протёкшие фрагменты JSON вычищаются из строковых полей."""
    t = ExtractedTask(title='Пополнить счет в Cloud.ru"\n        }\n    ],\n')
    assert t.title == "Пополнить счет в Cloud.ru"
    # парные «ёлочки» — часть содержимого, сохраняются
    t2 = ExtractedTask(title='  «Оформить заказ»  ', description='до пятницы"}')
    assert t2.title == "«Оформить заказ»"
    assert t2.description == "до пятницы"
    # непарная ёлочка по краю (обрезанная кавычка) — убирается
    t3 = ExtractedTask(title='подготовить отчёт по проекту «Альфа')
    assert t3.title == "подготовить отчёт по проекту Альфа"


def test_chunking():
    from gigapost.knowledge.vector_store import _chunk_text

    text = "\n\n".join(f"Абзац {i} " + "х" * 500 for i in range(10))
    chunks = _chunk_text(text, 2500)
    assert all(len(c) <= 2500 for c in chunks)
    assert "".join(chunks).replace("\n\n", "") != ""  # ничего не потеряли по сути
