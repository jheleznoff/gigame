"""Live-тесты качества извлечения на реальном GigaChat.

Запуск вручную: pytest -m live tests/test_extraction_live.py
Требует GIGACHAT_CREDENTIALS в .env.
"""

import pytest

from gigapost.config import load_prompt, load_taxonomy
from gigapost.llm.schemas import EmailClassification, ExtractionResult
from gigapost.llm.structured import structured_call
from gigapost.pipeline.nodes import clean_body

pytestmark = pytest.mark.live


@pytest.fixture(scope="module")
def classify_llm():
    from gigapost.llm.factory import get_llm
    return get_llm("classify")


@pytest.fixture(scope="module")
def extract_llm():
    from gigapost.llm.factory import get_llm
    return get_llm("extract")


def _classify(llm, email):
    taxonomy = load_taxonomy()
    categories = "\n".join(f"- {c.name}: {c.description}" for c in taxonomy.categories)
    prompt = load_prompt("classify").format(
        categories=categories, sender_name=email.sender_name,
        sender_email=email.sender_email, subject=email.subject,
        received_at=email.received_at, body=clean_body(email.body_text))
    return structured_call(llm, EmailClassification, prompt)


def _extract(llm, email):
    prompt = load_prompt("extract").format(
        sender_name=email.sender_name, sender_email=email.sender_email,
        recipients=", ".join(email.recipients), subject=email.subject,
        received_at=email.received_at, body=clean_body(email.body_text))
    return structured_call(llm, ExtractionResult, prompt)


def test_classify_task_request(classify_llm, email_task_request):
    c = _classify(classify_llm, email_task_request)
    assert c.requires_action is True
    assert c.importance >= 3


def test_extract_task_with_deadline(extract_llm, email_task_request):
    r = _extract(extract_llm, email_task_request)
    assert len(r.tasks) >= 1
    task = r.tasks[0]
    assert "отчёт" in task.title.lower() or "отчет" in task.title.lower()
    assert task.deadline == "2026-07-24"


def test_extract_agreement_they_owe(extract_llm, email_agreement):
    r = _extract(extract_llm, email_agreement)
    assert any(a.direction == "they_owe" for a in r.agreements)
