"""Тесты анализа отправленных писем: обещания → задачи, ответы → закрытие."""

from gigapost.config import settings
from gigapost.llm.schemas import (ClosureVerdict, ExtractedAgreement, ExtractedTask,
                                  ExtractionResult)
from gigapost.outlook.models import EmailMessage
from gigapost.pipeline.sent import SentProcessor


class SeqLLM:
    """Возвращает результаты по очереди (extract → closure)."""

    def __init__(self, results):
        self._results = list(results)

    def with_structured_output(self, schema):
        return self

    def invoke(self, prompt):
        return self._results.pop(0)


def _sent_email(num, body, conv="SCONV"):
    return EmailMessage(
        message_id=f"<sent-{num:02d}@me.ru>", entry_id=f"S{num}", conversation_id=conv,
        subject="RE: Схема процесса", sender_name=settings.owner.name,
        sender_email="me@work.ru", recipients=["m.egorova@x.ru"],
        received_at="2026-07-21T12:00:00",
        body_text=body, folder="Sent")


def test_promise_becomes_draft_task(repos, fake_outlook):
    extraction = ExtractionResult(
        tasks=[ExtractedTask(title="Прислать список сотрудников с доступами",
                             deadline="2026-07-22", assignee="я")],
        agreements=[ExtractedAgreement(
            description="пришлю список до завтра", counterparty="Егорова",
            direction="we_owe", due_date="2026-07-22")])
    proc = SentProcessor(repos, fake_outlook,
                         extract_llm=SeqLLM([extraction]))
    email = _sent_email(1, "Маша, пришлю список сотрудников с доступами завтра.")
    repos.emails.upsert(email)
    stats = proc.process_email(email)

    assert stats["promises"] == 1
    drafts = repos.tasks.list("draft")
    assert len(drafts) == 1 and drafts[0]["title"].startswith("(обещание)")
    agreements = repos.agreements.list()
    assert agreements and agreements[0]["direction"] == "we_owe"


def test_reply_flags_task_maybe_done(repos, fake_outlook, email_task_request):
    # входящее письмо породило задачу
    repos.emails.upsert(email_task_request)
    task_id = repos.tasks.create("Подготовить отчёт по продажам", status="open",
                                 source_message_id=email_task_request.message_id)
    # моё ответное письмо в том же треде: extract пустой, closure говорит «сделано»
    proc = SentProcessor(repos, fake_outlook,
                         extract_llm=SeqLLM([ExtractionResult(),
                                             ClosureVerdict(done_task_ids=[task_id])]))
    email = _sent_email(2, "Коллеги, отчёт во вложении, готово.",
                        conv=email_task_request.conversation_id)
    repos.emails.upsert(email)
    stats = proc.process_email(email)

    assert stats["maybe_done"] == 1
    alerts = repos.alerts.list_active()
    assert any(a["kind"] == "task_maybe_done" and a["ref_id"] == task_id for a in alerts)
    # задача НЕ закрыта молча — ждёт подтверждения
    assert repos.tasks.get(task_id)["status"] == "open"


def test_vip_detection():
    assert settings.is_vip("Егорова Мария Дмитриевна", "MDmEgorova@sberbank.ru")
    assert settings.is_vip(None, "something+Дубров Антон@x")
    assert not settings.is_vip("Пётр Иванов", "p.ivanov@romashka.ru")
