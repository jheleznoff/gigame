package ru.sber.cs.ai.gigame.utils;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.compress.archivers.sevenz.SevenZArchiveEntry;
import org.apache.commons.compress.archivers.sevenz.SevenZFile;
import org.apache.commons.compress.utils.SeekableInMemoryByteChannel;
import ru.sber.cs.ai.gigame.exception.FileException;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/**
 * Распаковка ZIP- и 7z-архивов с документами для сценариев.
 * <p>
 * Возвращает только содержательные документы: служебные файлы ЭДО
 * (электронные подписи, хэши, паспорта, технологические квитанции,
 * протоколы передачи) отфильтровываются. Вложенные архивы распаковываются
 * рекурсивно. Имя каждого документа включает имя архива и путь внутри него
 * ("архив.zip/папка/файл.pdf") — путь используется для группировки документов.
 */
@Slf4j
public final class ZipExtractor {

    /** Файл, извлечённый из архива: полное имя (архив + путь внутри) и содержимое. */
    public record ExtractedFile(String name, byte[] content) {
    }

    /** Результат распаковки: документы и количество отфильтрованных служебных файлов. */
    public record ExtractionResult(List<ExtractedFile> files, int skippedCount) {
    }

    static final int MAX_ENTRIES = 500;
    static final long MAX_TOTAL_UNCOMPRESSED_BYTES = 500L * 1024 * 1024;
    static final int MAX_NESTING_DEPTH = 3;

    /** Кодировка имён записей для архивов без UTF-8-флага (архивы из Windows-инструментов). */
    private static final Charset LEGACY_NAME_CHARSET = Charset.forName("CP866");

    /** Расширения содержательных документов; всё прочее внутри архива пропускается. */
    private static final Set<String> DOCUMENT_EXTENSIONS = Set.of("pdf", "docx", "xlsx", "xls", "txt", "xml");

    /** Расширения служебных файлов ЭДО (подписи и хэши). */
    private static final Set<String> SIGNATURE_EXTENSIONS = Set.of("sig", "sgn", "hash", "hash2012", "p7s");

    private ZipExtractor() {
    }

    /**
     * Распаковывает архив (ZIP или 7z — по расширению имени), отфильтровывая
     * служебные файлы.
     *
     * @param zipName имя архива (используется как префикс имён документов)
     * @param bytes   содержимое архива
     * @return содержательные документы и счётчик пропущенных файлов
     * @throws FileException если архив повреждён или превышены лимиты распаковки
     */
    public static ExtractionResult extract(String zipName, byte[] bytes) {
        List<ExtractedFile> files = new ArrayList<>();
        Budget budget = new Budget();
        if ("7z".equals(extension(zipName))) {
            extract7zInto(zipName, bytes, 1, files, budget);
        } else {
            extractInto(zipName, bytes, 1, files, budget);
        }
        if (budget.entries == 0) {
            // ZipInputStream на «мусорных» байтах молча отдаёт 0 записей
            throw new FileException("Архив пуст или повреждён: " + zipName);
        }
        log.info("Архив '{}': извлечено {} документ(ов), пропущено {} служебных/неподдерживаемых файлов",
                zipName, files.size(), budget.skipped);
        return new ExtractionResult(files, budget.skipped);
    }

    private static final class Budget {
        int entries;
        long uncompressedBytes;
        int skipped;
    }

    private static void extractInto(String prefix, byte[] bytes, int depth,
                                    List<ExtractedFile> out, Budget budget) {
        try (ZipInputStream zis = new ZipInputStream(new ByteArrayInputStream(bytes), LEGACY_NAME_CHARSET)) {
            ZipEntry entry;
            while ((entry = zis.getNextEntry()) != null) {
                if (entry.isDirectory()) {
                    continue;
                }
                processEntry(prefix, entry, zis, depth, out, budget);
            }
        } catch (FileException e) {
            throw e;
        } catch (IOException e) {
            throw new FileException("Не удалось распаковать архив: " + prefix, e);
        }
    }

    /**
     * Обрабатывает одну запись архива: учитывает лимит записей, пропускает
     * служебные файлы, вложенный zip распаковывает рекурсивно (с учётом глубины),
     * содержательный документ добавляет в результат.
     */
    private static void processEntry(String prefix, ZipEntry entry, ZipInputStream zis, int depth,
                                     List<ExtractedFile> out, Budget budget) throws IOException {
        if (++budget.entries > MAX_ENTRIES) {
            throw new FileException("Архив содержит слишком много файлов (лимит " + MAX_ENTRIES + ")");
        }
        String entryName = entry.getName().replace('\\', '/');
        String fullName = prefix + "/" + entryName;
        String ext = extension(entryName);

        if ("zip".equals(ext) || "7z".equals(ext)) {
            recurseNestedArchive(fullName, ext, readEntry(zis, entryName, budget), depth, out, budget);
            return;
        }
        if (isJunk(entryName)) {
            budget.skipped++;
            return;
        }
        out.add(new ExtractedFile(fullName, readEntry(zis, entryName, budget)));
    }

    /** Вложенный архив (zip/7z): рекурсивная распаковка с контролем глубины. */
    private static void recurseNestedArchive(String fullName, String ext, byte[] bytes, int depth,
                                             List<ExtractedFile> out, Budget budget) {
        if (depth >= MAX_NESTING_DEPTH) {
            log.warn("Пропущен вложенный архив '{}': превышена глубина вложенности {}",
                    fullName, MAX_NESTING_DEPTH);
            budget.skipped++;
            return;
        }
        if ("7z".equals(ext)) {
            extract7zInto(fullName, bytes, depth + 1, out, budget);
        } else {
            extractInto(fullName, bytes, depth + 1, out, budget);
        }
    }

    /**
     * Распаковка 7z-архива (commons-compress + XZ for Java): та же логика, что
     * у ZIP — фильтр служебных файлов, рекурсия вложенных архивов, общие лимиты.
     * 7z требует произвольного доступа, поэтому читается из памяти целиком
     * (SeekableInMemoryByteChannel), а не потоково.
     */
    private static void extract7zInto(String prefix, byte[] bytes, int depth,
                                      List<ExtractedFile> out, Budget budget) {
        try (SevenZFile sevenZ = SevenZFile.builder()
                .setSeekableByteChannel(new SeekableInMemoryByteChannel(bytes)).get()) {
            SevenZArchiveEntry entry;
            while ((entry = sevenZ.getNextEntry()) != null) {
                if (entry.isDirectory()) {
                    continue;
                }
                if (++budget.entries > MAX_ENTRIES) {
                    throw new FileException("Архив содержит слишком много файлов (лимит " + MAX_ENTRIES + ")");
                }
                String entryName = entry.getName() == null ? "" : entry.getName().replace('\\', '/');
                String fullName = prefix + "/" + entryName;
                String ext = extension(entryName);
                if ("zip".equals(ext) || "7z".equals(ext)) {
                    recurseNestedArchive(fullName, ext,
                            readStream(sevenZ.getInputStream(entry), entryName, budget), depth, out, budget);
                    continue;
                }
                if (isJunk(entryName)) {
                    budget.skipped++;
                    continue;
                }
                out.add(new ExtractedFile(fullName,
                        readStream(sevenZ.getInputStream(entry), entryName, budget)));
            }
        } catch (FileException e) {
            throw e;
        } catch (IOException e) {
            throw new FileException("Не удалось распаковать архив: " + prefix, e);
        }
    }

    private static byte[] readEntry(ZipInputStream zis, String entryName, Budget budget) throws IOException {
        return readStream(zis, entryName, budget);
    }

    /** Читает поток записи архива с учётом общего лимита распакованных байт. */
    private static byte[] readStream(InputStream in, String entryName, Budget budget) throws IOException {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        byte[] buf = new byte[64 * 1024];
        int read;
        while ((read = in.read(buf)) > 0) {
            budget.uncompressedBytes += read;
            if (budget.uncompressedBytes > MAX_TOTAL_UNCOMPRESSED_BYTES) {
                throw new FileException("Превышен лимит распакованного размера архива ("
                        + (MAX_TOTAL_UNCOMPRESSED_BYTES / (1024 * 1024)) + " МБ) на файле: " + entryName);
            }
            bos.write(buf, 0, read);
        }
        return bos.toByteArray();
    }

    /**
     * Служебный файл ЭДО или неподдерживаемый формат — в обработку не идёт.
     * Видимость package-private для тестов.
     */
    static boolean isJunk(String entryPath) {
        String baseName = entryPath.substring(entryPath.lastIndexOf('/') + 1);
        String lower = baseName.toLowerCase(Locale.ROOT);
        String ext = extension(baseName);

        if (SIGNATURE_EXTENSIONS.contains(ext)) {
            return true;
        }
        if (!DOCUMENT_EXTENSIONS.contains(ext)) {
            return true;
        }
        // паспорта ЭП: Passport(01).txt и т.п.
        if ("txt".equals(ext) && lower.startsWith("passport")) {
            return true;
        }
        // протоколы оператора ЭДО о передаче документа
        if ("pdf".equals(ext) && lower.contains("протокол передачи документа")) {
            return true;
        }
        // из XML содержателен только сам УПД (ON_NSCHFDOPPR);
        // DP_* и ON_NSCHFDOPPOK — технологические квитанции документооборота
        if ("xml".equals(ext) && !lower.startsWith("on_nschfdoppr_")) {
            return true;
        }
        return false;
    }

    private static String extension(String name) {
        int dotIdx = name.lastIndexOf('.');
        return dotIdx < 0 ? "" : name.substring(dotIdx + 1).toLowerCase(Locale.ROOT);
    }
}
