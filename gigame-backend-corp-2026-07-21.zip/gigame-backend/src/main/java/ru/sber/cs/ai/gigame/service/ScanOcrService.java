package ru.sber.cs.ai.gigame.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

/**
 * Распознавание PDF-сканов через файловое хранилище GigaChat.
 * <p>
 * PDF без текстового слоя загружается в хранилище GigaChat вложением к запросу
 * «перепиши текст документа» — модель распознаёт скан и возвращает текст,
 * который дальше идёт по обычному конвейеру сценария (группировка, проверки,
 * суммы). Файл после распознавания удаляется из хранилища.
 * <p>
 * Выключено по умолчанию: {@code app.document.ocr-via-gigachat=true}
 * (env {@code OCR_VIA_GIGACHAT}) включает. Результат помечается префиксом
 * {@link #OCR_PREFIX} — суммы из скана в итоговой форме стоит перепроверять.
 */
@Service
@Slf4j
@RequiredArgsConstructor
public class ScanOcrService {

    /** Префикс распознанного текста — виден конвейеру и в итоговой форме. */
    public static final String OCR_PREFIX = "[РАСПОЗНАНО ИЗ СКАНА — данные извлечены "
            + "автоматическим распознаванием, суммы рекомендуется перепроверить]";

    /**
     * Формулировка «выпиши содержимое» вместо «перепиши дословно текст вложения»:
     * на просьбу дословной переписки вложения GigaChat отвечает шаблонным отказом,
     * хотя файл обработан и находится в контексте (проверено экспериментально).
     */
    private static final String OCR_PROMPT = """
            Это отсканированный финансовый документ. Выпиши максимально полно его \
            содержимое в текстовом виде: тип и реквизиты документа (номера, даты), \
            стороны (исполнитель, заказчик, ИНН), основание (договор, спецификация), \
            таблицу работ построчно (колонки через « | »), все суммы, включая ИТОГО \
            с НДС. Нечитаемые фрагменты помечай [НЕЧИТАЕМО]. Ничего не добавляй от себя.""";

    private final GigaChatClient gigaChatClient;

    @Value("${app.document.ocr-via-gigachat:false}")
    private boolean enabled;

    /** Модель для распознавания (пусто — глобальная модель по умолчанию). */
    @Value("${app.document.ocr-model:}")
    private String ocrModel;

    /**
     * Лимит токенов ответа (~30-45 страниц текста) — одновременно потолок
     * расхода на один документ. При обрезке ответа текст помечается
     * {@link #OCR_TRUNCATED_NOTE}.
     */
    @Value("${app.document.ocr-max-tokens:32000}")
    private int ocrMaxTokens = 32000;

    /** Пометка неполного распознавания (ответ упёрся в лимит токенов). */
    public static final String OCR_TRUNCATED_NOTE = "\n[РАСПОЗНАНО ЧАСТИЧНО — документ длиннее "
            + "лимита распознавания, хвост текста отсутствует; увеличьте OCR_MAX_TOKENS "
            + "или проверьте документ вручную]";

    public boolean isEnabled() {
        return enabled;
    }

    /**
     * Распознаёт PDF-скан через GigaChat.
     *
     * @param filename имя файла (для хранилища и префикса)
     * @param content  содержимое PDF
     * @return распознанный текст с префиксом {@link #OCR_PREFIX}
     */
    public String recognize(String filename, byte[] content) {
        log.info("OCR скана через GigaChat: {} ({} КБ)", filename, content.length / 1024);
        var result = gigaChatClient.chatCompletionWithFile(
                OCR_PROMPT, filename, content, "application/pdf",
                ocrModel == null || ocrModel.isBlank() ? null : ocrModel,
                0.01, ocrMaxTokens);
        String text = OCR_PREFIX + " Документ «" + filename + "»:\n" + result.text();
        if (result.truncated()) {
            log.warn("OCR скана «{}»: ответ обрезан лимитом {} токенов — текст неполный",
                    filename, ocrMaxTokens);
            text += OCR_TRUNCATED_NOTE;
        }
        return text;
    }
}
