package ru.sber.cs.ai.gigame.service;

import lombok.extern.slf4j.Slf4j;
import org.springframework.ai.chat.messages.AssistantMessage;
import org.springframework.ai.chat.messages.Message;
import org.springframework.ai.chat.messages.SystemMessage;
import org.springframework.ai.chat.messages.UserMessage;
import org.springframework.ai.chat.model.ChatModel;
import org.springframework.ai.chat.model.ChatResponse;
import org.springframework.ai.chat.prompt.Prompt;
import org.springframework.ai.embedding.Embedding;
import org.springframework.ai.embedding.EmbeddingModel;
import org.springframework.ai.embedding.EmbeddingRequest;
import org.springframework.ai.embedding.EmbeddingResponse;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

/**
 * Тонкая обёртка над Spring AI моделями (авто-настроенные GigaChat).
 * <p>
 * Сохраняет те же сигнатуры публичных методов, чтобы ChatService и ScenarioEngine
 * не требовали изменений.
 *
 * @see ChatModel
 * @see EmbeddingModel
 */
@Service
@Slf4j
public class GigaChatClient {

    private final ChatModel chatModel;
    private final EmbeddingModel embeddingModel;
    /** API файлового хранилища GigaChat (может отсутствовать в тестовом контексте). */
    private final org.springframework.beans.factory.ObjectProvider<chat.giga.springai.api.chat.GigaChatApi> gigaChatApiProvider;
    @Value("${app.embedding.text-max-length:800}")
    private int textMaxLength;
    @Value("${app.embedding.batch-size:50}")
    private int batchSize;
    /**
     * Повторные попытки вызова GigaChat при временных сбоях (429, 5xx, сеть).
     * Дорогие многоузловые сценарии не должны падать из-за разового сбоя API.
     */
    @Value("${app.gigachat.retry.max-attempts:3}")
    private int retryMaxAttempts;
    @Value("${app.gigachat.retry.delay-millis:3000}")
    private long retryDelayMillis;
    @Value("${app.gigachat.retry.delay-429-millis:30000}")
    private long retryDelay429Millis;

    /**
     * Стек счётчиков токенов текущего потока: движок сценариев открывает кадр
     * перед выполнением узла и закрывает после — все LLM-вызовы узла суммируются.
     * Стек (а не одиночный счётчик) нужен для вложенных под-сценариев:
     * закрытый кадр вливается в родительский.
     */
    private static final ThreadLocal<java.util.Deque<long[]>> USAGE_CAPTURE =
            ThreadLocal.withInitial(java.util.ArrayDeque::new);

    @org.springframework.beans.factory.annotation.Autowired
    public GigaChatClient(ChatModel chatModel,
                          EmbeddingModel embeddingModel,
                          org.springframework.beans.factory.ObjectProvider<chat.giga.springai.api.chat.GigaChatApi> gigaChatApiProvider) {
        this.chatModel = chatModel;
        this.embeddingModel = embeddingModel;
        this.gigaChatApiProvider = gigaChatApiProvider;
    }

    public GigaChatClient(ChatModel chatModel,
                          EmbeddingModel embeddingModel) {
        this(chatModel, embeddingModel, null);
    }

    /** Открывает кадр учёта токенов для текущего потока. */
    public static void beginUsageCapture() {
        USAGE_CAPTURE.get().push(new long[1]);
    }

    /**
     * Закрывает кадр учёта и возвращает суммарные токены кадра.
     * Токены вливаются в родительский кадр (вложенные под-сценарии).
     *
     * @return суммарные total_tokens кадра или {@code null}, если токенов не было
     */
    public static Integer endUsageCapture() {
        var stack = USAGE_CAPTURE.get();
        if (stack.isEmpty()) {
            return null;
        }
        long total = stack.pop()[0];
        if (!stack.isEmpty()) {
            stack.peek()[0] += total;
        } else {
            USAGE_CAPTURE.remove();
        }
        return total > 0 ? (int) Math.min(total, Integer.MAX_VALUE) : null;
    }

    /** Добавляет usage LLM-вызова в открытый кадр учёта (если он есть). */
    public static void addCapturedUsage(Map<String, Object> usage) {
        if (usage == null) {
            return;
        }
        var stack = USAGE_CAPTURE.get();
        if (stack.isEmpty()) {
            USAGE_CAPTURE.remove();
            return;
        }
        Object total = usage.get("total_tokens");
        if (total instanceof Number number) {
            stack.peek()[0] += number.longValue();
        }
    }

    // -------------------------------------------------------------------------
    // Chat completion (synchronous)
    // -------------------------------------------------------------------------

    /**
     * Синхронное выполнение чат-запроса.
     *
     * @param messages список сообщений в формате {role, content}
     * @return текст ответа ассистента
     */
    public String chatCompletion(List<Map<String, String>> messages) {
        return chatCompletion(messages, null, null);
    }

    /**
     * Синхронный чат-запрос с переопределением модели и температуры
     * (настройки конкретного узла сценария).
     *
     * @param messages    список сообщений в формате {role, content}
     * @param model       модель GigaChat (null — модель по умолчанию)
     * @param temperature температура генерации (null — значение по умолчанию)
     * @return текст ответа ассистента
     */
    public String chatCompletion(List<Map<String, String>> messages, String model, Double temperature) {
        return chatCompletionResult(messages, model, temperature).text();
    }

    /**
     * Результат чат-запроса: текст ответа и статистика использования токенов.
     *
     * @param text      текст ответа ассистента
     * @param usage     {prompt_tokens, completion_tokens, total_tokens} или {@code null},
     *                  если провайдер не вернул статистику
     * @param truncated ответ обрезан лимитом токенов (finish_reason=length)
     */
    public record ChatResult(String text, Map<String, Object> usage, boolean truncated) {
        public ChatResult(String text, Map<String, Object> usage) {
            this(text, usage, false);
        }
    }

    /**
     * Определяет, обрезан ли ответ лимитом токенов (finish_reason=length).
     *
     * @param response ответ модели
     * @return {@code true}, если генерация остановлена по лимиту
     */
    private static boolean isTruncated(ChatResponse response) {
        try {
            var metadata = response.getResult().getMetadata();
            return metadata != null && "length".equalsIgnoreCase(metadata.getFinishReason());
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Синхронный чат-запрос с переопределением модели/температуры,
     * возвращающий текст ответа вместе со статистикой usage.
     *
     * @param messages    список сообщений в формате {role, content}
     * @param model       модель GigaChat (null — модель по умолчанию)
     * @param temperature температура генерации (null — значение по умолчанию)
     * @return текст ответа и usage
     */
    public ChatResult chatCompletionResult(List<Map<String, String>> messages, String model, Double temperature) {
        Prompt prompt;
        if (model == null && temperature == null) {
            prompt = toPrompt(messages);
        } else {
            var options = chat.giga.springai.GigaChatOptions.builder();
            if (model != null) {
                options.model(model);
            }
            if (temperature != null) {
                options.temperature(temperature);
            }
            prompt = new Prompt(toPrompt(messages).getInstructions(), options.build());
        }
        ChatResponse response = callWithRetry(prompt);
        Map<String, Object> usage = extractUsage(response);
        addCapturedUsage(usage);
        return new ChatResult(response.getResult().getOutput().getText(), usage);
    }

    /**
     * Чат-запрос с файлом-вложением: файл загружается в файловое хранилище
     * GigaChat (это делает {@code GigaChatModel} автоматически для Media без id),
     * модель распознаёт содержимое (включая сканы), после ответа файл удаляется
     * из хранилища.
     *
     * @param userText    текст запроса к модели
     * @param filename    имя файла (для хранилища)
     * @param content     содержимое файла
     * @param mimeType    MIME-тип файла (например, application/pdf)
     * @param model       модель GigaChat (null — модель по умолчанию)
     * @param temperature температура генерации (null — значение по умолчанию)
     * @param maxTokens   лимит токенов ответа (null — значение по умолчанию;
     *                    для полной перепечатки многостраничного скана нужен запас)
     * @return текст ответа и usage
     */
    public ChatResult chatCompletionWithFile(String userText, String filename, byte[] content,
                                             String mimeType, String model, Double temperature,
                                             Integer maxTokens) {
        // имя файла уходит в Content-Disposition хранилища GigaChat: кириллица,
        // пути и пробелы ломают обработку файла — передаётся безопасное ASCII-имя
        var media = org.springframework.ai.content.Media.builder()
                .mimeType(org.springframework.util.MimeType.valueOf(mimeType))
                .data(content)
                .name(safeAttachmentName(filename))
                .build();
        var userMessage = UserMessage.builder().text(userText).media(media).build();
        var options = chat.giga.springai.GigaChatOptions.builder();
        if (model != null) {
            options.model(model);
        }
        if (temperature != null) {
            options.temperature(temperature);
        }
        if (maxTokens != null) {
            options.maxTokens(maxTokens);
        }
        Prompt prompt = new Prompt(List.of(userMessage), options.build());
        ChatResponse response = callWithRetry(prompt);
        deleteUploadedMedia(response);
        Map<String, Object> usage = extractUsage(response);
        addCapturedUsage(usage);
        return new ChatResult(response.getResult().getOutput().getText(), usage, isTruncated(response));
    }

    /**
     * Безопасное ASCII-имя вложения для файлового хранилища GigaChat:
     * расширение сохраняется, остальное заменяется хэшем исходного имени.
     *
     * @param filename исходное имя файла (может содержать путь и кириллицу)
     * @return имя вида {@code attachment-1a2b3c4d.pdf}
     */
    static String safeAttachmentName(String filename) {
        String ext = "";
        int dot = filename.lastIndexOf('.');
        if (dot >= 0 && filename.substring(dot + 1).matches("[A-Za-z0-9]{1,8}")) {
            ext = "." + filename.substring(dot + 1).toLowerCase(java.util.Locale.ROOT);
        }
        return "attachment-" + Integer.toHexString(filename.hashCode()) + ext;
    }

    /**
     * Удаляет из файлового хранилища GigaChat файлы, загруженные моделью
     * для этого запроса (их id — в метаданных ответа). Ошибка удаления не
     * прерывает обработку: файлы приватные и лишь занимают квоту хранилища.
     *
     * @param response ответ модели
     */
    private void deleteUploadedMedia(ChatResponse response) {
        try {
            var api = gigaChatApiProvider != null ? gigaChatApiProvider.getIfAvailable() : null;
            if (api == null || response.getMetadata() == null) {
                return;
            }
            Object ids = response.getMetadata().get(chat.giga.springai.GigaChatModel.UPLOADED_MEDIA_IDS);
            if (!(ids instanceof java.util.Collection<?> list)) {
                return;
            }
            for (Object id : list) {
                api.deleteFile(String.valueOf(id));
            }
        } catch (Exception e) {
            log.warn("Не удалось удалить файлы из хранилища GigaChat: {}", e.getMessage());
        }
    }

    /**
     * Извлекает статистику использования токенов из ответа модели.
     *
     * @param response ответ Spring AI
     * @return map с ключами prompt_tokens/completion_tokens/total_tokens или {@code null}
     */
    private Map<String, Object> extractUsage(ChatResponse response) {
        try {
            var metadata = response.getMetadata();
            if (metadata == null || metadata.getUsage() == null) {
                return null;
            }
            var usage = metadata.getUsage();
            Map<String, Object> map = new java.util.HashMap<>();
            map.put("prompt_tokens", usage.getPromptTokens());
            map.put("completion_tokens", usage.getCompletionTokens());
            map.put("total_tokens", usage.getTotalTokens());
            return map;
        } catch (Exception e) {
            log.debug("Не удалось извлечь usage из ответа GigaChat: {}", e.getMessage());
            return null;
        }
    }

    /**
     * Вызов чат-модели с повторными попытками при временных сбоях.
     * <p>
     * Повторяются: 429 (превышение лимита — увеличенная задержка), 5xx, сетевые
     * таймауты. Не повторяются: 4xx-ошибки данных (400, 401, 402, 413) —
     * повтор их не исправит. Задержка растёт линейно с номером попытки.
     *
     * @param prompt промпт
     * @return ответ модели
     */
    private ChatResponse callWithRetry(Prompt prompt) {
        return withRetry(() -> chatModel.call(prompt));
    }

    private <T> T withRetry(java.util.function.Supplier<T> call) {
        // защита от нулевой/отрицательной конфигурации — хотя бы одна попытка
        int maxAttempts = Math.max(1, retryMaxAttempts);
        RuntimeException last = null;
        for (int attempt = 1; attempt <= maxAttempts; attempt++) {
            try {
                return call.get();
            } catch (RuntimeException e) {
                handleRetryableFailure(e, attempt, maxAttempts);
                last = e;
            }
        }
        throw last;
    }

    /**
     * Обрабатывает сбой попытки вызова: неповторяемую ошибку (или исчерпание
     * попыток) пробрасывает, при повторяемой — логирует и выдерживает задержку.
     *
     * @param e           возникшая ошибка
     * @param attempt     номер текущей попытки (с 1)
     * @param maxAttempts максимальное число попыток
     */
    private void handleRetryableFailure(RuntimeException e, int attempt, int maxAttempts) {
        String msg = String.valueOf(e.getMessage());
        boolean rateLimited = isRateLimited(msg);
        boolean retryable = rateLimited || isTransientFailure(msg);
        if (!retryable || attempt == maxAttempts) {
            throw e;
        }
        long delay = (rateLimited ? retryDelay429Millis : retryDelayMillis) * attempt;
        log.warn("GigaChat: временный сбой (попытка {}/{}), повтор через {} мс: {}",
                attempt, maxAttempts, delay, msg);
        sleepBeforeRetry(delay, e);
    }

    /**
     * Превышение лимита запросов (429) — повторяется с увеличенной задержкой.
     *
     * @param msg текст ошибки
     * @return {@code true}, если ошибка — превышение лимита
     */
    private static boolean isRateLimited(String msg) {
        return msg.contains("429") || msg.contains("Too Many Requests");
    }

    /**
     * Временный сбой (5xx, сетевой таймаут, обрыв соединения) — повторяется.
     * 4xx-ошибки данных (400, 401, 402, 413) не повторяются: повтор их не исправит.
     *
     * @param msg текст ошибки
     * @return {@code true}, если сбой временный
     */
    private static boolean isTransientFailure(String msg) {
        boolean serverError = msg.contains("50") && (msg.contains("500") || msg.contains("502")
                || msg.contains("503") || msg.contains("504"));
        return serverError
                || msg.contains("timed out") || msg.contains("timeout")
                || msg.contains("Connection") || msg.contains("connection");
    }

    /**
     * Приостанавливает поток перед повторной попыткой вызова.
     * <p>
     * При прерывании ожидания восстанавливает флаг прерывания потока
     * и пробрасывает исходную ошибку вызова.
     *
     * @param delay задержка в миллисекундах
     * @param cause исходная ошибка, из-за которой выполняется повтор
     */
    private void sleepBeforeRetry(long delay, RuntimeException cause) {
        try {
            Thread.sleep(delay);
        } catch (InterruptedException ie) {
            Thread.currentThread().interrupt();
            throw cause;
        }
    }

    // -------------------------------------------------------------------------
    // Завершение чата (последовательное)
    // -------------------------------------------------------------------------

    /**
     * Потоковое выполнение чат-запроса, возвращает Flux текстовых фрагментов.
     * <p>
     * Использует синхронный вызов, обёрнутый в Flux — у GigaChat streaming есть
     * проблемы совместимости с JDK HttpClient + Reactor в WebFlux контексте.
     * Синхронный вызов надёжен и возвращает полный ответ.
     *
     * @param messages список сообщений в формате {role, content}
     * @return Flux строк текста
     */
    public Flux<String> chatCompletionStream(List<Map<String, String>> messages) {
        return chatCompletionStreamResult(messages, null, null).map(ChatResult::text);
    }

    /**
     * Потоковый чат-запрос с переопределением модели/температуры и usage в результате.
     * <p>
     * Используется синхронный вызов, обёрнутый в Flux — у spring-ai-gigachat streaming есть
     * проблемы совместимости с JDK HttpClient + Reactor в WebFlux контексте.
     * Синхронный вызов надёжен и возвращает полный ответ одним элементом.
     *
     * @param messages    список сообщений в формате {role, content}
     * @param model       модель GigaChat (null — модель по умолчанию)
     * @param temperature температура генерации (null — значение по умолчанию)
     * @return Flux с единственным ChatResult
     */
    public Flux<ChatResult> chatCompletionStreamResult(List<Map<String, String>> messages,
                                                       String model, Double temperature) {
        return Flux.defer(() -> {
            log.debug("Start chat completion (synchronous)");
            ChatResult result = chatCompletionResult(messages, model, temperature);
            log.debug("Chat completion completed, {} characters", result.text().length());
            return Flux.just(result);
        });
    }

    // -------------------------------------------------------------------------
    // эмбеддинги
    // -------------------------------------------------------------------------

    /**
     * Получает векторные эмбеддинги для списка текстов.
     * <p>
     * Пакетная обработка: по 50 текстов за раз. Текст усекается до 800 символов
     * (ограничение GigaChat ~514 токенов).
     *
     * @param texts список текстов для эмбеддинги
     * @return список массивов float[] векторных эмбеддингов
     */
    public List<float[]> getEmbeddings(List<String> texts) {
        List<String> truncated = texts.stream()
                .map(t -> t.length() > textMaxLength ? t.substring(0, textMaxLength) : t)
                .toList();

        List<float[]> results = new ArrayList<>();
        for (int i = 0; i < truncated.size(); i += batchSize) {
            List<String> batch = truncated.subList(i, Math.min(i + batchSize, truncated.size()));
            // Используются специфичные для GigaChat опции, чтобы избежать NPE при getModel()
            try {
                var opts = chat.giga.springai.GigaChatEmbeddingOptions.builder()
                        .withModel("Embeddings").withDimensions(1024).build();
                EmbeddingResponse response = withRetry(() -> embeddingModel.call(
                        new EmbeddingRequest(batch, opts)));
                results.addAll(response.getResults().stream()
                        .map(Embedding::getOutput)
                        .toList());
            } catch (Exception e) {
                log.error("Embedding batch {} failed {}", i / batchSize, e.getMessage());
                // Return nulls or empty arrays for failed batch
                results.addAll(Collections.nCopies(batch.size(), new float[1024]));
            }
        }
        return results;
    }

    // -------------------------------------------------------------------------
    // Внутренние вспомогательные методы
    // -------------------------------------------------------------------------

    /**
     * Преобразует наш формат List&lt;Map&lt;role,content&gt;&gt; в Spring AI Prompt.
     *
     * @param messages список сообщений
     * @return объект Prompt для Spring AI
     */
    private Prompt toPrompt(List<Map<String, String>> messages) {
        List<Message> aiMessages = new ArrayList<>();
        for (Map<String, String> msg : messages) {
            String role = msg.get("role");
            String content = msg.get("content");
            switch (role) {
                case "system" -> aiMessages.add(new SystemMessage(content));
                case "assistant" -> aiMessages.add(new AssistantMessage(content));
                default /*user*/ -> aiMessages.add(new UserMessage(content));
            }
        }
        return new Prompt(aiMessages);
    }
}
