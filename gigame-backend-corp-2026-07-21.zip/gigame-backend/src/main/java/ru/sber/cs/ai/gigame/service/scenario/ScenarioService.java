package ru.sber.cs.ai.gigame.service.scenario;

import org.springframework.core.io.Resource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.codec.ServerSentEvent;
import org.springframework.http.codec.multipart.FilePart;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;
import reactor.core.publisher.Flux;
import ru.sber.cs.ai.gigame.dto.scenario.ScenarioDetailResponse;
import ru.sber.cs.ai.gigame.dto.scenario.ScenarioResponse;
import ru.sber.cs.ai.gigame.dto.scenario.ScenarioRunDetailResponse;
import ru.sber.cs.ai.gigame.dto.scenario.ScenarioRunResponse;
import ru.sber.cs.ai.gigame.dto.scenario.ScenarioRunStepResponse;
import ru.sber.cs.ai.gigame.dto.scenario.graph.GraphDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.GraphDataMapper;
import ru.sber.cs.ai.gigame.exception.FileException;
import ru.sber.cs.ai.gigame.exception.NotFoundException;
import ru.sber.cs.ai.gigame.model.Scenario;
import ru.sber.cs.ai.gigame.model.ScenarioRun;
import ru.sber.cs.ai.gigame.model.ScenarioRunStep;
import ru.sber.cs.ai.gigame.repository.ScenarioRepository;
import ru.sber.cs.ai.gigame.repository.ScenarioRunRepository;
import ru.sber.cs.ai.gigame.repository.ScenarioRunStepRepository;
import ru.sber.cs.ai.gigame.service.DocumentService;
import ru.sber.cs.ai.gigame.utils.FileUtils;
import ru.sber.cs.ai.gigame.utils.UserUtils;
import ru.sber.cs.ai.gigame.utils.ZipExtractor;

import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Сервис управления сценариями.
 * <p>
 * Реализует простые операции CRUD для сценариев, запусков и шагов.
 * Логика выполнения сценариев находится в {@link ScenarioEngine}.
 *
 * @see Scenario
 * @see ScenarioRun
 * @see ScenarioRunStep
 */
@Service
@lombok.extern.slf4j.Slf4j
public class ScenarioService {

    /**
     * Максимум документов на прогон после распаковки архивов
     * ({@code app.scenario.max-documents-per-run}, env {@code SCENARIO_MAX_DOCUMENTS}).
     * Большие наборы догружаются частями: POST /upload?append=true.
     */
    @org.springframework.beans.factory.annotation.Value("${app.scenario.max-documents-per-run:500}")
    private int maxDocumentsPerRun = 500;

    /** Порог длины текста PDF, ниже которого документ считается сканом без текстового слоя. */
    @org.springframework.beans.factory.annotation.Value("${app.document.min-parsed-chars:40}")
    private int minParsedChars;

    /**
     * Параллельность парсинга документов при загрузке
     * ({@code app.document.parse-parallelism}, env {@code DOCUMENT_PARSE_PARALLELISM}):
     * большие комплекты (сотни страниц PDF, OCR сканов) при последовательном парсинге
     * превышают таймауты корпоративных шлюзов.
     */
    @org.springframework.beans.factory.annotation.Value("${app.document.parse-parallelism:4}")
    private int parseParallelism = 4;

    /**
     * Лимит распакованного размера одной внутренней записи OOXML-файла
     * ({@code app.document.max-ooxml-entry-mb}): защита от «XML-бомб»,
     * которые POI раздувает минутами перед отказом.
     */
    @org.springframework.beans.factory.annotation.Value("${app.document.max-ooxml-entry-mb:50}")
    private int maxOoxmlEntryMb = 50;

    private final ScenarioRepository scenarioRepository;
    private final ScenarioRunRepository scenarioRunRepository;
    private final ScenarioRunStepRepository scenarioRunStepRepository;
    private final ru.sber.cs.ai.gigame.repository.ScenarioVersionRepository scenarioVersionRepository;
    private final ScenarioEngine scenarioEngine;
    private final DocumentService documentService;
    private final ru.sber.cs.ai.gigame.service.ScanOcrService scanOcrService;

    public ScenarioService(ScenarioRepository scenarioRepository,
                           ScenarioRunRepository scenarioRunRepository,
                           ScenarioRunStepRepository scenarioRunStepRepository,
                           ru.sber.cs.ai.gigame.repository.ScenarioVersionRepository scenarioVersionRepository,
                           ScenarioEngine scenarioEngine,
                           DocumentService documentService,
                           ru.sber.cs.ai.gigame.service.ScanOcrService scanOcrService) {
        this.scenarioRepository = scenarioRepository;
        this.scenarioRunRepository = scenarioRunRepository;
        this.scenarioRunStepRepository = scenarioRunStepRepository;
        this.scenarioVersionRepository = scenarioVersionRepository;
        this.scenarioEngine = scenarioEngine;
        this.documentService = documentService;
        this.scanOcrService = scanOcrService;
    }

    /** Действующий лимит документов на прогон (для сквозных проверок при догрузке). */
    public int getMaxDocumentsPerRun() {
        return maxDocumentsPerRun;
    }

    // -------------------------------------------------------------------------
    // CRUD сценариев
    // -------------------------------------------------------------------------

    /**
     * Возвращает список всех сценариев, отсортированных по дате обновления.
     *
     * @param userId идентификатор пользователя
     * @return список сценариев пользователя
     */
    public List<ScenarioResponse> getScenarios(String userId) {
        return scenarioRepository.findAllByUserIdOrderByUpdatedAtDesc(UserUtils.getUserId(userId)).stream()
                .map(ScenarioMapper::toResponse)
                .toList();
    }

    /**
     * Возвращает один сценарий с полными данными графа.
     * Выбрасывает исключение, если сценарий не найден.
     *
     * @param userId идентификатор пользователя
     * @param id     UUID сценария
     * @return подробная информация о сценарии
     */
    public ScenarioDetailResponse getScenario(String userId, UUID id) {
        Scenario scenario = scenarioRepository.findById(id)
                .orElseThrow(() -> new NotFoundException("Scenario not found: " + id));
        UserUtils.checkUserId(userId, scenario.getUserId());
        return ScenarioMapper.toDetailResponse(scenario);
    }

    /**
     * Создаёт новый сценарий.
     *
     * @param userId      идентификатор пользователя
     * @param name        имя сценария
     * @param description описание сценария (опционально)
     * @param graphData   данные графа (узлы и рёбра)
     * @return созданный сценарий
     */
    @Transactional
    public ScenarioResponse createScenario(String userId, String name, String description, GraphDataDto graphData) {
        Scenario scenario = new Scenario();
        scenario.setName(name);
        scenario.setDescription(description);
        scenario.setGraphData(graphData != null ? GraphDataMapper.fromDto(graphData) : Map.of());
        scenario.setUserId(UserUtils.getUserId(userId));
        scenario = scenarioRepository.save(scenario);
        return ScenarioMapper.toResponse(scenario);
    }

    /**
     * Обновляет существующий сценарий.
     *
     * @param userId      идентификатор пользователя
     * @param id          UUID сценария
     * @param name        новое имя (опционально)
     * @param description новое описание (опционально)
     * @param graphData   новые данные графа (опционально)
     * @return обновлённый сценарий
     */
    @Transactional
    public ScenarioResponse updateScenario(String userId, UUID id, String name, String description, GraphDataDto graphData) {
        Scenario scenario = scenarioRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Scenario not found: " + id));
        UserUtils.checkUserId(userId, scenario.getUserId());
        snapshotVersion(scenario);
        if (name != null) {
            scenario.setName(name);
        }
        if (description != null) {
            scenario.setDescription(description);
        }
        if (graphData != null) {
            scenario.setGraphData(GraphDataMapper.fromDto(graphData));
        }
        scenario = scenarioRepository.save(scenario);
        return ScenarioMapper.toResponse(scenario);
    }

    /**
     * Сохраняет снапшот текущего состояния сценария как очередную версию.
     * Вызывается перед каждым изменением — история правок не теряется.
     *
     * @param scenario текущее состояние сценария
     */
    private void snapshotVersion(Scenario scenario) {
        int next = scenarioVersionRepository
                .findFirstByScenarioIdOrderByVersionNoDesc(scenario.getId())
                .map(v -> v.getVersionNo() + 1)
                .orElse(1);
        var version = new ru.sber.cs.ai.gigame.model.ScenarioVersion();
        version.setId(UUID.randomUUID());
        version.setScenarioId(scenario.getId());
        version.setVersionNo(next);
        version.setName(scenario.getName());
        version.setDescription(scenario.getDescription());
        version.setGraphData(scenario.getGraphData());
        version.setCreatedAt(OffsetDateTime.now());
        scenarioVersionRepository.save(version);
    }

    /**
     * Список версий сценария (метаданные, без графов).
     *
     * @param userId идентификатор пользователя
     * @param id     UUID сценария
     * @return версии от новых к старым
     */
    public List<Map<String, Object>> getVersions(String userId, UUID id) {
        Scenario scenario = scenarioRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Scenario not found: " + id));
        UserUtils.checkUserId(userId, scenario.getUserId());
        return scenarioVersionRepository.findByScenarioIdOrderByVersionNoDesc(id).stream()
                .map(v -> Map.<String, Object>of(
                        "version_no", v.getVersionNo(),
                        "name", v.getName() == null ? "" : v.getName(),
                        "created_at", v.getCreatedAt()))
                .toList();
    }

    /**
     * Восстанавливает сценарий из версии. Текущее состояние предварительно
     * сохраняется как новая версия — откат отката возможен.
     *
     * @param userId    идентификатор пользователя
     * @param id        UUID сценария
     * @param versionNo номер версии
     * @return обновлённый сценарий
     */
    @Transactional
    public ScenarioResponse restoreVersion(String userId, UUID id, int versionNo) {
        Scenario scenario = scenarioRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Scenario not found: " + id));
        UserUtils.checkUserId(userId, scenario.getUserId());
        var version = scenarioVersionRepository.findByScenarioIdAndVersionNo(id, versionNo)
                .orElseThrow(() -> new NotFoundException("Версия " + versionNo + " не найдена"));
        snapshotVersion(scenario);
        scenario.setName(version.getName());
        scenario.setDescription(version.getDescription());
        scenario.setGraphData(version.getGraphData());
        scenario = scenarioRepository.save(scenario);
        return ScenarioMapper.toResponse(scenario);
    }

    /**
     * Возобновляет упавший прогон с места сбоя: создаёт новый прогон, восстанавливая
     * результаты завершённых LLM-узлов из шагов исходного (без повторных обращений
     * к GigaChat за уже полученными ответами).
     *
     * @param userId идентификатор пользователя
     * @param runId  идентификатор упавшего прогона
     * @return поток SSE-событий нового прогона
     */
    public Flux<ServerSentEvent<Map<String, Object>>> resumeScenarioRun(String userId, UUID runId) {
        ScenarioRun oldRun = scenarioRunRepository.findById(runId)
                .orElseThrow(() -> new IllegalArgumentException("Запуск сценария не найден: " + runId));
        Scenario model = scenarioRepository.findById(oldRun.getScenarioId())
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Scenario not found"));
        UserUtils.checkUserId(userId, model.getUserId());
        List<ScenarioRunStep> oldSteps = scenarioRunStepRepository.findByRunIdOrderByStartedAtAsc(runId);
        ScenarioRun run = new ScenarioRun();
        run.setScenarioId(oldRun.getScenarioId());
        run.setStatus("running");
        run.setStartedAt(OffsetDateTime.now());
        run = scenarioRunRepository.save(run);
        return scenarioEngine.resumeScenario(run, GraphDataMapper.toDto(model.getGraphData()), oldSteps);
    }

    /**
     * Создаёт копию сценария с суффиксом "(копия)".
     *
     * @param userId идентификатор пользователя
     * @param id     UUID сценария
     * @return дубликат сценария
     */
    @Transactional
    public ScenarioResponse duplicateScenario(String userId, UUID id) {
        Scenario original = scenarioRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Scenario not found: " + id));
        UserUtils.checkUserId(userId, original.getUserId());
        Scenario copy = new Scenario();
        copy.setName(original.getName() + " (копия)");
        copy.setDescription(original.getDescription());
        copy.setGraphData(original.getGraphData());
        copy.setUserId(UserUtils.getUserId(userId));
        copy = scenarioRepository.save(copy);
        return ScenarioMapper.toResponse(copy);
    }

    /**
     * Удаляет сценарий по идентификатору.
     *
     * @param userId идентификатор пользователя
     * @param id     UUID сценария
     */
    @Transactional
    public void deleteScenario(String userId, UUID id) {
        Scenario scenario = scenarioRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Сценарий не найден: " + id));
        UserUtils.checkUserId(userId, scenario.getUserId());
        scenarioRepository.delete(scenario);
    }

    // -------------------------------------------------------------------------
    // Запросы запусков сценариев
    // -------------------------------------------------------------------------

    /**
     * Возвращает список запусков для указанного сценария.
     *
     * @param userId     идентификатор пользователя
     * @param scenarioId UUID сценария
     * @return список запусков, отсортированных по дате начала
     */
    public List<ScenarioRunResponse> getScenarioRuns(String userId, UUID scenarioId) {
        Scenario scenario = scenarioRepository.findById(scenarioId)
                .orElseThrow(() -> new IllegalArgumentException("Сценарий не найден: " + scenarioId));
        UserUtils.checkUserId(userId, scenario.getUserId());
        return scenarioRunRepository.findByScenarioIdOrderByStartedAtDesc(scenarioId).stream()
                .map(ScenarioMapper::toRunResponse)
                .toList();
    }

    /**
     * Возвращает детальную информацию о запуске сценария со всеми шагами.
     *
     * @param userId идентификатор пользователя
     * @param runId  UUID запуска
     * @return детальная информация о запуске
     */
    public ScenarioRunDetailResponse getScenarioRun(String userId, UUID runId) {
        ScenarioRun run = scenarioRunRepository.findById(runId)
                .orElseThrow(() -> new IllegalArgumentException("Запуск сценария не найден: " + runId));
        Scenario scenario = scenarioRepository.findById(run.getScenarioId())
                .orElseThrow(() -> new IllegalArgumentException("Сценарий не найден: " + run.getScenarioId()));
        UserUtils.checkUserId(userId, scenario.getUserId());
        List<ScenarioRunStepResponse> stepResponses = scenarioRunStepRepository
                .findByRunIdOrderByStartedAtAsc(run.getId()).stream()
                .map(ScenarioMapper::toStepResponse)
                .toList();
        return new ScenarioRunDetailResponse(
                run.getId(),
                run.getScenarioId(),
                run.getStatus(),
                run.getInputDocumentIds(),
                run.getResult(),
                run.getStartedAt(),
                run.getCompletedAt(),
                stepResponses
        );
    }

    /**
     * Сохраняет запуск сценария.
     *
     * @param run запуск сценария
     * @return сохраненный запуск
     */
    @Transactional
    @SuppressWarnings("unused")
    public ScenarioRun saveScenarioRun(ScenarioRun run) {
        return scenarioRunRepository.save(run);
    }

    public Flux<ServerSentEvent<Map<String, Object>>> runScenario(String userId, UUID id, Boolean stepMode) {
        var model = scenarioRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Scenario not found"));
        UserUtils.checkUserId(userId, model.getUserId());
        var scenario = ScenarioMapper.toDetailResponse(model);
        ScenarioRun run = new ScenarioRun();
        run.setScenarioId(id);
        run.setStatus("running");
        run.setStartedAt(OffsetDateTime.now());
        run = scenarioRunRepository.save(run);

        if (Boolean.TRUE.equals(stepMode)) {
            scenarioEngine.enableStepMode(run.getId().toString());
        }

        run = scenarioRunRepository.save(run);
        return scenarioEngine.executeScenario(run, scenario.graphData());
    }

    public List<String> getDocumentsText(List<FilePart> files, List<ServerSentEvent<Map<String, Object>>> uploadEvents) {
        return getDocuments(files, uploadEvents).stream().map(DocumentText::text).toList();
    }

    /**
     * Превращает загруженные файлы в документы для прогона сценария.
     * <p>
     * ZIP-архивы распаковываются ({@link ZipExtractor}): служебные файлы ЭДО
     * отфильтровываются, а имя каждого документа включает путь внутри архива.
     * PDF без текстового слоя (скан) не отбрасывается — его текст заменяется
     * маркером «ТРЕБУЕТСЯ РУЧНАЯ ПРОВЕРКА», который проходит по конвейеру
     * до итоговой таблицы.
     *
     * @param files        загруженные файлы (в т.ч. ZIP)
     * @param uploadEvents накопитель SSE-событий прогресса (может быть {@code null})
     * @return документы: имя + извлечённый текст
     */
    public List<DocumentText> getDocuments(List<FilePart> files, List<ServerSentEvent<Map<String, Object>>> uploadEvents) {
        // фаза 1 (последовательно, I/O): чтение файлов и распаковка архивов в (имя, байты)
        List<RawDocument> raws = new ArrayList<>();
        for (int i = 0; i < files.size(); i++) {
            var file = files.get(i);
            String filename = FileUtils.getFilename(file);
            emitUploadProgress(uploadEvents, filename, i + 1, files.size());
            byte[] content = readFileContent(file, filename);
            if (filename.toLowerCase().endsWith(".zip") || filename.toLowerCase().endsWith(".7z")) {
                var extraction = ZipExtractor.extract(filename, content);
                if (extraction.files().isEmpty()) {
                    throw new FileException("Архив не содержит поддерживаемых документов: " + filename);
                }
                for (var extracted : extraction.files()) {
                    raws.add(new RawDocument(extracted.name(), extracted.content()));
                }
            } else {
                raws.add(new RawDocument(filename, content));
            }
        }
        List<DocumentText> documents = parseAllParallel(raws, uploadEvents);
        if (documents.size() > maxDocumentsPerRun) {
            throw new FileException("Слишком много документов после распаковки архивов: "
                    + documents.size() + ". Максимум: " + maxDocumentsPerRun);
        }
        if (uploadEvents != null) {
            uploadEvents.add(ServerSentEvent.<Map<String, Object>>builder()
                    .data(Map.of("type", "upload_done", "count", documents.size()))
                    .build());
        }
        return documents;
    }

    /** Сырой документ до извлечения текста: имя + байты содержимого. */
    private record RawDocument(String name, byte[] content) {
    }

    /**
     * Быстрая отсечка «XML-бомб» в OOXML-файлах (docx/xlsx/pptx) ДО парсинга POI:
     * если любая внутренняя запись при распаковке превышает
     * {@code app.document.max-ooxml-entry-mb}, файл отклоняется сразу — иначе POI
     * минутами раздувает сотни мегабайт XML и лишь затем падает (реальный кейс:
     * docx со сжатием x112, document.xml 207 МБ). Записи распаковываются потоково
     * со счётчиком байт и ранним выходом по лимиту — без построения DOM.
     *
     * @param filename    имя файла
     * @param contentType определённый тип контента
     * @param content     содержимое файла
     */
    private void rejectOoxmlBomb(String filename, String contentType, byte[] content) throws java.io.IOException {
        if (!"docx".equals(contentType) && !"xlsx".equals(contentType) && !"pptx".equals(contentType)) {
            return;
        }
        long limitBytes = maxOoxmlEntryMb * 1024L * 1024L;
        byte[] buf = new byte[64 * 1024];
        try (var zip = new java.util.zip.ZipInputStream(new java.io.ByteArrayInputStream(content))) {
            java.util.zip.ZipEntry entry;
            while ((entry = zip.getNextEntry()) != null) {
                // getSize() у ZipInputStream часто -1: считаем реально распакованные байты
                long total = 0;
                int n;
                while ((n = zip.read(buf)) > 0) {
                    total += n;
                    if (total > limitBytes) {
                        throw new FileException("Внутренняя часть «" + entry.getName() + "» файла «"
                                + filename + "» распаковывается более чем в " + maxOoxmlEntryMb
                                + " МБ — похоже на повреждённый или аномальный документ");
                    }
                }
            }
        }
    }

    /**
     * Фаза 2 (параллельно, CPU/OCR): парсинг документов пулом {@code parseParallelism}
     * потоков с сохранением порядка — синхронная загрузка больших комплектов
     * (сотни страниц PDF + OCR сканов) при последовательном парсинге превышает
     * таймауты корпоративных шлюзов.
     *
     * @param raws         документы: имя + сырое содержимое (текст ещё не извлечён)
     * @param uploadEvents накопитель SSE-событий (может быть {@code null})
     * @return распарсенные документы в исходном порядке
     */
    private List<DocumentText> parseAllParallel(List<RawDocument> raws,
                                                List<ServerSentEvent<Map<String, Object>>> uploadEvents) {
        List<DocumentText> documents = new ArrayList<>();
        var events = uploadEvents == null
                ? null
                : java.util.Collections.synchronizedList(uploadEvents);
        var pool = java.util.concurrent.Executors.newFixedThreadPool(
                Math.max(1, Math.min(parseParallelism, Math.max(raws.size(), 1))));
        try {
            List<java.util.concurrent.Callable<DocumentText>> tasks = new ArrayList<>();
            for (RawDocument raw : raws) {
                tasks.add(() -> parseDocument(raw.name(), raw.content(), events));
            }
            for (var future : pool.invokeAll(tasks)) {
                documents.add(future.get());
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new FileException("Обработка файлов прервана", e);
        } catch (java.util.concurrent.ExecutionException e) {
            Throwable cause = e.getCause() != null ? e.getCause() : e;
            throw cause instanceof RuntimeException runtime
                    ? runtime
                    : new FileException("Ошибка обработки файлов", cause);
        } finally {
            pool.shutdownNow();
        }
        return documents;
    }

    /**
     * Отправляет SSE-событие прогресса загрузки файла (если накопитель задан).
     *
     * @param uploadEvents накопитель SSE-событий (может быть {@code null})
     * @param filename     имя загружаемого файла
     * @param current      номер текущего файла (с 1)
     * @param total        общее количество файлов
     */
    private void emitUploadProgress(List<ServerSentEvent<Map<String, Object>>> uploadEvents,
                                    String filename, int current, int total) {
        if (uploadEvents != null) {
            uploadEvents.add(ServerSentEvent.<Map<String, Object>>builder()
                    .data(Map.of("type", "upload_progress",
                            "file", filename, "current", current, "total", total))
                    .build());
        }
    }

    /**
     * Читает содержимое загруженного файла в массив байт.
     *
     * @param file     загруженный файл
     * @param filename имя файла (для сообщения об ошибке)
     * @return содержимое файла
     */
    private byte[] readFileContent(FilePart file, String filename) {
        try {
            return FileUtils.toInputStream(file).block().readAllBytes();
        } catch (Exception e) {
            throw new FileException("Не удалось прочитать файл: " + filename, e);
        }
    }

    /**
     * Парсит один документ. Нечитаемый файл (повреждён, XML-бомба внутри docx,
     * неподдержанное содержимое) НЕ роняет загрузку всего комплекта — документ
     * получает маркер ручной проверки и проходит по конвейеру, а в лог загрузки
     * уходит предупреждение.
     */
    private DocumentText parseDocument(String filename, byte[] content,
                                       List<ServerSentEvent<Map<String, Object>>> uploadEvents) {
        String text;
        String contentType;
        try {
            contentType = FileUtils.detectContentType(filename);
            rejectOoxmlBomb(filename, contentType, content);
            text = documentService.parseText(new java.io.ByteArrayInputStream(content), contentType);
        } catch (Exception e) {
            log.warn("Не удалось обработать файл «{}» ({}) — маркер ручной проверки",
                    filename, String.valueOf(e.getMessage()));
            emitUploadWarning(uploadEvents, filename,
                    "файл не обработан (повреждён или неподдерживаемое содержимое) — требуется ручная проверка");
            return new DocumentText(filename, "[ТРЕБУЕТСЯ РУЧНАЯ ПРОВЕРКА] Документ «" + filename
                    + "» не удалось обработать: файл повреждён или содержит неподдерживаемое "
                    + "содержимое. Автоматический анализ невозможен — проверьте документ вручную.");
        }
        if ("pdf".equals(contentType) && text.strip().length() < minParsedChars) {
            text = handleScanPdf(filename, content, uploadEvents);
        }
        return new DocumentText(filename, text);
    }

    /**
     * PDF без текстового слоя: при включённом OCR ({@code app.document.ocr-via-gigachat})
     * скан распознаётся через файловое хранилище GigaChat, при выключенном или при
     * ошибке распознавания — маркер ручной проверки (прежнее поведение).
     *
     * @param filename     имя файла
     * @param content      содержимое PDF
     * @param uploadEvents накопитель SSE-событий (может быть {@code null})
     * @return распознанный текст либо маркер ручной проверки
     */
    private String handleScanPdf(String filename, byte[] content,
                                 List<ServerSentEvent<Map<String, Object>>> uploadEvents) {
        if (scanOcrService.isEnabled()) {
            try {
                String recognized = scanOcrService.recognize(filename, content);
                emitUploadWarning(uploadEvents, filename,
                        "PDF-скан распознан через GigaChat — проверьте суммы");
                return recognized;
            } catch (Exception e) {
                log.warn("OCR скана «{}» не удался ({}) — маркер ручной проверки", filename, e.getMessage());
            }
        }
        log.warn("PDF без текстового слоя (скан): {} — документ помечен для ручной проверки", filename);
        emitUploadWarning(uploadEvents, filename,
                "PDF без текстового слоя (скан) — требуется ручная проверка");
        return "[ТРЕБУЕТСЯ РУЧНАЯ ПРОВЕРКА] Документ «" + filename
                + "» не распознан: PDF без текстового слоя (скан). "
                + "Автоматический анализ содержимого невозможен — проверьте документ вручную.";
    }

    private void emitUploadWarning(List<ServerSentEvent<Map<String, Object>>> uploadEvents,
                                   String filename, String message) {
        if (uploadEvents != null) {
            uploadEvents.add(ServerSentEvent.<Map<String, Object>>builder()
                    .data(Map.of("type", "upload_warning", "file", filename, "message", message))
                    .build());
        }
    }

    public ResponseEntity<Resource> extractToDocx(String userId, UUID runId, boolean includeSteps) {
        ScenarioRunDetailResponse runDetail = getScenarioRun(userId, runId);
        var model = scenarioRepository.findById(runDetail.scenarioId())
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Scenario not found"));
        UserUtils.checkUserId(userId, model.getUserId());
        return ExportToDocx.generateDocx(runId, runDetail, includeSteps);
    }
}
