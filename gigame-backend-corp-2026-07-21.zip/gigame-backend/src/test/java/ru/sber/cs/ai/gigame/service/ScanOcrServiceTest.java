package ru.sber.cs.ai.gigame.service;

import org.junit.jupiter.api.Test;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.contains;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.ArgumentMatchers.isNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * Тесты распознавания PDF-сканов через файловое хранилище GigaChat.
 */
class ScanOcrServiceTest {

    @Test
    void disabledByDefault() {
        var service = new ScanOcrService(mock(GigaChatClient.class));
        assertFalse(service.isEnabled());
    }

    @Test
    void recognize_delegatesToGigaChatWithPdfAttachment_andPrefixesResult() {
        var gigaChat = mock(GigaChatClient.class);
        when(gigaChat.chatCompletionWithFile(anyString(), anyString(), any(), anyString(),
                isNull(), any(), anyInt()))
                .thenReturn(new GigaChatClient.ChatResult(
                        "Акт SSBRF21062 от 03.12.2021, ИТОГО с НДС 10530672.68",
                        Map.of("total_tokens", 6198)));
        var service = new ScanOcrService(gigaChat);
        ReflectionTestUtils.setField(service, "enabled", true);
        ReflectionTestUtils.setField(service, "ocrModel", "");
        ReflectionTestUtils.setField(service, "ocrMaxTokens", 32000);

        String text = service.recognize("акт-скан.pdf", new byte[]{1, 2, 3});

        assertTrue(text.startsWith(ScanOcrService.OCR_PREFIX));
        assertTrue(text.contains("акт-скан.pdf"));
        assertTrue(text.contains("10530672.68"));
        verify(gigaChat).chatCompletionWithFile(contains("Выпиши максимально полно"),
                eq("акт-скан.pdf"), any(), eq("application/pdf"), isNull(), eq(0.01), eq(32000));
    }

    @Test
    void recognize_truncatedResponse_marksTextAsPartial() {
        var gigaChat = mock(GigaChatClient.class);
        when(gigaChat.chatCompletionWithFile(anyString(), anyString(), any(), anyString(),
                isNull(), any(), anyInt()))
                .thenReturn(new GigaChatClient.ChatResult("начало длинного документа...",
                        Map.of("total_tokens", 32000), true));
        var service = new ScanOcrService(gigaChat);
        ReflectionTestUtils.setField(service, "enabled", true);
        ReflectionTestUtils.setField(service, "ocrModel", "");
        ReflectionTestUtils.setField(service, "ocrMaxTokens", 32000);

        String text = service.recognize("огромный-скан.pdf", new byte[]{1});

        assertTrue(text.contains("РАСПОЗНАНО ЧАСТИЧНО"));
        assertTrue(text.contains("начало длинного документа"));
    }

    @Test
    void recognize_usesConfiguredOcrModel() {
        var gigaChat = mock(GigaChatClient.class);
        when(gigaChat.chatCompletionWithFile(anyString(), anyString(), any(), anyString(),
                eq("GigaChat-2-Max"), any(), anyInt()))
                .thenReturn(new GigaChatClient.ChatResult("текст", null));
        var service = new ScanOcrService(gigaChat);
        ReflectionTestUtils.setField(service, "enabled", true);
        ReflectionTestUtils.setField(service, "ocrModel", "GigaChat-2-Max");
        ReflectionTestUtils.setField(service, "ocrMaxTokens", 32000);

        service.recognize("скан.pdf", new byte[]{1});

        verify(gigaChat).chatCompletionWithFile(anyString(), eq("скан.pdf"), any(),
                eq("application/pdf"), eq("GigaChat-2-Max"), eq(0.01), eq(32000));
    }
}
