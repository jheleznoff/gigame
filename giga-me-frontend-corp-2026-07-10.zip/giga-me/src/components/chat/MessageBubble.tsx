import { useState } from 'react';
import { Markdown } from '@/components/ui/markdown';
import { DocumentViewer } from '@/components/ui/document-viewer';
import type { RagSource } from '@/api/chat';
import { toast } from '@/components/ui/toast';

interface MessageBubbleProps {
  role: 'user' | 'assistant' | 'system';
  content: string;
  documentCount?: number;
  sources?: RagSource[] | null;
  /** Идентификатор сообщения из БД; у стримящегося сообщения отсутствует */
  messageId?: string;
  /** Редактирование доступно только для сообщений пользователя */
  onEdit?: (messageId: string, newContent: string) => void;
  /** Регенерация доступна только для последнего ответа ассистента */
  onRegenerate?: () => void;
  actionsDisabled?: boolean;
}

function pluralDocs(n: number): string {
  if (n === 1) return '1 документ прикреплён';
  if (n >= 2 && n <= 4) return `${n} документа прикреплено`;
  return `${n} документов прикреплено`;
}

export function MessageBubble({
  role,
  content,
  documentCount = 0,
  sources,
  messageId,
  onEdit,
  onRegenerate,
  actionsDisabled,
}: MessageBubbleProps) {
  const isUser = role === 'user';
  const [editing, setEditing] = useState(false);
  const [editText, setEditText] = useState(content);
  const [sourcesOpen, setSourcesOpen] = useState(false);
  const [viewerSource, setViewerSource] = useState<RagSource | null>(null);

  const copyContent = async () => {
    try {
      await navigator.clipboard.writeText(content);
      toast('Скопировано', 'success');
    } catch {
      toast('Не удалось скопировать', 'error');
    }
  };

  const submitEdit = () => {
    const trimmed = editText.trim();
    if (!trimmed || !messageId || !onEdit) return;
    setEditing(false);
    if (trimmed !== content) {
      onEdit(messageId, trimmed);
    }
  };

  const actionBtn =
    'p-1 rounded-md text-muted-foreground hover:text-foreground hover:bg-accent transition-colors disabled:opacity-40';

  return (
    <div className={`group flex ${isUser ? 'justify-end' : 'justify-start'} mb-4`}>
      {!isUser && (
        <div className="w-8 h-8 rounded-full bg-[#21a038] flex items-center justify-center mr-2 mt-1 flex-shrink-0">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="white">
            <path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/>
          </svg>
        </div>
      )}
      <div className={`max-w-[75%] flex flex-col ${isUser ? 'items-end' : 'items-start'}`}>
        <div
          className={`rounded-2xl px-4 py-2.5 w-fit max-w-full ${
            isUser
              ? 'bg-[#21a038] text-white rounded-br-md'
              : 'bg-white text-foreground shadow-sm border border-border/50 rounded-bl-md'
          }`}
        >
          {documentCount > 0 && (
            <div className={`text-xs mb-1.5 flex items-center gap-1.5 ${isUser ? 'text-white/70' : 'text-muted-foreground'}`}>
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/>
              </svg>
              <span>{pluralDocs(documentCount)}</span>
            </div>
          )}
          {editing ? (
            <div className="min-w-[280px]">
              <textarea
                value={editText}
                onChange={(e) => setEditText(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    submitEdit();
                  } else if (e.key === 'Escape') {
                    setEditing(false);
                    setEditText(content);
                  }
                }}
                autoFocus
                rows={Math.min(8, Math.max(2, editText.split('\n').length))}
                className="w-full text-sm rounded-lg border border-white/40 bg-white/10 text-white placeholder:text-white/50 p-2 resize-y focus:outline-none"
              />
              <div className="flex gap-1.5 mt-1.5 justify-end">
                <button
                  onClick={submitEdit}
                  disabled={!editText.trim()}
                  className="text-xs bg-white text-[#21a038] font-medium rounded-lg px-2.5 py-1 hover:bg-white/90 disabled:opacity-50"
                >
                  Отправить
                </button>
                <button
                  onClick={() => {
                    setEditing(false);
                    setEditText(content);
                  }}
                  className="text-xs border border-white/40 text-white rounded-lg px-2.5 py-1 hover:bg-white/10"
                >
                  Отмена
                </button>
              </div>
            </div>
          ) : isUser ? (
            <p className="text-sm whitespace-pre-wrap leading-relaxed">{content}</p>
          ) : (
            <Markdown className="text-sm">{content}</Markdown>
          )}
        </div>

        {/* Источники RAG (только у ответов ассистента) */}
        {!isUser && sources && sources.length > 0 && (
          <div className="mt-1.5 max-w-full">
            <button
              onClick={() => setSourcesOpen((v) => !v)}
              className="flex items-center gap-1.5 text-[11px] text-muted-foreground hover:text-foreground transition-colors"
            >
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#21a038" strokeWidth="2">
                <path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/>
              </svg>
              Источники: {sources.length}
              <svg
                width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"
                className={`transition-transform ${sourcesOpen ? 'rotate-180' : ''}`}
              >
                <polyline points="6 9 12 15 18 9" />
              </svg>
            </button>
            {sourcesOpen && (
              <div className="mt-1 space-y-1">
                {sources.map((s, i) => (
                  <button
                    key={i}
                    onClick={() => s.document_id && setViewerSource(s)}
                    disabled={!s.document_id}
                    className="block w-full text-left text-[11px] bg-accent/60 border border-border/50 rounded-lg px-2.5 py-1.5 hover:border-[#21a038]/60 hover:bg-accent transition-colors disabled:cursor-default"
                    title={s.document_id ? 'Открыть документ-источник' : undefined}
                  >
                    <div className="font-medium text-foreground truncate flex items-center gap-1" title={s.document_name}>
                      {i + 1}. {s.document_name || s.document_id}
                      {s.document_id && (
                        <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="#21a038" strokeWidth="2" className="flex-shrink-0">
                          <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/>
                        </svg>
                      )}
                    </div>
                    {s.snippet && (
                      <div className="text-muted-foreground line-clamp-2">{s.snippet}</div>
                    )}
                  </button>
                ))}
              </div>
            )}
            {viewerSource?.document_id && (
              <DocumentViewer
                documentId={viewerSource.document_id}
                snippet={viewerSource.snippet}
                onClose={() => setViewerSource(null)}
              />
            )}
          </div>
        )}

        {/* Панель действий (появляется при наведении) */}
        {!editing && (
          <div className="flex gap-0.5 mt-1 opacity-0 group-hover:opacity-100 transition-opacity">
            <button onClick={copyContent} className={actionBtn} title="Копировать">
              <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <rect x="9" y="9" width="13" height="13" rx="2" />
                <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1" />
              </svg>
            </button>
            {isUser && messageId && onEdit && (
              <button
                onClick={() => {
                  setEditText(content);
                  setEditing(true);
                }}
                disabled={actionsDisabled}
                className={actionBtn}
                title="Редактировать и перегенерировать"
              >
                <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M17 3a2.828 2.828 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5L17 3z" />
                </svg>
              </button>
            )}
            {!isUser && onRegenerate && (
              <button
                onClick={onRegenerate}
                disabled={actionsDisabled}
                className={actionBtn}
                title="Перегенерировать ответ"
              >
                <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <polyline points="23 4 23 10 17 10" />
                  <path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10" />
                </svg>
              </button>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
