import { useEffect, useRef, useState, type KeyboardEvent, type ChangeEvent, type DragEvent, type ClipboardEvent } from 'react';
import { Textarea } from '@/components/ui/textarea';
import { toast } from '@/components/ui/toast';

interface MessageInputProps {
  onSend: (content: string, files?: File[]) => void;
  disabled?: boolean;
  /** Для черновиков: свой черновик на каждый диалог */
  conversationId?: string;
}

const ALLOWED_EXTENSIONS = [
  '.pdf', '.docx', '.xlsx', '.xls', '.pptx', '.txt', '.csv', '.tsv',
  '.md', '.json', '.xml', '.yaml', '.yml', '.log',
];
// Синхронизировано с spring.servlet.multipart.max-file-size на бэкенде
const MAX_FILE_SIZE_MB = 30;

const DRAFT_KEY_PREFIX = 'gigame-draft:';
const TEMPLATES_KEY = 'gigame-prompt-templates';

interface PromptTemplate {
  name: string;
  text: string;
}

function loadTemplates(): PromptTemplate[] {
  try {
    const raw = localStorage.getItem(TEMPLATES_KEY);
    const parsed = raw ? JSON.parse(raw) : [];
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

function saveTemplates(templates: PromptTemplate[]) {
  localStorage.setItem(TEMPLATES_KEY, JSON.stringify(templates));
}

function filterAllowed(list: Iterable<File>): { ok: File[]; rejected: number; oversized: string[] } {
  const ok: File[] = [];
  const oversized: string[] = [];
  let rejected = 0;
  for (const file of list) {
    const ext = '.' + file.name.split('.').pop()?.toLowerCase();
    if (!ALLOWED_EXTENSIONS.includes(ext)) {
      rejected++;
    } else if (file.size > MAX_FILE_SIZE_MB * 1024 * 1024) {
      oversized.push(file.name);
    } else {
      ok.push(file);
    }
  }
  return { ok, rejected, oversized };
}

export function MessageInput({ onSend, disabled, conversationId }: MessageInputProps) {
  const [content, setContent] = useState('');
  const [files, setFiles] = useState<File[]>([]);
  const [dragOver, setDragOver] = useState(false);
  const [templatesOpen, setTemplatesOpen] = useState(false);
  const [templates, setTemplates] = useState<PromptTemplate[]>(loadTemplates);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const templatesRef = useRef<HTMLDivElement>(null);
  // Счётчик dragenter/dragleave: события всплывают от вложенных элементов
  const dragDepth = useRef(0);

  // Черновик: восстановление при смене диалога, сохранение при вводе
  useEffect(() => {
    if (!conversationId) return;
    setContent(localStorage.getItem(DRAFT_KEY_PREFIX + conversationId) || '');
    setFiles([]);
  }, [conversationId]);

  const updateContent = (value: string) => {
    setContent(value);
    if (conversationId) {
      if (value) {
        localStorage.setItem(DRAFT_KEY_PREFIX + conversationId, value);
      } else {
        localStorage.removeItem(DRAFT_KEY_PREFIX + conversationId);
      }
    }
  };

  useEffect(() => {
    if (!templatesOpen) return;
    const onDocClick = (e: MouseEvent) => {
      if (templatesRef.current && !templatesRef.current.contains(e.target as Node)) {
        setTemplatesOpen(false);
      }
    };
    document.addEventListener('mousedown', onDocClick);
    return () => document.removeEventListener('mousedown', onDocClick);
  }, [templatesOpen]);

  const handleSend = () => {
    const trimmed = content.trim();
    if (!trimmed || disabled) return;
    onSend(trimmed, files.length > 0 ? files : undefined);
    updateContent('');
    setFiles([]);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const handleKeyDown = (e: KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const addFiles = (incoming: Iterable<File>) => {
    const { ok, rejected, oversized } = filterAllowed(incoming);
    if (ok.length > 0) {
      setFiles(prev => [...prev, ...ok]);
    }
    if (rejected > 0) {
      toast(`Пропущено файлов: ${rejected}. Поддерживаются: ${ALLOWED_EXTENSIONS.join(', ')}`, 'error');
    }
    if (oversized.length > 0) {
      toast(`Слишком большие файлы (лимит ${MAX_FILE_SIZE_MB} МБ): ${oversized.join(', ')}`, 'error');
    }
  };

  const handleFileChange = (e: ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) addFiles(Array.from(e.target.files));
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const handleDrop = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    dragDepth.current = 0;
    setDragOver(false);
    if (disabled) return;
    if (e.dataTransfer.files?.length) {
      addFiles(Array.from(e.dataTransfer.files));
    }
  };

  const handleDragEnter = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    if (disabled) return;
    dragDepth.current++;
    setDragOver(true);
  };

  const handleDragLeave = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    dragDepth.current = Math.max(0, dragDepth.current - 1);
    if (dragDepth.current === 0) setDragOver(false);
  };

  const handlePaste = (e: ClipboardEvent<HTMLTextAreaElement>) => {
    const pasted = e.clipboardData?.files;
    if (pasted && pasted.length > 0) {
      e.preventDefault();
      addFiles(Array.from(pasted));
    }
  };

  const removeFile = (index: number) => {
    setFiles(prev => prev.filter((_, i) => i !== index));
  };

  const saveCurrentAsTemplate = () => {
    const text = content.trim();
    if (!text) {
      toast('Введите текст, который нужно сохранить как шаблон', 'info');
      return;
    }
    const name = window.prompt('Название шаблона:', text.slice(0, 40));
    if (!name) return;
    const next = [...templates.filter(t => t.name !== name), { name, text }];
    setTemplates(next);
    saveTemplates(next);
    toast('Шаблон сохранён', 'success');
  };

  const deleteTemplate = (name: string) => {
    const next = templates.filter(t => t.name !== name);
    setTemplates(next);
    saveTemplates(next);
  };

  return (
    <div
      className={`bg-card border-t px-5 py-3 transition-colors ${
        dragOver ? 'border-[#21a038] bg-[#21a038]/5' : 'border-border'
      }`}
      onDrop={handleDrop}
      onDragOver={(e) => e.preventDefault()}
      onDragEnter={handleDragEnter}
      onDragLeave={handleDragLeave}
    >
      {dragOver && (
        <div className="mb-2 text-xs text-[#21a038] flex items-center gap-1.5">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/>
          </svg>
          Отпустите, чтобы прикрепить файлы (PDF, DOCX, XLSX, PPTX, CSV, TXT...)
        </div>
      )}
      {files.length > 0 && (
        <div className="mb-2 flex flex-wrap gap-1.5">
          {files.map((file, i) => (
            <div key={i} className="flex items-center gap-1.5 text-sm text-foreground bg-[#21a038]/10 rounded-xl px-2.5 py-1.5">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#21a038" strokeWidth="2">
                <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/>
              </svg>
              <span className="text-xs max-w-[120px] truncate">{file.name}</span>
              <span className="text-[10px] text-muted-foreground">({(file.size / 1024).toFixed(0)} КБ)</span>
              <button
                onClick={() => removeFile(i)}
                className="ml-0.5 text-muted-foreground hover:text-destructive"
              >
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
                </svg>
              </button>
            </div>
          ))}
        </div>
      )}
      <div className="flex items-end gap-2">
        <button
          onClick={() => fileInputRef.current?.click()}
          disabled={disabled}
          className="flex-shrink-0 w-9 h-9 rounded-full flex items-center justify-center text-muted-foreground hover:bg-accent hover:text-foreground transition-colors disabled:opacity-50"
          title={`Прикрепить документы (${ALLOWED_EXTENSIONS.join(', ')}) — можно перетащить или вставить из буфера, до ${MAX_FILE_SIZE_MB} МБ`}
        >
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M21.44 11.05l-9.19 9.19a6 6 0 0 1-8.49-8.49l9.19-9.19a4 4 0 0 1 5.66 5.66l-9.2 9.19a2 2 0 0 1-2.83-2.83l8.49-8.48"/>
          </svg>
        </button>
        <input
          ref={fileInputRef}
          type="file"
          accept={ALLOWED_EXTENSIONS.join(',')}
          multiple
          onChange={handleFileChange}
          className="hidden"
        />
        {/* Шаблоны промптов */}
        <div ref={templatesRef} className="relative flex-shrink-0">
          <button
            onClick={() => setTemplatesOpen(v => !v)}
            disabled={disabled}
            className="w-9 h-9 rounded-full flex items-center justify-center text-muted-foreground hover:bg-accent hover:text-foreground transition-colors disabled:opacity-50"
            title="Шаблоны промптов"
          >
            <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M4 4h16v4H4z"/><path d="M4 12h10"/><path d="M4 16h10"/><path d="M4 20h7"/><path d="M18 14v6"/><path d="M15 17h6"/>
            </svg>
          </button>
          {templatesOpen && (
            <div className="absolute bottom-full left-0 mb-1.5 z-30 w-72 max-h-80 overflow-y-auto bg-card border border-border rounded-xl shadow-lg py-1.5">
              <div className="px-3 py-1.5 text-[10px] uppercase tracking-wide text-muted-foreground">
                Шаблоны промптов
              </div>
              {templates.length === 0 && (
                <div className="px-3 py-2 text-xs text-muted-foreground">
                  Нет сохранённых шаблонов
                </div>
              )}
              {templates.map((t) => (
                <div key={t.name} className="flex items-start gap-1 px-1.5 group/tpl">
                  <button
                    onClick={() => {
                      updateContent(t.text);
                      setTemplatesOpen(false);
                    }}
                    className="flex-1 text-left px-1.5 py-1.5 rounded-lg hover:bg-accent min-w-0"
                    title={t.text}
                  >
                    <div className="text-xs font-medium text-foreground truncate">{t.name}</div>
                    <div className="text-[11px] text-muted-foreground truncate">{t.text}</div>
                  </button>
                  <button
                    onClick={() => deleteTemplate(t.name)}
                    className="p-1.5 mt-0.5 text-muted-foreground opacity-0 group-hover/tpl:opacity-100 hover:text-destructive"
                    title="Удалить шаблон"
                  >
                    <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                      <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
                    </svg>
                  </button>
                </div>
              ))}
              <div className="border-t border-border mt-1 pt-1">
                <button
                  onClick={() => {
                    saveCurrentAsTemplate();
                    setTemplatesOpen(false);
                  }}
                  className="w-full text-left px-3 py-1.5 text-xs text-[#21a038] hover:bg-accent"
                >
                  + Сохранить текущий ввод как шаблон
                </button>
              </div>
            </div>
          )}
        </div>
        <Textarea
          value={content}
          onChange={(e) => updateContent(e.target.value)}
          onKeyDown={handleKeyDown}
          onPaste={handlePaste}
          placeholder="Введите сообщение..."
          className="min-h-[44px] max-h-[200px] resize-none rounded-2xl bg-background border-border text-sm"
          rows={1}
          disabled={disabled}
        />
        <button
          onClick={handleSend}
          disabled={!content.trim() || disabled}
          className="flex-shrink-0 w-9 h-9 rounded-full bg-[#21a038] text-white flex items-center justify-center transition-all hover:bg-[#1b8a30] disabled:opacity-40 disabled:hover:bg-[#21a038]"
        >
          <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
            <path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z"/>
          </svg>
        </button>
      </div>
    </div>
  );
}
