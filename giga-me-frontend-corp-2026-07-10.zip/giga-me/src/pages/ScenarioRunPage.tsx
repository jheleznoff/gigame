import type { ReactNode } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { getScenarioRun } from "@/api/scenarios";
import { Button } from "@/components/ui/button";
import { Markdown } from "@/components/ui/markdown";
import { BASE_URL } from "@/api/constants";

const STATUS_STYLES: Record<string, { label: string; color: string }> = {
  pending: { label: "Ожидание", color: "text-gray-500" },
  running: { label: "Выполняется", color: "text-blue-500" },
  completed: { label: "Завершён", color: "text-green-600" },
  failed: { label: "Ошибка", color: "text-red-600" },
};

export function ScenarioRunPage() {
  const { scenarioId, runId } = useParams<{
    scenarioId: string;
    runId: string;
  }>();
  const navigate = useNavigate();

  const { data: run, isLoading } = useQuery({
    queryKey: ["scenario-run", runId],
    queryFn: () => getScenarioRun(runId!),
    enabled: !!runId,
    refetchInterval: (query) =>
      query.state.data?.status === "running" ? 2000 : false,
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-full text-muted-foreground">
        Загрузка...
      </div>
    );
  }

  if (!run) return null;

  const status = STATUS_STYLES[run.status] || STATUS_STYLES.pending;
  const totalTokens = run.steps.reduce(
    (sum, s) => sum + (s.tokens_used || 0),
    0
  );

  return (
    <div className="h-full overflow-y-auto">
      <div className="p-6 max-w-4xl mx-auto">
        <div className="flex items-center gap-3 mb-6">
          <Button
            variant="outline"
            size="sm"
            onClick={() => navigate(`/scenarios/${scenarioId}/edit`)}
          >
            ← К редактору
          </Button>
          <h1 className="text-xl font-semibold">Запуск сценария</h1>
          <span className={`text-sm font-medium ${status.color}`}>
            {status.label}
          </span>
          {totalTokens > 0 && (
            <span
              className="text-xs font-mono text-[#7b1fa2] bg-[#7b1fa2]/10 rounded-md px-2 py-0.5"
              title="Суммарный расход токенов GigaChat за прогон (по шагам)"
            >
              🪙 {totalTokens.toLocaleString("ru-RU")} токенов
            </span>
          )}
          <div className="flex-1" />
          {run.status === "completed" && (
            <Button
              size="sm"
              variant="outline"
              className="rounded-xl"
              onClick={() => {
                window.open(
                  BASE_URL + `/scenarios/runs/${runId}/export`,
                  "_blank"
                );
              }}
            >
              <svg
                width="14"
                height="14"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                className="mr-1.5"
              >
                <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
                <polyline points="7 10 12 15 17 10" />
                <line x1="12" y1="15" x2="12" y2="3" />
              </svg>
              Скачать DOCX
            </Button>
          )}
          {run.status === "failed" && (
            <Button
              size="sm"
              className="rounded-xl bg-[#ff6f00] hover:bg-[#e65100]"
              title="Новый прогон: результаты завершённых LLM-узлов будут переиспользованы"
              onClick={async () => {
                try {
                  const { resumeScenarioRun } = await import("@/api/scenarios");
                  const newRunId = await resumeScenarioRun(runId!);
                  if (newRunId) {
                    navigate(`/scenarios/${scenarioId}/runs/${newRunId}`);
                  } else {
                    alert("Возобновление запущено, но id нового прогона не получен — обновите список запусков");
                  }
                } catch {
                  alert("Не удалось возобновить прогон");
                }
              }}
            >
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="mr-1.5">
                <polyline points="23 4 23 10 17 10" />
                <path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10" />
              </svg>
              Продолжить с места сбоя
            </Button>
          )}
        </div>

        {/* Steps */}
        <div className="space-y-3 mb-6">
          <h2 className="text-sm font-semibold">Шаги выполнения</h2>
          {run.steps.length === 0 ? (
            <p className="text-sm text-muted-foreground">Нет шагов</p>
          ) : (
            run.steps.map((step) => {
              const stepStatus =
                STATUS_STYLES[step.status] || STATUS_STYLES.pending;
              return (
                <div
                  key={step.id}
                  className="border border-border rounded-lg p-4"
                >
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <span
                        className={`w-2.5 h-2.5 rounded-full ${
                          step.status === "completed"
                            ? "bg-green-500"
                            : step.status === "running"
                            ? "bg-blue-500 animate-pulse"
                            : step.status === "failed"
                            ? "bg-red-500"
                            : "bg-gray-300"
                        }`}
                      />
                      <span className="text-sm font-medium">
                        {step.node_id} ({step.node_type})
                      </span>
                    </div>
                    <div className="flex items-center gap-2">
                      {!!step.tokens_used && (
                        <span
                          className="text-[10px] font-mono text-[#7b1fa2]"
                          title="Токены GigaChat на этом шаге"
                        >
                          🪙 {step.tokens_used.toLocaleString("ru-RU")}
                        </span>
                      )}
                      <span className={`text-xs ${stepStatus.color}`}>
                        {stepStatus.label}
                      </span>
                    </div>
                  </div>
                  {/* Input data (new) */}
                  {!!step.input_data &&
                    typeof step.input_data === "object" &&
                    ((): ReactNode => {
                      const inp = step.input_data as {
                        documents_text?: string;
                        previous_output?: string;
                      };
                      if (!inp.documents_text && !inp.previous_output)
                        return null;
                      return (
                        <details className="mt-2">
                          <summary className="text-xs text-[#1976d2] cursor-pointer font-medium">
                            📥 Входные данные
                          </summary>
                          <div className="mt-1 space-y-2">
                            {inp.previous_output && (
                              <div>
                                <div className="text-[10px] text-muted-foreground mb-1">
                                  Результат предыдущего шага:
                                </div>
                                <pre className="text-xs bg-muted rounded p-2 overflow-x-auto whitespace-pre-wrap max-h-48">
                                  {inp.previous_output.length > 2000
                                    ? inp.previous_output.slice(0, 2000) +
                                      "\n... (" +
                                      inp.previous_output.length +
                                      " симв)"
                                    : inp.previous_output}
                                </pre>
                              </div>
                            )}
                            {inp.documents_text && (
                              <div>
                                <div className="text-[10px] text-muted-foreground mb-1">
                                  Документы:
                                </div>
                                <pre className="text-xs bg-muted rounded p-2 overflow-x-auto whitespace-pre-wrap max-h-48">
                                  {inp.documents_text.length > 2000
                                    ? inp.documents_text.slice(0, 2000) +
                                      "\n... (" +
                                      inp.documents_text.length +
                                      " симв)"
                                    : inp.documents_text}
                                </pre>
                              </div>
                            )}
                          </div>
                        </details>
                      );
                    })()}
                  {!!step.prompt_used && (
                    <details className="mt-2">
                      <summary className="text-xs text-[#7b1fa2] cursor-pointer font-medium">
                        📝 Промпт в GigaChat
                      </summary>
                      <pre className="text-xs bg-muted rounded p-2 mt-1 overflow-x-auto whitespace-pre-wrap max-h-64">
                        {step.prompt_used}
                      </pre>
                    </details>
                  )}
                  {!!step.output_data && (
                    <details
                      className="mt-2"
                      open={step.status === "completed"}
                    >
                      <summary className="text-xs text-[#21a038] cursor-pointer font-medium">
                        📤 Результат
                      </summary>
                      <div className="text-xs bg-muted rounded p-2 mt-1 max-h-64 overflow-auto">
                        {typeof step.output_data === "object" &&
                        step.output_data !== null &&
                        "result" in step.output_data ? (
                          <Markdown>
                            {String(
                              (step.output_data as { result: unknown }).result
                            )}
                          </Markdown>
                        ) : typeof step.output_data === "object" ? (
                          <pre className="whitespace-pre-wrap">
                            {JSON.stringify(step.output_data, null, 2)}
                          </pre>
                        ) : (
                          <Markdown>{String(step.output_data)}</Markdown>
                        )}
                      </div>
                    </details>
                  )}
                </div>
              );
            })
          )}
        </div>

        {/* Final result */}
        {run.result && (
          <div className="border border-border rounded-lg p-4 bg-card mb-6">
            <h2 className="text-sm font-semibold mb-3">Итоговый результат</h2>
            <Markdown>{run.result.output || ""}</Markdown>
          </div>
        )}
      </div>
    </div>
  );
}
