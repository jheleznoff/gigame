# GigaMe Backend

## Project Overview

**GigaMe** is a Spring Boot 3.5.11 Java 17 backend service that provides AI-powered chat, knowledge base management,
RAG (Retrieval-Augmented Generation), and scenario engine capabilities powered by **GigaChat** (Sber's AI platform).

### Key Technologies

| Category        | Technology                                                      |
|-----------------|-----------------------------------------------------------------|
| **Framework**   | Spring Boot 3.5.11 with Spring WebFlux (reactive)               |
| **Language**    | Java 17                                                         |
| **AI Provider** | GigaChat API (chat + embedding endpoints)                       |
| **Database**    | PostgreSQL with pgvector extension for vector similarity search |
| **Migrations**  | Liquibase (SQL-based changelog)                                 |
| **ORM**         | Spring Data JPA (Hibernate 6)                                   |
| **Build**       | Maven                                                           |

### Architecture Summary

The application implements a micro-service-like architecture within a single Spring Boot application:

1. **Chat Service** - Manages conversations, messages, and streaming chat completions with RAG support
2. **Document Service** - Handles file uploads (PDF, DOCX, XLSX), text extraction, and vector indexing
3. **Knowledge Base Service** - Manages KBs with document collections and embedded chunks
4. **Scenario Engine** - Executes graph-based AI workflows with step-by-step SSE streaming
5. **Embedding Service** - pgvector-based vector storage and cosine similarity search

### Core Features

- **Conversational AI**: Multi-turn conversations with auto-generated titles, SSE streaming responses
- **RAG Support**: Similarity search over document chunks and knowledge bases using pgvector
- **Document Upload**: Support for PDF, DOCX, XLSX, TXT with automatic text extraction
- **Scenario Engine**: Graph-based AI workflows (nodes: input, output, loop, switch, if_node) with live debugging
- **Knowledge Bases**: Persistent collections of documents with vector embeddings for RAG

---

## Building and Running

### Prerequisites

- Java 17
- Maven 3.6+
- PostgreSQL 15+ with `pgvector` and `uuid-ossp` extensions
- GigaChat API credentials (certificate, private key, scope)

### Environment Variables

Create a `.env` file or set these environment variables:

```bash
DATABASE_URL=jdbc:postgresql://localhost:5432/gigame
db.username=your_user
db.password=your_password
DATABASE_SCHEMA=public

GIGACHAT_URL=https://gigachat-ift.sberdevices.delta.sbrf.ru/v1
GIGACHAT_SERT=classpath:giga_ift.pem
GIGACHAT_KEY=classpath:giga_ift.key
GIGACHAT_SCOPE=GIGACHAT_API_CORP
GIGACHAT_MODEL=GigaChat-2-Max
```

### Database Setup

The application uses Liquibase for migrations. Run migrations automatically on startup or manually:

```bash
# If running manually, execute these SQL files in order:
# src/main/resources/db/changelog/db.changelog-master.sql
```

Required PostgreSQL extensions:

```sql
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "vector";
```

### Building

```bash
# Build the project
mvn clean package

# Run with Maven
mvn spring-boot:run

# Run the JAR
java -jar target/gigame-backend-1.0.0.jar
```

### Running

```bash
# Default: runs on port 8080 with base path /gigame
java -jar target/gigame-backend-1.0.0.jar

# Custom port
java -jar target/gigame-backend-1.0.0.jar --server.port=8080
```

### Testing

```bash
mvn test
mvn test -Dtest=ChatServiceTest
mvn test -Dtest=ScenarioEngineTest
```

### API Documentation

After running the application, access:

- **OpenAPI JSON**: `http://localhost:8080/gigame/sample-api-docs`
- **Swagger UI**: `http://localhost:8080/gigame/swagger-ui.html`
- **Actuator**: `http://localhost:8080/gigame/actuator`

---

## API Endpoints

### Conversations

| Method   | Endpoint                                  | Description                                   |
|----------|-------------------------------------------|-----------------------------------------------|
| `GET`    | `/api/conversations`                      | List conversations with optional title search |
| `POST`   | `/api/conversations`                      | Create a new conversation                     |
| `GET`    | `/api/conversations/{id}`                 | Get conversation with messages                |
| `PUT`    | `/api/conversations/{id}`                 | Update conversation title                     |
| `DELETE` | `/api/conversations/{id}`                 | Delete conversation                           |
| `POST`   | `/api/conversations/{id}/messages`        | Send message (SSE stream)                     |
| `POST`   | `/api/conversations/{id}/messages/upload` | Upload files + send message (SSE stream)      |

### Documents

| Method   | Endpoint              | Description        |
|----------|-----------------------|--------------------|
| `GET`    | `/api/documents`      | List all documents |
| `POST`   | `/api/documents`      | Upload a document  |
| `DELETE` | `/api/documents/{id}` | Delete a document  |

### Knowledge Bases

| Method   | Endpoint                              | Description                   |
|----------|---------------------------------------|-------------------------------|
| `GET`    | `/api/knowledge-bases`                | List all KBs                  |
| `POST`   | `/api/knowledge-bases`                | Create a KB                   |
| `GET`    | `/api/knowledge-bases/{id}`           | Get KB details with documents |
| `PUT`    | `/api/knowledge-bases/{id}`           | Update a KB                   |
| `DELETE` | `/api/knowledge-bases/{id}`           | Delete a KB                   |
| `POST`   | `/api/knowledge-bases/{id}/documents` | Add document to KB            |
| `POST`   | `/api/knowledge-bases/{id}/documents/{docId}/reindex` | Reindex document in KB |

### Scenarios

| Method   | Endpoint                                   | Description              |
|----------|--------------------------------------------|--------------------------|
| `GET`    | `/api/scenarios`                           | List all scenarios       |
| `POST`   | `/api/scenarios`                           | Create a scenario        |
| `GET`    | `/api/scenarios/{id}`                      | Get scenario details     |
| `PUT`    | `/api/scenarios/{id}`                      | Update a scenario        |
| `DELETE` | `/api/scenarios/{id}`                      | Delete a scenario        |
| `POST`   | `/api/scenarios/{id}/duplicate`            | Duplicate a scenario     |
| `POST`   | `/api/scenarios/{id}/run`                  | Execute a scenario (SSE) |
| `GET`    | `/api/scenarios/runs/{runId}`              | Get run status           |
| `POST`   | `/api/scenarios/runs/{runId}/continue`     | Continue paused run      |
| `POST`   | `/api/scenarios/runs/{runId}/disable-step-mode` | Disable step mode   |

---

## Development Conventions

### Package Structure

```
ru.sber.cs.ai.gigame/
├── Application.java                # Main entry point
├── config/                         # Spring configuration
│   ├── JacksonConfig.java         # JSON serialization settings
│   ├── OpenApiConfig.java         # Swagger/OpenAPI configuration
│   └── PostgresVectorConfig.java  # pgvector support
├── controller/                     # REST controllers
│   ├── ConversationController.java
│   ├── DocumentController.java
│   ├── KnowledgeBaseController.java
│   └── ScenarioController.java
├── service/                        # Business logic
│   ├── ChatService.java           # Conversations & messaging
│   ├── DocumentService.java       # File upload & extraction
│   ├── KBService.java             # Knowledge base management
│   ├── ScenarioEngine.java        # Graph execution engine
│   ├── ScenarioService.java       # Scenario CRUD
│   ├── EmbeddingService.java      # pgvector operations
│   ├── GigaChatClient.java        # GigaChat API client wrapper
│   ├── MessageService.java        # Message handling
│   ├── DocumentIndexService.java  # Chunking & embedding
│   ├── TextSplitter.java          # Document chunking strategy
│   └── KBMapper.java              # KB-specific mapping
├── model/                          # JPA entities
│   ├── Conversation.java
│   ├── Message.java
│   ├── Document.java
│   ├── KnowledgeBase.java
│   ├── KBDocument.java
│   ├── Scenario.java
│   ├── ScenarioRun.java
│   ├── ScenarioRunStep.java
│   └── Embedding.java
├── repository/                     # JPA repositories
│   ├── ConversationRepository.java
│   ├── MessageRepository.java
│   ├── DocumentRepository.java
│   ├── KnowledgeBaseRepository.java
│   ├── KBDocumentRepository.java
│   ├── ScenarioRepository.java
│   ├── ScenarioRunRepository.java
│   ├── ScenarioRunStepRepository.java
│   └── EmbeddingRepository.java
├── dto/                            # Data Transfer Objects
│   ├── chat/
│   ├── document/
│   ├── kb/
│   └── scenario/
├── exception/                      # Custom exceptions
│   ├── AccessDeniedException.java
│   ├── ApplicationErrorHandler.java
│   ├── ApplicationRuntimeException.java
│   ├── FileException.java
│   ├── GigaChatException.java
│   └── NotFoundException.java
└── utils/                          # Utility classes
    ├── FileUtils.java
    ├── TextSplitter.java
    └── UserUtils.java
```

### Code Style

- **Null safety**: Use Kotlin-style null checks with `isBlank()`, `isNotEmpty()`
- **Immutable DTOs**: Use Java records for response DTOs
- **Reactive streams**: Use `Flux` for SSE streaming, `Mono` for single responses
- **Threading**: Blocking operations (JPA, GigaChat calls) run on `boundedElastic` scheduler
- **Logging**: Slf4j with structured logging (Context is a service, not just a utility)
- **Documentation**: Methods include Javadoc with flow descriptions (see `ChatService.sendMessageStream`)
- **Lombok**: Used for boilerplate reduction (`@RequiredArgsConstructor`, `@Data`)
- **Error handling**: Custom exceptions with `@ControllerAdvice` for global error handling

### Database Conventions

- **UUIDs**: All primary keys use `UUID` with `DEFAULT uuid_generate_v4()`
- **Timestamps**: `TIMESTAMP WITH TIME ZONE` with `now()` default
- **Cascading**: Foreign keys use `ON DELETE CASCADE` or `ON DELETE SET NULL` as appropriate
- **pgvector**: Vector columns use `vector(1024)` with IVFFlat index for cosine similarity
- **User isolation**: All entity tables include `user_id` column for multi-tenancy

### Embedding Strategy

- **Document chunks**: Stored with `collection_type='doc'`, `collection_id=source_document_id`
- **KB chunks**: Stored with `collection_type='kb'`, `collection_id=kb_id`
- **Query embeddings**: Generated via `GigaChatClient.getEmbeddings(List<String>)`
- **Similarity search**: Cosine distance via `pgvector` `VECTOR_COSINE_OPS`
- **Index**: IVFFlat index with 100 lists for efficient similarity search

### Scenario Engine Details

- **Node types**: `input`, `output`, `loop`, `switch`, `if_node`, and generic processing nodes
- **Step-by-step mode**: Enables live debugging with pause/resume capability
- **SSE events**: `status`, `node_status`, `step_complete`, `step_paused`, `loop_progress`, `rag_search`
- **Graph validation**: Topological sort ensures DAG execution order
- **Concurrency**: Uses `CompletableFuture` and `ExecutorService` for parallel execution

---

## Testing

### Manual Testing with curl

```bash
# Create a conversation
curl -X POST http://localhost:8080/gigame/api/conversations \
  -H "Content-Type: application/json" \
  -H "X-UserId: user123" \
  -d '{"title": "Test Conversation"}'

# Upload a document
curl -X POST http://localhost:8080/gigame/api/documents \
  -H "Content-Type: application/json" \
  -H "X-UserId: user123" \
  -d '{"filename": "test.pdf", "extractedText": "..."}'

# Send a message (streaming)
curl -X POST http://localhost:8080/gigame/api/conversations/{id}/messages \
  -H "Content-Type: application/json" \
  -H "X-UserId: user123" \
  -d '{"content": "Hello, how are you?"}' \
  -N http://localhost:8080/gigame/gigame/api/conversations/{id}/messages
```

### Running Tests

```bash
# Run all tests
mvn test

# Run specific test class
mvn test -Dtest=ChatServiceTest

# Run integration tests
mvn test -Dtest=ApplicationIntegrationTest
```

---

## Troubleshooting

### Common Issues

1. **Certificate authentication failures**: Ensure `giga_ift.pem` and `giga_ift.key` are in `src/main/resources/`
2. **Vector similarity search returns no results**: Check pgvector extension is installed and IVFFlat index exists
3. **JPA LazyInitializationException**: Ensure queries are within `@Transactional` context or use `open-in-view: false`
4. **File upload fails with 500**: Check `UPLOAD_DIR` exists and is writable
5. **GigaChat API timeouts**: Adjust `spring.ai.gigachat.internal.read-timeout` in `application.yaml`
6. **Database migrations fail**: Ensure Liquibase changelog is correctly formatted and extensions are available

### Debug Logging

```bash
# Enable full debug logging
java -jar target/gigame-backend-1.0.0.jar \
  --logging.level.ru.sber.cs.ai.gigame=DEBUG \
  --logging.level.org.springframework.web=DEBUG
```

### Jenkins Pipeline

The project uses a custom Jenkins pipeline (`Jenkinsfile`) for CI/CD:

- Maven build with SonarQube integration
- Conditional test skipping via `app.test_skip`
- Artifact deployment to back-end modules catalog

---

## Performance Considerations

- **Connection pooling**: HikariCP with 20 max connections, 5 min idle
- **Thread pool**: Executor with 5-10 threads for blocking operations
- **Embedding caching**: Scenario engine caches embeddings per execution to avoid duplicate API calls
- **Chunking**: Documents >12,000 chars are chunked and embedded for similarity search
- **History window**: Chat service keeps only last 20 messages in conversation history
- **Multipart limits**: Max file size 50MB, max request size 100MB

---

## Related Files

| File                                                          | Purpose                              |
|---------------------------------------------------------------|--------------------------------------|
| `pom.xml`                                                     | Maven dependencies and configuration |
| `src/main/resources/application.yaml`                         | Application configuration            |
| `src/main/resources/giga_ift.pem`                             | GigaChat certificate                 |
| `src/main/resources/giga_ift.key`                             | GigaChat private key                 |
| `src/main/resources/db/changelog/db.changelog-master.sql`     | Liquibase database migrations        |
| `src/main/resources/preliquibase/postgresql.sql`             | Pre-Liquibase SQL setup              |
| `Jenkinsfile`                                                 | CI/CD pipeline configuration         |
| `openapi.yaml`                                                | Generated OpenAPI specification      |

---

*Last updated: 2026-05-15*
