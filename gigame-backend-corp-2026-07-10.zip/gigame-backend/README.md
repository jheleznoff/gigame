# GigaMe Backend

**GigaMe** — это backend-сервис на Spring Boot 3.5.11 с поддержкой Java 17, предоставляющий API для работы с AI-чатом, базами знаний, RAG (Retrieval-Augmented Generation) и движком сценариев (workflow), основанный на GigaChat (AI-платформа Сбера).

## 📋 Содержание

- [Ключевые возможности](#-ключевые-возможности)
- [Быстрый старт](#-быстрый-старт)
- [Структура проекта](#-структура-проекта)
- [API документация](#-api-документация)
- [WebSocket API](#-websocket-api)
- [Настройка среды](#-настройка-среды)
- [Разработка](#-разработка)
- [Тестирование](#-тестирование)
- [Архитектура движка сценариев](#-архитектура-движка-сценариев)
- [Troubleshooting](#-troubleshooting)

## 🚀 Ключевые возможности

- **Чат с AI**: Многоходовые диалоги с автогенерацией заголовков, потоковая передача ответов через SSE и WebSocket
- **RAG (Retrieval-Augmented Generation)**: Поиск похожих фрагментов в документах и базах знаний с использованием pgvector
- **Загрузка документов**: Поддержка PDF, DOCX, XLSX, TXT с автоматическим извлечением текста (до 30MB на файл)
- **Движок сценариев**: Графовый AI-воркфлоу с узлами `processing_node`, `input`, `output`, `loop`, `switch`, `if_node` и пошаговой отладкой
- **Базы знаний**: Постоянные коллекции документов с векторными эмбеддингами для RAG
- **Экспорт результатов**: Экспорт выполненных сценариев в DOCX и XLSX
- **WebSocket**: Двунаправленная связь для чата и выполнения сценариев в реальном времени

## 🏃 Быстрый старт

### Предварительные требования

- Java 17+
- Maven 3.6+
- PostgreSQL 15+ с расширениями `pgvector` и `uuid-ossp`
- GigaChat API credentials (сертификат, приватный ключ, scope)

### 1. Настройка базы данных

```sql
-- Подключитесь к PostgreSQL и выполните:
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "vector";
```

### 2. Установка зависимостей

```bash
mvn clean install -DskipTests
```

### 3. Запуск приложения

```bash
# С помощью Maven
mvn spring-boot:run

# Или через JAR
java -jar target/gigame-backend-1.1.6.jar
```

Приложение запустится на порту `8080` по пути `/gigame`.

## 📁 Структура проекта

```
src/main/java/ru/sber/cs/ai/gigame/
├── Application.java                         # Точка входа (@SpringBootApplication, @EnableAsync, @EnableScheduling)
├── config/                                  # Конфигурация Spring
│   ├── JacksonConfig.java                  # ObjectMapper: JavaTimeModule, NON_NULL, без таймстампов
│   ├── OpenApiConfig.java                  # Swagger/OpenAPI с группами (actuator, chat, documents, kb, scenarios)
│   ├── PostgresVectorConfig.java           # @EnableJpaAuditing, поддержка pgvector
│   ├── TransactionConfig.java              # @EnableTransactionManagement, JpaTransactionManager
│   └── WebSocketConfig.java                # SimpleUrlHandlerMapping для /ws/chat и /ws/scenario
├── controller/                              # REST контроллеры
│   ├── ConversationController.java         # Управление диалогами (+ загрузка документов в кеш)
│   ├── KnowledgeBaseController.java        # Управление базами знаний (+ загрузка документов в БЗ)
│   └── ScenarioController.java             # Управление и выполнение сценариев (+ экспорт)
├── service/                                 # Бизнес-логика
│   ├── ChatService.java                    # Чат, потоковая передача (SSE), авто-заголовки, RAG
│   ├── DocsTextCacheService.java           # In-memory кеш текстов документов для диалогов и сценариев
│   ├── DocumentIndexService.java           # Чанкование, эмбеддинг, индексация документов БЗ
│   ├── DocumentService.java                # Загрузка файлов, извлечение текста (PDF, DOCX, XLSX, TXT)
│   ├── EmbeddingService.java               # pgvector: создание, поиск, удаление эмбеддингов
│   ├── GigaChatClient.java                 # Wrapper над Spring AI GigaChat (chat + embeddings)
│   ├── KBMapper.java                       # Преобразования для БЗ
│   ├── KBService.java                      # CRUD для баз знаний
│   ├── MessageService.java                 # Персистентность и маппинг сообщений
│   └── scenario/                           # Движок сценариев (14 файлов)
│       ├── ScenarioEngine.java             # Исполнитель графа: топологическая сортировка, обход узлов
│       ├── ScenarioGraphStructure.java     # Разобранный граф: successors, predecessors, edgeMap, nodeOutputs
│       ├── ScenarioNode.java               # Запись: id, type, label, rules, prompt, mode и др.
│       ├── ScenarioMapper.java             # Entity → DTO преобразования
│       ├── ScenarioService.java            # CRUD + управление запусками сценариев
│       ├── ScenarioRunService.java         # Жизненный цикл выполнения
│       ├── ScenarioRunStepService.java     # Создание и обновление шагов
│       ├── ScenarioEventEmission.java      # Вспомогательные методы для SSE-событий
│       ├── ExportToDocx.java               # Экспорт результатов сценария в DOCX
│       ├── ScenarioResultToXlsx.java       # Экспорт JSON-данных в XLSX
│       ├── enums/
│       │   ├── ScenarioEventType.java      # STATUS, NODE_STATUS, LOOP_PROGRESS, SWITCH_RESULT и др.
│       │   ├── ScenarioNodeType.java       # PROCESSING_NODE, IF_NODE, SWITCH_NODE, LOOP_NODE, INPUT_NODE, OUTPUT_NODE
│       │   └── ScenarioStatus.java         # RUNNING, COMPLETED, FAILED, SKIPPED
│       └── executor/                       # Исполнители узлов графа (8 файлов)
│           ├── AbstractScenarioExecutor.java    # Базовый класс: buildPrompt, previousOutputCollection, getSkipSet
│           ├── ScenarioExecutorFactory.java     # Фабрика: создаёт исполнителя по типу узла
│           ├── ScenarioExecutorInputNode.java   # Пробрасывает documentsText на выход
│           ├── ScenarioExecutorOutputNode.java  # Объединяет выходы предшественников (поддерживает EXCEL/TEXT_FILE)
│           ├── ScenarioExecutorProcessingNode.java  # Вызов GigaChat с промптом, контекстом и RAG
│           ├── ScenarioExecutorLoopNode.java        # Циклическая обработка: classify_strict / full analysis
│           ├── ScenarioExecutorSwitchNode.java      # Маршрутизация по классификации (от Loop) или правилам
│           └── ScenarioExecutorIfNode.java          # Условное ветвление (contains, equals, greater_than и др.)
├── model/                                   # JPA сущности
│   ├── Conversation.java                   # Диалог
│   ├── Message.java                        # Сообщение (documentIds — JSONB)
│   ├── Document.java                       # Документ
│   ├── Embedding.java                      # Эмбеддинг (vector(1024), collectionType, chunkText)
│   ├── KnowledgeBase.java                  # База знаний
│   ├── KBDocument.java                     # Связь БЗ ↔ Документ
│   ├── Scenario.java                       # Сценарий (graphData — JSONB)
│   ├── ScenarioRun.java                    # Запуск сценария
│   └── ScenarioRunStep.java                # Шаг выполнения (inputData, outputData — JSONB)
├── repository/                              # JPA репозитории
│   ├── ConversationRepository.java
│   ├── DocumentRepository.java
│   ├── EmbeddingRepository.java
│   ├── KBDocumentRepository.java
│   ├── KnowledgeBaseRepository.java
│   ├── MessageRepository.java
│   ├── ScenarioRepository.java
│   ├── ScenarioRunRepository.java
│   └── ScenarioRunStepRepository.java
├── dto/                                     # Data Transfer Objects
│   ├── ErrorResponse.java                  # Стандартный формат ошибки
│   ├── chat/
│   │   ├── ConversationCreate.java
│   │   ├── ConversationResponse.java
│   │   ├── ConversationWithMessages.java
│   │   ├── MessageResponse.java
│   │   └── SendMessageRequest.java
│   ├── kb/
│   │   ├── KBCreate.java
│   │   ├── KBDetailResponse.java
│   │   ├── KBDocumentResponse.java
│   │   ├── KBResponse.java
│   │   └── KBUpdate.java
│   └── scenario/
│       ├── graph/                          # DTO для графа сценария (8 файлов)
│       │   ├── EdgeDataDto.java
│       │   ├── EdgeDto.java
│       │   ├── GraphDataDto.java
│       │   ├── GraphDataMapper.java
│       │   ├── MeasuredDto.java
│       │   ├── NodeDataDto.java
│       │   ├── NodeDto.java
│       │   └── PositionDto.java
│       ├── ScenarioCreate.java
│       ├── ScenarioDetailResponse.java
│       ├── ScenarioResponse.java
│       ├── ScenarioRunDetailResponse.java
│       ├── ScenarioRunResponse.java
│       ├── ScenarioRunStepInputDataResponse.java
│       ├── ScenarioRunStepOutputDataResponse.java
│       ├── ScenarioRunStepResponse.java
│       └── ScenarioUpdate.java
├── exception/                               # Исключения и глобальный обработчик
│   ├── AccessDeniedException.java          # HTTP 403
│   ├── ApplicationErrorHandler.java        # @ControllerAdvice со всеми обработчиками
│   ├── ApplicationRuntimeException.java    # Базовое исключение с statusCode
│   ├── FileException.java                  # HTTP 500
│   ├── GigaChatException.java              # HTTP 500
│   ├── NotFoundException.java              # HTTP 404
│   └── ScenarioException.java              # HTTP 400
├── ws/                                      # WebSocket обработчики
│   ├── ChatWebSocketHandler.java           # /ws/chat: приём сообщений, поток SSE-ответов
│   ├── ScenarioWebSocketHandler.java       # /ws/scenario: запуск сценария, SSE-события
│   └── WebSocketSessionManager.java        # ConcurrentHashMap: sessionId → WebSocketSession + userId
└── utils/                                   # Утилиты
    ├── FileUtils.java                      # Определение Content-Type, преобразование InputStream
    ├── TextSplitter.java                   # Чанкование текста с перекрытием
    └── UserUtils.java                      # Извлечение и валидация X-UserId
```

## 📖 API документация

После запуска приложения документация доступна по:

- **OpenAPI JSON**: `http://localhost:8080/gigame/sample-api-docs`
- **Swagger UI**: `http://localhost:8080/gigame/swagger-ui.html`
- **Actuator**: `http://localhost:8080/gigame/actuator`

### Основные endpoints

#### Диалоги (Conversations)

| Метод | Endpoint | Описание |
|-------|----------|----------|
| `GET` | `/api/conversations?q=` | Список диалогов (опциональный поиск по заголовку) |
| `POST` | `/api/conversations` | Создать диалог |
| `GET` | `/api/conversations/{id}` | Получить диалог с сообщениями |
| `PUT` | `/api/conversations/{id}` | Обновить заголовок диалога |
| `DELETE` | `/api/conversations/{id}` | Удалить диалог |
| `POST` | `/api/conversations/{id}/messages` | Отправить сообщение (SSE поток) |
| `POST` | `/api/conversations/{id}/messages/upload` | Отправить сообщение с файлами (multipart + SSE) |
| `POST` | `/api/conversations/{id}/upload` | Загрузить документы в кеш (без ответа AI) |

#### Базы знаний (Knowledge Bases)

| Метод | Endpoint | Описание |
|-------|----------|----------|
| `GET` | `/api/knowledge-bases?q=` | Список баз знаний |
| `POST` | `/api/knowledge-bases` | Создать базу знаний |
| `GET` | `/api/knowledge-bases/{id}` | Получить БЗ с документами |
| `PUT` | `/api/knowledge-bases/{id}` | Обновить БЗ |
| `DELETE` | `/api/knowledge-bases/{id}` | Удалить БЗ |
| `POST` | `/api/knowledge-bases/{id}/documents` | Загрузить документ в БЗ (multipart) |
| `POST` | `/api/knowledge-bases/{id}/documents/{docId}/reindex` | Переиндексировать документ в БЗ |
| `DELETE` | `/api/knowledge-bases/{id}/documents/{docId}` | Удалить документ из БЗ |

#### Сценарии (Scenarios)

| Метод | Endpoint | Описание |
|-------|----------|----------|
| `GET` | `/api/scenarios` | Список сценариев |
| `POST` | `/api/scenarios` | Создать сценарий |
| `GET` | `/api/scenarios/{id}` | Получить детали сценария |
| `PUT` | `/api/scenarios/{id}` | Обновить сценарий |
| `DELETE` | `/api/scenarios/{id}` | Удалить сценарий |
| `POST` | `/api/scenarios/{id}/duplicate` | Дублировать сценарий |
| `GET` | `/api/scenarios/{id}/runs` | Список выполнений сценария |
| `POST` | `/api/scenarios/{id}/run` | Запустить сценарий с файлами (SSE поток) |
| `POST` | `/api/scenarios/{id}/upload` | Загрузить файлы в кеш сценария |
| `GET` | `/api/scenarios/runs/{runId}` | Получить детали выполнения |
| `POST` | `/api/scenarios/runs/{runId}/continue` | Продолжить приостановленный запуск |
| `POST` | `/api/scenarios/runs/{runId}/disable-step-mode` | Отключить пошаговый режим |
| `GET` | `/api/scenarios/runs/{runId}/export` | Экспорт результатов в DOCX |

## 🔌 WebSocket API

Приложение поддерживает два WebSocket эндпоинта для двунаправленной связи в реальном времени.

### `/ws/chat` (ChatWebSocketHandler)

Принимает сообщения и возвращает потоковые ответы AI через SSE-события.

**Вход** (JSON):
```json
{
  "conversation_id": "uuid",
  "content": "текст сообщения",
  "document_ids": ["uuid1", "uuid2"]
}
```

**Выход** (поток JSON-событий):
```json
{"conversation_id": "uuid", "content": "токен", "usage": null, "document_ids": null, "done": false, "error": null}
```
```json
{"conversation_id": "uuid", "content": "", "usage": {"total_tokens": 150}, "document_ids": ["uuid1"], "done": true, "error": null}
```

**Аутентификация**: `X-UserId` в заголовках WebSocket handshake.

### `/ws/scenario` (ScenarioWebSocketHandler)

Принимает запрос на запуск сценария и возвращает поток SSE-событий с прогрессом выполнения.

**Вход** (JSON):
```json
{
  "scenario_id": "uuid",
  "step_mode": false
}
```

**Выход** (поток событий с полем `type`):
- `status` — изменение статуса выполнения
- `node_status` — статус текущего узла
- `step_complete` — шаг выполнен
- `step_paused` — шаг приостановлен (пошаговый режим)
- `loop_progress` — прогресс цикла (i/n)
- `rag_search` — результаты RAG-поиска
- `file_output` — результат в виде файла

## ⚙️ Настройка среды

Создайте файл `.env` или установите переменные окружения:

```bash
# База данных
DATABASE_URL=jdbc:postgresql://localhost:5432/gigame
db.username=your_user
db.password=your_password
DATABASE_SCHEMA=public

# GigaChat API
GIGACHAT_URL=https://gigachat-ift.sberdevices.delta.sbrf.ru/v1
GIGACHAT_SERT=classpath:giga_ift.pem
GIGACHAT_KEY=classpath:giga_ift.key
GIGACHAT_SCOPE=GIGACHAT_API_CORP
GIGACHAT_MODEL=GigaChat-2-Max

# Настройки приложения
PORT=8080
CONTEXT_CHAR_LIMIT=200000
MAX_HISTORY_MESSAGES=20
AUTO_TITLE_LENGTH=100
TOPK=5
CHUNK_SIZE=1000
OVERLAP=200
BATCH_SIZE=50
```

### Конфигурация GigaChat

Для работы с GigaChat API необходимы:
- `giga_ift.pem` — сертификат (должен быть в `src/main/resources/`)
- `giga_ift.key` — приватный ключ (должен быть в `src/main/resources/`)

## 💻 Разработка

### Сборка проекта

```bash
mvn clean package
```

### Запуск с DEBUG логами

```bash
java -jar target/gigame-backend-1.1.6.jar \
  --logging.level.ru.sber.cs.ai.gigame=DEBUG \
  --logging.level.org.springframework.web=DEBUG
```

### Правила кодирования

- **Длина строки**: максимум 300 символов
- **Длина метода**: максимум 50 строк
- **Параметры метода**: максимум 8
- **Документация**: Javadoc для всех публичных методов
- **Null safety**: Использовать `isBlank()`, `isNotEmpty()` для строк
- **DTO**: Использовать Java records для response DTO
- **Логирование**: Slf4j со structured logging
- **Lombok**: `@RequiredArgsConstructor`, `@Data`, `@Slf4j`
- **Ошибки**: Кастомные исключения с `@ControllerAdvice`

### Checkstyle

Проверка стиля кода осуществляется автоматически при сборке (конфигурация в `checkstyle.xml`):

```bash
mvn validate
```

## 🧪 Тестирование

```bash
# Запуск всех тестов
mvn test

# Запуск конкретного класса тестов
mvn test -Dtest=ChatServiceTest
mvn test -Dtest=ScenarioEngineTest
mvn test -Dtest=ScenarioExecutorProcessingNodeTest

# Отчёт о покрытии кода
mvn test jacoco:report
```

### Структура тестов (75+ тестов)

Тесты покрывают все уровни приложения:

| Уровень | Количество | Примеры |
|---------|-----------|---------|
| config | 5 | JacksonConfig, OpenApiConfig, WebSocketConfig |
| controller | 5 | ConversationController, ScenarioController, ExceptionHandler |
| exception | 6 | Каждое исключение + ErrorResponse |
| model | 8 | JPA entity tests |
| repository | 9 | Repository + PersistenceLayerIntegration |
| service | 8 | ChatService, DocumentService, KBService, EmbeddingService и др. |
| scenario | 10 | Engine, ExportToDocx, ScenarioResultToXlsx, Mapper, Node, GraphStructure |
| executors | 8 | Каждый executor + фабрика |
| utils | 3 | FileUtils, TextSplitter, UserUtils |
| ws | 3 | ChatWebSocket, ScenarioWebSocket, SessionManager |

### Требования к покрытию

- Минимальное покрытие по сложности: **70%** (JaCoCo + checkstyle)

## 🧠 Архитектура движка сценариев

### Исполнители узлов

`ScenarioExecutorFactory` — фабрика, которая по типу узла создаёт нужный исполнитель.

`AbstractScenarioExecutor` — базовый класс для всех исполнителей. Хранит ссылку на весь граф (`ScenarioGraphStructure`) и текущий узел (`ScenarioNode`). Предоставляет общие методы:

- `buildPrompt()` — сборка промпта из контекста (документы + результат предыдущего шага + RAG-фрагменты)
- `previousOutputCollection()` — сборка входных данных от предшествующих узлов (с учётом пропущенных веток)
- `getSkipSet()` — вычисление узлов, которые нужно обойти при ветвлении (Switch/If)

### Алгоритм по типам узлов

1. **InputNode** — пробрасывает `documentsText` как есть на выход. Без AI-обработки.

2. **ProcessingNode** — собирает входные данные, выполняет RAG-поиск (если подключена БЗ), формирует промпт, вызывает GigaChat и сохраняет ответ.

3. **LoopNode** — два режима:
   - `classify_strict`: каждый документ классифицируется GigaChat в один из заданных классов
   - `full analysis`: каждый документ обрабатывается через GigaChat с полным промптом
   - Между итерациями — настраиваемая задержка. SSE-событие `loop_progress` по каждой итерации.

4. **SwitchNode** — маршрутизация на основе классификации (от LoopNode) или правил сопоставления (`contains`/`equals`/`startswith`). Невыбранные ветки помечаются как `skipped`.

5. **IfNode** — вычисляет логическое условие (`contains`/`not_contains`/`equals`/`greater_than`/`less_than`) и выбирает ветку `true` или `false`. Проигравшая ветка (с потомками) добавляется в `skippedNodes`.

6. **OutputNode** — собирает выходы всех непропущенных предшественников, объединяет через `\n\n`. Без AI-обработки. Поддерживает режимы `TEXT_FILE` (сохранение в файл) и `EXCEL` (генерация XLSX).

### Порядок выполнения

Граф обходится топологически — порядок гарантируется `ScenarioEngine`, который итерирует узлы и вызывает `execute()` на каждом. Результаты сохраняются в `structure.getNodeOutputs()`, пропущенные узлы отмечаются в `skippedNodes`.

## 🔧 Troubleshooting

### Проблема: Ошибки аутентификации сертификата

**Решение**: Убедитесь, что `giga_ift.pem` и `giga_ift.key` находятся в `src/main/resources/`. Сертификаты должны быть в формате PEM (не PKCS#12).

### Проблема: Поиск похожести возвращает пустоту

**Решение**: Проверьте, что расширение `pgvector` установлено и создан IVFFlat индекс:

```sql
CREATE INDEX IF NOT EXISTS idx_embeddings_vector
ON embeddings USING ivfflat (embedding vector_cosine_ops) WITH (lists = 100);
```

### Проблема: JPA LazyInitializationException

**Решение**: Убедитесь, что запросы выполняются в `@Transactional` контексте. В конфигурации установлено `open-in-view: false`.

### Проблема: Ошибки при загрузке файлов (500)

**Решение**: Убедитесь, что размер файлов не превышает 30MB (максимальный размер запроса 100MB).

### Проблема: GigaChat API timeout

**Решение**: Увеличьте таймауты в `application.yaml`:

```yaml
spring:
  ai:
    gigachat:
      internal:
        connect-timeout: 60s
        read-timeout: 600s
```

### Проблема: Миграции Liquibase не применяются

**Решение**: Проверьте, что PostgreSQL расширения `uuid-ossp` и `vector` установлены. Liquibase выполняет миграции автоматически при старте (`ddl-auto: validate`).

## 📝 Лицензия

© Сбербанк 2026. Все права защищены.