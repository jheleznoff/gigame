package ru.sber.cs.ai.gigame.service.scenario.executor;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.PositionDto;
import ru.sber.cs.ai.gigame.service.EmbeddingService;
import ru.sber.cs.ai.gigame.service.GigaChatClient;
import ru.sber.cs.ai.gigame.service.scenario.enums.ScenarioNodeType;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunNode;

import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.assertInstanceOf;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;

@ExtendWith(MockitoExtension.class)
class ScenarioExecutorFactoryTest {

    @Mock
    private GigaChatClient gigaChatClient;

    @Mock
    private EmbeddingService embeddingService;

    private ScenarioExecutorFactory factory;

    @BeforeEach
    void setUp() {
        factory = new ScenarioExecutorFactory(gigaChatClient, embeddingService, org.mockito.Mockito.mock(org.springframework.beans.factory.ObjectProvider.class));
    }

    private NodeDto createNode(String id, ScenarioNodeType type, String label, int x, int y) {
        return NodeDto.builder()
                .id(id)
                .type(type.toString())
                .data(NodeDataDto.builder().label(label).build())
                .position(new PositionDto(x, y))
                .build();
    }

    // ================================================================
    // createExecutor tests
    // ================================================================

    @ParameterizedTest
    @MethodSource("executorProvider")
    void testCreateExecutor_withNodeType(ScenarioNodeType type, Class<? extends AbstractScenarioExecutor> expectedClass) {
        NodeDto nodeDto = createNode("node-1", type, "Node", 100, 100);
        ScenarioRunNode node = ScenarioRunNode.fromDto(0, nodeDto, null);

        AbstractScenarioExecutor executor = factory.createExecutor(node);

        assertNotNull(executor);
        assertInstanceOf(expectedClass, executor);
    }

    static Stream<Arguments> executorProvider() {
        return Stream.of(
                Arguments.arguments(ScenarioNodeType.INPUT_NODE, ScenarioExecutorInputNode.class),
                Arguments.arguments(ScenarioNodeType.OUTPUT_NODE, ScenarioExecutorOutputNode.class),
                Arguments.arguments(ScenarioNodeType.PROCESSING_NODE, ScenarioExecutorProcessingNode.class),
                Arguments.arguments(ScenarioNodeType.IF_NODE, ScenarioExecutorIfNode.class),
                Arguments.arguments(ScenarioNodeType.SWITCH_NODE, ScenarioExecutorSwitchNode.class),
                Arguments.arguments(ScenarioNodeType.LOOP_NODE, ScenarioExecutorLoopNode.class)
        );
    }

    @Test
    void testCreateExecutor_withUnknownNodeType_throwsException() {
        NodeDto unknownNode = NodeDto.builder()
                .id("unknown-1")
                .type("unknown_type")
                .data(NodeDataDto.builder()
                        .label("Unknown Node")
                        .build())
                .position(new PositionDto(100, 100))
                .build();

        ScenarioRunNode node = ScenarioRunNode.fromDto(0, unknownNode, null);

        assertThrows(IllegalArgumentException.class, () -> factory.createExecutor(node));
    }

    @Test
    void testFactoryConstructorWithDependencies() {
        assertNotNull(factory);
    }
}
