package ru.sber.cs.ai.gigame.service.scenario;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.http.codec.ServerSentEvent;
import reactor.core.publisher.Flux;
import reactor.core.publisher.FluxSink;
import ru.sber.cs.ai.gigame.dto.scenario.graph.EdgeDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.EdgeDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.GraphDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.PositionDto;
import ru.sber.cs.ai.gigame.model.ScenarioRun;
import ru.sber.cs.ai.gigame.model.ScenarioRunStep;
import ru.sber.cs.ai.gigame.service.DocsTextCacheService;
import ru.sber.cs.ai.gigame.service.scenario.enums.ScenarioNodeType;
import ru.sber.cs.ai.gigame.service.scenario.executor.AbstractScenarioExecutor;
import ru.sber.cs.ai.gigame.service.scenario.executor.ScenarioExecutorFactory;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunGraph;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunNode;

import java.util.List;
import java.util.Map;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

/**
 * Интеграционные тесты для {@link ScenarioEngine}.
 * <p>
 * Тестирует публичный API executeScenario, который запускает doExecute в отдельном потоке.
 * <p>
 * Также тестирует doExecute напрямую через рефлексию.
 */
class ScenarioEngineIntegrationTest {

    // -------------------------------------------------------------------------
    // executeScenario integration tests
    // -------------------------------------------------------------------------

    @Test
    void testExecuteScenario_withValidGraph_returnsFlux() {
        var runService = Mockito.mock(ScenarioRunService.class);
        var stepService = Mockito.mock(ScenarioRunStepService.class);
        var executorFactory = Mockito.mock(ScenarioExecutorFactory.class);
        var cacheService = Mockito.mock(DocsTextCacheService.class);

        NodeDto inputNode = createInputNode("input-1");
        NodeDto outputNode = createOutputNode("output-1");
        EdgeDto edge = createEdge("e1", "input-1", "output-1");

        GraphDataDto graphData = new GraphDataDto(List.of(inputNode, outputNode), List.of(edge));
        ScenarioRun run = createScenarioRun();

        ScenarioEngine engine = new ScenarioEngine(runService, stepService, executorFactory, cacheService, org.mockito.Mockito.mock(ru.sber.cs.ai.gigame.repository.ScenarioRepository.class));

        when(runService.setScenarioRunStatusRunning(any(ScenarioRun.class))).thenReturn(run);
        when(runService.setScenarioRunStatusCompleted(any(ScenarioRun.class), anyString())).thenReturn(run);
        when(stepService.setScenarioStepStatusRunning(any(UUID.class), anyString(), any(ScenarioNodeType.class)))
                .thenReturn(createScenarioRunStep());
        when(stepService.setScenarioStepStatusCompleted(any(ScenarioRunStep.class), anyString(), anyString(),
                anyString(), anyString())).thenReturn(createScenarioRunStep());

        var mockExecutor = getMockExecutor(graphData, inputNode, 0, "input");

        when(executorFactory.createExecutor(
                any(ScenarioRunNode.class))).thenReturn(mockExecutor);

        Flux<ServerSentEvent<Map<String, Object>>> result = engine.executeScenario(run, graphData);

        assertNotNull(result);
    }

    @Test
    void testExecuteScenario_withMultipleNodes_returnsFlux() {
        var runService = Mockito.mock(ScenarioRunService.class);
        var stepService = Mockito.mock(ScenarioRunStepService.class);
        var executorFactory = Mockito.mock(ScenarioExecutorFactory.class);
        var cacheService = Mockito.mock(DocsTextCacheService.class);

        NodeDto inputNode = createInputNode("input-1");
        NodeDto outputNode = createOutputNode("output-1");

        EdgeDto edge = createEdge("e1", "input-1", "output-1");

        GraphDataDto graphData = new GraphDataDto(
                List.of(inputNode, outputNode),
                List.of(edge)
        );
        ScenarioRun run = createScenarioRun();

        ScenarioEngine engine = new ScenarioEngine(runService, stepService, executorFactory, cacheService, org.mockito.Mockito.mock(ru.sber.cs.ai.gigame.repository.ScenarioRepository.class));

        when(runService.setScenarioRunStatusRunning(any(ScenarioRun.class))).thenReturn(run);
        when(runService.setScenarioRunStatusCompleted(any(ScenarioRun.class), anyString())).thenReturn(run);
        when(stepService.setScenarioStepStatusRunning(any(UUID.class), anyString(), any(ScenarioNodeType.class)))
                .thenReturn(createScenarioRunStep());

        AbstractScenarioExecutor mockExecutor1 = getMockExecutor(graphData, inputNode, 0, "Input result");

        AbstractScenarioExecutor mockExecutor2 = getMockExecutor(graphData, outputNode, 1, "Final output");

        when(executorFactory.createExecutor(any(ScenarioRunNode.class)))
                .thenReturn(mockExecutor1)
                .thenReturn(mockExecutor2);

        when(stepService.setScenarioStepStatusCompleted(any(ScenarioRunStep.class), anyString(), anyString(),
                anyString(), anyString())).thenReturn(createScenarioRunStep());

        Flux<ServerSentEvent<Map<String, Object>>> result = engine.executeScenario(run, graphData);

        assertNotNull(result);
    }

    @Test
    void testExecuteScenario_withException_returnsFailedStatus() {
        var runService = Mockito.mock(ScenarioRunService.class);
        var stepService = Mockito.mock(ScenarioRunStepService.class);
        var executorFactory = Mockito.mock(ScenarioExecutorFactory.class);
        var cacheService = Mockito.mock(DocsTextCacheService.class);

        NodeDto inputNode = createInputNode("input-1");
        NodeDto outputNode = createOutputNode("output-1");
        EdgeDto edge = createEdge("e1", "input-1", "output-1");

        GraphDataDto graphData = new GraphDataDto(List.of(inputNode, outputNode), List.of(edge));
        ScenarioRun run = createScenarioRun();

        ScenarioEngine engine = new ScenarioEngine(runService, stepService, executorFactory, cacheService, org.mockito.Mockito.mock(ru.sber.cs.ai.gigame.repository.ScenarioRepository.class));

        when(runService.setScenarioRunStatusRunning(any(ScenarioRun.class))).thenReturn(run);
        when(runService.setScenarioRunStatusFailed(any(ScenarioRun.class))).thenReturn(run);
        when(stepService.setScenarioStepStatusRunning(any(UUID.class), anyString(), any(ScenarioNodeType.class)))
                .thenReturn(createScenarioRunStep());

        AbstractScenarioExecutor mockExecutor = getMockExecutorWithException(graphData, inputNode, "Test exception");

        when(executorFactory.createExecutor(any(ScenarioRunNode.class)))
                .thenReturn(mockExecutor);

        when(stepService.setScenarioStepStatusFailed(any(ScenarioRunStep.class), anyString()))
                .thenReturn(createScenarioRunStep());

        Flux<ServerSentEvent<Map<String, Object>>> result = engine.executeScenario(run, graphData);

        assertNotNull(result);
    }

    @Test
    void testExecuteScenario_stepModePausesExecution() {
        var runService = Mockito.mock(ScenarioRunService.class);
        var stepService = Mockito.mock(ScenarioRunStepService.class);
        var executorFactory = Mockito.mock(ScenarioExecutorFactory.class);
        var cacheService = Mockito.mock(DocsTextCacheService.class);

        NodeDto inputNode = createInputNode("node-1");
        NodeDto outputNode = createOutputNode("node-2");

        EdgeDto edge = createEdge("e1", "node-1", "node-2");

        GraphDataDto graphData = new GraphDataDto(
                List.of(inputNode, outputNode),
                List.of(edge)
        );
        ScenarioRun run = createScenarioRun();

        ScenarioEngine engine = new ScenarioEngine(runService, stepService, executorFactory, cacheService, org.mockito.Mockito.mock(ru.sber.cs.ai.gigame.repository.ScenarioRepository.class));

        when(runService.setScenarioRunStatusRunning(any(ScenarioRun.class))).thenReturn(run);

        AbstractScenarioExecutor mockExecutor1 = getMockExecutor(graphData, inputNode, 0, "Step 1 result");
        AbstractScenarioExecutor mockExecutor2 = getMockExecutor(graphData, outputNode, 1, "Step 2 result");

        when(executorFactory.createExecutor(any(ScenarioRunNode.class)))
                .thenReturn(mockExecutor1)
                .thenReturn(mockExecutor2);

        when(stepService.setScenarioStepStatusRunning(any(UUID.class), anyString(), any(ScenarioNodeType.class)))
                .thenReturn(createScenarioRunStep());
        when(stepService.setScenarioStepStatusCompleted(any(ScenarioRunStep.class), anyString(), anyString(),
                anyString(), anyString())).thenReturn(createScenarioRunStep());

        Flux<ServerSentEvent<Map<String, Object>>> result = engine.executeScenario(run, graphData);

        assertNotNull(result);
    }

    @Test
    void testExecuteScenario_withSkippedNode_emitsSkippedStatus() {
        var runService = Mockito.mock(ScenarioRunService.class);
        var stepService = Mockito.mock(ScenarioRunStepService.class);
        var executorFactory = Mockito.mock(ScenarioExecutorFactory.class);
        var cacheService = Mockito.mock(DocsTextCacheService.class);

        NodeDto inputNode = createInputNode("input-1");
        NodeDto processingNode = createProcessingNode("process-1", "Condition check");
        NodeDto outputNode = createOutputNode("output-1");

        EdgeDto edge1 = createEdge("e1", "input-1", "process-1");
        EdgeDto edge2 = createEdge("e2", "process-1", "output-1");

        GraphDataDto graphData = new GraphDataDto(
                List.of(inputNode, processingNode, outputNode),
                List.of(edge1, edge2)
        );
        ScenarioRun run = createScenarioRun();

        ScenarioEngine engine = new ScenarioEngine(runService, stepService, executorFactory, cacheService, org.mockito.Mockito.mock(ru.sber.cs.ai.gigame.repository.ScenarioRepository.class));

        when(runService.setScenarioRunStatusRunning(any(ScenarioRun.class))).thenReturn(run);
        when(runService.setScenarioRunStatusCompleted(any(ScenarioRun.class), anyString())).thenReturn(run);

        AbstractScenarioExecutor mockExecutor1 = getMockExecutor(graphData, inputNode, 0, "Input result");
        AbstractScenarioExecutor mockExecutor2 = getMockExecutor(graphData, processingNode, 1, "");
        AbstractScenarioExecutor mockExecutor3 = getMockExecutor(graphData, outputNode, 2, "Final");

        when(executorFactory.createExecutor(any(ScenarioRunNode.class)))
                .thenReturn(mockExecutor1)
                .thenReturn(mockExecutor2)
                .thenReturn(mockExecutor3);

        when(stepService.setScenarioStepStatusRunning(any(UUID.class), anyString(), any(ScenarioNodeType.class)))
                .thenReturn(createScenarioRunStep());
        when(stepService.setScenarioStepStatusCompleted(any(ScenarioRunStep.class), anyString(), anyString(),
                anyString(), anyString())).thenReturn(createScenarioRunStep());

        Flux<ServerSentEvent<Map<String, Object>>> result = engine.executeScenario(run, graphData);

        assertNotNull(result);
    }

    // -------------------------------------------------------------------------
    // doExecute direct tests (via reflection)
    // -------------------------------------------------------------------------

    /**
     * Тестирует прямой вызов doExecute с валидным графом.
     * doExecute вызывается напрямую через рефлексию.
     */
    @Test
    void testDoExecute_withValidGraph_executesSuccessfully() {
        var runService = Mockito.mock(ScenarioRunService.class);
        var stepService = Mockito.mock(ScenarioRunStepService.class);
        var executorFactory = Mockito.mock(ScenarioExecutorFactory.class);
        var cacheService = Mockito.mock(DocsTextCacheService.class);

        NodeDto node1 = createInputNode("node-1");
        NodeDto node2 = createOutputNode("node-2");
        EdgeDto edge = createEdge("e1", "node-1", "node-2");

        GraphDataDto graphData = new GraphDataDto(List.of(node1, node2), List.of(edge));
        ScenarioRun run = createScenarioRun();

        ScenarioEngine engine = new ScenarioEngine(runService, stepService, executorFactory, cacheService, org.mockito.Mockito.mock(ru.sber.cs.ai.gigame.repository.ScenarioRepository.class));

        when(runService.setScenarioRunStatusRunning(any(ScenarioRun.class))).thenReturn(run);
        when(runService.setScenarioRunStatusCompleted(any(ScenarioRun.class), anyString())).thenReturn(run);
        var step = createScenarioRunStep();
        when(stepService.setScenarioStepStatusRunning(any(UUID.class), anyString(), any(ScenarioNodeType.class)))
                .thenReturn(step);
        step.setInputData(Map.of(
                "documents_text", "",
                "previous_output", ""));
        step.setOutputData(Map.of("result", "result"));
        step.setPromptUsed("");
        when(stepService.setScenarioStepStatusCompleted(any(ScenarioRunStep.class), anyString(), anyString(),
                anyString(), anyString())).thenReturn(step);
        var mockExecutor = getMockExecutor(graphData, node1, 0, "Result");
        when(executorFactory.createExecutor(any(ScenarioRunNode.class))).thenReturn(mockExecutor);

        // Создаем Flux и вызываем doExecute напрямую через рефлексию
        Flux<ServerSentEvent<Map<String, Object>>> flux = Flux.create(sink -> {
            try {
                var method = ScenarioEngine.class.getDeclaredMethod("doExecute",
                        FluxSink.class, ScenarioRun.class, GraphDataDto.class);
                method.setAccessible(true);
                method.invoke(engine, sink, run, graphData);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        });

        // Подписываемся на Flux и ждем завершения
        var events = flux.collectList().block();
        assertNotNull(events);
    }

    /**
     * Тестирует обработку исключений в doExecute.
     */
    @Test
    void testDoExecute_withException_handledCorrectly() {
        var runService = Mockito.mock(ScenarioRunService.class);
        var stepService = Mockito.mock(ScenarioRunStepService.class);
        var executorFactory = Mockito.mock(ScenarioExecutorFactory.class);
        var cacheService = Mockito.mock(DocsTextCacheService.class);

        NodeDto node1 = createInputNode("node-1");
        NodeDto node2 = createOutputNode("node-2");
        EdgeDto edge = createEdge("e1", "node-1", "node-2");

        GraphDataDto graphData = new GraphDataDto(List.of(node1, node2), List.of(edge));
        ScenarioRun run = createScenarioRun();

        ScenarioEngine engine = new ScenarioEngine(runService, stepService, executorFactory, cacheService, org.mockito.Mockito.mock(ru.sber.cs.ai.gigame.repository.ScenarioRepository.class));

        when(runService.setScenarioRunStatusRunning(any(ScenarioRun.class))).thenReturn(run);
        when(runService.setScenarioRunStatusFailed(any(ScenarioRun.class))).thenReturn(run);
        when(stepService.setScenarioStepStatusRunning(any(UUID.class), anyString(), any(ScenarioNodeType.class)))
                .thenReturn(createScenarioRunStep());
        AbstractScenarioExecutor mockExecutor = getMockExecutorWithException(graphData, node1, "Test exception in doExecute");

        when(executorFactory.createExecutor(any(ScenarioRunNode.class)))
                .thenReturn(mockExecutor);

        when(stepService.setScenarioStepStatusFailed(any(ScenarioRunStep.class), anyString()))
                .thenReturn(createScenarioRunStep());
        // Ошибка узла (on_error=stop по умолчанию) пробрасывается из doExecute;
        // прогон завершается со статусом FAILED на уровне executeScenario
        Flux<ServerSentEvent<Map<String, Object>>> flux = engine.executeScenario(run, graphData);

        // Подписываемся на Flux - должен завершиться корректно (исключение обработано)
        var events = flux.collectList().block();
        assertNotNull(events);
        Mockito.verify(runService, Mockito.timeout(5000)).setScenarioRunStatusFailed(any(ScenarioRun.class));
    }

    // -------------------------------------------------------------------------
    // Factory methods for test data
    // -------------------------------------------------------------------------

    private ScenarioRun createScenarioRun() {
        ScenarioRun run = new ScenarioRun();
        run.setId(UUID.randomUUID());
        run.setScenarioId(UUID.randomUUID());
        run.setStatus("pending");
        return run;
    }

    private ScenarioRunStep createScenarioRunStep() {
        ScenarioRunStep step = new ScenarioRunStep();
        step.setId(UUID.randomUUID());
        step.setRunId(UUID.randomUUID());
        step.setNodeId("node-1");
        step.setNodeType("input");
        step.setStatus("pending");
        return step;
    }

    private NodeDto createInputNode(String id) {
        return NodeDto.builder()
                .id(id)
                .type(ScenarioNodeType.INPUT_NODE.toString())
                .data(NodeDataDto.builder().label("Input").build())
                .position(new PositionDto(100, 100))
                .build();
    }

    private NodeDto createOutputNode(String id) {
        return NodeDto.builder()
                .id(id)
                .type(ScenarioNodeType.OUTPUT_NODE.toString())
                .data(NodeDataDto.builder().label("Output").build())
                .position(new PositionDto(100, 100))
                .build();
    }

    private NodeDto createProcessingNode(String id, String prompt) {
        return NodeDto.builder()
                .id(id)
                .type(ScenarioNodeType.PROCESSING_NODE.toString())
                .data(NodeDataDto.builder().label("Processing").prompt(prompt).build())
                .position(new PositionDto(100, 100))
                .build();
    }

    private EdgeDto createEdge(String id, String source, String target) {
        return new EdgeDto(id, source, target, new EdgeDataDto(null));
    }

    private AbstractScenarioExecutor getMockExecutor(GraphDataDto graphData, NodeDto node, int index, String inputResult) {
        return new AbstractScenarioExecutor(ScenarioRunNode.fromDto(index, node, new ScenarioRunGraph(graphData))) {
            @Override
            public String execute(FluxSink<ServerSentEvent<Map<String, Object>>> sink) {
                return inputResult;
            }

            @Override
            public String getPrompt() {
                return "";
            }

        };
    }

    private AbstractScenarioExecutor getMockExecutorWithException(GraphDataDto graphData, NodeDto node1, String exceptionText) {
        return new AbstractScenarioExecutor(
                ScenarioRunNode.fromDto(0, node1, new ScenarioRunGraph(graphData))) {
            @Override
            public String execute(FluxSink<ServerSentEvent<Map<String, Object>>> sink) {
                throw new RuntimeException(exceptionText);
            }

            @Override
            public String getPrompt() {
                return "";
            }
        };
    }
}
