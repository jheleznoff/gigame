package ru.sber.cs.ai.gigame.ws;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpHeaders;
import org.springframework.web.reactive.socket.HandshakeInfo;
import org.springframework.web.reactive.socket.WebSocketSession;
import reactor.core.publisher.Mono;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

class WebSocketSessionManagerTest {

    private WebSocketSessionManager sessionManager;
    private WebSocketSession webSocketSession;

    @BeforeEach
    void setUp() {
        sessionManager = new WebSocketSessionManager();

        // Create a mock WebSocketSession
        HandshakeInfo handshakeInfo = mock(HandshakeInfo.class);
        HttpHeaders headers = new HttpHeaders();
        headers.put("X-UserId", List.of("test-user-id"));
        when(handshakeInfo.getHeaders()).thenReturn(headers);

        webSocketSession = mock(WebSocketSession.class);
        when(webSocketSession.getId()).thenReturn("test-session-id");
        when(webSocketSession.getHandshakeInfo()).thenReturn(handshakeInfo);
        when(webSocketSession.isOpen()).thenReturn(true);
        when(webSocketSession.close()).thenReturn(Mono.empty());
    }

    @Test
    void testAddSession() {
        String userId = "test-user-id";

        sessionManager.addSession(webSocketSession, userId);

        assertNotNull(sessionManager.getSession("test-session-id"));
        assertEquals(userId, sessionManager.getUserId("test-session-id"));
        assertTrue(sessionManager.hasSession("test-session-id"));
    }

    @Test
    void testAddSession_multipleSessions() {
        String userId1 = "user-1";
        String userId2 = "user-2";

        WebSocketSession session1 = mock(WebSocketSession.class);
        when(session1.getId()).thenReturn("session-1");
        HandshakeInfo handshakeInfo1 = mock(HandshakeInfo.class);
        HttpHeaders headers1 = new HttpHeaders();
        headers1.put("X-UserId", List.of("user-1"));
        when(handshakeInfo1.getHeaders()).thenReturn(headers1);
        when(session1.getHandshakeInfo()).thenReturn(handshakeInfo1);
        when(session1.isOpen()).thenReturn(true);
        when(session1.close()).thenReturn(Mono.empty());

        WebSocketSession session2 = mock(WebSocketSession.class);
        when(session2.getId()).thenReturn("session-2");
        HandshakeInfo handshakeInfo2 = mock(HandshakeInfo.class);
        HttpHeaders headers2 = new HttpHeaders();
        headers2.put("X-UserId", List.of("user-2"));
        when(handshakeInfo2.getHeaders()).thenReturn(headers2);
        when(session2.getHandshakeInfo()).thenReturn(handshakeInfo2);
        when(session2.isOpen()).thenReturn(true);
        when(session2.close()).thenReturn(Mono.empty());

        sessionManager.addSession(session1, userId1);
        sessionManager.addSession(session2, userId2);

        assertEquals(userId1, sessionManager.getUserId("session-1"));
        assertEquals(userId2, sessionManager.getUserId("session-2"));
        assertEquals(2, sessionManager.getAllSessions().size());
    }

    @Test
    void testRemoveSession() {
        String userId = "test-user-id";

        sessionManager.addSession(webSocketSession, userId);
        sessionManager.removeSession(webSocketSession);

        assertNull(sessionManager.getSession("test-session-id"));
        assertNull(sessionManager.getUserId("test-session-id"));
        assertFalse(sessionManager.hasSession("test-session-id"));
    }

    @Test
    void testRemoveSession_sessionAlreadyRemoved() {
        // Try to remove a session that was never added
        assertDoesNotThrow(() -> sessionManager.removeSession(webSocketSession));
    }

    @Test
    void testRemoveSession_closesSessionIfOpen() {
        String userId = "test-user-id";

        sessionManager.addSession(webSocketSession, userId);
        sessionManager.removeSession(webSocketSession);

        verify(webSocketSession, times(1)).close();
    }

    @Test
    void testRemoveSession_doesNotThrowOnCloseException() {
        WebSocketSession failingSession = mock(WebSocketSession.class);
        when(failingSession.getId()).thenReturn("failing-session");
        HandshakeInfo failingHandshakeInfo = mock(HandshakeInfo.class);
        HttpHeaders failingHeaders = new HttpHeaders();
        failingHeaders.put("X-UserId", List.of("test-user-id"));
        when(failingHandshakeInfo.getHeaders()).thenReturn(failingHeaders);
        when(failingSession.getHandshakeInfo()).thenReturn(failingHandshakeInfo);
        when(failingSession.isOpen()).thenReturn(true);
        when(failingSession.close()).thenThrow(new RuntimeException("Close failed"));

        String userId = "test-user-id";

        sessionManager.addSession(failingSession, userId);
        assertDoesNotThrow(() -> sessionManager.removeSession(failingSession));
    }

    @Test
    void testGetSession_existingSession() {
        String userId = "test-user-id";
        sessionManager.addSession(webSocketSession, userId);

        WebSocketSession result = sessionManager.getSession("test-session-id");

        assertNotNull(result);
        assertEquals(webSocketSession, result);
    }

    @Test
    void testGetSession_nonExistingSession() {
        WebSocketSession result = sessionManager.getSession("non-existing-session");

        assertNull(result);
    }

    @Test
    void testGetUserId_existingSession() {
        String userId = "test-user-id";
        sessionManager.addSession(webSocketSession, userId);

        String result = sessionManager.getUserId("test-session-id");

        assertEquals(userId, result);
    }

    @Test
    void testGetUserId_nonExistingSession() {
        String result = sessionManager.getUserId("non-existing-session");

        assertNull(result);
    }

    @Test
    void testGetAllSessions() {
        String userId1 = "user-1";
        String userId2 = "user-2";

        WebSocketSession session1 = mock(WebSocketSession.class);
        when(session1.getId()).thenReturn("session-1");
        HandshakeInfo handshakeInfo1 = mock(HandshakeInfo.class);
        HttpHeaders headers1 = new HttpHeaders();
        headers1.put("X-UserId", List.of("user-1"));
        when(handshakeInfo1.getHeaders()).thenReturn(headers1);
        when(session1.getHandshakeInfo()).thenReturn(handshakeInfo1);
        when(session1.isOpen()).thenReturn(true);
        when(session1.close()).thenReturn(Mono.empty());

        WebSocketSession session2 = mock(WebSocketSession.class);
        when(session2.getId()).thenReturn("session-2");
        HandshakeInfo handshakeInfo2 = mock(HandshakeInfo.class);
        HttpHeaders headers2 = new HttpHeaders();
        headers2.put("X-UserId", List.of("user-2"));
        when(handshakeInfo2.getHeaders()).thenReturn(headers2);
        when(session2.getHandshakeInfo()).thenReturn(handshakeInfo2);
        when(session2.isOpen()).thenReturn(true);
        when(session2.close()).thenReturn(Mono.empty());

        sessionManager.addSession(session1, userId1);
        sessionManager.addSession(session2, userId2);

        var sessions = sessionManager.getAllSessions();

        assertEquals(2, sessions.size());
        assertTrue(sessions.contains(session1));
        assertTrue(sessions.contains(session2));
    }

    @Test
    void testGetAllSessions_empty() {
        var sessions = sessionManager.getAllSessions();

        assertNotNull(sessions);
        assertEquals(0, sessions.size());
    }

    @Test
    void testHasSession_existingSession() {
        sessionManager.addSession(webSocketSession, "test-user");

        assertTrue(sessionManager.hasSession("test-session-id"));
    }

    @Test
    void testHasSession_nonExistingSession() {
        assertFalse(sessionManager.hasSession("non-existing-session"));
    }

    @Test
    void testSessionIdToUserIdMapping_consistency() {
        String userId = "test-user-id";
        sessionManager.addSession(webSocketSession, userId);

        // Verify that we can get the userId using the session id
        String retrievedUserId = sessionManager.getUserId(webSocketSession.getId());
        assertEquals(userId, retrievedUserId);

        // Verify session is accessible by its id
        WebSocketSession retrievedSession = sessionManager.getSession(webSocketSession.getId());
        assertEquals(webSocketSession, retrievedSession);
    }

    @Test
    void testConcurrentAccess() {
        // Test that the underlying ConcurrentHashMap handles concurrent access
        int threadCount = 10;
        Thread[] threads = new Thread[threadCount];

        for (int i = 0; i < threadCount; i++) {
            final int index = i;
            threads[i] = new Thread(() -> {
                WebSocketSession session = mock(WebSocketSession.class);
                when(session.getId()).thenReturn("concurrent-session-" + index);
                HandshakeInfo handshakeInfo = mock(HandshakeInfo.class);
                HttpHeaders headers = new HttpHeaders();
                headers.put("X-UserId", List.of("user-" + index));
                when(handshakeInfo.getHeaders()).thenReturn(headers);
                when(session.getHandshakeInfo()).thenReturn(handshakeInfo);
                when(session.isOpen()).thenReturn(true);
                when(session.close()).thenReturn(Mono.empty());

                sessionManager.addSession(session, "user-" + index);
                sessionManager.getSession("concurrent-session-" + index);
                sessionManager.getUserId("concurrent-session-" + index);
            });
        }

        for (Thread thread : threads) {
            thread.start();
        }

        for (Thread thread : threads) {
            try {
                thread.join();
            } catch (InterruptedException e) {
                fail("Thread interrupted: " + e.getMessage());
            }
        }

        assertEquals(threadCount, sessionManager.getAllSessions().size());
    }
}
