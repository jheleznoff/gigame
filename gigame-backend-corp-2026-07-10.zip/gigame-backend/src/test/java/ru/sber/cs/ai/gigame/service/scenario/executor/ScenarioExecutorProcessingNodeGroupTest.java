package ru.sber.cs.ai.gigame.service.scenario.executor;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.springframework.http.codec.ServerSentEvent;
import reactor.core.publisher.FluxSink;
import ru.sber.cs.ai.gigame.dto.scenario.graph.EdgeDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.EdgeDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.GraphDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.PositionDto;
import ru.sber.cs.ai.gigame.exception.ScenarioException;
import ru.sber.cs.ai.gigame.service.EmbeddingService;
import ru.sber.cs.ai.gigame.service.GigaChatClient;
import ru.sber.cs.ai.gigame.service.scenario.enums.ScenarioNodeType;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunGraph;

import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * Тесты режима группировки (mode=group) processing-узла:
 * один LLM-вызов на группу документов, ключ группы из имени файла.
 */
class ScenarioExecutorProcessingNodeGroupTest {

    private GigaChatClient gigaChatClient;
    private EmbeddingService embeddingService;
    @SuppressWarnings("unchecked")
    private final FluxSink<ServerSentEvent<Map<String, Object>>> sink = mock(FluxSink.class);

    @BeforeEach
    void setUp() {
        gigaChatClient = mock(GigaChatClient.class);
        embeddingService = mock(EmbeddingService.class);
    }

    private static ScenarioRunGraph createGroupGraph(String regexValue) {
        var inputDto = NodeDto.builder()
                .id("input-1")
                .type(ScenarioNodeType.INPUT_NODE.toString())
                .data(NodeDataDto.builder().label("Input").build())
                .position(new PositionDto(0, 0))
                .build();
        var processDto = NodeDto.builder()
                .id("process-1")
                .type(ScenarioNodeType.PROCESSING_NODE.toString())
                .data(NodeDataDto.builder()
                        .label("Кросс-проверка")
                        .prompt("Сверь документы группы")
                        .mode("group")
                        .value(regexValue)
                        .build())
                .position(new PositionDto(200, 0))
                .build();
        var gd = new GraphDataDto(List.of(inputDto, processDto),
                List.of(new EdgeDto("e1", "input-1", "process-1", new EdgeDataDto(null))));
        return new ScenarioRunGraph(gd);
    }

    private ScenarioExecutorProcessingNode executorFor(ScenarioRunGraph graph) {
        var node = graph.getNodeMap().get("process-1");
        var executor = new ScenarioExecutorProcessingNode(node, gigaChatClient, embeddingService);
        executor.setDocCharLimit(200000);
        return executor;
    }

    @Test
    void groupMode_oneCallPerGroup_defaultRegex() {
        when(gigaChatClient.chatCompletion(anyList(), any(), any())).thenReturn("группа ок");
        var graph = createGroupGraph(null);
        graph.addDocs(
                List.of("текст договора", "текст акта", "текст другого договора"),
                List.of("архив.zip/Договор 111222/договор.pdf",
                        "архив.zip/Договор 111222/акт.pdf",
                        "архив2.zip/Contract # 333444/contract.pdf"));
        var node = graph.getNodeMap().get("process-1");
        node.getDocList().addAll(List.of("DOC_1", "DOC_2", "DOC_3"));

        String result = executorFor(graph).execute(sink);

        // 2 группы (111222 и 333444) → ровно 2 вызова
        verify(gigaChatClient, times(2)).chatCompletion(anyList(), any(), any());
        assertTrue(result.contains("=== Группа 111222 ==="));
        assertTrue(result.contains("=== Группа 333444 ==="));
    }

    @Test
    void groupMode_promptContainsFilenamesAndAllGroupDocs() {
        when(gigaChatClient.chatCompletion(anyList(), any(), any())).thenReturn("ок");
        var graph = createGroupGraph(null);
        graph.addDocs(
                List.of("ТЕКСТ_ДОГОВОРА", "ТЕКСТ_АКТА"),
                List.of("Договор 55555/договор.pdf", "Договор 55555/акт.pdf"));
        var node = graph.getNodeMap().get("process-1");
        node.getDocList().addAll(List.of("DOC_1", "DOC_2"));

        executorFor(graph).execute(sink);

        @SuppressWarnings("unchecked")
        ArgumentCaptor<List<Map<String, String>>> captor = ArgumentCaptor.forClass((Class) List.class);
        verify(gigaChatClient).chatCompletion(captor.capture(), any(), any());
        String prompt = captor.getValue().get(0).get("content");
        assertTrue(prompt.contains("Группа документов: 55555"));
        assertTrue(prompt.contains("<<<Документ: Договор 55555/договор.pdf>>>"));
        assertTrue(prompt.contains("<<<Документ: Договор 55555/акт.pdf>>>"));
        assertTrue(prompt.contains("ТЕКСТ_ДОГОВОРА"));
        assertTrue(prompt.contains("ТЕКСТ_АКТА"));
    }

    @Test
    void groupMode_documentWithoutMatch_formsOwnGroup() {
        when(gigaChatClient.chatCompletion(anyList(), any(), any())).thenReturn("ок");
        var graph = createGroupGraph(null);
        graph.addDocs(
                List.of("текст 1", "текст 2"),
                List.of("Договор 77777/договор.pdf", "просто-файл.pdf"));
        var node = graph.getNodeMap().get("process-1");
        node.getDocList().addAll(List.of("DOC_1", "DOC_2"));

        String result = executorFor(graph).execute(sink);

        verify(gigaChatClient, times(2)).chatCompletion(anyList(), any(), any());
        assertTrue(result.contains("=== Группа просто-файл.pdf ==="));
    }

    @Test
    void groupMode_customRegex() {
        when(gigaChatClient.chatCompletion(anyList(), any(), any())).thenReturn("ок");
        var graph = createGroupGraph("LOT-(\\d+)");
        graph.addDocs(
                List.of("a", "b", "c"),
                List.of("LOT-1_справка.pdf", "LOT-1_форма.pdf", "LOT-2_справка.pdf"));
        var node = graph.getNodeMap().get("process-1");
        node.getDocList().addAll(List.of("DOC_1", "DOC_2", "DOC_3"));

        String result = executorFor(graph).execute(sink);

        verify(gigaChatClient, times(2)).chatCompletion(anyList(), any(), any());
        assertTrue(result.contains("=== Группа 1 ==="));
        assertTrue(result.contains("=== Группа 2 ==="));
    }

    @Test
    void groupMode_budgetKeepsSmallDocsFull_truncatesLargest() {
        when(gigaChatClient.chatCompletion(anyList(), any(), any())).thenReturn("ок");
        var graph = createGroupGraph(null);
        String hugeContract = "ДОГОВОРНЫЙ_ТЕКСТ ".repeat(5000); // ~85k символов
        graph.addDocs(
                List.of(hugeContract, "КОРОТКИЙ_АКТ_12345", "КОРОТКАЯ_СПЕЦИФИКАЦИЯ_67890"),
                List.of("Договор 99999/договор.pdf",
                        "Договор 99999/акт.pdf",
                        "Договор 99999/спецификация.pdf"));
        var node = graph.getNodeMap().get("process-1");
        node.getDocList().addAll(List.of("DOC_1", "DOC_2", "DOC_3"));
        var executor = new ScenarioExecutorProcessingNode(node, gigaChatClient, embeddingService);
        executor.setDocCharLimit(30000); // меньше суммарного размера группы

        executor.execute(sink);

        @SuppressWarnings("unchecked")
        ArgumentCaptor<List<Map<String, String>>> captor = ArgumentCaptor.forClass((Class) List.class);
        verify(gigaChatClient).chatCompletion(captor.capture(), any(), any());
        String prompt = captor.getValue().get(0).get("content");
        // короткие документы вошли целиком, договор обрезан по остатку бюджета
        assertTrue(prompt.contains("КОРОТКИЙ_АКТ_12345"));
        assertTrue(prompt.contains("КОРОТКАЯ_СПЕЦИФИКАЦИЯ_67890"));
        assertTrue(prompt.contains("[... документ обрезан по лимиту контекста ...]"));
        // блок не был повторно обрезан общим лимитом buildPrompt
        assertTrue(!prompt.contains("[... документы обрезаны ...]"));
        assertTrue(prompt.length() < 32000);
    }

    @Test
    void groupMode_invalidRegex_throwsScenarioException() {
        var graph = createGroupGraph("([недозакрытая");
        graph.addDocs(List.of("a"), List.of("файл.pdf"));
        var node = graph.getNodeMap().get("process-1");
        node.getDocList().add("DOC_1");
        var executor = executorFor(graph);

        assertThrows(ScenarioException.class, () -> executor.execute(sink));
    }

    @Test
    void defaultMode_unchanged_perDocumentCalls() {
        when(gigaChatClient.chatCompletion(anyList(), any(), any())).thenReturn("ок");
        var inputDto = NodeDto.builder()
                .id("input-1")
                .type(ScenarioNodeType.INPUT_NODE.toString())
                .data(NodeDataDto.builder().label("Input").build())
                .position(new PositionDto(0, 0))
                .build();
        var processDto = NodeDto.builder()
                .id("process-1")
                .type(ScenarioNodeType.PROCESSING_NODE.toString())
                .data(NodeDataDto.builder().label("Proc").prompt("p").build())
                .position(new PositionDto(200, 0))
                .build();
        var gd = new GraphDataDto(List.of(inputDto, processDto),
                List.of(new EdgeDto("e1", "input-1", "process-1", new EdgeDataDto(null))));
        var graph = new ScenarioRunGraph(gd);
        graph.addDocs(List.of("t1", "t2"), List.of("Договор 1/a.pdf", "Договор 1/b.pdf"));
        var node = graph.getNodeMap().get("process-1");
        node.getDocList().addAll(List.of("DOC_1", "DOC_2"));
        var executor = new ScenarioExecutorProcessingNode(node, gigaChatClient, embeddingService);
        executor.setDocCharLimit(200000);

        executor.execute(sink);

        // без mode=group — прежнее поведение: вызов на каждый документ
        verify(gigaChatClient, times(2)).chatCompletion(anyList(), any(), any());
    }
}
