package ru.sber.cs.ai.gigame.ws;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.springframework.http.HttpHeaders;
import org.springframework.http.codec.ServerSentEvent;
import org.springframework.web.reactive.socket.HandshakeInfo;
import org.springframework.web.reactive.socket.WebSocketMessage;
import org.springframework.web.reactive.socket.WebSocketSession;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import ru.sber.cs.ai.gigame.service.ChatService;
import ru.sber.cs.ai.gigame.service.DocsTextCacheService;

import java.util.List;
import java.util.Map;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@SuppressWarnings("unchecked")
class ChatWebSocketHandlerTest {

    private ChatWebSocketHandler handler;
    private ChatService chatService;
    private WebSocketSessionManager sessionManager;
    private ObjectMapper objectMapper;
    private WebSocketSession webSocketSession;

    @BeforeEach
    void setUp() {
        chatService = mock(ChatService.class);
        sessionManager = mock(WebSocketSessionManager.class);
        objectMapper = new ObjectMapper();
        DocsTextCacheService docsTextCacheService = mock(DocsTextCacheService.class);

        handler = new ChatWebSocketHandler(
                chatService,
                sessionManager,
                objectMapper,
                docsTextCacheService
        );

        // Mock DocsTextCacheService to return empty list instead of null
        when(docsTextCacheService.getCachedDocumentTexts(any())).thenReturn(List.of());
        when(docsTextCacheService.getCachedFileNames(any())).thenReturn(List.of());

        // Create a mock WebSocketSession
        HandshakeInfo handshakeInfo = mock(HandshakeInfo.class);
        HttpHeaders headers = new HttpHeaders();
        headers.put("X-UserId", List.of("test-user-id"));
        when(handshakeInfo.getHeaders()).thenReturn(headers);

        webSocketSession = mock(WebSocketSession.class);
        when(webSocketSession.getId()).thenReturn("test-session-id");
        when(webSocketSession.getHandshakeInfo()).thenReturn(handshakeInfo);
        when(webSocketSession.isOpen()).thenReturn(true);
        when(webSocketSession.textMessage(anyString())).thenReturn(mock(WebSocketMessage.class));
        when(webSocketSession.send(any())).thenReturn(Mono.empty());
    }

    @Test
    void testHandle_addsSession() {
        when(webSocketSession.receive()).thenReturn(Flux.empty());
        when(sessionManager.getSession("test-session-id")).thenReturn(webSocketSession);
        when(chatService.sendMessageStream(anyString(), any(UUID.class), anyString(), any(List.class), any(List.class)))
                .thenReturn(Flux.empty());

        handler.handle(webSocketSession).block();

        verify(sessionManager, times(1)).addSession(webSocketSession, "test-user-id");
    }

    @Test
    void testHandle_removesSessionOnTerminate() {
        when(webSocketSession.receive()).thenReturn(Flux.empty());

        handler.handle(webSocketSession).block();

        verify(sessionManager, times(1)).removeSession(webSocketSession);
    }

    @Test
    void testHandle_processesIncomingMessage() {
        UUID conversationId = UUID.randomUUID();
        String payload = """
                {
                    "conversation_id": "%s",
                    "content": "Hello, how are you?",
                    "document_ids": []
                }
                """.formatted(conversationId);

        WebSocketMessage message = mock(
                WebSocketMessage.class
        );
        when(message.getPayloadAsText()).thenReturn(payload);

        when(webSocketSession.receive()).thenReturn(Flux.just(message));
        when(sessionManager.getSession("test-session-id")).thenReturn(webSocketSession);
        when(webSocketSession.send(any())).thenReturn(Mono.empty());
        when(chatService.sendMessageStream(anyString(), any(UUID.class), anyString(), any(List.class), any(List.class)))
                .thenReturn(Flux.empty());

        handler.handle(webSocketSession).block();

        verify(chatService, times(1)).sendMessageStream(
                eq("test-user-id"),
                eq(conversationId),
                anyString(),
                eq(List.of()),
                any()
        );
    }

    @Test
    void testHandle_sendsErrorMessageOnJsonParseError() {
        String invalidPayload = "{ invalid json }";

        WebSocketMessage message = mock(
                WebSocketMessage.class
        );
        when(message.getPayloadAsText()).thenReturn(invalidPayload);

        when(webSocketSession.receive()).thenReturn(Flux.just(message));
        when(webSocketSession.send(any())).thenReturn(Mono.empty());

        handler.handle(webSocketSession).block();

        verify(webSocketSession, times(1)).send(any());
    }

    @Test
    void testHandle_sendsErrorMessageOnSessionClosed() {
        UUID conversationId = UUID.randomUUID();
        String payload = """
                {
                    "conversation_id": "%s",
                    "content": "Hello",
                    "document_ids": []
                }
                """.formatted(conversationId);

        WebSocketMessage message = mock(
                WebSocketMessage.class
        );
        when(message.getPayloadAsText()).thenReturn(payload);

        when(webSocketSession.receive()).thenReturn(Flux.just(message));
        when(sessionManager.getSession("test-session-id")).thenReturn(null); // Session not found

        handler.handle(webSocketSession).block();
        verify(sessionManager).getSession("test-session-id");
    }

    @Test
    void testHandle_sessionNotFound() {
        UUID conversationId = UUID.randomUUID();
        String payload = """
                {
                    "conversation_id": "%s",
                    "content": "Hello",
                    "document_ids": []
                }
                """.formatted(conversationId);

        WebSocketMessage message = mock(
                WebSocketMessage.class
        );
        when(message.getPayloadAsText()).thenReturn(payload);

        when(webSocketSession.receive()).thenReturn(Flux.just(message));
        when(sessionManager.getSession("test-session-id")).thenReturn(null);

        handler.handle(webSocketSession).block();

        verify(chatService, never()).sendMessageStream(any(), any(), any(), any(), any());
    }

    @Test
    void testHandle_withNullContent() {
        UUID conversationId = UUID.randomUUID();
        String payload = """
                {
                    "conversation_id": "%s",
                    "content": null,
                    "document_ids": []
                }
                """.formatted(conversationId);

        WebSocketMessage message = mock(
                WebSocketMessage.class
        );
        when(message.getPayloadAsText()).thenReturn(payload);

        when(webSocketSession.receive()).thenReturn(Flux.just(message));
        when(sessionManager.getSession("test-session-id")).thenReturn(webSocketSession);
        when(chatService.sendMessageStream(anyString(), any(UUID.class), anyString(), any(List.class), any(List.class)))
                .thenReturn(Flux.empty());

        handler.handle(webSocketSession).block();
        verify(chatService).sendMessageStream(any(), any(), any(), any(), any());
    }

    @Test
    void testHandle_withNullUserIdInHeaders() {
        HandshakeInfo handshakeInfo = mock(HandshakeInfo.class);
        HttpHeaders headers = new HttpHeaders();
        when(handshakeInfo.getHeaders()).thenReturn(headers); // No X-UserId

        WebSocketSession session = mock(WebSocketSession.class);
        when(session.getId()).thenReturn("test-session-id-2");
        when(session.getHandshakeInfo()).thenReturn(handshakeInfo);
        when(session.isOpen()).thenReturn(true);
        when(session.receive()).thenReturn(Flux.empty());

        handler.handle(session).block();

        verify(sessionManager, times(1)).addSession(session, "anonymous");
    }

    @Test
    void testHandle_createsStreamEvent() {
        UUID conversationId = UUID.randomUUID();

        String payload = """
                {
                    "conversation_id": "%s",
                    "content": "Hello",
                    "document_ids": []
                }
                """.formatted(conversationId);

        WebSocketMessage message = mock(
                WebSocketMessage.class
        );
        when(message.getPayloadAsText()).thenReturn(payload);

        when(webSocketSession.receive()).thenReturn(Flux.just(message));
        when(sessionManager.getSession("test-session-id")).thenReturn(webSocketSession);
        when(webSocketSession.send(any())).thenReturn(Mono.empty());

        // Mock a server sent event with data
        Map<String, Object> eventData = Map.of(
                "content", "Hi there!",
                ChatService.USAGE, Map.of("prompt_tokens", 10, "completion_tokens", 5),
                "done", true
        );
        ServerSentEvent<Map<String, Object>> sse = ServerSentEvent.<Map<String, Object>>builder().data(eventData).build();
        when(chatService.sendMessageStream(any(), any(), any(), any(), any()))
                .thenReturn(Flux.just(sse));

        handler.handle(webSocketSession).block();

        ArgumentCaptor<Flux<WebSocketMessage>> fluxCaptor = ArgumentCaptor.forClass(Flux.class);
        verify(webSocketSession, times(1)).send(fluxCaptor.capture());

        Flux<?> capturedFlux = fluxCaptor.getValue();
        List<?> messages = capturedFlux.collectList().block();

        assertNotNull(messages);
        assertEquals(1, messages.size());
    }

    @Test
    void testHandle_emptyDataInStreamEvent() {
        UUID conversationId = UUID.randomUUID();

        String payload = """
                {
                    "conversation_id": "%s",
                    "content": "Hello",
                    "document_ids": []
                }
                """.formatted(conversationId);

        WebSocketMessage message = mock(
                WebSocketMessage.class
        );
        when(message.getPayloadAsText()).thenReturn(payload);

        when(webSocketSession.receive()).thenReturn(Flux.just(message));
        when(sessionManager.getSession("test-session-id")).thenReturn(webSocketSession);
        when(webSocketSession.send(any())).thenReturn(Mono.empty());

        // Mock a server sent event with null data
        ServerSentEvent<Map<String, Object>> sse = ServerSentEvent.<Map<String, Object>>builder().data(null).build();
        when(chatService.sendMessageStream(any(), any(), any(), any(), any()))
                .thenReturn(Flux.just(sse));

        handler.handle(webSocketSession).block();
        verify(chatService).sendMessageStream(any(), any(), any(), any(), any());
    }

    @Test
    void testHandle_withAllEventFields() {
        UUID conversationId = UUID.randomUUID();
        List<String> documentIds = List.of("doc-1");

        String payload = """
                {
                    "conversation_id": "%s",
                    "content": "Hello",
                    "document_ids": ["doc-1"]
                }
                """.formatted(conversationId);

        WebSocketMessage message = mock(
                WebSocketMessage.class
        );
        when(message.getPayloadAsText()).thenReturn(payload);

        when(webSocketSession.receive()).thenReturn(Flux.just(message));
        when(sessionManager.getSession("test-session-id")).thenReturn(webSocketSession);
        when(webSocketSession.send(any())).thenReturn(Mono.empty());

        // Mock a server sent event with all fields
        Map<String, Object> eventData = Map.of(
                "content", "Response",
                ChatService.USAGE, Map.of("prompt_tokens", 10, "completion_tokens", 5, "total_tokens", 15),
                "document_ids", documentIds,
                "done", true
        );
        ServerSentEvent<Map<String, Object>> sse = ServerSentEvent.<Map<String, Object>>builder().data(eventData).build();
        when(chatService.sendMessageStream(any(), any(), any(), any(), any()))
                .thenReturn(Flux.just(sse));

        handler.handle(webSocketSession).block();

        ArgumentCaptor<Flux<WebSocketMessage>> fluxCaptor = ArgumentCaptor.forClass(Flux.class);
        verify(webSocketSession, times(1)).send(fluxCaptor.capture());

        Flux<?> capturedFlux = fluxCaptor.getValue();
        List<?> messages = capturedFlux.collectList().block();

        assertNotNull(messages);
        assertEquals(1, messages.size());
    }

    @Test
    void testHandle_withErrorInStream() {
        UUID conversationId = UUID.randomUUID();

        String payload = """
                {
                    "conversation_id": "%s",
                    "content": "Hello",
                    "document_ids": []
                }
                """.formatted(conversationId);

        WebSocketMessage message = mock(
                WebSocketMessage.class
        );
        when(message.getPayloadAsText()).thenReturn(payload);

        when(webSocketSession.receive()).thenReturn(Flux.just(message));
        when(sessionManager.getSession("test-session-id")).thenReturn(webSocketSession);
        when(webSocketSession.send(any())).thenReturn(Mono.empty());

        // Mock a server sent event with error
        Map<String, Object> eventData = Map.of("error", "Something went wrong");
        ServerSentEvent<Map<String, Object>> sse = ServerSentEvent.<Map<String, Object>>builder().data(eventData).build();
        when(chatService.sendMessageStream(any(), any(), any(), any(), any()))
                .thenReturn(Flux.just(sse));

        handler.handle(webSocketSession).block();

        ArgumentCaptor<Flux<WebSocketMessage>> fluxCaptor = ArgumentCaptor.forClass(Flux.class);
        verify(webSocketSession, times(1)).send(fluxCaptor.capture());

        Flux<?> capturedFlux = fluxCaptor.getValue();
        List<?> messages = capturedFlux.collectList().block();

        assertNotNull(messages);
        assertEquals(1, messages.size());
    }

    @Test
    void testHandle_withMultipleEvents() {
        UUID conversationId = UUID.randomUUID();

        String payload = """
                {
                    "conversation_id": "%s",
                    "content": "Hello",
                    "document_ids": []
                }
                """.formatted(conversationId);

        WebSocketMessage message = mock(
                WebSocketMessage.class
        );
        when(message.getPayloadAsText()).thenReturn(payload);

        when(webSocketSession.receive()).thenReturn(Flux.just(message));
        when(sessionManager.getSession("test-session-id")).thenReturn(webSocketSession);
        when(webSocketSession.send(any())).thenReturn(Mono.empty());

        // Mock multiple server sent events
        ServerSentEvent<Map<String, Object>> event1 = ServerSentEvent.<Map<String, Object>>builder()
                .data(Map.of("content", "First"))
                .build();
        ServerSentEvent<Map<String, Object>> event2 = ServerSentEvent.<Map<String, Object>>builder()
                .data(Map.of("content", "Second", "done", true))
                .build();

        when(chatService.sendMessageStream(any(), any(), any(), any(), any()))
                .thenReturn(Flux.just(event1, event2));

        handler.handle(webSocketSession).block();

        ArgumentCaptor<Flux<WebSocketMessage>> fluxCaptor = ArgumentCaptor.forClass(Flux.class);
        verify(webSocketSession, times(1)).send(fluxCaptor.capture());

        Flux<?> capturedFlux = fluxCaptor.getValue();
        List<?> messages = capturedFlux.collectList().block();

        assertNotNull(messages);
        assertEquals(2, messages.size());
    }

    @Test
    void testChatMessageRecord() throws Exception {
        UUID conversationId = UUID.randomUUID();
        String payload = """
                {
                    "conversation_id": "%s",
                    "content": "Hello",
                    "document_ids": ["doc-1"]
                }
                """.formatted(conversationId);

        ChatWebSocketHandler.ChatMessage message = objectMapper.readValue(
                payload,
                ChatWebSocketHandler.ChatMessage.class
        );

        assertEquals(conversationId, message.conversation_id());
        assertEquals("Hello", message.content());
        assertEquals(List.of("doc-1"), message.document_ids());
    }

    @Test
    void testChatMessageRecord_withNulls() throws Exception {
        String payload = """
                {
                    "conversation_id": "123e4567-e89b-12d3-a456-426614174000",
                    "content": null,
                    "document_ids": null
                }
                """;

        ChatWebSocketHandler.ChatMessage message = objectMapper.readValue(
                payload,
                ChatWebSocketHandler.ChatMessage.class
        );

        assertNull(message.content());
        assertNull(message.document_ids());
    }
}