package ru.sber.cs.ai.gigame.controller;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpEntity;
import org.springframework.http.MediaType;
import org.springframework.http.codec.ServerSentEvent;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.reactive.server.WebTestClient;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.reactive.function.BodyInserters;
import reactor.core.publisher.Flux;
import reactor.test.StepVerifier;
import ru.sber.cs.ai.gigame.service.ChatService;
import ru.sber.cs.ai.gigame.service.DocsTextCacheService;
import ru.sber.cs.ai.gigame.service.DocumentService;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.Map;
import java.util.UUID;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

@WebFluxTest(controllers = ConversationController.class)
@SuppressWarnings("unused")
class ConversationControllerSendMessageWithDocumentsTest {

    @MockitoBean
    DocsTextCacheService docsTextCacheService;
    @Autowired
    private WebTestClient webClient;
    @MockitoBean
    private ChatService chatService;
    @MockitoBean
    private DocumentService documentService;

    private static MultiValueMap<String, HttpEntity<?>> getMockMultyPartBody(String messageContent, String fileText, String filename, String contentType) {
        // Подготовка multipart тела с использованием ByteArrayResource
        MultiValueMap<String, HttpEntity<?>> body = new LinkedMultiValueMap<>();

        // Добавляем текстовое поле "content"
        body.add("content", new HttpEntity<>(messageContent));

        // Добавляем файл
        ByteArrayResource resource = new ByteArrayResource(fileText.getBytes(StandardCharsets.UTF_8)) {
            @Override
            public String getFilename() {
                return filename;
            }
        };

        LinkedMultiValueMap<String, String> fileHeaders = new LinkedMultiValueMap<>();
        fileHeaders.add("Content-Type", contentType);
        body.add("files", new HttpEntity<>(resource, fileHeaders));
        return body;
    }

    @Test
    @SuppressWarnings({"unchecked"})
    void sendMessageWithDocuments_ShouldProcessFilesAndReturnStream() throws IOException {
        // Given
        String userId = "USER123";
        UUID conversationId = UUID.randomUUID();
        String messageContent = "Расскажи о приложенном документе.";
        String filename = "test.pdf";
        String fileText = "Текст из PDF файла.";

        // Мокируем извлечение текста из файла
        when(documentService.parseText(any(InputStream.class), eq("application/pdf")))
                .thenReturn(fileText);
        // Мокируем ответ потока SSE
        when(chatService.sendMessageStream(
                eq(userId),
                eq(conversationId),
                any(),
                any(),
                any()
        )).thenReturn(Flux.just(
                ServerSentEvent.<Map<String, Object>>builder().data(Map.of("content", "Часть ответа...")).build(),
                ServerSentEvent.<Map<String, Object>>builder().data(Map.of("done", true)).build()
        ));
        MultiValueMap<String, HttpEntity<?>> body = getMockMultyPartBody(messageContent, fileText, filename, MediaType.APPLICATION_PDF.toString());
        // When & Then
        StepVerifier.create(
                        webClient.post()
                                .uri("/api/conversations/{id}/messages/upload", conversationId)
                                .header("X-UserId", userId)
                                .contentType(MediaType.MULTIPART_FORM_DATA)
                                .body(BodyInserters.fromMultipartData(body))
                                .accept(MediaType.TEXT_EVENT_STREAM)
                                .exchange()
                                .expectStatus().isOk()
                                .returnResult(ServerSentEvent.class)
                                .getResponseBody())
                .expectNextMatches(event -> {
                    Map<String, Object> data = (Map<String, Object>) event.data();
                    Assertions.assertNotNull(data);
                    return "Часть ответа...".equals(data.get("content"));
                })
                .expectNextMatches(event -> {
                    Map<String, Object> data = (Map<String, Object>) event.data();
                    Assertions.assertNotNull(data);
                    return Boolean.TRUE.equals(data.get("done"));
                })
                .expectComplete()
                .verify(Duration.ofSeconds(5));
    }

    @Test
    void sendMessageWithUnsupportedContentType_ShouldFailWithBadRequest() throws IOException {
        // Given
        String userId = "USER123";
        UUID conversationId = UUID.randomUUID();
        String messageContent = "Расскажи о приложенном документе.";
        String filename = "test.xyz";
        String fileText = "Текст из файла.";

        // Мокируем вызов documentService.parseText для выброса исключения
        when(documentService.parseText(any(), any()))
                .thenThrow(new IllegalArgumentException("Неподдерживаемый тип контента: application/xyz"));

        // Подготовка multipart тела с использованием ByteArrayResource
        MultiValueMap<String, HttpEntity<?>> body = getMockMultyPartBody(messageContent, fileText, filename, "application/xyz");

        // When & Then
        webClient.post()
                .uri("/api/conversations/{id}/messages/upload", conversationId)
                .header("X-UserId", userId)
                .contentType(MediaType.MULTIPART_FORM_DATA)
                .body(BodyInserters.fromMultipartData(body))
                .accept(MediaType.TEXT_EVENT_STREAM)
                .exchange()
                .expectStatus().isEqualTo(422);
    }

    @Test
    @SuppressWarnings("unchecked")
    void sendMessageWithoutFiles_ShouldProcessMessageAndReturnStream() {
        // Given
        String userId = "USER123";
        UUID conversationId = UUID.randomUUID();
        String messageContent = "Простое сообщение без файлов.";

        // Подготавливаем multipart тело даже без файлов
        MultiValueMap<String, HttpEntity<?>> body = new LinkedMultiValueMap<>();
        body.add("content", new HttpEntity<>(messageContent));

        // Мокируем ответ потока SSE без участия DocumentService
        when(chatService.sendMessageStream(
                eq(userId),
                eq(conversationId),
                eq(messageContent),
                any(),
                any()
        )).thenReturn(Flux.just(
                ServerSentEvent.<Map<String, Object>>builder().data(Map.of("content", "Ответ на простое сообщение...")).build(),
                ServerSentEvent.<Map<String, Object>>builder().data(Map.of("done", true)).build()
        ));

        // When & Then
        StepVerifier.create(
                        webClient.post()
                                .uri("/api/conversations/{id}/messages/upload", conversationId)
                                .header("X-UserId", userId)
                                .contentType(MediaType.MULTIPART_FORM_DATA)
                                .body(BodyInserters.fromMultipartData(body))
                                .accept(MediaType.TEXT_EVENT_STREAM)
                                .exchange()
                                .expectStatus().isOk()
                                .returnResult(ServerSentEvent.class)
                                .getResponseBody())
                .expectNextMatches(event -> {
                    Map<String, Object> data = (Map<String, Object>) event.data();
                    Assertions.assertNotNull(data);
                    return "Ответ на простое сообщение...".equals(data.get("content"));
                })
                .expectNextMatches(event -> {
                    Map<String, Object> data = (Map<String, Object>) event.data();
                    Assertions.assertNotNull(data);
                    return Boolean.TRUE.equals(data.get("done"));
                })
                .expectComplete()
                .verify(Duration.ofSeconds(5));
    }

    @Test
    void sendMessageWithTooManyFiles_ShouldFailWithUnprocessableEntity() {
        // Given
        String userId = "USER123";
        UUID conversationId = UUID.randomUUID();
        String messageContent = "Сообщение";
        String filename = "test.txt";
        String fileText = "Текст";

        // Подготовка multipart тела с количеством файлов, превышающим лимит
        MultiValueMap<String, HttpEntity<?>> body = new LinkedMultiValueMap<>();
        body.add("content", new HttpEntity<>(messageContent));
        for (int i = 0; i < ConversationController.MAX_FILES_PER_REQUEST + 1; i++) {
            final int idx = i;
            ByteArrayResource resource = new ByteArrayResource(fileText.getBytes(StandardCharsets.UTF_8)) {
                @Override
                public String getFilename() {
                    return idx + "_" + filename;
                }
            };
            LinkedMultiValueMap<String, String> headers = new LinkedMultiValueMap<>();
            headers.add("Content-Type", "text/plain");
            body.add("files", new HttpEntity<>(resource, headers));
        }

        // When & Then
        webClient.post()
                .uri("/api/conversations/{id}/messages/upload", conversationId)
                .header("X-UserId", userId)
                .contentType(MediaType.MULTIPART_FORM_DATA)
                .body(BodyInserters.fromMultipartData(body))
                .accept(MediaType.TEXT_EVENT_STREAM)
                .exchange()
                .expectStatus().isEqualTo(422);
    }

    @Test
    void sendMessageWithJsonInsteadOfMultipart_ShouldReturnUnsupportedMediaType() {
        // Given
        String userId = "USER123";
        UUID conversationId = UUID.randomUUID();
        String messageContent = "Сообщение с неправильным Content-Type";

        // Подготавливаем тело как JSON (некорректно для /upload)
        Map<String, String> jsonBody = Map.of("content", messageContent);

        // When & Then
        webClient.post()
                .uri("/api/conversations/{id}/messages/upload", conversationId)
                .header("X-UserId", userId)
                .contentType(MediaType.APPLICATION_JSON) // Отправляем JSON вместо multipart
                .accept(MediaType.TEXT_EVENT_STREAM)
                .bodyValue(jsonBody)
                .exchange()
                .expectStatus().isEqualTo(415); // Expect 415 Unsupported Media Type

    }
}