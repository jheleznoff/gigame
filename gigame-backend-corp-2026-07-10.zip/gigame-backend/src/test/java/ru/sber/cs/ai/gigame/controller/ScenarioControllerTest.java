package ru.sber.cs.ai.gigame.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.codec.ServerSentEvent;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.reactive.server.WebTestClient;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.reactive.function.BodyInserters;
import reactor.core.publisher.Flux;
import reactor.test.StepVerifier;
import ru.sber.cs.ai.gigame.TestConfiguration;
import ru.sber.cs.ai.gigame.dto.scenario.ScenarioCreate;
import ru.sber.cs.ai.gigame.dto.scenario.ScenarioDetailResponse;
import ru.sber.cs.ai.gigame.dto.scenario.ScenarioResponse;
import ru.sber.cs.ai.gigame.dto.scenario.ScenarioRunDetailResponse;
import ru.sber.cs.ai.gigame.dto.scenario.ScenarioRunResponse;
import ru.sber.cs.ai.gigame.dto.scenario.ScenarioRunStepInputDataResponse;
import ru.sber.cs.ai.gigame.dto.scenario.ScenarioRunStepOutputDataResponse;
import ru.sber.cs.ai.gigame.dto.scenario.ScenarioRunStepResponse;
import ru.sber.cs.ai.gigame.dto.scenario.graph.GraphDataDto;
import ru.sber.cs.ai.gigame.service.DocsTextCacheService;
import ru.sber.cs.ai.gigame.service.scenario.ScenarioEngine;
import ru.sber.cs.ai.gigame.service.scenario.ScenarioService;

import java.time.Duration;
import java.time.OffsetDateTime;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = {ScenarioController.class, TestConfiguration.class})
@WebFluxTest(controllers = ScenarioController.class)
@SuppressWarnings("unused")
class ScenarioControllerTest {

    @MockitoBean
    DocsTextCacheService docsTextCacheService;
    @Autowired
    private WebTestClient webClient;
    @Autowired
    private ObjectMapper objectMapper;
    @MockitoBean
    private ScenarioService scenarioService;
    @MockitoBean
    private ScenarioEngine scenarioEngine;
    private String userId;
    private UUID scenarioId;
    private UUID runId;
    private ScenarioResponse scenarioResponse;

    @BeforeEach
    void setUp() {
        userId = "test-user";
        scenarioId = UUID.randomUUID();
        runId = UUID.randomUUID();
        scenarioResponse = new ScenarioResponse(
                scenarioId,
                "Test Scenario",
                "Description",
                OffsetDateTime.now(),
                OffsetDateTime.now()
        );
    }

    @Test
    void testListScenarios() {
        when(scenarioService.getScenarios(any())).thenReturn(List.of(scenarioResponse));

        webClient.get()
                .uri("/api/scenarios")
                .header("X-UserId", userId)
                .accept(MediaType.APPLICATION_JSON)
                .exchange()
                .expectStatus().isOk()
                .expectHeader().contentType(MediaType.APPLICATION_JSON)
                .expectBody(List.class);
    }

    @Test
    void testCreateScenario() {
        ScenarioCreate body = new ScenarioCreate(
                "New Scenario",
                "Description",
                new ru.sber.cs.ai.gigame.dto.scenario.graph.GraphDataDto(
                        List.of(),
                        List.of()
                )
        );

        when(scenarioService.createScenario(any(), eq("New Scenario"), eq("Description"), any()))
                .thenReturn(scenarioResponse);

        webClient.post()
                .uri("/api/scenarios")
                .header("X-UserId", userId)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(body)
                .exchange()
                .expectStatus().isCreated()
                .expectHeader().contentType(MediaType.APPLICATION_JSON)
                .expectBody(ScenarioResponse.class);
    }

    @Test
    void testGetScenario() {
        ScenarioDetailResponse result = new ScenarioDetailResponse(
                scenarioId,
                "Test Scenario",
                "Description",
                OffsetDateTime.now(),
                OffsetDateTime.now(),
                new GraphDataDto(List.of(), List.of())
        );

        when(scenarioService.getScenario(any(), eq(scenarioId))).thenReturn(result);

        webClient.get()
                .uri("/api/scenarios/{id}", scenarioId)
                .header("X-UserId", userId)
                .accept(MediaType.APPLICATION_JSON)
                .exchange()
                .expectStatus().isOk()
                .expectHeader().contentType(MediaType.APPLICATION_JSON)
                .expectBody(ScenarioDetailResponse.class);
    }

    @Test
    void testUpdateScenario() {
        ScenarioCreate body = new ScenarioCreate(
                "Updated Scenario",
                "Updated description",
                new ru.sber.cs.ai.gigame.dto.scenario.graph.GraphDataDto(
                        List.of(),
                        List.of()
                )
        );

        when(scenarioService.updateScenario(any(), eq(scenarioId), eq("Updated Scenario"), eq("Updated description"), any()))
                .thenReturn(scenarioResponse);

        webClient.put()
                .uri("/api/scenarios/{id}", scenarioId)
                .header("X-UserId", userId)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(body)
                .exchange()
                .expectStatus().isOk()
                .expectHeader().contentType(MediaType.APPLICATION_JSON)
                .expectBody(ScenarioResponse.class);
    }

    @Test
    void testDeleteScenario() {
        doNothing().when(scenarioService).deleteScenario(any(), eq(scenarioId));

        webClient.delete()
                .uri("/api/scenarios/{id}", scenarioId)
                .header("X-UserId", userId)
                .exchange()
                .expectStatus().isNoContent();
    }

    @Test
    void duplicateScenario_ShouldReturnCopiedScenario() {
        // Given
        ScenarioResponse copiedResponse = new ScenarioResponse(
                UUID.randomUUID(),
                "Original Scenario (копия)",
                "Original description",
                OffsetDateTime.now(),
                OffsetDateTime.now()
        );

        when(scenarioService.duplicateScenario(userId, scenarioId))
                .thenReturn(copiedResponse);

        // When & Then
        webClient.post()
                .uri("/api/scenarios/{id}/duplicate", scenarioId)
                .header("X-UserId", userId)
                .exchange()
                .expectStatus().isOk()
                .expectHeader().contentType(MediaType.APPLICATION_JSON)
                .expectBody(ScenarioResponse.class)
                .value(response -> {
                    assert response != null;
                });
    }

    @Test
    void duplicateScenario_ShouldReturnNotFound_WhenScenarioNotFound() {
        // Given
        when(scenarioService.duplicateScenario(userId, scenarioId))
                .thenThrow(new IllegalArgumentException("Scenario not found: " + scenarioId));

        // When & Then
        webClient.post()
                .uri("/api/scenarios/{id}/duplicate", scenarioId)
                .header("X-UserId", userId)
                .exchange()
                .expectStatus().is5xxServerError();
    }

    // -------------------------------------------------------------------------
    // listRuns
    // -------------------------------------------------------------------------

    @Test
    void listRuns_ShouldReturnRunsList() {
        // Given
        ScenarioRunResponse run1 = new ScenarioRunResponse(
                UUID.randomUUID(),
                scenarioId,
                "completed",
                List.of("doc1", "doc2"),
                "Result 1",
                OffsetDateTime.now().minusDays(1),
                OffsetDateTime.now().minusDays(1)
        );

        ScenarioRunResponse run2 = new ScenarioRunResponse(
                UUID.randomUUID(),
                scenarioId,
                "failed",
                List.of("doc3"),
                null,
                OffsetDateTime.now().minusHours(2),
                OffsetDateTime.now().minusHours(2)
        );

        when(scenarioService.getScenarioRuns(userId, scenarioId))
                .thenReturn(List.of(run1, run2));

        // When & Then
        webClient.get()
                .uri("/api/scenarios/{id}/runs", scenarioId)
                .header("X-UserId", userId)
                .exchange()
                .expectStatus().isOk()
                .expectHeader().contentType(MediaType.APPLICATION_JSON)
                .expectBody(List.class);
    }

    @Test
    void listRuns_ShouldReturnEmptyList_WhenNoRuns() {
        // Given
        when(scenarioService.getScenarioRuns(userId, scenarioId))
                .thenReturn(List.of());

        // When & Then
        webClient.get()
                .uri("/api/scenarios/{id}/runs", scenarioId)
                .header("X-UserId", userId)
                .exchange()
                .expectStatus().isOk()
                .expectBody(List.class)
                .value(list -> {
                    assert list != null;
                    assert ((List<?>) list).isEmpty();
                });
    }

    @Test
    void listRuns_ShouldReturnNotFound_WhenScenarioNotFound() {
        // Given
        when(scenarioService.getScenarioRuns(userId, scenarioId))
                .thenThrow(new IllegalArgumentException("Сценарий не найден: " + scenarioId));

        // When & Then
        webClient.get()
                .uri("/api/scenarios/{id}/runs", scenarioId)
                .header("X-UserId", userId)
                .exchange()
                .expectStatus().is5xxServerError();
    }

    @Test
    void getRunDetail_ShouldReturnDetailedRunInfo() {
        // Given
        ScenarioRunStepResponse step1 = new ScenarioRunStepResponse(
                UUID.randomUUID(),
                "node-1",
                "input",
                "completed",
                new ScenarioRunStepInputDataResponse("", "2024-01-01"),
                new ScenarioRunStepOutputDataResponse("Результат", null),
                "Это промпт",
                10,
                OffsetDateTime.now().minusHours(1),
                OffsetDateTime.now()
        );

        ScenarioRunDetailResponse runDetail = new ScenarioRunDetailResponse(
                runId,
                scenarioId,
                "completed",
                List.of("doc1"),
                "Final result",
                OffsetDateTime.now().minusHours(1),
                OffsetDateTime.now(),
                List.of(step1)
        );

        when(scenarioService.getScenarioRun(userId, runId))
                .thenReturn(runDetail);

        // When & Then
        webClient.get()
                .uri("/api/scenarios/runs/{runId}", runId)
                .header("X-UserId", userId)
                .exchange()
                .expectStatus().isOk()
                .expectHeader().contentType(MediaType.APPLICATION_JSON)
                .expectBody(ScenarioRunDetailResponse.class)
                .value(response -> {
                    assert response != null;
                    assert response.id().equals(runId);
                    assert response.scenarioId().equals(scenarioId);
                });
    }

    @Test
    void getRunDetail_ShouldReturnNotFound_WhenRunNotFound() {
        // Given
        when(scenarioService.getScenarioRun(userId, runId))
                .thenThrow(new IllegalArgumentException("Запуск сценария не найден: " + runId));

        // When & Then
        webClient.get()
                .uri("/api/scenarios/runs/{runId}", runId)
                .header("X-UserId", userId)
                .exchange()
                .expectStatus().is5xxServerError();
    }

    // -------------------------------------------------------------------------
    // continueRun
    // -------------------------------------------------------------------------

    @Test
    void continueRun_ShouldContinueExecution() {
        // Given
        doNothing().when(scenarioEngine).continueStep(runId.toString());

        // When & Then
        webClient.post()
                .uri("/api/scenarios/runs/{runId}/continue", runId)
                .header("X-UserId", userId)
                .exchange()
                .expectStatus().isOk();
    }

    // -------------------------------------------------------------------------
    // disableStepMode
    // -------------------------------------------------------------------------

    @Test
    void disableStepMode_ShouldDisableStepModeAndContinue() {
        // Given
        doNothing().when(scenarioEngine).disableStepMode(runId.toString());

        // When & Then
        webClient.post()
                .uri("/api/scenarios/runs/{runId}/disable-step-mode", runId)
                .header("X-UserId", userId)
                .exchange()
                .expectStatus().isOk();
    }

    // -------------------------------------------------------------------------
    // runScenario
    // -------------------------------------------------------------------------

    @Test
    void runScenario_ShouldStartExecutionAndReturnSSE() {
        // Given
        GraphDataDto graphData = new GraphDataDto(
                List.of(),
                List.of()
        );

        ScenarioDetailResponse scenarioDetail = new ScenarioDetailResponse(
                scenarioId,
                "Test Scenario",
                "Description",
                OffsetDateTime.now(),
                OffsetDateTime.now(),
                graphData
        );

        when(scenarioService.runScenario(userId, scenarioId, false))
                .thenReturn(Flux.just(
                        ServerSentEvent.<Map<String, Object>>builder()
                                .data(Map.of("type", "status", "status", "running"))
                                .build(),
                        ServerSentEvent.<Map<String, Object>>builder()
                                .data(Map.of("type", "node_status", "node_id", "node-1"))
                                .build(),
                        ServerSentEvent.<Map<String, Object>>builder()
                                .data(Map.of("type", "status", "status", "completed", "result", "done"))
                                .build()
                ));
        // Подготавливаем multipart тело даже без файлов
        MultiValueMap<String, HttpEntity<?>> body = new LinkedMultiValueMap<>();
        // When & Then
        StepVerifier.create(
                        webClient.post()
                                .uri("/api/scenarios/{id}/run?step_mode=false", scenarioId)
                                .header("X-UserId", userId)
                                .contentType(MediaType.MULTIPART_FORM_DATA)
                                .body(BodyInserters.fromMultipartData(body))
                                .accept(MediaType.TEXT_EVENT_STREAM)
                                .exchange()
                                .expectStatus().isOk()
                                .returnResult(ServerSentEvent.class)
                                .getResponseBody())
                .expectNextCount(3)
                .expectComplete()
                .verify(Duration.ofSeconds(5));
    }

    @Test
    void runScenario_WithStepMode_ShouldEnableStepMode() {
        // Given
        GraphDataDto graphData = new GraphDataDto(
                List.of(),
                List.of()
        );
        ScenarioDetailResponse scenarioDetail = new ScenarioDetailResponse(
                scenarioId,
                "Test Scenario",
                "Description",
                OffsetDateTime.now(),
                OffsetDateTime.now(),
                graphData
        );

        when(scenarioService.runScenario(userId, scenarioId, true))
                .thenReturn(Flux.just(
                        ServerSentEvent.<Map<String, Object>>builder()
                                .data(Map.of("type", "status", "status", "running"))
                                .build(),
                        ServerSentEvent.<Map<String, Object>>builder()
                                .data(Map.of("type", "node_status", "node_id", "node-1"))
                                .build()
                ));
        // Подготавливаем multipart тело даже без файлов
        MultiValueMap<String, HttpEntity<?>> body = new LinkedMultiValueMap<>();
        // When & Then
        StepVerifier.create(
                        webClient.post()
                                .uri("/api/scenarios/{id}/run?step_mode=true", scenarioId)
                                .header("X-UserId", userId)
                                .contentType(MediaType.MULTIPART_FORM_DATA)
                                .body(BodyInserters.fromMultipartData(body))
                                .accept(MediaType.TEXT_EVENT_STREAM)
                                .exchange()
                                .expectStatus().isOk()
                                .returnResult(ServerSentEvent.class)
                                .getResponseBody())
                .expectNextCount(2)
                .expectComplete()
                .verify(Duration.ofSeconds(5));
    }

    @Test
    void runScenario_WithFiles_ShouldProcessFilesAndReturnSSE() {
        // Given
        GraphDataDto graphData = new GraphDataDto(
                List.of(),
                List.of()
        );

        when(scenarioService.runScenario(userId, scenarioId, false))
                .thenReturn(Flux.just(
                        ServerSentEvent.<Map<String, Object>>builder()
                                .data(Map.of("type", "upload_progress", "file", "test.txt", "current", 1, "total", 1))
                                .build(),
                        ServerSentEvent.<Map<String, Object>>builder()
                                .data(Map.of("type", "upload_done", "count", 1))
                                .build(),
                        ServerSentEvent.<Map<String, Object>>builder()
                                .data(Map.of("type", "status", "status", "completed", "result", "done"))
                                .build()
                ));

        // Prepare multipart body
        MultiValueMap<String, HttpEntity<?>> body = new LinkedMultiValueMap<>();
        ByteArrayResource resource = new ByteArrayResource("test content".getBytes()) {
            @Override
            public String getFilename() {
                return "test.txt";
            }
        };
        LinkedMultiValueMap<String, String> fileHeaders = new LinkedMultiValueMap<>();
        fileHeaders.add("Content-Type", "text/plain");
        body.add("files", new HttpEntity<>(resource, fileHeaders));

        // When & Then
        StepVerifier.create(
                        webClient.post()
                                .uri("/api/scenarios/{id}/run?step_mode=false", scenarioId)
                                .header("X-UserId", userId)
                                .contentType(MediaType.MULTIPART_FORM_DATA)
                                .body(BodyInserters.fromMultipartData(body))
                                .accept(MediaType.TEXT_EVENT_STREAM)
                                .exchange()
                                .expectStatus().isOk()
                                .returnResult(ServerSentEvent.class)
                                .getResponseBody())
                .expectNextCount(3)
                .expectComplete()
                .verify(Duration.ofSeconds(5));
    }

    @Test
    void runScenario_ShouldReturnNotFound_WhenScenarioNotFound() {
        // Given
        when(scenarioService.runScenario(eq(userId), eq(scenarioId), any()))
                .thenThrow(new IllegalArgumentException("Scenario not found"));

        // When & Then
        webClient.post()
                .uri("/api/scenarios/{id}/run", scenarioId)
                .header("X-UserId", userId)
                .contentType(MediaType.MULTIPART_FORM_DATA)
                .accept(MediaType.TEXT_EVENT_STREAM)
                .exchange()
                .expectStatus().is5xxServerError();
    }

    @Test
    void runScenario_WithTooManyFiles_ShouldFailWithUnprocessableEntity() {
        // Given
        String filename = "test.txt";
        String fileText = "test content";

        // Prepare multipart body with files exceeding the limit
        MultiValueMap<String, HttpEntity<?>> body = new LinkedMultiValueMap<>();
        for (int i = 0; i < ScenarioController.MAX_FILES_PER_REQUEST + 1; i++) {
            int idx = i;
            ByteArrayResource resource = new ByteArrayResource(fileText.getBytes()) {
                @Override
                public String getFilename() {
                    return idx + "_" + filename;
                }
            };
            LinkedMultiValueMap<String, String> fileHeaders = new LinkedMultiValueMap<>();
            fileHeaders.add("Content-Type", "text/plain");
            body.add("files", new HttpEntity<>(resource, fileHeaders));
        }

        // When & Then
        webClient.post()
                .uri("/api/scenarios/{id}/run", scenarioId)
                .header("X-UserId", userId)
                .contentType(MediaType.MULTIPART_FORM_DATA)
                .body(BodyInserters.fromMultipartData(body))
                .accept(MediaType.TEXT_EVENT_STREAM)
                .exchange()
                .expectStatus().isEqualTo(422);
    }

    @Test
    void runScenario_WithoutFiles_ShouldReturnSSE() {
        // Given
        when(scenarioService.runScenario(userId, scenarioId, false))
                .thenReturn(Flux.just(
                        ServerSentEvent.<Map<String, Object>>builder()
                                .data(Map.of("type", "status", "status", "running"))
                                .build()
                ));
        // Подготавливаем multipart тело даже без файлов
        MultiValueMap<String, HttpEntity<?>> body = new LinkedMultiValueMap<>();
        // When & Then
        StepVerifier.create(
                        webClient.post()
                                .uri("/api/scenarios/{id}/run?step_mode=false", scenarioId)
                                .header("X-UserId", userId)
                                .contentType(MediaType.MULTIPART_FORM_DATA)
                                .body(BodyInserters.fromMultipartData(body))
                                .accept(MediaType.TEXT_EVENT_STREAM)
                                .exchange()
                                .expectStatus().isOk()
                                .returnResult(ServerSentEvent.class)
                                .getResponseBody())
                .expectNextCount(1)
                .expectComplete()
                .verify(Duration.ofSeconds(5));
    }

    // -------------------------------------------------------------------------
    // exportRun
    // -------------------------------------------------------------------------

    @Test
    void exportRun_ShouldReturnDocxFile() {
        // Given
        byte[] docxContent = "mock docx content".getBytes();
        ByteArrayResource resource = new ByteArrayResource(docxContent) {
            @Override
            public String getFilename() {
                return "test.docx";
            }
        };

        HttpHeaders headers = new org.springframework.http.HttpHeaders();
        headers.setContentType(MediaType.parseMediaType("application/vnd.openxmlformats-officedocument.wordprocessingml.document"));

        when(scenarioService.extractToDocx(userId, runId, false))
                .thenReturn(new ResponseEntity<>(resource, headers, org.springframework.http.HttpStatus.OK));

        // When & Then
        webClient.get()
                .uri("/api/scenarios/runs/{runId}/export", runId)
                .header("X-UserId", userId)
                .exchange()
                .expectStatus().isOk()
                .expectHeader().contentType("application/vnd.openxmlformats-officedocument.wordprocessingml.document")
                .expectBody(byte[].class);
    }

    @Test
    void exportRun_ShouldReturnNotFound_WhenRunNotFound() {
        // Given
        when(scenarioService.extractToDocx(userId, runId, false))
                .thenThrow(new IllegalArgumentException("Run not found: " + runId));

        // When & Then
        webClient.get()
                .uri("/api/scenarios/runs/{runId}/export", runId)
                .header("X-UserId", userId)
                .exchange()
                .expectStatus().is5xxServerError();
    }
}

