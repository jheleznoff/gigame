package ru.sber.cs.ai.gigame.service;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.codec.multipart.FilePart;
import org.springframework.test.util.ReflectionTestUtils;
import ru.sber.cs.ai.gigame.dto.kb.KBDocumentResponse;
import ru.sber.cs.ai.gigame.dto.kb.KBResponse;
import ru.sber.cs.ai.gigame.exception.NotFoundException;
import ru.sber.cs.ai.gigame.model.Document;
import ru.sber.cs.ai.gigame.model.KBDocument;
import ru.sber.cs.ai.gigame.model.KnowledgeBase;
import ru.sber.cs.ai.gigame.repository.DocumentRepository;
import ru.sber.cs.ai.gigame.repository.KBDocumentRepository;
import ru.sber.cs.ai.gigame.repository.KnowledgeBaseRepository;

import java.time.OffsetDateTime;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class KBServiceTest {

    @Mock
    private KnowledgeBaseRepository knowledgeBaseRepository;

    @Mock
    private KBDocumentRepository kbDocumentRepository;

    @Mock
    private DocumentRepository documentRepository;

    @Mock
    private DocumentService documentService;

    @Mock
    private EmbeddingService embeddingService;

    @Mock
    private DocumentIndexService indexService;

    @InjectMocks
    private KBService kbService;

    @Captor
    private ArgumentCaptor<KnowledgeBase> kbCaptor;

    private UUID userId;
    private UUID kbId;
    private KnowledgeBase knowledgeBase;
    private Document document;

    @BeforeEach
    void setUp() {
        userId = UUID.randomUUID();
        kbId = UUID.randomUUID();
        knowledgeBase = new KnowledgeBase();
        knowledgeBase.setId(kbId);
        knowledgeBase.setUserId(userId.toString());
        knowledgeBase.setName("Test KB");
        knowledgeBase.setDescription("Description");

        document = new Document();
        document.setId(UUID.randomUUID());
        document.setFilename("test.pdf");
        document.setContentType("pdf");
        document.setSizeBytes(1024);
        document.setExtractedText("test content");
        document.setUserId(userId.toString());

        ReflectionTestUtils.setField(documentService, "charLimit", 12000);
    }

    // -------------------------------------------------------------------------
    // Шаринг: общие базы знаний
    // -------------------------------------------------------------------------

    @Test
    void testGetKnowledgeBase_sharedKb_accessibleToOtherUser() {
        knowledgeBase.setShared(true);
        when(knowledgeBaseRepository.findById(any())).thenReturn(Optional.of(knowledgeBase));
        when(kbDocumentRepository.findByKnowledgeBaseIdWithDocument(any())).thenReturn(List.of());

        var result = kbService.getKnowledgeBase("OTHER1", kbId);

        assertNotNull(result);
        assertEquals(true, result.shared());
        assertEquals(false, result.isOwner());
    }

    @Test
    void testGetKnowledgeBase_privateKb_deniedToOtherUser() {
        when(knowledgeBaseRepository.findById(any())).thenReturn(Optional.of(knowledgeBase));

        assertThrows(ru.sber.cs.ai.gigame.exception.AccessDeniedException.class,
                () -> kbService.getKnowledgeBase("OTHER1", kbId));
    }

    @Test
    void testUpdateKnowledgeBase_sharedKb_deniedToNonOwner() {
        knowledgeBase.setShared(true);
        when(knowledgeBaseRepository.findById(any())).thenReturn(Optional.of(knowledgeBase));

        assertThrows(ru.sber.cs.ai.gigame.exception.AccessDeniedException.class,
                () -> kbService.updateKnowledgeBase("OTHER1", kbId, "hacked", null, null));
    }

    @Test
    void testUpdateKnowledgeBase_ownerTogglesShared() {
        when(knowledgeBaseRepository.findById(any())).thenReturn(Optional.of(knowledgeBase));
        when(knowledgeBaseRepository.save(any())).thenAnswer(inv -> inv.getArgument(0));

        KBResponse result = kbService.updateKnowledgeBase(userId.toString(), kbId, null, null, true);

        assertNotNull(result);
        assertEquals(true, result.shared());
        assertEquals(true, knowledgeBase.isShared());
    }

    @Test
    void testGetDocumentView_owner() {
        when(documentRepository.findById(any())).thenReturn(Optional.of(document));

        var result = kbService.getDocumentView(userId.toString(), document.getId());

        assertNotNull(result);
        assertEquals("test.pdf", result.filename());
        assertEquals("test content", result.extractedText());
    }

    @Test
    void testGetDocumentView_viaSharedKb() {
        knowledgeBase.setShared(true);
        KBDocument link = new KBDocument();
        link.setKnowledgeBase(knowledgeBase);
        link.setDocumentId(document.getId());
        when(documentRepository.findById(any())).thenReturn(Optional.of(document));
        when(kbDocumentRepository.findByDocumentIdWithKnowledgeBase(any())).thenReturn(List.of(link));

        var result = kbService.getDocumentView("OTHER1", document.getId());

        assertNotNull(result);
        assertEquals("test.pdf", result.filename());
    }

    @Test
    void testGetDocumentView_denied_whenNoAccessibleKb() {
        KBDocument link = new KBDocument();
        link.setKnowledgeBase(knowledgeBase); // личная база другого пользователя
        link.setDocumentId(document.getId());
        when(documentRepository.findById(any())).thenReturn(Optional.of(document));
        when(kbDocumentRepository.findByDocumentIdWithKnowledgeBase(any())).thenReturn(List.of(link));

        assertThrows(ru.sber.cs.ai.gigame.exception.AccessDeniedException.class,
                () -> kbService.getDocumentView("OTHER1", document.getId()));
    }

    @Test
    void testGetKnowledgeBases_withSearch() {
        when(knowledgeBaseRepository.searchAccessible(anyString(), any()))
                .thenReturn(List.of(knowledgeBase));

        List<KBResponse> result = kbService.getKnowledgeBases(userId.toString(), "test");

        assertNotNull(result);
        assertEquals(1, result.size());
        verify(knowledgeBaseRepository).searchAccessible(userId.toString(), "test");
    }

    @Test
    void testGetKnowledgeBases_withoutSearch() {
        when(knowledgeBaseRepository.findByUserIdOrSharedTrueOrderByUpdatedAtDesc(anyString()))
                .thenReturn(List.of(knowledgeBase));

        List<KBResponse> result = kbService.getKnowledgeBases(userId.toString(), null);

        assertNotNull(result);
        assertEquals(1, result.size());
        verify(knowledgeBaseRepository).findByUserIdOrSharedTrueOrderByUpdatedAtDesc(userId.toString());
    }

    @Test
    void testGetKnowledgeBase_withExistingKB() {
        when(knowledgeBaseRepository.findById(any())).thenReturn(Optional.of(knowledgeBase));
        when(kbDocumentRepository.findByKnowledgeBaseIdWithDocument(any()))
                .thenReturn(List.of());

        ru.sber.cs.ai.gigame.dto.kb.KBDetailResponse result = kbService.getKnowledgeBase(userId.toString(), kbId);

        assertNotNull(result);
        assertEquals("Test KB", result.name());
        assertEquals("Description", result.description());
    }

    @Test
    void testGetKnowledgeBase_withNonExistingKB_throwsNotFoundException() {
        when(knowledgeBaseRepository.findById(any())).thenReturn(Optional.empty());
        var userIdStr = userId.toString();
        var uuid = UUID.randomUUID();
        assertThrows(NotFoundException.class,
                () -> kbService.getKnowledgeBase(userIdStr, uuid));
    }

    @Test
    void testCreateKnowledgeBase() {
        when(knowledgeBaseRepository.save(any())).thenAnswer(inv -> inv.getArgument(0));

        KBResponse result = kbService.createKnowledgeBase(userId.toString(), "Test KB", "Description", null);

        assertNotNull(result);
        verify(knowledgeBaseRepository).save(kbCaptor.capture());
        assertEquals("Test KB", kbCaptor.getValue().getName());
        assertEquals("Description", kbCaptor.getValue().getDescription());
        assertEquals(userId.toString(), kbCaptor.getValue().getUserId());
    }

    @Test
    void testCreateKnowledgeBase_withNullDescription() {
        when(knowledgeBaseRepository.save(any())).thenAnswer(inv -> inv.getArgument(0));

        KBResponse result = kbService.createKnowledgeBase(userId.toString(), "Test KB", null, null);

        assertNotNull(result);
        verify(knowledgeBaseRepository).save(kbCaptor.capture());
        assertEquals("Test KB", kbCaptor.getValue().getName());
        assertNull(kbCaptor.getValue().getDescription());
    }

    @Test
    void testUpdateKnowledgeBase_withValidName() {
        when(knowledgeBaseRepository.findById(any())).thenReturn(Optional.of(knowledgeBase));
        when(knowledgeBaseRepository.save(any())).thenAnswer(inv -> inv.getArgument(0));

        KBResponse result = kbService.updateKnowledgeBase(userId.toString(), kbId, "New Name", null, null);

        assertNotNull(result);
        assertEquals("New Name", knowledgeBase.getName());
    }

    @Test
    void testUpdateKnowledgeBase_withNonExistingKB_throwsNotFoundException() {
        when(knowledgeBaseRepository.findById(any())).thenReturn(Optional.empty());
        var userIdStr = userId.toString();
        var uuid = UUID.randomUUID();
        assertThrows(NotFoundException.class,
                () -> kbService.updateKnowledgeBase(userIdStr, uuid, "New Name", null, null));
    }

    @Test
    void testUpdateKnowledgeBase_withValidDescription() {
        when(knowledgeBaseRepository.findById(any())).thenReturn(Optional.of(knowledgeBase));
        when(knowledgeBaseRepository.save(any())).thenAnswer(inv -> inv.getArgument(0));

        KBResponse result = kbService.updateKnowledgeBase(userId.toString(), kbId, null, "New Description", null);

        assertNotNull(result);
        assertEquals("New Description", knowledgeBase.getDescription());
    }

    @Test
    void testUpdateKnowledgeBase_withBothParameters() {
        when(knowledgeBaseRepository.findById(any())).thenReturn(Optional.of(knowledgeBase));
        when(knowledgeBaseRepository.save(any())).thenAnswer(inv -> inv.getArgument(0));

        KBResponse result = kbService.updateKnowledgeBase(userId.toString(), kbId, "New Name", "New Description", null);

        assertNotNull(result);
        assertEquals("New Name", knowledgeBase.getName());
        assertEquals("New Description", knowledgeBase.getDescription());
    }

    @Test
    void testDeleteKnowledgeBase_withExistingKB() {
        when(knowledgeBaseRepository.findById(any())).thenReturn(Optional.of(knowledgeBase));

        assertDoesNotThrow(() -> kbService.deleteKnowledgeBase(userId.toString(), kbId));

        verify(embeddingService).deleteKBCollection(kbId);
        verify(knowledgeBaseRepository).delete(knowledgeBase);
    }

    @Test
    void testDeleteKnowledgeBase_withNonExistingKB_throwsNotFoundException() {
        when(knowledgeBaseRepository.findById(any())).thenReturn(Optional.empty());
        var userIdStr = userId.toString();
        var uuid = UUID.randomUUID();
        assertThrows(NotFoundException.class,
                () -> kbService.deleteKnowledgeBase(userIdStr, uuid));
    }

    @Test
    void testAddDocumentToKB() {
        when(knowledgeBaseRepository.findById(any())).thenReturn(Optional.of(knowledgeBase));
        when(documentService.uploadDocument(any(), eq(userId.toString())))
                .thenReturn(new DocumentService.DocumentResponse(
                        document.getId(), "test.pdf", "pdf", 1024, 500, "", OffsetDateTime.now(), OffsetDateTime.now()));
        when(documentRepository.findById(any())).thenReturn(Optional.of(document));
        doAnswer(inv -> {
            KBDocument kbDoc = inv.getArgument(0);
            kbDoc.setId(UUID.randomUUID());
            return kbDoc;
        }).when(kbDocumentRepository).save(any());

        FilePart file = mock(FilePart.class);

        KBDocumentResponse result = kbService.addDocumentToKB(userId.toString(), kbId, file);

        assertNotNull(result);
        verify(indexService).indexDocumentAsync(eq(kbId), eq(document.getId()), any());
    }

    @Test
    void testRemoveDocumentFromKB_withExistingKBDocument() {
        var kb = new KnowledgeBase();
        UUID docId = UUID.randomUUID();
        KBDocument kbDoc = new KBDocument();
        kbDoc.setKnowledgeBase(kb);
        kbDoc.setDocumentId(docId);
        kbDoc.setDocument(document);

        when(kbDocumentRepository.findByKnowledgeBaseIdAndDocumentId(any(), any()))
                .thenReturn(Optional.of(kbDoc));
        when(knowledgeBaseRepository.findById(any())).thenReturn(Optional.of(knowledgeBase));

        assertDoesNotThrow(() -> kbService.removeDocumentFromKB(userId.toString(), kbId, docId));

        verify(embeddingService).deleteKBDocumentChunks(kbId, docId);
        verify(kbDocumentRepository).delete(kbDoc);
    }

    @Test
    void testRemoveDocumentFromKB_withNonExistingKBDocument_throwsNotFoundException() {
        UUID docId = UUID.randomUUID();

        lenient().when(kbDocumentRepository.findByKnowledgeBaseIdAndDocumentId(any(), any()))
                .thenReturn(Optional.empty());
        var userIdStr = userId.toString();
        assertThrows(NotFoundException.class,
                () -> kbService.removeDocumentFromKB(userIdStr, kbId, docId));
    }
}
