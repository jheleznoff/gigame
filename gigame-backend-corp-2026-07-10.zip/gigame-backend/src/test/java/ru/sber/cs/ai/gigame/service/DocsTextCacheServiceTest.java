package ru.sber.cs.ai.gigame.service;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Тест для {@link DocsTextCacheService}.
 * <p>
 * Проверяет базовые операции кэширования текстов документов: сохранение,
 * получение, очистка кэша для отдельного диалога/сценария и всего кэша.
 */
@ExtendWith(MockitoExtension.class)
class DocsTextCacheServiceTest {

    private DocsTextCacheService cacheService;

    private UUID id;
    private List<String> documentTexts;
    private List<String> fileNames;
    private List<String> docIds;

    @BeforeEach
    void setUp() {
        cacheService = new DocsTextCacheService();
        id = UUID.randomUUID();
        documentTexts = List.of("текст документа 1", "текст документа 2");
        fileNames = List.of("file1.pdf", "file2.docx");
        docIds = List.of("doc-001", "doc-002");
    }

    @Test
    void testCacheDocumentTexts_shouldStoreAndReturnData() {
        cacheService.cacheDocumentTexts(id, documentTexts, fileNames, docIds);

        assertEquals(documentTexts, cacheService.getCachedDocumentTexts(id));
        assertEquals(fileNames, cacheService.getCachedFileNames(id));
        assertEquals(docIds, cacheService.getCachedDocIds(id));
    }

    @Test
    void testGetCachedDocumentTexts_withEmptyCache_shouldReturnEmptyList() {
        List<String> result = cacheService.getCachedDocumentTexts(id);
        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    @Test
    void testGetCachedFileNames_withEmptyCache_shouldReturnEmptyString() {
        var result = cacheService.getCachedFileNames(id);
        assertNotNull(result);
        assertEquals(List.of(), result);
    }

    @Test
    void testGetCachedDocIds_withEmptyCache_shouldReturnEmptyList() {
        List<String> result = cacheService.getCachedDocIds(id);
        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    @Test
    void testClearCache_shouldRemoveOnlySpecifiedEntry() {
        UUID otherId = UUID.randomUUID();
        List<String> otherTexts = List.of("другой текст");

        cacheService.cacheDocumentTexts(id, documentTexts, fileNames, docIds);
        cacheService.cacheDocumentTexts(otherId, otherTexts, List.of("other.pdf"), List.of("doc-003"));

        cacheService.clearCache(id);

        assertTrue(cacheService.getCachedDocumentTexts(id).isEmpty());
        assertEquals(List.of(), cacheService.getCachedFileNames(id));
        assertTrue(cacheService.getCachedDocIds(id).isEmpty());

        // otherId должен остаться в кэше
        assertEquals(otherTexts, cacheService.getCachedDocumentTexts(otherId));
    }

    @Test
    void testClearAllCache_shouldRemoveAllEntries() {
        cacheService.cacheDocumentTexts(id, documentTexts, fileNames, docIds);

        cacheService.clearAllCache();

        assertTrue(cacheService.getCachedDocumentTexts(id).isEmpty());
        assertEquals(List.of(), cacheService.getCachedFileNames(id));
        assertTrue(cacheService.getCachedDocIds(id).isEmpty());
    }

    @Test
    void testCacheDocumentTexts_shouldOverwriteExistingEntry() {
        List<String> updatedTexts = List.of("обновленный текст");
        List<String> updatedFileNames = List.of("new.pdf");
        List<String> updatedDocIds = List.of("doc-003");

        cacheService.cacheDocumentTexts(id, documentTexts, fileNames, docIds);
        cacheService.cacheDocumentTexts(id, updatedTexts, updatedFileNames, updatedDocIds);

        assertEquals(updatedTexts, cacheService.getCachedDocumentTexts(id));
        assertEquals(updatedFileNames, cacheService.getCachedFileNames(id));
        assertEquals(updatedDocIds, cacheService.getCachedDocIds(id));
    }
}