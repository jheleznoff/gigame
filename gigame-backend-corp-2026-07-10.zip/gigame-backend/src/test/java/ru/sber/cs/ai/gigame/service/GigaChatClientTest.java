package ru.sber.cs.ai.gigame.service;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.ai.chat.messages.AssistantMessage;
import org.springframework.ai.chat.model.ChatModel;
import org.springframework.ai.chat.model.ChatResponse;
import org.springframework.ai.chat.model.Generation;
import org.springframework.ai.chat.prompt.Prompt;
import org.springframework.ai.embedding.Embedding;
import org.springframework.ai.embedding.EmbeddingModel;
import org.springframework.ai.embedding.EmbeddingRequest;
import org.springframework.ai.embedding.EmbeddingResponse;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class GigaChatClientTest {

    @Mock
    private ChatModel chatModel;

    @Mock
    private EmbeddingModel embeddingModel;

    private GigaChatClient gigaChatClient;

    @BeforeEach
    void setUp() {
        gigaChatClient = new GigaChatClient(chatModel, embeddingModel);
        ReflectionTestUtils.setField(gigaChatClient, "textMaxLength", 800);
        ReflectionTestUtils.setField(gigaChatClient, "batchSize", 50);
    }

    @Test
    void testChatCompletion() {
        AssistantMessage assistantMsg = new AssistantMessage("");
        Generation generation = new Generation(assistantMsg);
        ChatResponse chatResponse = new ChatResponse(List.of(generation));
        when(chatModel.call(any(Prompt.class))).thenReturn(chatResponse);
        List<Map<String, String>> messages = List.of(
                Map.of("role", "user", "content", "Hello"),
                Map.of("role", "system", "content", "Ты помогаешь людям"),
                Map.of("role", "assistant", "content", "Привет")
        );
        assertDoesNotThrow(() -> gigaChatClient.chatCompletion(messages));
    }

    @Test
    void testChatCompletionStream() {
        AssistantMessage assistantMsg = new AssistantMessage("");
        Generation generation = new Generation(assistantMsg);
        ChatResponse chatResponse = new ChatResponse(List.of(generation));
        when(chatModel.call(any(Prompt.class))).thenReturn(chatResponse);

        List<Map<String, String>> messages = List.of(
                Map.of("role", "user", "content", "Hello")
        );

        var result = gigaChatClient.chatCompletionStream(messages);

        assertNotNull(result);
        assertDoesNotThrow(() -> result.collectList().block());
    }

    @Test
    void testGetEmbeddings() {
        EmbeddingResponse embeddingResponse = mock(EmbeddingResponse.class);
        when(embeddingResponse.getResults()).thenReturn(List.of());

        when(embeddingModel.call(any(EmbeddingRequest.class))).thenReturn(embeddingResponse);

        List<String> texts = List.of("Test text");

        assertDoesNotThrow(() -> {
            List<float[]> result = gigaChatClient.getEmbeddings(texts);
            assertNotNull(result);
            assertTrue(result.isEmpty());
        });
    }

    @Test
    void testGetEmbeddings_withMultipleBatches() {
        var f = new float[4];
        f[0] = 10.10f;
        f[1] = 30.3f;
        f[2] = 40.60f;
        f[3] = 77.50f;
        var embedding = new Embedding(f, 4);
        EmbeddingResponse embeddingResponse = new EmbeddingResponse(List.of(embedding));
        when(embeddingModel.call(any(EmbeddingRequest.class))).thenReturn(embeddingResponse);

        // Create 100 texts to test batching (50 texts per batch, 2 batches)
        List<String> texts = new ArrayList<>(Collections.nCopies(100, "Это тестовая строка"));
        assertDoesNotThrow(() -> {
            List<float[]> result = gigaChatClient.getEmbeddings(texts);
            assertNotNull(result);
            assertEquals(2, result.size());
        });
    }

    @Test
    void testGetEmbeddings_truncatesLongTexts() {
        var f = new float[4];
        f[0] = 10.10f;
        f[1] = 30.3f;
        f[2] = 40.60f;
        f[3] = 77.50f;
        var embedding = new Embedding(f, 4);
        EmbeddingResponse embeddingResponse = new EmbeddingResponse(List.of(embedding));

        when(embeddingModel.call(any(EmbeddingRequest.class))).thenReturn(embeddingResponse);

        String longText = "A".repeat(2000);
        List<String> texts = List.of(longText);

        assertDoesNotThrow(() -> {
            List<float[]> result = gigaChatClient.getEmbeddings(texts);
            assertNotNull(result);
            assertEquals(1, result.size());
        });
    }

    @Test
    void testGetEmbeddings_emptyList() {
        var f = new float[0];
        var embedding = new Embedding(f, 0);
        EmbeddingResponse embeddingResponse = new EmbeddingResponse(List.of(embedding));

        lenient().when(embeddingModel.call(any(EmbeddingRequest.class))).thenReturn(embeddingResponse);

        List<String> texts = List.of();

        List<float[]> result = gigaChatClient.getEmbeddings(texts);

        assertNotNull(result);
        assertTrue(result.isEmpty());
    }
}
