package ru.sber.cs.ai.gigame.service.scenario.executor;

import org.junit.jupiter.api.Test;
import org.springframework.http.codec.ServerSentEvent;
import reactor.core.publisher.FluxSink;
import ru.sber.cs.ai.gigame.dto.scenario.graph.EdgeDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.EdgeDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.GraphDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.PositionDto;
import ru.sber.cs.ai.gigame.exception.ScenarioException;
import ru.sber.cs.ai.gigame.service.scenario.enums.ScenarioNodeType;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunGraph;

import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.mock;

/**
 * Тесты узла «Агрегация»: детерминированное суммирование без LLM.
 */
class ScenarioExecutorAggregateNodeTest {

    private static final String ROWS_JSON = """
            Результат извлечения:
            [
              {"договор": "3730725", "акт": "SSBRF219/20", "зачтено": "да", "сумма": "4210140.00"},
              {"договор": "3730725", "акт": "SSBRF123/20", "зачтено": "да", "сумма": "7840320"},
              {"договор": "4192652", "акт": "SSBRF220077", "зачтено": "да", "сумма": "4214370,6"},
              {"договор": "4192652", "акт": "SSBRF239558", "зачтено": "нет", "сумма": "1858566.6"},
              {"договор": "50003501273", "акт": "BUH-48626", "зачтено": "да", "сумма": "требуется ручная проверка"}
            ]
            """;

    @SuppressWarnings("unchecked")
    private final FluxSink<ServerSentEvent<Map<String, Object>>> sink = mock(FluxSink.class);

    private static ScenarioRunGraph graphWithRules(String rules) {
        var aggDto = NodeDto.builder()
                .id("agg-1")
                .type(ScenarioNodeType.AGGREGATE_NODE.toString())
                .data(NodeDataDto.builder().label("Сумма опыта").rules(rules).build())
                .position(new PositionDto(100, 0))
                .build();
        var outDto = NodeDto.builder()
                .id("out-1")
                .type(ScenarioNodeType.OUTPUT_NODE.toString())
                .data(NodeDataDto.builder().label("Выход").build())
                .position(new PositionDto(200, 0))
                .build();
        var gd = new GraphDataDto(List.of(aggDto, outDto),
                List.of(new EdgeDto("e1", "agg-1", "out-1", new EdgeDataDto(null))));
        return new ScenarioRunGraph(gd);
    }

    @Test
    void aggregate_sumsFilteredRowsByGroupAndChecksThreshold() {
        String rules = """
                {"суммировать": "сумма",
                 "группировать_по": "договор",
                 "фильтр": {"поле": "зачтено", "равно": "да"},
                 "порог": {"значение": 16000000, "оператор": "greater_or_equal", "метка": "50% НМЦ"}}
                """;
        var graph = graphWithRules(rules);
        var node = graph.getNodeMap().get("agg-1");
        node.getInput().add(ROWS_JSON);

        String result = new ScenarioExecutorAggregateNode(node).execute(sink);

        // 4210140 + 7840320 + 4214370.6 = 16264830.6 (строка «нет» и нечисловая — вне суммы)
        assertTrue(result.contains("ИТОГО: 16264830.6"));
        assertTrue(result.contains("СООТВЕТСТВУЕТ"));
        assertFalse(result.contains("НЕ СООТВЕТСТВУЕТ"));
        // группы: 3730725 = 4210140 + 7840320; 4192652 = 4214370.6
        assertTrue(result.contains("12050460"));
        assertTrue(result.contains("4214370.6"));
        // предупреждения: отфильтрованные и нечисловые строки
        assertTrue(result.contains("⚠️ Предупреждения"));
        assertTrue(result.contains("отфильтровано строк"));
        assertTrue(result.contains("«50003501273»")); // строка с нечисловой суммой — в предупреждениях
        // JSON-блок для следующих узлов
        assertTrue(result.contains("===РЕЗУЛЬТАТЫ РАСЧЁТА==="));
        assertTrue(result.contains("\"соответствует\":\"да\"")
                || result.contains("\"соответствует\" : \"да\""));
        // выход передан ребёнку
        var child = graph.getNodeMap().get("out-1");
        assertFalse(child.getInput().isEmpty());
        assertTrue(child.getInput().get(0).contains("Сумма опыта"));
    }

    @Test
    void aggregate_thresholdNotMet() {
        String rules = """
                {"суммировать": "сумма",
                 "порог": {"значение": 999999999, "оператор": "greater_or_equal"}}
                """;
        var graph = graphWithRules(rules);
        var node = graph.getNodeMap().get("agg-1");
        node.getInput().add(ROWS_JSON);

        String result = new ScenarioExecutorAggregateNode(node).execute(sink);

        assertTrue(result.contains("НЕ СООТВЕТСТВУЕТ"));
    }

    @Test
    void aggregate_deterministic_sameInputSameOutput() {
        String rules = "{\"суммировать\": \"сумма\", \"группировать_по\": \"договор\"}";
        var graph1 = graphWithRules(rules);
        var node1 = graph1.getNodeMap().get("agg-1");
        node1.getInput().add(ROWS_JSON);
        var graph2 = graphWithRules(rules);
        var node2 = graph2.getNodeMap().get("agg-1");
        node2.getInput().add(ROWS_JSON);

        String r1 = new ScenarioExecutorAggregateNode(node1).execute(sink);
        String r2 = new ScenarioExecutorAggregateNode(node2).execute(sink);

        assertEquals(r1, r2);
    }

    @Test
    void aggregate_noJsonArrayInInput_throws() {
        var graph = graphWithRules("{\"суммировать\": \"сумма\"}");
        var node = graph.getNodeMap().get("agg-1");
        node.getInput().add("просто текст без данных");
        var executor = new ScenarioExecutorAggregateNode(node);

        assertThrows(ScenarioException.class, () -> executor.execute(sink));
    }

    @Test
    void aggregate_missingConfig_throws() {
        var graph = graphWithRules("");
        var node = graph.getNodeMap().get("agg-1");
        node.getInput().add(ROWS_JSON);
        var executor = new ScenarioExecutorAggregateNode(node);

        assertThrows(ScenarioException.class, () -> executor.execute(sink));
    }

    @Test
    void aggregate_fuzzyFieldMatching() {
        // ключ в данных «Сумма зачтено, руб.» находится по конфигу «сумма_зачтено»
        String rules = "{\"суммировать\": \"сумма_зачтено\"}";
        var graph = graphWithRules(rules);
        var node = graph.getNodeMap().get("agg-1");
        node.getInput().add("[{\"договор\": \"1\", \"Сумма зачтено, руб.\": 100}, "
                + "{\"договор\": \"2\", \"Сумма зачтено, руб.\": 250.5}]");

        String result = new ScenarioExecutorAggregateNode(node).execute(sink);

        assertTrue(result.contains("ИТОГО: 350.5"));
    }
}
