package ru.sber.cs.ai.gigame.utils;

import org.junit.jupiter.api.Test;
import org.springframework.core.io.buffer.DataBuffer;
import org.springframework.core.io.buffer.DefaultDataBuffer;
import org.springframework.core.io.buffer.DefaultDataBufferFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.codec.multipart.FilePart;
import reactor.core.publisher.Flux;
import ru.sber.cs.ai.gigame.exception.FileException;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

class FileUtilsTest {

    @Test
    void testToInputStream_withValidData() {
        String content = "Test content for file upload";
        byte[] bytes = content.getBytes();

        DefaultDataBuffer dataBuffer = DefaultDataBufferFactory.sharedInstance.wrap(bytes);
        Flux<DataBuffer> flux = Flux.just(dataBuffer);

        FilePart filePart = mock(FilePart.class);
        when(filePart.filename()).thenReturn("test.txt");
        when(filePart.name()).thenReturn("file");
        when(filePart.headers()).thenReturn(new org.springframework.http.HttpHeaders());
        when(filePart.content()).thenReturn(flux);

        var result = FileUtils.toInputStream(filePart);

        assertNotNull(result);
    }

    @Test
    void testDetectContentType_PDF() {
        String result = FileUtils.detectContentType("document.pdf");
        assertEquals("pdf", result);
    }

    @Test
    void testDetectContentType_DOCX() {
        String result = FileUtils.detectContentType("document.docx");
        assertEquals("docx", result);
    }

    @Test
    void testDetectContentType_XLSX() {
        String result = FileUtils.detectContentType("document.xlsx");
        assertEquals("xlsx", result);
    }

    @Test
    void testDetectContentType_XLS() {
        String result = FileUtils.detectContentType("document.xls");
        assertEquals("xls", result);
    }

    @Test
    void testDetectContentType_PPTX() {
        assertEquals("pptx", FileUtils.detectContentType("слайды.pptx"));
    }

    @Test
    void testDetectContentType_plainTextFormats() {
        assertEquals("txt", FileUtils.detectContentType("data.csv"));
        assertEquals("txt", FileUtils.detectContentType("data.tsv"));
        assertEquals("txt", FileUtils.detectContentType("readme.md"));
        assertEquals("txt", FileUtils.detectContentType("config.json"));
        assertEquals("txt", FileUtils.detectContentType("app.yaml"));
        assertEquals("txt", FileUtils.detectContentType("app.yml"));
        assertEquals("txt", FileUtils.detectContentType("server.log"));
    }

    @Test
    void testDetectContentType_TXT() {
        String result = FileUtils.detectContentType("document.txt");
        assertEquals("txt", result);
    }

    @Test
    void testDetectContentType_unsupportedExtension_throwsFileException() {
        assertThrows(FileException.class,
                () -> FileUtils.detectContentType("document.xyz"));
    }

    @Test
    void testDetectContentType_emptyExtension_throwsFileException() {
        assertThrows(FileException.class,
                () -> FileUtils.detectContentType("document"));
    }

    @Test
    void testGetFilenamesFromFileParts_withContentDispositionHeader() {
        var filePart1 = mock(FilePart.class);
        var filePart2 = mock(FilePart.class);

        var headers1 = new HttpHeaders();
        headers1.add(HttpHeaders.CONTENT_DISPOSITION, "form-data; name=\"file\"; filename=\"report.pdf\"");
        when(filePart1.headers()).thenReturn(headers1);
        when(filePart1.filename()).thenReturn("report.pdf");

        var headers2 = new HttpHeaders();
        headers2.add(HttpHeaders.CONTENT_DISPOSITION, "form-data; name=\"file\"; filename=\"doc.docx\"");
        when(filePart2.headers()).thenReturn(headers2);
        when(filePart2.filename()).thenReturn("\"doc.docx\"");

        List<String> result = FileUtils.getFilenamesFromFileParts(List.of(filePart1, filePart2));

        assertEquals(List.of("report.pdf", "doc.docx"), result);
    }

    @Test
    void testGetFilenamesFromFileParts_withoutContentDisposition_fallsBackToFilename() {
        var filePart = mock(FilePart.class);

        var headers = new HttpHeaders();
        when(filePart.headers()).thenReturn(headers);
        when(filePart.filename()).thenReturn("document.pdf");

        List<String> result = FileUtils.getFilenamesFromFileParts(List.of(filePart));

        assertEquals(List.of("document.pdf"), result);
    }

    @Test
    void testGetFilenamesFromFileParts_withBlankDisposition_fallsBackToFilename() {
        var filePart = mock(FilePart.class);

        var headers = new HttpHeaders();
        headers.add(HttpHeaders.CONTENT_DISPOSITION, "");
        when(filePart.headers()).thenReturn(headers);
        when(filePart.filename()).thenReturn("test.txt");

        List<String> result = FileUtils.getFilenamesFromFileParts(List.of(filePart));

        assertEquals(List.of("test.txt"), result);
    }

    @Test
    void testGetFilenamesFromFileParts_emptyList() {
        List<String> result = FileUtils.getFilenamesFromFileParts(List.of());

        assertEquals(List.of(), result);
    }
}