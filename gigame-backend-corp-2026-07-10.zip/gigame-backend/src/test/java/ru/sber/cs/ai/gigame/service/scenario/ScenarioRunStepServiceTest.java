package ru.sber.cs.ai.gigame.service.scenario;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import ru.sber.cs.ai.gigame.model.ScenarioRunStep;
import ru.sber.cs.ai.gigame.repository.ScenarioRunStepRepository;
import ru.sber.cs.ai.gigame.service.scenario.enums.ScenarioNodeType;
import ru.sber.cs.ai.gigame.service.scenario.enums.ScenarioStatus;

import java.util.List;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ScenarioRunStepServiceTest {

    @Mock
    private ScenarioRunStepRepository stepRepository;

    @InjectMocks
    private ScenarioRunStepService stepService;

    @Captor
    private ArgumentCaptor<ScenarioRunStep> stepCaptor;

    private UUID runId;
    private UUID stepId;
    private String nodeId;
    private ScenarioRunStep step;

    @BeforeEach
    void setUp() {
        runId = UUID.randomUUID();
        stepId = UUID.randomUUID();
        nodeId = "node-1";

        step = new ScenarioRunStep();
        step.setId(stepId);
        step.setRunId(runId);
    }

    // -------------------------------------------------------------------------
    // setScenarioStepStatusRunning
    // -------------------------------------------------------------------------

    @Test
    void testSetScenarioStepStatusRunning() {
        when(stepRepository.save(any())).thenReturn(step);

        ScenarioRunStep result = stepService.setScenarioStepStatusRunning(runId, nodeId, ScenarioNodeType.INPUT_NODE);

        assertNotNull(result);
        assertEquals(step, result);
        verify(stepRepository).save(stepCaptor.capture());

        ScenarioRunStep captured = stepCaptor.getValue();
        assertEquals(runId, captured.getRunId());
        assertEquals(nodeId, captured.getNodeId());
        assertEquals(ScenarioNodeType.INPUT_NODE.toString(), captured.getNodeType());
        assertEquals(ScenarioStatus.RUNNING.getValue(), captured.getStatus());
        assertNotNull(captured.getStartedAt());
        assertNull(captured.getCompletedAt());
    }

    @Test
    void testSetScenarioStepStatusRunning_setsCorrectNodeType() {
        when(stepRepository.save(any())).thenReturn(step);

        stepService.setScenarioStepStatusRunning(runId, nodeId, ScenarioNodeType.PROCESSING_NODE);

        verify(stepRepository).save(stepCaptor.capture());
        assertEquals("processing", stepCaptor.getValue().getNodeType());
    }

    // -------------------------------------------------------------------------
    // setScenarioStepStatusCompleted
    // -------------------------------------------------------------------------

    @Test
    void testSetScenarioStepStatusCompleted() {
        when(stepRepository.save(any())).thenReturn(step);

        String previousOutput = "Previous result";
        String documentsText = "Document content";
        String output = "Final output";
        String prompt = "System prompt";

        ScenarioRunStep result = stepService.setScenarioStepStatusCompleted(
                step, previousOutput, documentsText, output, prompt);

        assertNotNull(result);
        assertEquals(step, result);
        verify(stepRepository).save(stepCaptor.capture());

        ScenarioRunStep captured = stepCaptor.getValue();
        assertEquals(ScenarioStatus.COMPLETED.getValue(), captured.getStatus());
        assertNotNull(captured.getCompletedAt());

        // Check input data
        var inputData = captured.getInputData();
        assertNotNull(inputData);
        assertEquals(documentsText, inputData.get("documents_text"));
        assertEquals(previousOutput, inputData.get("previous_output"));

        // Check output data
        var outputData = captured.getOutputData();
        assertNotNull(outputData);
        assertEquals(output, outputData.get("result"));

        assertEquals(prompt, captured.getPromptUsed());
    }

    @Test
    void testSetScenarioStepStatusCompleted_withEmptyStrings() {
        when(stepRepository.save(any())).thenReturn(step);

        stepService.setScenarioStepStatusCompleted(step, "", "", "", "");

        verify(stepRepository).save(stepCaptor.capture());
        ScenarioRunStep captured = stepCaptor.getValue();

        assertEquals(ScenarioStatus.COMPLETED.getValue(), captured.getStatus());
    }

    @Test
    void testSetScenarioStepStatusCompleted_preservesStepId() {
        when(stepRepository.save(any())).thenReturn(step);

        stepService.setScenarioStepStatusCompleted(step, "prev", "docs", "out", "prompt");

        verify(stepRepository).save(stepCaptor.capture());
        assertEquals(stepId, stepCaptor.getValue().getId());
    }

    // -------------------------------------------------------------------------
    // setScenarioStepStatusFailed
    // -------------------------------------------------------------------------

    @Test
    void testSetScenarioStepStatusFailed_withErrorMessage() {
        when(stepRepository.save(any())).thenReturn(step);

        ScenarioRunStep result = stepService.setScenarioStepStatusFailed(step, "Custom error message");

        assertNotNull(result);
        verify(stepRepository).save(stepCaptor.capture());

        ScenarioRunStep captured = stepCaptor.getValue();
        assertEquals(ScenarioStatus.FAILED.getValue(), captured.getStatus());
        assertNotNull(captured.getCompletedAt());

        var outputData = captured.getOutputData();
        assertNotNull(outputData);
        assertEquals("Custom error message", outputData.get("error"));
    }

    @Test
    void testSetScenarioStepStatusFailed_withNullMessage() {
        when(stepRepository.save(any())).thenReturn(step);

        ScenarioRunStep result = stepService.setScenarioStepStatusFailed(step, null);

        assertNotNull(result);
        verify(stepRepository).save(stepCaptor.capture());

        ScenarioRunStep captured = stepCaptor.getValue();
        assertEquals(ScenarioStatus.FAILED.getValue(), captured.getStatus());
        var outputData = captured.getOutputData();
        assertEquals("Неизвестная ошибка", outputData.get("error"));
    }

    @Test
    void testSetScenarioStepStatusFailed_withEmptyMessage() {
        when(stepRepository.save(any())).thenReturn(step);

        stepService.setScenarioStepStatusFailed(step, "");

        verify(stepRepository).save(stepCaptor.capture());
        ScenarioRunStep captured = stepCaptor.getValue();
        assertEquals("", captured.getOutputData().get("error"));
    }

    // -------------------------------------------------------------------------
    // Integration Tests
    // -------------------------------------------------------------------------

    @Test
    void testCompleteStepLifecycle() {
        // Step starts as running
        when(stepRepository.save(any())).thenReturn(step);
        stepService.setScenarioStepStatusRunning(runId, nodeId, ScenarioNodeType.INPUT_NODE);

        // Then completes
        when(stepRepository.save(any())).thenReturn(step);
        stepService.setScenarioStepStatusCompleted(step, "prev", "docs", "result", "prompt");

        // Verify two saves occurred
        verify(stepRepository, times(2)).save(stepCaptor.capture());

        // Get all captured steps
        List<ScenarioRunStep> allSteps = stepCaptor.getAllValues();
        assertEquals(2, allSteps.size());

        // First step should be running
        assertEquals(ScenarioStatus.RUNNING.getValue(), allSteps.get(0).getStatus());

        // Second step should be completed
        assertEquals(ScenarioStatus.COMPLETED.getValue(), allSteps.get(1).getStatus());
    }

    @Test
    void testFailedStepLifecycle() {
        // Step starts as running
        when(stepRepository.save(any())).thenReturn(step);
        stepService.setScenarioStepStatusRunning(runId, nodeId, ScenarioNodeType.PROCESSING_NODE);

        // Then fails
        when(stepRepository.save(any())).thenReturn(step);
        stepService.setScenarioStepStatusFailed(step, "Processing error");

        // Verify two saves occurred
        verify(stepRepository, times(2)).save(stepCaptor.capture());

        // Get all captured steps
        List<ScenarioRunStep> allSteps = stepCaptor.getAllValues();
        assertEquals(2, allSteps.size());

        // First step should be running
        assertEquals(ScenarioStatus.RUNNING.getValue(), allSteps.get(0).getStatus());

        // Second step should be failed
        assertEquals(ScenarioStatus.FAILED.getValue(), allSteps.get(1).getStatus());
        assertNotNull(allSteps.get(1).getCompletedAt());

        // Check error message in output data
        var outputData = allSteps.get(1).getOutputData();
        assertNotNull(outputData);
        assertEquals("Processing error", outputData.get("error"));
    }

    @Test
    void testMultipleSteps_sameRunId() {
        when(stepRepository.save(any())).thenReturn(step);

        stepService.setScenarioStepStatusRunning(runId, "node-1", ScenarioNodeType.INPUT_NODE);
        stepService.setScenarioStepStatusRunning(runId, "node-2", ScenarioNodeType.PROCESSING_NODE);

        // Verify save was called twice with argument capture
        verify(stepRepository, times(2)).save(stepCaptor.capture());

        // Both steps should have the same runId
        assertEquals(2, stepCaptor.getAllValues().size());
        for (ScenarioRunStep s : stepCaptor.getAllValues()) {
            assertEquals(runId, s.getRunId());
        }
    }

    @Test
    void testInputDataStructure() {
        when(stepRepository.save(any())).thenReturn(step);

        String documentsText = "Doc 1\nDoc 2";
        String previousOutput = "Previous result";

        stepService.setScenarioStepStatusCompleted(step, previousOutput, documentsText, "output", "prompt");

        verify(stepRepository).save(stepCaptor.capture());
        var inputData = stepCaptor.getValue().getInputData();

        assertTrue(inputData.containsKey("documents_text"));
        assertTrue(inputData.containsKey("previous_output"));
        assertEquals(documentsText, inputData.get("documents_text"));
        assertEquals(previousOutput, inputData.get("previous_output"));
    }

    @Test
    void testOutputDataStructure() {
        when(stepRepository.save(any())).thenReturn(step);

        String output = "Final answer";

        stepService.setScenarioStepStatusCompleted(step, "prev", "docs", output, "prompt");

        verify(stepRepository).save(stepCaptor.capture());
        var outputData = stepCaptor.getValue().getOutputData();

        assertTrue(outputData.containsKey("result"));
        assertEquals(output, outputData.get("result"));
    }

    @Test
    void testErrorDataStructure() {
        when(stepRepository.save(any())).thenReturn(step);

        String errorMsg = "Something went wrong";

        stepService.setScenarioStepStatusFailed(step, errorMsg);

        verify(stepRepository).save(stepCaptor.capture());
        var outputData = stepCaptor.getValue().getOutputData();

        assertTrue(outputData.containsKey("error"));
        assertEquals(errorMsg, outputData.get("error"));
    }
}
