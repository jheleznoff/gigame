package ru.sber.cs.ai.gigame.controller;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpEntity;
import org.springframework.http.MediaType;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.reactive.server.WebTestClient;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.reactive.function.BodyInserters;
import ru.sber.cs.ai.gigame.dto.scenario.ScenarioDetailResponse;
import ru.sber.cs.ai.gigame.dto.scenario.graph.GraphDataDto;
import ru.sber.cs.ai.gigame.exception.FileException;
import ru.sber.cs.ai.gigame.service.DocsTextCacheService;
import ru.sber.cs.ai.gigame.service.scenario.ScenarioEngine;
import ru.sber.cs.ai.gigame.service.scenario.ScenarioService;

import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

@WebFluxTest(controllers = ScenarioController.class)
@SuppressWarnings("unused")
class ScenarioControllerUploadFilesTest {

    @MockitoBean
    DocsTextCacheService docsTextCacheService;
    @Autowired
    private WebTestClient webClient;
    @MockitoBean
    private ScenarioService scenarioService;
    @MockitoBean
    private ScenarioEngine scenarioEngine;

    @Test
    void uploadFiles_ShouldProcessFilesAndCacheTexts() {
        // Given
        String userId = "USER123";
        UUID scenarioId = UUID.randomUUID();
        String filename = "test.txt";
        String fileText = "Текст из файла.";

        // Мокируем, что сценарий существует
        when(scenarioService.getScenario(userId, scenarioId))
                .thenReturn(new ScenarioDetailResponse(
                        scenarioId,
                        "Test Scenario",
                        "Description",
                        null,
                        null,
                        new GraphDataDto(List.of(), List.of())
                ));

        // Мокируем обработку документов
        when(scenarioService.getDocumentsText(any(), eq(null)))
                .thenReturn(List.of(fileText));

        // Подготовка multipart тела
        MultiValueMap<String, HttpEntity<?>> body = new LinkedMultiValueMap<>();
        ByteArrayResource resource = new ByteArrayResource(fileText.getBytes()) {
            @Override
            public String getFilename() {
                return filename;
            }
        };
        LinkedMultiValueMap<String, String> fileHeaders = new LinkedMultiValueMap<>();
        fileHeaders.add("Content-Type", "text/plain");
        body.add("files", new HttpEntity<>(resource, fileHeaders));

        // Мокируем кэширование
        doNothing().when(docsTextCacheService).cacheDocumentTexts(any(), any(), any(), any());

        // When & Then
        webClient.post()
                .uri("/api/scenarios/{id}/upload", scenarioId)
                .header("X-UserId", userId)
                .contentType(MediaType.MULTIPART_FORM_DATA)
                .body(BodyInserters.fromMultipartData(body))
                .exchange()
                .expectStatus().isOk();
    }

    @Test
    void uploadFiles_ShouldProcessMultipleFilesAndCacheTexts() {
        // Given
        String userId = "USER123";
        UUID scenarioId = UUID.randomUUID();
        String filename1 = "document1.txt";
        String fileText1 = "Текст из первого файла.";
        String filename2 = "document2.txt";
        String fileText2 = "Текст из второго файла.";

        // Мокируем, что сценарий существует
        when(scenarioService.getScenario(userId, scenarioId))
                .thenReturn(new ScenarioDetailResponse(
                        scenarioId,
                        "Test Scenario",
                        "Description",
                        null,
                        null,
                        new GraphDataDto(List.of(), List.of())
                ));

        // Мокируем обработку документов
        String combinedText = fileText1 + "\n---\n" + fileText2;
        when(scenarioService.getDocumentsText(any(), eq(null)))
                .thenReturn(List.of(combinedText));

        // Подготовка multipart тела с двумя файлами
        MultiValueMap<String, HttpEntity<?>> body = new LinkedMultiValueMap<>();

        ByteArrayResource resource1 = new ByteArrayResource(fileText1.getBytes()) {
            @Override
            public String getFilename() {
                return filename1;
            }
        };
        LinkedMultiValueMap<String, String> headers1 = new LinkedMultiValueMap<>();
        headers1.add("Content-Type", "text/plain");
        body.add("files", new HttpEntity<>(resource1, headers1));

        ByteArrayResource resource2 = new ByteArrayResource(fileText2.getBytes()) {
            @Override
            public String getFilename() {
                return filename2;
            }
        };
        LinkedMultiValueMap<String, String> headers2 = new LinkedMultiValueMap<>();
        headers2.add("Content-Type", "text/plain");
        body.add("files", new HttpEntity<>(resource2, headers2));

        // Мокируем кэширование
        doNothing().when(docsTextCacheService).cacheDocumentTexts(any(), any(), any(), any());

        // When & Then
        webClient.post()
                .uri("/api/scenarios/{id}/upload", scenarioId)
                .header("X-UserId", userId)
                .contentType(MediaType.MULTIPART_FORM_DATA)
                .body(BodyInserters.fromMultipartData(body))
                .exchange()
                .expectStatus().isOk();
    }

    @Test
    void uploadFiles_WithUnsupportedContentType_ShouldFailWithUnprocessableEntity() {
        // Given
        String userId = "USER123";
        UUID scenarioId = UUID.randomUUID();
        String filename = "test.xyz";
        String fileText = "Текст из файла.";

        // Мокируем, что сценарий существует
        when(scenarioService.getScenario(userId, scenarioId))
                .thenReturn(new ScenarioDetailResponse(
                        scenarioId,
                        "Test Scenario",
                        "Description",
                        null,
                        null,
                        new GraphDataDto(List.of(), List.of())
                ));

        // Мокируем вызов getDocuments для выброса исключения
        when(scenarioService.getDocuments(any(), any()))
                .thenThrow(new FileException("Не удалось обработать файл: " + filename));
        // Подготовка multipart тела
        MultiValueMap<String, HttpEntity<?>> body = new LinkedMultiValueMap<>();
        ByteArrayResource resource = new ByteArrayResource(fileText.getBytes()) {
            @Override
            public String getFilename() {
                return filename;
            }
        };
        LinkedMultiValueMap<String, String> fileHeaders = new LinkedMultiValueMap<>();
        fileHeaders.add("Content-Type", "application/xyz");
        body.add("files", new HttpEntity<>(resource, fileHeaders));

        // When & Then
        webClient.post()
                .uri("/api/scenarios/{id}/upload", scenarioId)
                .header("X-UserId", userId)
                .contentType(MediaType.MULTIPART_FORM_DATA)
                .body(BodyInserters.fromMultipartData(body))
                .exchange()
                .expectStatus().isEqualTo(422);
    }

    @Test
    void uploadFiles_WithoutFiles_ShouldReturnNoContent() {
        // Given
        String userId = "USER123";
        UUID scenarioId = UUID.randomUUID();

        // Мокируем, что сценарий существует
        when(scenarioService.getScenario(userId, scenarioId))
                .thenReturn(new ScenarioDetailResponse(
                        scenarioId,
                        "Test Scenario",
                        "Description",
                        null,
                        null,
                        new GraphDataDto(List.of(), List.of())
                ));

        // Мокируем обработку пустого списка файлов
        when(scenarioService.getDocumentsText(any(), eq(null)))
                .thenReturn(List.of());

        // Подготовка multipart тела без файлов
        MultiValueMap<String, HttpEntity<?>> body = new LinkedMultiValueMap<>();

        // Мокируем кэширование
        doNothing().when(docsTextCacheService).cacheDocumentTexts(any(), any(), any(), any());

        // When & Then
        webClient.post()
                .uri("/api/scenarios/{id}/upload", scenarioId)
                .header("X-UserId", userId)
                .contentType(MediaType.MULTIPART_FORM_DATA)
                .body(BodyInserters.fromMultipartData(body))
                .exchange()
                .expectStatus().isBadRequest();
    }

    @Test
    void uploadFiles_WithJsonInsteadOfMultipart_ShouldReturnUnsupportedMediaType() {
        // Given
        String userId = "USER123";
        UUID scenarioId = UUID.randomUUID();
        Map<String, String> jsonBody = Map.of("key", "value");

        // When & Then
        webClient.post()
                .uri("/api/scenarios/{id}/upload", scenarioId)
                .header("X-UserId", userId)
                .contentType(MediaType.APPLICATION_JSON) // Отправляем JSON вместо multipart
                .bodyValue(jsonBody)
                .exchange()
                .expectStatus().isEqualTo(415); // Expect 415 Unsupported Media Type
    }

    @Test
    void uploadFiles_WithTooManyFiles_ShouldFailWithUnprocessableEntity() {
        // Given
        String userId = "USER123";
        UUID scenarioId = UUID.randomUUID();
        String filename = "test.txt";
        String fileText = "Текст из файла.";

        // Мокируем, что сценарий существует
        when(scenarioService.getScenario(userId, scenarioId))
                .thenReturn(new ScenarioDetailResponse(
                        scenarioId,
                        "Test Scenario",
                        "Description",
                        null,
                        null,
                        new GraphDataDto(List.of(), List.of())
                ));

        // Подготовка multipart тела с количеством файлов, превышающим лимит
        MultiValueMap<String, HttpEntity<?>> body = new LinkedMultiValueMap<>();
        for (int i = 0; i < ScenarioController.MAX_FILES_PER_REQUEST + 1; i++) {
            int idx = i;
            ByteArrayResource resource = new ByteArrayResource(fileText.getBytes(StandardCharsets.UTF_8)) {
                @Override
                public String getFilename() {
                    return idx + "_" + filename;
                }
            };
            LinkedMultiValueMap<String, String> headers = new LinkedMultiValueMap<>();
            headers.add("Content-Type", "text/plain");
            body.add("files", new HttpEntity<>(resource, headers));
        }

        // When & Then
        webClient.post()
                .uri("/api/scenarios/{id}/upload", scenarioId)
                .header("X-UserId", userId)
                .contentType(MediaType.MULTIPART_FORM_DATA)
                .body(BodyInserters.fromMultipartData(body))
                .exchange()
                .expectStatus().isEqualTo(422);
    }

    @Test
    void uploadFiles_ShouldReturnNotFound_WhenScenarioNotFound() {
        // Given
        String userId = "USER123";
        UUID scenarioId = UUID.randomUUID();

        // Мокируем, что сценарий не найден
        when(scenarioService.getScenario(userId, scenarioId))
                .thenThrow(new IllegalArgumentException("Сценарий не найден: " + scenarioId));

        // Подготовка multipart тела
        MultiValueMap<String, HttpEntity<?>> body = new LinkedMultiValueMap<>();
        ByteArrayResource resource = new ByteArrayResource("test content".getBytes()) {
            @Override
            public String getFilename() {
                return "test.txt";
            }
        };
        LinkedMultiValueMap<String, String> fileHeaders = new LinkedMultiValueMap<>();
        fileHeaders.add("Content-Type", "text/plain");
        body.add("files", new HttpEntity<>(resource, fileHeaders));

        // When & Then
        webClient.post()
                .uri("/api/scenarios/{id}/upload", scenarioId)
                .header("X-UserId", userId)
                .contentType(MediaType.MULTIPART_FORM_DATA)
                .body(BodyInserters.fromMultipartData(body))
                .exchange()
                .expectStatus().is5xxServerError();
    }
}
