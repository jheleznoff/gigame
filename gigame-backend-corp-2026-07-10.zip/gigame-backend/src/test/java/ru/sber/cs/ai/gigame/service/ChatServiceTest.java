package ru.sber.cs.ai.gigame.service;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Pageable;
import org.springframework.test.util.ReflectionTestUtils;
import reactor.core.publisher.Flux;
import ru.sber.cs.ai.gigame.dto.chat.ConversationResponse;
import ru.sber.cs.ai.gigame.dto.chat.ConversationWithMessages;
import ru.sber.cs.ai.gigame.exception.NotFoundException;
import ru.sber.cs.ai.gigame.model.Conversation;
import ru.sber.cs.ai.gigame.model.KnowledgeBase;
import ru.sber.cs.ai.gigame.model.Message;
import ru.sber.cs.ai.gigame.repository.ConversationRepository;
import ru.sber.cs.ai.gigame.repository.DocumentRepository;
import ru.sber.cs.ai.gigame.repository.KnowledgeBaseRepository;
import ru.sber.cs.ai.gigame.repository.MessageRepository;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.argThat;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.ArgumentMatchers.isA;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ChatServiceTest {

    @Mock
    private ConversationRepository conversationRepository;

    @Mock
    private MessageRepository messageRepository;

    @Mock
    private GigaChatClient gigaChatClient;

    @Mock
    private EmbeddingService embeddingService;

    @Mock
    private MessageService messageService;

    @Mock
    private DocumentRepository documentRepository;

    @Mock
    private KnowledgeBaseRepository knowledgeBaseRepository;

    @InjectMocks
    private ChatService chatService;

    private UUID userId;
    private UUID conversationId;
    private UUID kbId;
    private Conversation conversation;

    @BeforeEach
    void setUp() {
        userId = UUID.randomUUID();
        kbId = UUID.randomUUID();
        conversationId = UUID.randomUUID();
        conversation = new Conversation();
        conversation.setId(conversationId);
        conversation.setUserId(userId.toString());
        ReflectionTestUtils.setField(chatService, "contextCharLimit", 12000);
        ReflectionTestUtils.setField(chatService, "maxHistoryMessages", 20);
        ReflectionTestUtils.setField(chatService, "maxAutoTitleLength", 100);
        // Сохранение возвращает сохраняемую сущность с присвоенным id (как JPA)
        lenient().when(messageRepository.save(any(Message.class))).thenAnswer(invocation -> {
            Message m = invocation.getArgument(0);
            if (m.getId() == null) {
                m.setId(UUID.randomUUID());
            }
            return m;
        });
        // Любая база знаний в тестах доступна (общая) — проверки доступа не мешают сценариям
        KnowledgeBase sharedKb = new KnowledgeBase();
        sharedKb.setShared(true);
        lenient().when(knowledgeBaseRepository.findById(any(UUID.class)))
                .thenReturn(Optional.of(sharedKb));
    }

    @AfterEach
    void cleanStubs() {
        Mockito.reset(conversationRepository, messageRepository, gigaChatClient,
                embeddingService, messageService, documentRepository, knowledgeBaseRepository);
    }

    @Test
    void testGetConversations_withSearch() {
        when(conversationRepository.searchByTitleOrMessageContent(any(), any()))
                .thenReturn(List.of(conversation));

        List<ConversationResponse> result = chatService.getConversations(userId.toString(), "test");

        assertNotNull(result);
        assertEquals(1, result.size());
        verify(conversationRepository).searchByTitleOrMessageContent(any(), eq("test"));
    }

    @Test
    void testGetConversations_withoutSearch() {
        when(conversationRepository.findByUserIdOrderByUpdatedAtDesc(any()))
                .thenReturn(List.of(conversation));

        List<ConversationResponse> result = chatService.getConversations(userId.toString(), null);

        assertNotNull(result);
        assertEquals(1, result.size());
        verify(conversationRepository).findByUserIdOrderByUpdatedAtDesc(any());
    }

    @Test
    void testGetConversation_withExistingConversation() {
        when(conversationRepository.findById(any())).thenReturn(Optional.of(conversation));
        when(messageRepository.findByConversationIdOrderByCreatedAtAsc(any())).thenReturn(List.of());

        ConversationWithMessages result = chatService.getConversation(userId.toString(), conversationId);

        assertNotNull(result);
        assertEquals(conversationId, result.id());
    }

    @Test
    void testGetConversation_withNonExistingConversation_throwsNotFoundException() {
        when(conversationRepository.findById(any())).thenReturn(Optional.empty());
        var userIdStr = userId.toString();
        var uuid = UUID.randomUUID();
        assertThrows(NotFoundException.class,
                () -> chatService.getConversation(userIdStr, uuid));
    }

    @ParameterizedTest
    @ValueSource(strings = {"", "   ", "   \t  ",})
    void testCreateConversation_withInvalidTitle_usesDefault(String title) {
        when(conversationRepository.save(any())).thenReturn(conversation);

        ConversationResponse result = chatService.createConversation(userId.toString(), title, null);

        assertNotNull(result);
        assertEquals("Новый диалог", result.title());
    }

    @Test
    void testCreateConversation_withKnowledgeBaseId() {
        conversation.setKnowledgeBaseId(kbId);
        when(conversationRepository.save(any())).thenReturn(conversation);

        ConversationResponse result = chatService.createConversation(userId.toString(), "Test", kbId.toString());

        assertNotNull(result);
        assertEquals(kbId.toString(), result.knowledgeBaseId());
    }

    @Test
    void testUpdateConversation_withValidTitle() {
        when(conversationRepository.findById(any())).thenReturn(Optional.of(conversation));
        when(conversationRepository.save(any())).thenReturn(conversation);

        ConversationResponse result = chatService.updateConversation(userId.toString(), conversationId, "New Title");

        assertNotNull(result);
        assertEquals("New Title", result.title());
    }

    @Test
    void testUpdateConversation_withNullTitle_doesNotUpdate() {
        when(conversationRepository.findById(any())).thenReturn(Optional.of(conversation));
        when(conversationRepository.save(any())).thenReturn(conversation);

        ConversationResponse result = chatService.updateConversation(userId.toString(), conversationId, (String) null);

        assertNotNull(result);
        assertEquals("Новый диалог", result.title());
    }

    @Test
    void testUpdateConversation_withNonExistingConversation_throwsNotFoundException() {
        when(conversationRepository.findById(any())).thenReturn(Optional.empty());
        var userIdStr = userId.toString();
        var uuid = UUID.randomUUID();
        assertThrows(NotFoundException.class,
                () -> chatService.updateConversation(userIdStr, uuid, "New Title"));
    }

    @Test
    void testDeleteConversation_withExistingConversation() {
        when(conversationRepository.findById(any())).thenReturn(Optional.of(conversation));

        assertDoesNotThrow(() -> chatService.deleteConversation(userId.toString(), conversationId));

        verify(conversationRepository).delete(conversation);
    }

    @Test
    void testDeleteConversation_withNonExistingConversation_throwsNotFoundException() {
        when(conversationRepository.findById(any())).thenReturn(Optional.empty());
        var userIdStr = userId.toString();
        var uuid = UUID.randomUUID();
        assertThrows(NotFoundException.class,
                () -> chatService.deleteConversation(userIdStr, uuid));
    }

    @Test
    void testSendMessageStream_withValidData() {
        lenient().when(conversationRepository.findById(any())).thenReturn(Optional.of(conversation));
        var result = chatService.sendMessageStream(userId.toString(), conversationId, "Hi", null, null);
        assertNotNull(result);
    }

    @Test
    void testGetConversations_withEmptySearch() {
        when(conversationRepository.findByUserIdOrderByUpdatedAtDesc(any()))
                .thenReturn(List.of(conversation));

        List<ConversationResponse> result = chatService.getConversations(userId.toString(), "");

        assertNotNull(result);
        assertEquals(1, result.size());
    }

    @Test
    void testCreateConversation_withLongTitle() {
        String longTitle = "A".repeat(200);
        when(conversationRepository.save(any())).thenAnswer(invocation -> {
            Conversation c = invocation.getArgument(0);
            c.setId(UUID.randomUUID());
            return c;
        });

        ConversationResponse result = chatService.createConversation(userId.toString(), longTitle, null);

        assertNotNull(result);
        assertEquals(longTitle, result.title());
    }

    @Test
    void testCreateConversation_withSpecialCharactersInTitle() {
        String specialTitle = "Test @#$%^&*()";
        when(conversationRepository.save(any())).thenAnswer(invocation -> {
            Conversation c = invocation.getArgument(0);
            c.setId(UUID.randomUUID());
            return c;
        });

        ConversationResponse result = chatService.createConversation(userId.toString(), specialTitle, null);

        assertNotNull(result);
        assertEquals(specialTitle, result.title());
    }

    @Test
    void testCreateConversation_withKnowledgeBaseId_andNullTitle() {
        when(conversationRepository.save(any())).thenAnswer(invocation -> {
            Conversation c = invocation.getArgument(0);
            c.setId(UUID.randomUUID());
            return c;
        });

        ConversationResponse result = chatService.createConversation(userId.toString(), null, kbId.toString());

        assertNotNull(result);
        assertEquals(kbId.toString(), result.knowledgeBaseId());
        assertEquals("Новый диалог", result.title());
    }

    @Test
    void testUpdateConversation_withWhitespaceTitle_doesNotUpdate() {
        when(conversationRepository.findById(any())).thenReturn(Optional.of(conversation));
        when(conversationRepository.save(any()))
                .thenAnswer(invocation -> invocation.getArgument(0));

        ConversationResponse result = chatService.updateConversation(userId.toString(), conversationId, "   ");

        assertNotNull(result);
    }

    @Test
    void testDeleteConversation_withNullConversationId() {
        var userIdStr = userId.toString();
        assertThrows(NotFoundException.class,
                () -> chatService.deleteConversation(userIdStr, null));
    }

    @Test
    void testGetConversation_withNullConversationId() {
        var userIdStr = userId.toString();
        assertThrows(NotFoundException.class,
                () -> chatService.getConversation(userIdStr, null));
    }

    @Test
    void testUpdateConversation_withNullConversation() {
        var userIdStr = userId.toString();
        assertThrows(NotFoundException.class,
                () -> chatService.updateConversation(userIdStr, null, "New Title"));
    }

    @Test
    void testSendMessageStream_withDocumentIds() {
        lenient().when(conversationRepository.findById(eq(conversationId))).thenReturn(Optional.of(conversation));
        var result = chatService.sendMessageStream(userId.toString(), conversationId, "Hi", List.of("doc1"), null);
        assertNotNull(result);
    }

    @Test
    void testSendMessageStream_withDocumentTexts() {
        lenient().when(conversationRepository.findById(eq(conversationId))).thenReturn(Optional.of(conversation));
        var result = chatService.sendMessageStream(userId.toString(), conversationId, "Hi", null, List.of("text"));
        assertNotNull(result);
    }

    @Test
    void testSendMessageStream_withBothDocumentsAndTexts() {
        lenient().when(conversationRepository.findById(eq(conversationId))).thenReturn(Optional.of(conversation));
        var result = chatService.sendMessageStream(userId.toString(), conversationId, "Hi", List.of("doc1"), List.of("text"));
        assertNotNull(result);
    }

    @Test
    void testSendMessageStream_callsBuildChatMessages_withDocumentTexts() {
        lenient().when(conversationRepository.findById(eq(conversationId))).thenReturn(Optional.of(conversation));
        when(messageRepository.findByConversationIdOrderByCreatedAtDesc(any(UUID.class), any(Pageable.class))).thenReturn(List.of());
        when(gigaChatClient.chatCompletionStreamResult(any(), any(), any()))
                .thenReturn(Flux.just(new GigaChatClient.ChatResult("Response", null)));

        chatService.sendMessageStream(userId.toString(), conversationId, "Hello", null, List.of("text")).blockLast();

        verify(gigaChatClient).chatCompletionStreamResult(argThat(messages ->
                messages.size() == 2 &&
                        "system".equals(messages.get(0).get("role")) &&
                        "user".equals(messages.get(1).get("role"))
        ), any(), any());
    }

    @Test
    void testSendMessageStream_callsBuildChatMessages_withLargeDocumentTexts() {
        lenient().when(conversationRepository.findById(eq(conversationId))).thenReturn(Optional.of(conversation));
        when(messageRepository.findByConversationIdOrderByCreatedAtDesc(any(UUID.class), any(Pageable.class))).thenReturn(List.of());
        when(gigaChatClient.chatCompletionStreamResult(any(), any(), any()))
                .thenReturn(Flux.just(new GigaChatClient.ChatResult("Response", null)));
        when(gigaChatClient.chatCompletion(any())).thenReturn("\"Это новый заголовок чата\"");
        ReflectionTestUtils.setField(chatService, "contextCharLimit", 2);
        ReflectionTestUtils.setField(chatService, "maxAutoTitleLength", 20);
        chatService.sendMessageStream(userId.toString(), conversationId, "Hello", null, List.of("text")).blockLast();

        verify(gigaChatClient).chatCompletionStreamResult(argThat(messages ->
                messages.size() == 2 &&
                        "system".equals(messages.get(0).get("role")) &&
                        "user".equals(messages.get(1).get("role"))
        ), any(), any());
    }

    @Test
    void testSendMessageStream_callsBuildChatMessages_withRAG() {
        conversation.setKnowledgeBaseId(kbId);
        UUID sourceDocId = UUID.randomUUID();
        lenient().when(conversationRepository.findById(eq(conversationId))).thenReturn(Optional.of(conversation));
        when(messageRepository.findByConversationIdOrderByCreatedAtDesc(any(UUID.class), any(Pageable.class))).thenReturn(List.of());
        when(gigaChatClient.getEmbeddings(any())).thenReturn(List.of(new float[1024]));
        when(embeddingService.searchSimilarWithSources(eq("kb"), eq(kbId), isA(float[].class)))
                .thenReturn(List.of(new EmbeddingService.ChunkHit("KB chunk", sourceDocId, 0.1)));
        when(embeddingService.getTopK()).thenReturn(5);
        when(documentRepository.findById(eq(sourceDocId))).thenReturn(Optional.empty());
        when(gigaChatClient.chatCompletionStreamResult(any(), any(), any()))
                .thenReturn(Flux.just(new GigaChatClient.ChatResult("Response", null)));

        chatService.sendMessageStream(userId.toString(), conversationId, "Hello", null, null).blockLast();

        verify(gigaChatClient).chatCompletionStreamResult(argThat(messages ->
                messages.size() == 2 &&
                        "system".equals(messages.get(0).get("role")) &&
                        messages.get(0).get("content").contains("KB chunk")
        ), any(), any());
    }

    @Test
    void testSendMessageStream_ragRelativeFilter_dropsFarKb() {
        UUID farKbId = UUID.randomUUID();
        conversation.setKnowledgeBaseIds(List.of(kbId.toString(), farKbId.toString()));
        UUID nearDocId = UUID.randomUUID();
        UUID farDocId = UUID.randomUUID();
        ReflectionTestUtils.setField(chatService, "ragDistanceDelta", 0.08);
        lenient().when(conversationRepository.findById(eq(conversationId))).thenReturn(Optional.of(conversation));
        when(messageRepository.findByConversationIdOrderByCreatedAtDesc(any(UUID.class), any(Pageable.class))).thenReturn(List.of());
        when(gigaChatClient.getEmbeddings(any())).thenReturn(List.of(new float[1024]));
        // Релевантная БЗ: лучший фрагмент 0.10, второй 0.30 (сам по себе за дельтой,
        // но база выиграла — остаются ВСЕ её фрагменты)
        when(embeddingService.searchSimilarWithSources(eq("kb"), eq(kbId), isA(float[].class)))
                .thenReturn(List.of(
                        new EmbeddingService.ChunkHit("Near chunk", nearDocId, 0.10),
                        new EmbeddingService.ChunkHit("Near chunk 2", nearDocId, 0.30)));
        // Нерелевантная БЗ: её лучший фрагмент 0.35 хуже глобального лучшего на 0.25 > 0.08
        when(embeddingService.searchSimilarWithSources(eq("kb"), eq(farKbId), isA(float[].class)))
                .thenReturn(List.of(
                        new EmbeddingService.ChunkHit("Far chunk", farDocId, 0.35)));
        when(embeddingService.getTopK()).thenReturn(5);
        when(documentRepository.findById(eq(nearDocId))).thenReturn(Optional.empty());
        when(gigaChatClient.chatCompletionStreamResult(any(), any(), any()))
                .thenReturn(Flux.just(new GigaChatClient.ChatResult("Response", null)));

        chatService.sendMessageStream(userId.toString(), conversationId, "Hello", null, null).blockLast();

        verify(gigaChatClient).chatCompletionStreamResult(argThat(messages ->
                messages.get(0).get("content").contains("Near chunk") &&
                        messages.get(0).get("content").contains("Near chunk 2") &&
                        !messages.get(0).get("content").contains("Far chunk")
        ), any(), any());
        // Документ отсечённой БЗ не должен попадать в источники
        verify(messageService).saveAssistantMessage(any(), any(), argThat(sources ->
                sources.size() == 1 && nearDocId.toString().equals(sources.get(0).get("document_id"))));
    }

    @Test
    void testSendMessageStream_ragRelativeFilter_keepsCloseKbs() {
        UUID kbId2 = UUID.randomUUID();
        conversation.setKnowledgeBaseIds(List.of(kbId.toString(), kbId2.toString()));
        UUID docId1 = UUID.randomUUID();
        UUID docId2 = UUID.randomUUID();
        ReflectionTestUtils.setField(chatService, "ragDistanceDelta", 0.08);
        lenient().when(conversationRepository.findById(eq(conversationId))).thenReturn(Optional.of(conversation));
        when(messageRepository.findByConversationIdOrderByCreatedAtDesc(any(UUID.class), any(Pageable.class))).thenReturn(List.of());
        when(gigaChatClient.getEmbeddings(any())).thenReturn(List.of(new float[1024]));
        // Лучшие фрагменты обеих БЗ в пределах дельты — вопрос касается обеих, остаются обе
        when(embeddingService.searchSimilarWithSources(eq("kb"), eq(kbId), isA(float[].class)))
                .thenReturn(List.of(new EmbeddingService.ChunkHit("First chunk", docId1, 0.10)));
        when(embeddingService.searchSimilarWithSources(eq("kb"), eq(kbId2), isA(float[].class)))
                .thenReturn(List.of(new EmbeddingService.ChunkHit("Second chunk", docId2, 0.15)));
        when(embeddingService.getTopK()).thenReturn(5);
        when(documentRepository.findById(any(UUID.class))).thenReturn(Optional.empty());
        when(gigaChatClient.chatCompletionStreamResult(any(), any(), any()))
                .thenReturn(Flux.just(new GigaChatClient.ChatResult("Response", null)));

        chatService.sendMessageStream(userId.toString(), conversationId, "Hello", null, null).blockLast();

        verify(gigaChatClient).chatCompletionStreamResult(argThat(messages ->
                messages.get(0).get("content").contains("First chunk") &&
                        messages.get(0).get("content").contains("Second chunk")
        ), any(), any());
    }

    @Test
    void testSendMessageStream_ragRouter_routesToSingleKb() {
        UUID kbId2 = UUID.randomUUID();
        conversation.setKnowledgeBaseIds(List.of(kbId.toString(), kbId2.toString()));
        UUID docId = UUID.randomUUID();
        ReflectionTestUtils.setField(chatService, "ragRouterEnabled", true);
        mockKb(kbId, "THUNDER");
        mockKb(kbId2, "ASUS");
        lenient().when(conversationRepository.findById(eq(conversationId))).thenReturn(Optional.of(conversation));
        when(messageRepository.findByConversationIdOrderByCreatedAtDesc(any(UUID.class), any(Pageable.class))).thenReturn(List.of());
        when(gigaChatClient.getEmbeddings(any())).thenReturn(List.of(new float[1024]));
        // Роутер выбирает вторую базу — поиск идёт только по ней
        when(gigaChatClient.chatCompletion(any(), any(), any())).thenReturn("2");
        when(embeddingService.searchSimilarWithSources(eq("kb"), eq(kbId2), isA(float[].class)))
                .thenReturn(List.of(new EmbeddingService.ChunkHit("ASUS chunk", docId, 0.1)));
        when(embeddingService.getTopK()).thenReturn(5);
        when(documentRepository.findById(eq(docId))).thenReturn(Optional.empty());
        when(gigaChatClient.chatCompletionStreamResult(any(), any(), any()))
                .thenReturn(Flux.just(new GigaChatClient.ChatResult("Response", null)));

        chatService.sendMessageStream(userId.toString(), conversationId, "Вопрос про ASUS", null, null).blockLast();

        verify(gigaChatClient).chatCompletionStreamResult(argThat(messages ->
                messages.get(0).get("content").contains("ASUS chunk")
        ), any(), any());
        verify(embeddingService, never())
                .searchSimilarWithSources(eq("kb"), eq(kbId), isA(float[].class));
    }

    @Test
    void testSendMessageStream_ragRouter_answerAll_searchesAllKbs() {
        UUID kbId2 = UUID.randomUUID();
        conversation.setKnowledgeBaseIds(List.of(kbId.toString(), kbId2.toString()));
        ReflectionTestUtils.setField(chatService, "ragRouterEnabled", true);
        mockKb(kbId, "THUNDER");
        mockKb(kbId2, "ASUS");
        lenient().when(conversationRepository.findById(eq(conversationId))).thenReturn(Optional.of(conversation));
        when(messageRepository.findByConversationIdOrderByCreatedAtDesc(any(UUID.class), any(Pageable.class))).thenReturn(List.of());
        when(gigaChatClient.getEmbeddings(any())).thenReturn(List.of(new float[1024]));
        // Роутер не уверен — поиск по всем базам
        when(gigaChatClient.chatCompletion(any(), any(), any())).thenReturn("все");
        when(embeddingService.searchSimilarWithSources(eq("kb"), any(UUID.class), isA(float[].class)))
                .thenReturn(List.of(new EmbeddingService.ChunkHit("KB chunk", UUID.randomUUID(), 0.1)));
        when(embeddingService.getTopK()).thenReturn(5);
        when(documentRepository.findById(any(UUID.class))).thenReturn(Optional.empty());
        when(gigaChatClient.chatCompletionStreamResult(any(), any(), any()))
                .thenReturn(Flux.just(new GigaChatClient.ChatResult("Response", null)));

        chatService.sendMessageStream(userId.toString(), conversationId, "Общий вопрос", null, null).blockLast();

        verify(embeddingService).searchSimilarWithSources(eq("kb"), eq(kbId), isA(float[].class));
        verify(embeddingService).searchSimilarWithSources(eq("kb"), eq(kbId2), isA(float[].class));
    }

    @Test
    void testSendMessageStream_ragRouter_failure_searchesAllKbs() {
        UUID kbId2 = UUID.randomUUID();
        conversation.setKnowledgeBaseIds(List.of(kbId.toString(), kbId2.toString()));
        ReflectionTestUtils.setField(chatService, "ragRouterEnabled", true);
        mockKb(kbId, "THUNDER");
        mockKb(kbId2, "ASUS");
        lenient().when(conversationRepository.findById(eq(conversationId))).thenReturn(Optional.of(conversation));
        when(messageRepository.findByConversationIdOrderByCreatedAtDesc(any(UUID.class), any(Pageable.class))).thenReturn(List.of());
        when(gigaChatClient.getEmbeddings(any())).thenReturn(List.of(new float[1024]));
        // Ошибка роутера не должна ломать RAG — fail-open на все базы
        when(gigaChatClient.chatCompletion(any(), any(), any())).thenThrow(new RuntimeException("router down"));
        when(embeddingService.searchSimilarWithSources(eq("kb"), any(UUID.class), isA(float[].class)))
                .thenReturn(List.of(new EmbeddingService.ChunkHit("KB chunk", UUID.randomUUID(), 0.1)));
        when(embeddingService.getTopK()).thenReturn(5);
        when(documentRepository.findById(any(UUID.class))).thenReturn(Optional.empty());
        when(gigaChatClient.chatCompletionStreamResult(any(), any(), any()))
                .thenReturn(Flux.just(new GigaChatClient.ChatResult("Response", null)));

        chatService.sendMessageStream(userId.toString(), conversationId, "Вопрос", null, null).blockLast();

        verify(embeddingService).searchSimilarWithSources(eq("kb"), eq(kbId), isA(float[].class));
        verify(embeddingService).searchSimilarWithSources(eq("kb"), eq(kbId2), isA(float[].class));
    }

    /**
     * Мокает доступную (общую) базу знаний с заданным именем.
     */
    private void mockKb(UUID id, String name) {
        KnowledgeBase kb = new KnowledgeBase();
        kb.setId(id);
        kb.setName(name);
        kb.setShared(true);
        lenient().when(knowledgeBaseRepository.findById(eq(id))).thenReturn(Optional.of(kb));
    }

    @Test
    void testSendMessageStream_ragMaxDistance_dropsAllChunks() {
        conversation.setKnowledgeBaseId(kbId);
        ReflectionTestUtils.setField(chatService, "ragMaxDistance", 0.3);
        lenient().when(conversationRepository.findById(eq(conversationId))).thenReturn(Optional.of(conversation));
        when(messageRepository.findByConversationIdOrderByCreatedAtDesc(any(UUID.class), any(Pageable.class))).thenReturn(List.of());
        when(gigaChatClient.getEmbeddings(any())).thenReturn(List.of(new float[1024]));
        // Все фрагменты дальше абсолютного порога — RAG-контекст не строится вовсе
        when(embeddingService.searchSimilarWithSources(eq("kb"), eq(kbId), isA(float[].class)))
                .thenReturn(List.of(
                        new EmbeddingService.ChunkHit("Far chunk", UUID.randomUUID(), 0.5)));
        when(gigaChatClient.chatCompletionStreamResult(any(), any(), any()))
                .thenReturn(Flux.just(new GigaChatClient.ChatResult("Response", null)));

        chatService.sendMessageStream(userId.toString(), conversationId, "Hello", null, null).blockLast();

        verify(gigaChatClient).chatCompletionStreamResult(argThat(messages ->
                messages.size() == 1 && "user".equals(messages.get(0).get("role"))
        ), any(), any());
    }

    @Test
    void testSendMessageStream_callsBuildChatMessages_withHistory() {
        // От новых к старым, как возвращает findByConversationIdOrderByCreatedAtDesc
        List<Message> history = List.of(
                createMessage("assistant", "Second"),
                createMessage("user", "First")
        );
        lenient().when(conversationRepository.findById(eq(conversationId))).thenReturn(Optional.of(conversation));
        when(messageRepository.findByConversationIdOrderByCreatedAtDesc(any(UUID.class), any(Pageable.class))).thenReturn(history);
        when(gigaChatClient.chatCompletionStreamResult(any(), any(), any()))
                .thenReturn(Flux.just(new GigaChatClient.ChatResult("Response", null)));

        chatService.sendMessageStream(userId.toString(), conversationId, "Third", null, null).blockLast();

        verify(gigaChatClient).chatCompletionStreamResult(argThat(messages ->
                messages.size() == 3 &&
                        "First".equals(messages.get(0).get("content")) &&
                        "Second".equals(messages.get(1).get("content")) &&
                        "Third".equals(messages.get(2).get("content"))
        ), any(), any());
    }

    @Test
    void testSendMessageStream_savesUserMessage() {
        lenient().when(conversationRepository.findById(eq(conversationId))).thenReturn(Optional.of(conversation));
        when(messageRepository.findByConversationIdOrderByCreatedAtDesc(any(UUID.class), any(Pageable.class))).thenReturn(List.of());
        when(gigaChatClient.chatCompletionStreamResult(any(), any(), any()))
                .thenReturn(Flux.just(new GigaChatClient.ChatResult("Response", null)));

        chatService.sendMessageStream(userId.toString(), conversationId, "Hello", null, null).blockLast();

        verify(messageRepository).save(any(Message.class));
    }

    @Test
    void testSendMessageStream_savesUserMessage_withDocumentIds() {
        lenient().when(conversationRepository.findById(eq(conversationId))).thenReturn(Optional.of(conversation));
        when(messageRepository.findByConversationIdOrderByCreatedAtDesc(any(UUID.class), any(Pageable.class))).thenReturn(List.of());
        when(gigaChatClient.chatCompletionStreamResult(any(), any(), any()))
                .thenReturn(Flux.just(new GigaChatClient.ChatResult("Response", null)));

        List<String> docIds = List.of("doc1", "doc2");
        chatService.sendMessageStream(userId.toString(), conversationId, "Hello", docIds, null).blockLast();

        verify(messageRepository).save(argThat(msg -> docIds.equals(msg.getDocumentIds())));
    }

    private Message createMessage(String role, String content) {
        Message msg = new Message();
        msg.setId(UUID.randomUUID());
        msg.setRole(role);
        msg.setContent(content);
        msg.setConversation(conversation);
        return msg;
    }

    // -------------------------------------------------------------------------
    // Tests for private methods using reflection
    // -------------------------------------------------------------------------

    private List<Map<String, String>> invokeBuildChatMessages(String content, List<String> docTexts) {
        Message userMessage = createMessage("user", content);
        Object promptBuild = ReflectionTestUtils.invokeMethod(chatService, "buildChatMessages",
                conversation, userMessage, null, docTexts);
        return ReflectionTestUtils.invokeMethod(promptBuild, "messages");
    }

    @Test
    void testBuildChatMessages_withEmptyDocumentTexts() {
        List<Map<String, String>> result = invokeBuildChatMessages("EmptyDocumentTexts", null);

        assertNotNull(result);
        assertEquals(1, result.size());
        assertEquals("user", result.get(0).get("role"));
        assertEquals("EmptyDocumentTexts", result.get(0).get("content"));
    }

    @Test
    void testBuildChatMessages_withDocumentTexts() {
        List<Map<String, String>> result = invokeBuildChatMessages("Hello", List.of("text"));

        assertNotNull(result);
        assertEquals(2, result.size());
        assertEquals("system", result.get(0).get("role"));
        assertTrue(result.get(0).get("content").contains("Пользователь загрузил 1 документ"));
        assertEquals("user", result.get(1).get("role"));
    }

    @Test
    void testBuildChatMessages_withHistory() {
        List<Message> history = List.of(createMessage("user", "First"));
        when(messageRepository.findByConversationIdOrderByCreatedAtDesc(any(), any())).thenReturn(history);

        List<Map<String, String>> result = invokeBuildChatMessages("withHistory", null);

        assertNotNull(result);
        assertEquals(2, result.size());
        assertEquals("user", result.get(0).get("role"));
        assertEquals("First", result.get(0).get("content"));
        assertEquals("user", result.get(1).get("role"));
        assertEquals("withHistory", result.get(1).get("content"));
    }

    @Test
    void testBuildChatMessages_withSummary() {
        conversation.setSummary("Краткое содержание ранней части");

        List<Map<String, String>> result = invokeBuildChatMessages("Next", null);

        assertNotNull(result);
        assertEquals(2, result.size());
        assertEquals("system", result.get(0).get("role"));
        assertTrue(result.get(0).get("content").contains("Краткое содержание ранней части"));
        assertEquals("user", result.get(1).get("role"));
    }
}
