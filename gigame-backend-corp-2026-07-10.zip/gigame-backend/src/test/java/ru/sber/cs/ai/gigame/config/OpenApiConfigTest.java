package ru.sber.cs.ai.gigame.config;

import org.junit.jupiter.api.Test;
import org.springframework.context.annotation.Configuration;

import static org.assertj.core.api.Assertions.assertThat;

class OpenApiConfigTest {

    @Test
    void configShouldBeConfigurationClass() {
        assertThat(OpenApiConfig.class.getAnnotation(Configuration.class))
                .isNotNull();
    }

    @Test
    void configShouldHaveLombokSlf4j() {
        assertThat(OpenApiConfig.class.getAnnotation(org.springframework.stereotype.Component.class))
                .isNull();
    }

    @Test
    void configClassShouldExist() {
        assertThat(OpenApiConfig.class).isNotNull();
    }
}
