package ru.sber.cs.ai.gigame.service.scenario;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import ru.sber.cs.ai.gigame.dto.scenario.graph.EdgeDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.EdgeDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.GraphDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.MeasuredDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.PositionDto;
import ru.sber.cs.ai.gigame.exception.ScenarioException;
import ru.sber.cs.ai.gigame.service.DocsTextCacheService;
import ru.sber.cs.ai.gigame.service.scenario.enums.ScenarioNodeType;
import ru.sber.cs.ai.gigame.service.scenario.executor.ScenarioExecutorFactory;

import java.util.List;
import java.util.UUID;
import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Тесты для {@link ScenarioEngine}.
 * <p>
 * Тестирует валидацию графов, топологическую сортировку,
 * управление пошаговым режимом отладки и очистку состояния.
 */
@ExtendWith(MockitoExtension.class)
class ScenarioEngineTest {

    @Mock
    private ScenarioRunService runService;

    @Mock
    private ScenarioRunStepService stepService;

    @Mock
    private ScenarioExecutorFactory executorFactory;

    @Mock
    private DocsTextCacheService cacheService;

    private ScenarioEngine engine;

    @BeforeEach
    void setUp() {
        engine = new ScenarioEngine(runService, stepService, executorFactory, cacheService, org.mockito.Mockito.mock(ru.sber.cs.ai.gigame.repository.ScenarioRepository.class));
    }

    // -------------------------------------------------------------------------
    // Constructor and basic initialization
    // -------------------------------------------------------------------------

    @Test
    void testConstructor_initializedSuccessfully() {
        assertNotNull(engine);
    }

    // -------------------------------------------------------------------------
    // Step mode tests
    // -------------------------------------------------------------------------

    @Test
    void testEnableStepMode_addsRunIdToEnabledSet() {
        String runId = "run-123";
        engine.enableStepMode(runId);
        engine.disableStepMode(runId);
        assertNotNull(engine);
    }

    @Test
    void testDisableStepMode_addsRunIdToDisabledSet() {
        String runId = UUID.randomUUID().toString();
        engine.disableStepMode(runId);
        engine.cleanupRun(runId);
        assertNotNull(engine);
    }

    @Test
    void testContinueStep_completesExistingFuture() {
        String runId = UUID.randomUUID().toString();
        engine.enableStepMode(runId);
        engine.continueStep(runId);
        engine.cleanupRun(runId);
        assertNotNull(engine);
    }

    @Test
    void testContinueStep_withNonExistentFuture_doesNotThrow() {
        String runId = UUID.randomUUID().toString();
        assertDoesNotThrow(() -> engine.continueStep(runId));
    }

    @Test
    void testCleanupRun_clearsAllState() {
        String runId = UUID.randomUUID().toString();
        engine.enableStepMode(runId);
        engine.continueStep(runId);
        engine.cleanupRun(runId);
        engine.enableStepMode(runId);
        engine.disableStepMode(runId);
        engine.cleanupRun(runId);
        assertNotNull(engine);
    }

    // -------------------------------------------------------------------------
    // Graph validation tests (via reflection on private methods)
    // -------------------------------------------------------------------------

    @Test
    void testValidateGraph_withEmptyNodes_throwsScenarioException() {
        GraphDataDto graphData = new GraphDataDto(List.of(), List.of());

        ScenarioException exception = assertThrows(ScenarioException.class, () ->
                validateGraph(engine, graphData));

        assertTrue(exception.getMessage().contains("отсутствует или пуст массив nodes"));
    }

    @Test
    void testValidateGraph_withEmptyEdges_throwsScenarioException() {
        NodeDto node = createInputNode("node-1");
        GraphDataDto graphData = new GraphDataDto(List.of(node), List.of());

        ScenarioException exception = assertThrows(ScenarioException.class, () ->
                validateGraph(engine, graphData));

        assertTrue(exception.getMessage().contains("отсутствует или пуст массив edges"));
    }

    @Test
    void testValidateGraph_withCyclicGraph_throwsScenarioException() {
        NodeDto nodeA = createNode("A", "input");
        NodeDto nodeB = createNode("B", "processing");
        NodeDto nodeC = createNode("C", "output");

        EdgeDto edgeAB = createEdge("e1", "A", "B");
        EdgeDto edgeBC = createEdge("e2", "B", "C");
        EdgeDto edgeCA = createEdge("e3", "C", "A");

        GraphDataDto graphData = new GraphDataDto(
                List.of(nodeA, nodeB, nodeC),
                List.of(edgeAB, edgeBC, edgeCA)
        );

        ScenarioException exception = assertThrows(ScenarioException.class, () ->
                validateGraph(engine, graphData));

        assertTrue(exception.getMessage().contains("обнаружен цикл"));
    }

    @Test
    void testValidateGraph_withNotExistentOutputNode_throwsScenarioException() {
        NodeDto nodeA = createNode("A", "input");
        NodeDto nodeB = createNode("B", "processing");
        EdgeDto edge = createEdge("e1", "A", "B");

        GraphDataDto graphData = new GraphDataDto(List.of(nodeA, nodeB), List.of(edge));

        ScenarioException exception = assertThrows(ScenarioException.class, () ->
                validateGraph(engine, graphData));

        assertTrue(exception.getMessage().contains("отсутствует узел с типом 'Выход'"));
    }

    @Test
    void testValidateGraph_withNotExistentInputNode_throwsScenarioException() {
        NodeDto nodeB = createNode("B", "processing");
        NodeDto nodeC = createNode("C", "output");
        EdgeDto edge = createEdge("e1", "B", "C");

        GraphDataDto graphData = new GraphDataDto(List.of(nodeB, nodeC), List.of(edge));

        ScenarioException exception = assertThrows(ScenarioException.class, () ->
                validateGraph(engine, graphData));

        assertTrue(exception.getMessage().contains("отсутствует узел с типом 'Вход'"));
    }

    @ParameterizedTest
    @MethodSource("invalidEdgeGraphProvider")
    void testValidateGraph_withInvalidEdge_throwsScenarioException(String testName, GraphDataDto graphData, String expectedMessage) {
        ScenarioException exception = assertThrows(ScenarioException.class, () ->
                validateGraph(engine, graphData));

        assertTrue(exception.getMessage().contains(expectedMessage),
                () -> "For case '" + testName + "': expected message containing '" + expectedMessage
                        + "' but got '" + exception.getMessage() + "'");
    }

    static Stream<Arguments> invalidEdgeGraphProvider() {
        NodeDto nodeA = createNode("A", "input");
        NodeDto nodeB = createNode("B", "processing");
        NodeDto nodeC = createNode("C", "output");

        return Stream.of(
                Arguments.of(
                        "invalid edge source",
                        new GraphDataDto(List.of(nodeA, nodeB, nodeC), List.of(createEdge("e1", "nonexistent", "B"))),
                        "источник ребра 'nonexistent' ссылается на несуществующий узел"
                ),
                Arguments.of(
                        "invalid edge target",
                        new GraphDataDto(List.of(nodeA, nodeB, nodeC), List.of(createEdge("e1", "A", "nonexistent"))),
                        "цель ребра 'nonexistent' ссылается на несуществующий узел"
                ),
                Arguments.of(
                        "disconnected node",
                        new GraphDataDto(List.of(nodeA, nodeB, nodeC), List.of(createEdge("e1", "A", "C"))),
                        "обнаружены узлы, не связанные рёбрами"
                )
        );
    }

    @Test
    void testValidateGraph_withNodeWithoutId_throwsScenarioException() {
        NodeDto nodeWithoutIdInput = new NodeDto(null, "input", NodeDataDto.builder().build(),
                new PositionDto(0, 0), new MeasuredDto(0, 0));
        NodeDto nodeWithoutIdOutnput = new NodeDto(null, "output", NodeDataDto.builder().build(),
                new PositionDto(0, 0), new MeasuredDto(0, 0));
        EdgeDto edge = createEdge("e1", "some-node", "another-node");

        GraphDataDto graphData = new GraphDataDto(List.of(nodeWithoutIdInput, nodeWithoutIdOutnput), List.of(edge));

        ScenarioException exception = assertThrows(ScenarioException.class, () ->
                validateGraph(engine, graphData));

        String message = exception.getMessage();
        assertTrue(message.contains("отсутствует идентификатор"),
                "Expected exception message to contain 'отсутствует идентификатор', but got: " + message);
    }

    @Test
    void testValidateGraph_withValidGraph_doesNotThrow() {
        NodeDto nodeA = createInputNode("node-a");
        NodeDto nodeB = createProcessingNode("node-b", "Prompt");
        NodeDto nodeC = createOutputNode("node-c");

        EdgeDto edge1 = createEdge("e1", "node-a", "node-b");
        EdgeDto edge2 = createEdge("e2", "node-b", "node-c");

        GraphDataDto graphData = new GraphDataDto(
                List.of(nodeA, nodeB, nodeC),
                List.of(edge1, edge2)
        );

        assertDoesNotThrow(() -> validateGraph(engine, graphData));
    }

    // -------------------------------------------------------------------------
    // Topological sort tests (via reflection)
    // -------------------------------------------------------------------------

    @Test
    void testTopologicalSort_linearGraph() {
        NodeDto nodeA = createNode("A", "input");
        NodeDto nodeB = createNode("B", "processing");
        NodeDto nodeC = createNode("C", "output");

        EdgeDto edgeAB = createEdge("e1", "A", "B");
        EdgeDto edgeBC = createEdge("e2", "B", "C");

        GraphDataDto graphData = new GraphDataDto(
                List.of(nodeA, nodeB, nodeC),
                List.of(edgeAB, edgeBC)
        );

        List<String> sorted = topologicalSort(engine, graphData);

        assertTrue(sorted.indexOf("A") < sorted.indexOf("B"));
        assertTrue(sorted.indexOf("B") < sorted.indexOf("C"));
    }

    @Test
    void testTopologicalSort_withMultiplePaths() {
        NodeDto nodeA = createNode("A", "input");
        NodeDto nodeB = createNode("B", "processing");
        NodeDto nodeC = createNode("C", "processing");
        NodeDto nodeD = createNode("D", "output");

        EdgeDto edgeAB = createEdge("e1", "A", "B");
        EdgeDto edgeAC = createEdge("e2", "A", "C");
        EdgeDto edgeBD = createEdge("e3", "B", "D");
        EdgeDto edgeCD = createEdge("e4", "C", "D");

        GraphDataDto graphData = new GraphDataDto(
                List.of(nodeA, nodeB, nodeC, nodeD),
                List.of(edgeAB, edgeAC, edgeBD, edgeCD)
        );

        List<String> sorted = topologicalSort(engine, graphData);

        assertEquals("A", sorted.get(0));
        assertEquals("D", sorted.get(sorted.size() - 1));
    }

    @Test
    void testTopologicalSort_singleNode() {
        NodeDto nodeA = createNode("A", "input");

        GraphDataDto graphData = new GraphDataDto(List.of(nodeA), List.of());

        List<String> sorted = topologicalSort(engine, graphData);

        assertEquals(1, sorted.size());
        assertEquals("A", sorted.get(0));
    }

    @Test
    void testTopologicalSort_emptyGraph() {
        GraphDataDto graphData = new GraphDataDto(List.of(), List.of());

        List<String> sorted = topologicalSort(engine, graphData);

        assertEquals(0, sorted.size());
    }

    // -------------------------------------------------------------------------
    // shutdown test
    // -------------------------------------------------------------------------

    @Test
    void testShutdown_doesNotThrow() {
        assertDoesNotThrow(() -> engine.shutdown());
    }

    // -------------------------------------------------------------------------
    // evictStaleRuns test
    // -------------------------------------------------------------------------

    @Test
    void testEvictStaleRuns_doesNotThrow() {
        String runId = UUID.randomUUID().toString();
        engine.cleanupRun(runId);

        assertDoesNotThrow(() -> engine.evictStaleRuns());

        engine.cleanupRun(runId);
    }

    // -------------------------------------------------------------------------
    // Helper methods for testing private/package-private methods
    // -------------------------------------------------------------------------

    private void validateGraph(ScenarioEngine scenarioEngine, GraphDataDto graphData) {
        try {
            var method = ScenarioEngine.class.getDeclaredMethod("validateGraph", GraphDataDto.class);
            method.setAccessible(true);
            method.invoke(scenarioEngine, graphData);
        } catch (Exception e) {
            throw unwrapException(e);
        }
    }

    private List<String> topologicalSort(ScenarioEngine scenarioEngine, GraphDataDto graphData) {
        try {
            var method = ScenarioEngine.class.getDeclaredMethod("topologicalSort", GraphDataDto.class);
            method.setAccessible(true);
            return (List<String>) method.invoke(scenarioEngine, graphData);
        } catch (Exception e) {
            throw unwrapException(e);
        }
    }

    private RuntimeException unwrapException(Exception e) {
        if (e instanceof java.lang.reflect.InvocationTargetException) {
            Throwable cause = e.getCause();
            if (cause != null) {
                if (cause instanceof RuntimeException) {
                    return (RuntimeException) cause;
                }
                if (cause instanceof Exception) {
                    return unwrapException((Exception) cause);
                }
                return new RuntimeException(cause);
            }
        }
        if (e instanceof RuntimeException) {
            Throwable cause = e.getCause();
            if (cause != null) {
                return unwrapException((Exception) cause);
            }
        }
        return new RuntimeException(e);
    }

    private void assertDoesNotThrow(Runnable runnable) {
        try {
            runnable.run();
        } catch (Exception e) {
            throw new AssertionError("Should not have thrown exception", e);
        }
    }

    // -------------------------------------------------------------------------
    // Factory methods for test data
    // -------------------------------------------------------------------------

    private static NodeDto createNode(String id, String type) {
        return NodeDto.builder()
                .id(id)
                .type(type)
                .data(NodeDataDto.builder().label("Node " + id).build())
                .position(new PositionDto(100, 100))
                .build();
    }

    private static NodeDto createInputNode(String id) {
        return NodeDto.builder()
                .id(id)
                .type(ScenarioNodeType.INPUT_NODE.toString())
                .data(NodeDataDto.builder().label("Input").build())
                .position(new PositionDto(100, 100))
                .build();
    }

    private static NodeDto createProcessingNode(String id, String prompt) {
        return NodeDto.builder()
                .id(id)
                .type(ScenarioNodeType.PROCESSING_NODE.toString())
                .data(NodeDataDto.builder().label("Processing").prompt(prompt).build())
                .position(new PositionDto(100, 100))
                .build();
    }

    private static NodeDto createOutputNode(String id) {
        return NodeDto.builder()
                .id(id)
                .type(ScenarioNodeType.OUTPUT_NODE.toString())
                .data(NodeDataDto.builder().label("Output").build())
                .position(new PositionDto(100, 100))
                .build();
    }

    private static EdgeDto createEdge(String id, String source, String target) {
        return new EdgeDto(id, source, target, new EdgeDataDto(null));
    }

    // -------------------------------------------------------------------------
    // Edge case tests
    // -------------------------------------------------------------------------

    @Test
    void testEnableStepMode_withMultipleRunIds() {
        String runId1 = UUID.randomUUID().toString();
        String runId2 = UUID.randomUUID().toString();
        String runId3 = UUID.randomUUID().toString();

        engine.enableStepMode(runId1);
        engine.enableStepMode(runId2);
        engine.enableStepMode(runId3);

        engine.cleanupRun(runId1);
        engine.cleanupRun(runId2);
        engine.cleanupRun(runId3);
        assertNotNull(engine);
    }

    @Test
    void testDisableStepMode_withActivePause() {
        String runId = UUID.randomUUID().toString();
        engine.enableStepMode(runId);
        engine.continueStep(runId);
        engine.disableStepMode(runId);
        engine.cleanupRun(runId);
        assertNotNull(engine);
    }

    @Test
    void testCleanupRun_idempotent() {
        String runId = UUID.randomUUID().toString();
        engine.cleanupRun(runId);
        engine.cleanupRun(runId);
        engine.cleanupRun(runId);
        assertNotNull(engine);
    }
}
