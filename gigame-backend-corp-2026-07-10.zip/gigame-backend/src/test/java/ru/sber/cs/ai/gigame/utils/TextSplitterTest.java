package ru.sber.cs.ai.gigame.utils;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

class TextSplitterTest {

    private final TextSplitter splitter = new TextSplitter();

    @BeforeEach
    void setUp() {
        ReflectionTestUtils.setField(splitter, "defaultChunkSize", 1000);
        ReflectionTestUtils.setField(splitter, "defaultOverlap", 200);
    }

    @Test
    void testSplit_withNullText_returnsEmptyList() {
        List<String> result = splitter.split(null);
        assertTrue(result.isEmpty());
    }

    @Test
    void testSplit_withBlankText_returnsEmptyList() {
        List<String> result = splitter.split("   ");
        assertTrue(result.isEmpty());
    }

    @Test
    void testSplit_withShortText_returnsSingleChunk() {
        String text = "Hello world";
        List<String> result = splitter.split(text);
        assertEquals(1, result.size());
        assertEquals(text, result.get(0));
    }

    @Test
    void testSplit_withLongText_returnsMultipleChunks() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 50; i++) {
            sb.append("This is test sentence number ").append(i).append(". ");
        }
        String text = sb.toString();

        List<String> result = splitter.split(text, 200, 50);
        assertTrue(result.size() > 1, "Should produce multiple chunks for long text");

        // Check that chunks don't exceed chunkSize significantly
        for (String chunk : result) {
            assertTrue(chunk.length() <= 250, "Chunk should not exceed chunkSize by much");
        }
    }

    @Test
    void testSplit_withOverlap_verifyOverlap() {
        var chunkSize = 100;
        var overlap = 20;
        String text = "Sentence one. Sentence two. Sentence three. Sentence four. Sentence five. Sentence six. Sentence seven. Sentence eight. Sentence nine. Sentence ten. Sentence eleven. Sentence twelve. Sentence thirteen. Sentence fourteen. Sentence fifteen.";
        List<String> result = splitter.split(text, chunkSize, overlap);
        assertTrue(result.size() > 1, "Should produce multiple chunks");

        // Check that consecutive chunks share some text (overlap)
        String first = result.get(0);
        String second = result.get(1);
        // There should be some overlap - second chunk should start with text from end of first
        boolean hasOverlap = second.startsWith(first.substring(Math.max(0, first.length() - overlap + 2)));
        assertTrue(hasOverlap || first.length() + second.length() > 200,
                "Consecutive chunks should have some overlap");
    }

    @Test
    void testSplit_withParagraphSeparators_preservesParagraphs() {
        String text = "First paragraph content.\n\nSecond paragraph content.\n\nThird paragraph content.";
        List<String> result = splitter.split(text, 1000, 100);
        // Should preserve paragraph structure when possible
        assertFalse(result.isEmpty());
    }

    @Test
    void testSplit_withNewlineSeparators() {
        String text = "Line 1\nLine 2\nLine 3\nLine 4\nLine 5";
        List<String> result = splitter.split(text, 50, 10);
        assertFalse(result.isEmpty());
    }

    @Test
    void testSplit_withDefaultParameters() {
        String text = "A".repeat(1500); // 1500 characters
        List<String> result = splitter.split(text);
        assertTrue(result.size() > 1, "Should split text larger than default chunk size");
    }

    @Test
    void testSplit_exactChunkSize_returnsOneChunk() {
        String text = "Hello world";
        List<String> result = splitter.split(text, text.length(), 0);
        assertEquals(1, result.size());
        assertEquals(text, result.get(0));
    }

    @Test
    void testSplit_zeroOverlap() {
        String text = "A B C D E F G H I J K L M N O P Q R S T U V W X Y Z";
        List<String> result = splitter.split(text, 30, 0);
        assertFalse(result.isEmpty());
    }

    @Test
    void testSplit_byChuknSize() {
        String text = "A".repeat(1500);
        List<String> result = splitter.split(text, 30, 0);
        assertFalse(result.isEmpty());
        assertEquals("A".repeat(30), result.get(0));
        assertEquals(50, result.size());
    }

    @Test
    void testSplit_withNextSelector() {
        String text = """
                Это длинный текст, который должен быть разделен на несколько частей.
                С разными сепараторами (символами по которым делится текст))
                """;
        List<String> result = splitter.split(text, 10, 0);
        assertFalse(result.isEmpty());
        assertEquals("Это", result.get(0));
        assertEquals(17, result.size());
    }
}
