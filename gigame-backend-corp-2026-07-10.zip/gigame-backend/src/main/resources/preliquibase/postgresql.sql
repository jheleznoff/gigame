CREATE SCHEMA IF NOT EXISTS ${spring.liquibase.default-schema};

-- Версии сценариев (идемпотентно; основной changelog — raw-SQL, дописывать его нельзя
-- из-за контрольной суммы Liquibase)
CREATE TABLE IF NOT EXISTS ${spring.liquibase.default-schema}.scenario_versions (
    id UUID PRIMARY KEY,
    scenario_id UUID NOT NULL,
    version_no INTEGER NOT NULL,
    name VARCHAR(255),
    description TEXT,
    graph_data JSONB,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_scenario_versions_sid
    ON ${spring.liquibase.default-schema}.scenario_versions(scenario_id, version_no);

-- Доработки чата (2026-07-09): несколько БЗ на диалог, модель/температура,
-- суммаризация истории, источники RAG. ALTER TABLE IF EXISTS: на пустой БД
-- таблицы ещё не созданы liquibase (preliquibase выполняется раньше) — тогда
-- колонки добавятся при следующем старте приложения.
ALTER TABLE IF EXISTS ${spring.liquibase.default-schema}.conversations
    ADD COLUMN IF NOT EXISTS knowledge_base_ids JSONB,
    ADD COLUMN IF NOT EXISTS model VARCHAR(64),
    ADD COLUMN IF NOT EXISTS temperature DOUBLE PRECISION,
    ADD COLUMN IF NOT EXISTS summary TEXT,
    ADD COLUMN IF NOT EXISTS summary_message_count INTEGER NOT NULL DEFAULT 0;
ALTER TABLE IF EXISTS ${spring.liquibase.default-schema}.messages
    ADD COLUMN IF NOT EXISTS sources JSONB;

-- Общие базы знаний (2026-07-09): признак «общая база» — видна всем
-- пользователям (чтение и RAG), изменяет только владелец.
ALTER TABLE IF EXISTS ${spring.liquibase.default-schema}.knowledge_bases
    ADD COLUMN IF NOT EXISTS shared BOOLEAN NOT NULL DEFAULT FALSE;

-- Backfill владельца легаси-записей (user_id IS NULL) выполняется в Java
-- (LegacyOwnerBackfill, после liquibase): здесь нельзя — на пустой БД таблиц
-- ещё нет, а DO-блок ломается разбиением скрипта по «;».
