package ru.sber.cs.ai.gigame.service.scenario.executor;

import com.fasterxml.jackson.core.json.JsonReadFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.json.JsonMapper;
import org.springframework.http.codec.ServerSentEvent;
import reactor.core.publisher.FluxSink;
import ru.sber.cs.ai.gigame.exception.ScenarioException;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunNode;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/**
 * Вычислительный узел: детерминированные расчёты по формулам без LLM.
 * <p>
 * Вход — последний JSON во входе узла (предпочтительно после маркера
 * «ДАННЫЕ ДЛЯ РАСЧЁТА»). Поддерживаются две формы данных:
 * <ul>
 *   <li>плоский объект чисел — {@code {"цена": 1250.5, "количество": 320}};</li>
 *   <li>таблица — объект, содержащий массив объектов (любой ключ:
 *       позиции, участники, строки…); прочие поля верхнего уровня становятся
 *       общими переменными (например, НМЦ). Вложенные объекты строки
 *       (например, «показатели») расплющиваются в колонки.</li>
 * </ul>
 * Конфигурация в rules узла:
 * <pre>
 * {"формулы": [
 *    {"имя": "Балл цены", "формула": "МИН(цена) / цена"},
 *    {"имя": "Итог", "формула": "0.6 * Балл_цены + 0.4 * Балл_срока"}
 *  ],
 *  "фильтр": "статус &lt;&gt; \"ОТКЛОНЁН\"",
 *  "сортировка": ["-Итог", "цена"]}
 * </pre>
 * Формулы вычисляются для каждой строки таблицы (как формула, протянутая по
 * столбцу в Excel); агрегаты (МИН/МАКС/СУММ/…) с именем колонки считаются по
 * всем строкам. Результат формулы доступен следующим формулам по имени.
 * «фильтр» — выражение-условие отбора строк; «сортировка» — имена колонок или
 * формул, префикс «-» означает по убыванию. Синтаксис формул —
 * {@link FormulaEvaluator}. Все вычисления — BigDecimal.
 */
public class ScenarioExecutorCalcNode extends AbstractScenarioExecutor {

    /**
     * Терпимый парсер: LLM изредка добавляет в JSON комментарии (# / //),
     * хвостовые запятые или одинарные кавычки — принимаем такой блок.
     */
    private static final ObjectMapper MAPPER = JsonMapper.builder()
            .enable(JsonReadFeature.ALLOW_JAVA_COMMENTS)
            .enable(JsonReadFeature.ALLOW_YAML_COMMENTS)
            .enable(JsonReadFeature.ALLOW_TRAILING_COMMA)
            .enable(JsonReadFeature.ALLOW_SINGLE_QUOTES)
            .build();
    private static final String DATA_MARKER = "ДАННЫЕ ДЛЯ РАСЧЁТА";
    private static final String RESULT_MARKER = "===РЕЗУЛЬТАТЫ РАСЧЁТА===";
    private static final Set<String> LABEL_KEYS = Set.of("название", "имя", "участник", "name", "строка");

    protected ScenarioExecutorCalcNode(ScenarioRunNode node) {
        super(node);
    }

    @Override
    public String execute(FluxSink<ServerSentEvent<Map<String, Object>>> sink) {
        Map<String, Object> config = parseJsonObject(node.getRules(),
                "Вычислительный узел: не задана конфигурация (настройте формулы в панели узла)");
        List<Map<String, Object>> formulas = listOfMaps(config.get("формулы"));
        if (formulas.isEmpty()) {
            throw new ScenarioException("Вычислительный узел: в конфигурации нет ни одной формулы");
        }
        String filter = str(config.get("фильтр"));
        List<String> sortKeys = sortKeys(config.get("сортировка"));
        String tableName = str(config.get("таблица"));
        String groupBy = str(config.get("группировка"));

        Data data = extractData(String.join("\n\n", node.getInput()), tableName);
        List<String> warnings = new ArrayList<>();

        // фильтр строк
        List<Map<String, Object>> rows = new ArrayList<>();
        List<String> excluded = new ArrayList<>();
        for (Map<String, Object> row : data.rows) {
            if (filter.isBlank() || truthy(FormulaEvaluator.evalRaw(filter,
                    context(row, Map.of(), data, data.rows, List.of(), warnings::add)))) {
                rows.add(row);
            } else {
                excluded.add(rowLabel(row, data.rows.indexOf(row)));
            }
        }
        if (rows.isEmpty()) {
            throw new ScenarioException("Вычислительный узел: после фильтра «" + filter
                    + "» не осталось ни одной строки данных");
        }

        // группировка: агрегаты (МИН/МАКС/СУММ/…) считаются в пределах группы
        // строки — например, по членам команды одного участника
        List<List<Integer>> groupOf = new ArrayList<>();
        for (int i = 0; i < rows.size(); i++) {
            List<Integer> idx = new ArrayList<>();
            if (groupBy.isBlank()) {
                for (int j = 0; j < rows.size(); j++) {
                    idx.add(j);
                }
            } else {
                Object my = fuzzyGet(rows.get(i), groupBy);
                for (int j = 0; j < rows.size(); j++) {
                    if (looseEquals(my, fuzzyGet(rows.get(j), groupBy))) {
                        idx.add(j);
                    }
                }
            }
            groupOf.add(idx);
        }

        // вычисления: формула за формулой, построчно — результат формулы доступен
        // следующим формулам и как колонка для агрегатов
        List<Map<String, Object>> computed = new ArrayList<>();
        for (int i = 0; i < rows.size(); i++) {
            computed.add(new LinkedHashMap<>());
        }
        for (Map<String, Object> f : formulas) {
            String name = str(f.getOrDefault("имя", f.getOrDefault("название", "результат")));
            String expr = str(f.get("формула")).trim();
            if (expr.isBlank()) {
                throw new ScenarioException("Вычислительный узел: у показателя «" + name + "» пустая формула");
            }
            for (int i = 0; i < rows.size(); i++) {
                final int rowIdx = i;
                List<Map<String, Object>> groupRows = new ArrayList<>();
                List<Map<String, Object>> groupComputed = new ArrayList<>();
                for (int j : groupOf.get(i)) {
                    groupRows.add(rows.get(j));
                    groupComputed.add(computed.get(j));
                }
                BigDecimal value = FormulaEvaluator.eval(expr, context(rows.get(i), computed.get(i), data,
                        groupRows, groupComputed, m -> warnings.add(
                                "строка «" + rowLabel(rows.get(rowIdx), rowIdx) + "»: " + m)));
                computed.get(i).put(name, value);
            }
        }

        // сортировка по колонкам/формулам («-имя» — по убыванию)
        List<Integer> order = new ArrayList<>();
        for (int i = 0; i < rows.size(); i++) {
            order.add(i);
        }
        if (!sortKeys.isEmpty() && data.tabular) {
            order.sort(sortComparator(sortKeys, rows, computed));
        }

        String result = buildReport(data, rows, computed, order, formulas, excluded, warnings, sortKeys, groupBy, groupOf);
        prompt = "[вычислительный узел — расчёт по формулам выполнен кодом, без обращения к GigaChat]";
        node.getOutput().add(result);
        var input = prepareNextInput();
        for (var next : node.getChildNodeList()) {
            next.setSkip(false);
            next.getInput().addAll(input);
        }
        return result;
    }

    // ------------------------------------------------------------------
    // Контекст переменных для вычислителя
    // ------------------------------------------------------------------

    private FormulaEvaluator.Context context(Map<String, Object> row,
                                             Map<String, Object> computedRow,
                                             Data data,
                                             List<Map<String, Object>> rowsForColumns,
                                             List<Map<String, Object>> allComputed,
                                             java.util.function.Consumer<String> warn) {
        return new FormulaEvaluator.Context() {
            @Override
            public Object variable(String name) {
                Object v = fuzzyGet(computedRow, name);
                if (v == null) {
                    v = fuzzyGet(row, name);
                }
                if (v == null) {
                    v = fuzzyGet(data.globals, name);
                }
                return v;
            }

            @Override
            public List<Object> column(String name) {
                // колонка вычисленных формул либо исходных данных — по строкам,
                // прошедшим фильтр (исключённые не участвуют в МИН/МАКС/СУММ)
                if (!allComputed.isEmpty() && fuzzyGet(allComputed.get(0), name) != null) {
                    return allComputed.stream().map(m -> fuzzyGet(m, name)).toList();
                }
                if (fuzzyGet(row, name) != null && data.tabular) {
                    return rowsForColumns.stream().map(m -> fuzzyGet(m, name)).toList();
                }
                return null;
            }

            @Override
            public void warn(String message) {
                warn.accept(message);
            }

            @Override
            public Object lookup(String table, String keyColumn, Object keyValue, String valueColumn) {
                List<Map<String, Object>> rows = null;
                for (var e : data.tables.entrySet()) {
                    if (normalize(e.getKey()).equals(normalize(table))) {
                        rows = e.getValue();
                        break;
                    }
                }
                if (rows == null) {
                    return null;
                }
                for (Map<String, Object> r : rows) {
                    if (looseEquals(keyValue, fuzzyGet(r, keyColumn))) {
                        return fuzzyGet(r, valueColumn);
                    }
                }
                return null;
            }
        };
    }

    /**
     * Нестрогое сравнение значений: числа — по величине, строки — без учёта
     * регистра, пробелов и пунктуации (названия участников в разных таблицах
     * могут отличаться видом кавычек и тире).
     */
    private static boolean looseEquals(Object a, Object b) {
        if (a == null || b == null) {
            return a == b;
        }
        String sa = String.valueOf(a);
        String sb = String.valueOf(b);
        if (sa.equals(sb)) {
            return true;
        }
        return normalizeLoose(sa).equals(normalizeLoose(sb));
    }

    private static String normalizeLoose(String s) {
        StringBuilder sb = new StringBuilder();
        for (char c : s.toLowerCase(Locale.ROOT).toCharArray()) {
            if (Character.isLetterOrDigit(c)) {
                sb.append(c == 'ё' ? 'е' : c);
            }
        }
        return sb.toString();
    }

    /**
     * Поиск значения по имени: точное, «_»→пробел, затем без учёта
     * регистра/пробелов/подчёркиваний/ё.
     */
    private static Object fuzzyGet(Map<String, Object> map, String key) {
        if (map == null || map.isEmpty()) {
            return null;
        }
        if (map.containsKey(key)) {
            return map.get(key);
        }
        String spaced = key.replace('_', ' ');
        if (map.containsKey(spaced)) {
            return map.get(spaced);
        }
        String normalized = normalize(key);
        for (var e : map.entrySet()) {
            if (normalize(e.getKey()).equals(normalized)) {
                return e.getValue();
            }
        }
        return null;
    }

    private static String normalize(String s) {
        return s.toLowerCase(Locale.ROOT).replace(" ", "").replace("_", "").replace("ё", "е");
    }

    private static boolean truthy(Object v) {
        if (v instanceof BigDecimal b) {
            return b.signum() != 0;
        }
        return v != null && !String.valueOf(v).isBlank();
    }

    // ------------------------------------------------------------------
    // Извлечение данных из входа
    // ------------------------------------------------------------------

    /**
     * Данные расчёта: строки основной таблицы (или одна строка для плоского
     * объекта), общие переменные и реестр всех таблиц входа (для функции ВПР).
     */
    private record Data(List<Map<String, Object>> rows, Map<String, Object> globals, boolean tabular,
                        Map<String, List<Map<String, Object>>> tables) {
    }

    private Data extractData(String input, String tableName) {
        int at = input.lastIndexOf(DATA_MARKER);
        String search = at >= 0 ? input.substring(at + DATA_MARKER.length()) : input;
        // перебираем НЕвложенные JSON-объекты слева направо (вложенные пропускаются
        // прыжком через сбалансированный блок); реестр таблиц собирается по всем
        // объектам, основная таблица — из последнего пригодного (или по имени)
        Data found = null;
        Map<String, List<Map<String, Object>>> tables = new LinkedHashMap<>();
        int i = 0;
        while (i < search.length()) {
            if (search.charAt(i) != '{') {
                i++;
                continue;
            }
            int end = balancedEnd(search, i);
            if (end < 0) {
                i++;
                continue;
            }
            try {
                Map<String, Object> candidate = parseJsonObject(
                        sanitizeDecimalCommas(search.substring(i, end + 1)), "json");
                for (var e : candidate.entrySet()) {
                    if (e.getValue() instanceof List<?> list && !list.isEmpty()
                            && list.stream().allMatch(o -> o instanceof Map)) {
                        List<Map<String, Object>> flat = new ArrayList<>();
                        for (Map<String, Object> raw : listOfMaps(e.getValue())) {
                            flat.add(flatten(raw));
                        }
                        tables.put(e.getKey(), flat);
                    }
                }
                Data data = toData(candidate);
                if (data != null) {
                    found = data;
                }
            } catch (Exception ignored) {
                // не JSON — идём дальше
            }
            i = end + 1;
        }
        if (!tableName.isBlank()) {
            for (var e : tables.entrySet()) {
                if (normalize(e.getKey()).equals(normalize(tableName))) {
                    Map<String, Object> globals = found != null ? found.globals : Map.of();
                    return new Data(e.getValue(), globals, true, tables);
                }
            }
            throw new ScenarioException("Вычислительный узел: во входных данных нет таблицы «"
                    + tableName + "». Найдены таблицы: " + tables.keySet());
        }
        if (found != null) {
            return new Data(found.rows, found.globals, found.tabular, tables);
        }
        throw new ScenarioException("Вычислительный узел: во входных данных не найден JSON со значениями "
                + "(блок «" + DATA_MARKER + "») — предыдущий узел должен выдать извлечённые данные "
                + "в формате JSON");
    }

    /**
     * Превращает JSON-объект в данные расчёта: первый ключ с непустым массивом
     * объектов становится таблицей (вложенные объекты строк расплющиваются
     * в колонки), остальные скалярные поля — общими переменными. Если массива
     * нет, скалярные поля образуют единственную строку.
     */
    private Data toData(Map<String, Object> candidate) {
        List<Map<String, Object>> tableRaw = null;
        Map<String, Object> globals = new LinkedHashMap<>();
        for (var e : candidate.entrySet()) {
            if (tableRaw == null && e.getValue() instanceof List<?> list && !list.isEmpty()
                    && list.stream().allMatch(o -> o instanceof Map)) {
                tableRaw = listOfMaps(e.getValue());
            } else if (e.getValue() instanceof Number || e.getValue() instanceof String) {
                globals.put(e.getKey(), e.getValue());
            }
        }
        if (tableRaw != null) {
            List<Map<String, Object>> rows = new ArrayList<>();
            for (Map<String, Object> raw : tableRaw) {
                rows.add(flatten(raw));
            }
            return new Data(rows, globals, true, Map.of());
        }
        if (!globals.isEmpty() && globals.values().stream().anyMatch(v -> v instanceof Number
                || v instanceof String s && FormulaTypes.isNumeric(s))) {
            return new Data(List.of(new LinkedHashMap<>(globals)), Map.of(), false, Map.of());
        }
        return null;
    }

    /** Расплющивает строку таблицы: вложенные объекты (например, «показатели») — в колонки. */
    private static Map<String, Object> flatten(Map<String, Object> raw) {
        Map<String, Object> row = new LinkedHashMap<>();
        for (var e : raw.entrySet()) {
            if (e.getValue() instanceof Map<?, ?> nested) {
                for (var n : nested.entrySet()) {
                    row.put(String.valueOf(n.getKey()), n.getValue());
                }
            } else if (!(e.getValue() instanceof List)) {
                row.put(e.getKey(), e.getValue());
            }
        }
        return row;
    }

    /** Утилита распознавания числовых строк («1 234,5» — число). */
    private static final class FormulaTypes {
        static boolean isNumeric(String s) {
            try {
                new BigDecimal(s.trim().replace(" ", "").replace(",", "."));
                return true;
            } catch (NumberFormatException e) {
                return false;
            }
        }
    }

    // ------------------------------------------------------------------
    // Сортировка и отчёт
    // ------------------------------------------------------------------

    private List<String> sortKeys(Object raw) {
        List<String> keys = new ArrayList<>();
        if (raw instanceof String s && !s.isBlank()) {
            keys.add(s.trim());
        } else if (raw instanceof List<?> list) {
            for (Object o : list) {
                String s = String.valueOf(o).trim();
                if (!s.isEmpty()) {
                    keys.add(s);
                }
            }
        }
        return keys;
    }

    private Comparator<Integer> sortComparator(List<String> sortKeys,
                                               List<Map<String, Object>> rows,
                                               List<Map<String, Object>> computed) {
        Comparator<Integer> cmp = null;
        for (String rawKey : sortKeys) {
            boolean desc = rawKey.startsWith("-");
            String key = desc ? rawKey.substring(1).trim() : rawKey;
            Comparator<Integer> byKey = Comparator.comparing(i -> sortValue(key, rows.get(i), computed.get(i)),
                    (a, b) -> {
                        BigDecimal na = a instanceof BigDecimal x ? x : null;
                        BigDecimal nb = b instanceof BigDecimal y ? y : null;
                        if (na != null && nb != null) {
                            return na.compareTo(nb);
                        }
                        return String.valueOf(a).compareTo(String.valueOf(b));
                    });
            if (desc) {
                byKey = byKey.reversed();
            }
            cmp = cmp == null ? byKey : cmp.thenComparing(byKey);
        }
        return cmp;
    }

    private Object sortValue(String key, Map<String, Object> row, Map<String, Object> computedRow) {
        Object v = fuzzyGet(computedRow, key);
        if (v == null) {
            v = fuzzyGet(row, key);
        }
        if (v == null) {
            throw new ScenarioException("Вычислительный узел: колонка сортировки «" + key
                    + "» не найдена ни среди данных, ни среди формул");
        }
        if (v instanceof BigDecimal) {
            return v;
        }
        if (v instanceof Number n) {
            return new BigDecimal(n.toString());
        }
        if (v instanceof String s && FormulaTypes.isNumeric(s)) {
            return new BigDecimal(s.trim().replace(" ", "").replace(",", "."));
        }
        return String.valueOf(v);
    }

    private static String rowLabel(Map<String, Object> row, int index) {
        for (String k : LABEL_KEYS) {
            Object v = fuzzyGet(row, k);
            if (v instanceof String s && !s.isBlank()) {
                return s;
            }
        }
        for (var e : row.entrySet()) {
            if (e.getValue() instanceof String s && !s.isBlank() && !FormulaTypes.isNumeric(s)) {
                return s;
            }
        }
        return "строка " + (index + 1);
    }

    private String buildReport(Data data,
                               List<Map<String, Object>> rows,
                               List<Map<String, Object>> computed,
                               List<Integer> order,
                               List<Map<String, Object>> formulas,
                               List<String> excluded,
                               List<String> warnings,
                               List<String> sortKeys,
                               String groupBy,
                               List<List<Integer>> groupOf) {
        StringBuilder out = new StringBuilder("## Расчёт по формулам (вычислительный узел, без LLM)\n\n");

        if (data.tabular) {
            out.append("### Исходные данные — строк: ").append(rows.size());
            if (!excluded.isEmpty()) {
                out.append(", исключено фильтром: ").append(excluded.size())
                        .append(" (").append(String.join(", ", excluded)).append(")");
            }
            out.append("\n\n");
            Set<String> cols = new LinkedHashSet<>();
            rows.forEach(r -> cols.addAll(r.keySet()));
            out.append("| Строка |");
            cols.forEach(c -> out.append(" ").append(c).append(" |"));
            out.append("\n|---|").append("---|".repeat(cols.size())).append("\n");
            for (int i = 0; i < rows.size(); i++) {
                out.append("| ").append(rowLabel(rows.get(i), i)).append(" |");
                for (String c : cols) {
                    out.append(" ").append(cell(rows.get(i).get(c))).append(" |");
                }
                out.append("\n");
            }
            out.append("\n### Вычисления\n\n| Строка |");
            for (var f : formulas) {
                out.append(" ").append(str(f.getOrDefault("имя", "результат"))).append(" |");
            }
            out.append("\n|---|").append("---|".repeat(formulas.size())).append("\n");
            for (int idx : order) {
                out.append("| ").append(rowLabel(rows.get(idx), idx)).append(" |");
                for (var f : formulas) {
                    Object v = computed.get(idx).get(str(f.getOrDefault("имя", "результат")));
                    out.append(" **").append(cell(v)).append("** |");
                }
                out.append("\n");
            }
            if (!sortKeys.isEmpty()) {
                out.append("\nСтроки упорядочены по: ").append(String.join(", ", sortKeys))
                        .append(" («-» — по убыванию); первая строка — лучшая по заданной сортировке.\n");
            }
            if (!groupBy.isBlank()) {
                out.append("\n### Свод по группам («").append(groupBy).append("»)\n\n| ")
                        .append(groupBy).append(" |");
                for (var f : formulas) {
                    out.append(" ").append(str(f.getOrDefault("имя", "результат"))).append(" |");
                }
                out.append("\n|---|").append("---|".repeat(formulas.size())).append("\n");
                Set<String> seen = new LinkedHashSet<>();
                for (int i = 0; i < rows.size(); i++) {
                    String key = str(fuzzyGet(rows.get(i), groupBy));
                    if (!seen.add(normalizeLoose(key))) {
                        continue;
                    }
                    out.append("| ").append(key).append(" |");
                    for (var f : formulas) {
                        Object v = computed.get(i).get(str(f.getOrDefault("имя", "результат")));
                        out.append(" **").append(cell(v)).append("** |");
                    }
                    out.append("\n");
                }
            }
        } else {
            Map<String, Object> row = rows.get(0);
            out.append("### Исходные значения\n\n| Показатель | Значение |\n|---|---|\n");
            for (var e : row.entrySet()) {
                out.append("| ").append(e.getKey()).append(" | ").append(cell(e.getValue())).append(" |\n");
            }
            out.append("\n### Вычисления\n\n| Показатель | Формула | Результат |\n|---|---|---|\n");
            for (var f : formulas) {
                String name = str(f.getOrDefault("имя", "результат"));
                out.append("| ").append(name).append(" | `").append(str(f.get("формула")).trim())
                        .append("` | **").append(cell(computed.get(0).get(name))).append("** |\n");
            }
        }

        if (!warnings.isEmpty()) {
            out.append("\n### ⚠️ Предупреждения\n\n");
            for (String w : new LinkedHashSet<>(warnings)) {
                out.append("- ").append(w).append("\n");
            }
        }

        // машиночитаемые результаты для следующих узлов ({{json:Метка:путь}})
        out.append("\n").append(RESULT_MARKER).append("\n");
        try {
            if (data.tabular) {
                List<Map<String, Object>> jsonRows = new ArrayList<>();
                for (int idx : order) {
                    Map<String, Object> jr = new LinkedHashMap<>();
                    jr.put("строка", rowLabel(rows.get(idx), idx));
                    if (!groupBy.isBlank()) {
                        jr.put(groupBy, fuzzyGet(rows.get(idx), groupBy));
                    }
                    computed.get(idx).forEach((k, v) -> jr.put(k, cell(v)));
                    jsonRows.add(jr);
                }
                Map<String, Object> jsonOut = new LinkedHashMap<>();
                jsonOut.put("строки", jsonRows);
                if (!groupBy.isBlank()) {
                    // по одной записи на группу — для ВПР из следующего узла «Расчёт»
                    List<Map<String, Object>> jsonGroups = new ArrayList<>();
                    Set<String> seen = new LinkedHashSet<>();
                    for (int i = 0; i < rows.size(); i++) {
                        String key = str(fuzzyGet(rows.get(i), groupBy));
                        if (!seen.add(normalizeLoose(key))) {
                            continue;
                        }
                        Map<String, Object> jg = new LinkedHashMap<>();
                        jg.put(groupBy, key);
                        computed.get(i).forEach((k, v) -> jg.put(k, cell(v)));
                        jsonGroups.add(jg);
                    }
                    jsonOut.put("группы", jsonGroups);
                }
                out.append(MAPPER.writeValueAsString(jsonOut));
            } else {
                Map<String, Object> jr = new LinkedHashMap<>();
                computed.get(0).forEach((k, v) -> jr.put(k, cell(v)));
                out.append(MAPPER.writeValueAsString(jr));
            }
        } catch (Exception e) {
            out.append("{}");
        }
        out.append("\n");
        return out.toString();
    }

    private static String cell(Object v) {
        if (v == null) {
            return "—";
        }
        if (v instanceof BigDecimal b) {
            return fmtPlain(b);
        }
        if (v instanceof Number n) {
            return fmtPlain(new BigDecimal(n.toString()));
        }
        return String.valueOf(v);
    }

    /**
     * Число без экспоненты и без хвостовых нулей: 1080360.000 → 1080360; 0.850 → 0.85.
     */
    private static String fmtPlain(BigDecimal v) {
        BigDecimal s = v.stripTrailingZeros();
        if (s.scale() < 0) {
            s = s.setScale(0);
        }
        if (s.scale() > 6) {
            s = s.setScale(6, java.math.RoundingMode.HALF_UP).stripTrailingZeros();
        }
        return s.toPlainString();
    }

    // ------------------------------------------------------------------
    // Разбор JSON
    // ------------------------------------------------------------------

    /**
     * Чинит десятичные запятые в числах JSON («: 18196721,31» → «: 18196721.31»):
     * модели на русском регулярно пишут запятую как разделитель дробной части.
     * Замена выполняется только вне строковых значений.
     */
    private static String sanitizeDecimalCommas(String json) {
        StringBuilder sb = new StringBuilder(json.length());
        boolean inString = false;
        for (int i = 0; i < json.length(); i++) {
            char c = json.charAt(i);
            if (inString) {
                sb.append(c);
                if (c == '\\' && i + 1 < json.length()) {
                    sb.append(json.charAt(++i));
                } else if (c == '"') {
                    inString = false;
                }
                continue;
            }
            if (c == '"') {
                inString = true;
                sb.append(c);
            } else if (c == ',' && i > 0 && i + 1 < json.length()
                    && Character.isDigit(json.charAt(i - 1))
                    && Character.isDigit(json.charAt(i + 1))) {
                sb.append('.');
            } else {
                sb.append(c);
            }
        }
        return sb.toString();
    }

    private static int balancedEnd(String text, int start) {
        int depth = 0;
        boolean inString = false;
        for (int i = start; i < text.length(); i++) {
            char c = text.charAt(i);
            if (inString) {
                if (c == '\\') {
                    i++;
                } else if (c == '"') {
                    inString = false;
                }
                continue;
            }
            if (c == '"') {
                inString = true;
            } else if (c == '{') {
                depth++;
            } else if (c == '}') {
                depth--;
                if (depth == 0) {
                    return i;
                }
            }
        }
        return -1;
    }

    @SuppressWarnings("unchecked")
    private Map<String, Object> parseJsonObject(Object raw, String errorMessage) {
        try {
            if (raw instanceof Map) {
                return (Map<String, Object>) raw;
            }
            if (raw instanceof String s && !s.isBlank()) {
                return MAPPER.readValue(s, Map.class);
            }
        } catch (Exception e) {
            throw new ScenarioException(errorMessage + ": " + e.getMessage());
        }
        throw new ScenarioException(errorMessage);
    }

    @SuppressWarnings("unchecked")
    private static List<Map<String, Object>> listOfMaps(Object raw) {
        if (raw instanceof List<?> list) {
            List<Map<String, Object>> result = new ArrayList<>();
            for (Object o : list) {
                if (o instanceof Map) {
                    result.add((Map<String, Object>) o);
                }
            }
            return result;
        }
        return List.of();
    }

    private static String str(Object v) {
        return v == null ? "" : String.valueOf(v);
    }
}
