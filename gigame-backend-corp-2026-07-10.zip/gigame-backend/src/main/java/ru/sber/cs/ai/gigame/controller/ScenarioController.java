package ru.sber.cs.ai.gigame.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.codec.ServerSentEvent;
import org.springframework.http.codec.multipart.FilePart;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;
import ru.sber.cs.ai.gigame.dto.ErrorResponse;
import ru.sber.cs.ai.gigame.dto.scenario.ScenarioCreate;
import ru.sber.cs.ai.gigame.dto.scenario.ScenarioDetailResponse;
import ru.sber.cs.ai.gigame.dto.scenario.ScenarioResponse;
import ru.sber.cs.ai.gigame.dto.scenario.ScenarioRunDetailResponse;
import ru.sber.cs.ai.gigame.dto.scenario.ScenarioRunResponse;
import ru.sber.cs.ai.gigame.dto.scenario.ScenarioUpdate;
import ru.sber.cs.ai.gigame.exception.FileException;
import ru.sber.cs.ai.gigame.service.DocsTextCacheService;
import ru.sber.cs.ai.gigame.service.scenario.DocumentText;
import ru.sber.cs.ai.gigame.service.scenario.ScenarioEngine;
import ru.sber.cs.ai.gigame.service.scenario.ScenarioService;

import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Контроллер для управления сценариями (AI-workflow).
 * <p>
 * Сценарии представляют собой графы узлов (input, output, loop, switch, if_node),
 * которые выполняются последовательно для обработки документов с использованием AI.
 */
@Slf4j
@RestController
@RequestMapping("/api/scenarios")
@RequiredArgsConstructor
@Tag(name = "scenarios", description = "Управление AI-сценариями (workflow)")
@SuppressWarnings("unused")
public class ScenarioController {

    static final int MAX_FILES_PER_REQUEST = 100;

    private final ScenarioService scenarioService;
    private final ScenarioEngine scenarioEngine;
    private final DocsTextCacheService docsTextCacheService;

    /**
     * Список всех сценариев.
     * <p>
     * Возвращает список всех доступных сценариев с краткой информацией.
     *
     * @param userId Идентификатор пользователя (из заголовка X-UserId)
     * @return Список сценариев
     */
    @GetMapping
    @Operation(
            summary = "Получить список сценариев",
            description = "Возвращает список всех доступных сценариев с их базовыми метаданными.",
            responses = {
                    @ApiResponse(responseCode = "200",
                            description = "Список сценариев получен успешно",
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    array = @ArraySchema(maxItems = 1000, schema = @Schema(implementation = ScenarioResponse.class)))),
                    @ApiResponse(responseCode = "400",
                            description = "Неверные данные запроса",
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ErrorResponse.class)))})
    public Mono<List<ScenarioResponse>> listScenarios(
            @RequestHeader(name = "X-UserId", required = false)
            @Parameter(
                    name = "X-UserId",
                    in = ParameterIn.HEADER,
                    schema = @Schema(type = "string", pattern = "^[A-Z0-9]{0,16}$")
            )
            String userId) {
        return Mono.fromCallable(() -> scenarioService.getScenarios(userId))
                .subscribeOn(Schedulers.boundedElastic());
    }

    /**
     * Создание нового сценария.
     * <p>
     * Создаёт новый сценарий с заданным названием, описанием и графом выполнения.
     *
     * @param userId Идентификатор пользователя (из заголовка X-UserId)
     * @param body   Данные для создания сценария
     * @return Созданный сценарий
     */
    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    @Operation(
            summary = "Создать новый сценарий",
            description = """
                    Создаёт новый AI-сценарий с заданным графом выполнения.
                    
                    ## Структура graph_data:
                    
                    ```json
                    {
                      "nodes": [
                        {
                          "id": "node-id",
                          "type": "input|output|loop|switch|if_node",
                          "data": { ... }
                        }
                      ],
                      "edges": [
                        {
                          "source": "node-id-1",
                          "target": "node-id-2",
                          "data": { ... }
                        }
                      ]
                    }
                    ```
                    
                    ## Типы узлов:
                    - `input` — входной узел для документа
                    - `output` — выходной узел для результата
                    - `loop` — цикл по документам
                    - `switch` — условное ветвление
                    - `if_node` — условная проверка
                    """,
            responses = {
                    @ApiResponse(responseCode = "201",
                            description = "Сценарий успешно создан",
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ScenarioResponse.class))
                    ),
                    @ApiResponse(responseCode = "400",
                            description = "Неверные данные запроса",
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ErrorResponse.class)))})
    public Mono<ScenarioResponse> createScenario(
            @RequestHeader(name = "X-UserId", required = false)
            @Parameter(
                    name = "X-UserId",
                    in = ParameterIn.HEADER,
                    schema = @Schema(type = "string", pattern = "^[A-Z0-9]{0,16}$")
            )
            String userId,
            @Parameter(description = "Данные для создания сценария",
                    content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                            schema = @Schema(implementation = ScenarioCreate.class)))
            @RequestBody ScenarioCreate body) {
        return Mono.fromCallable(() -> scenarioService.createScenario(userId, body.name(), body.description(), body.graphData()))
                .subscribeOn(Schedulers.boundedElastic());
    }

    /**
     * Получение сценария с деталями.
     * <p>
     * Возвращает полную информацию о сценарии, включая граф выполнения.
     *
     * @param userId Идентификатор пользователя (из заголовка X-UserId)
     * @param id     Идентификатор сценария
     * @return Детальная информация о сценарии
     */
    @GetMapping("/{id}")
    @Operation(
            summary = "Получить сценарий с деталями",
            description = "Возвращает сценарий с полным графом выполнения и всеми метаданными.",
            responses = {
                    @ApiResponse(responseCode = "200",
                            description = "Сценарий найден",
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ScenarioDetailResponse.class))
                    ),
                    @ApiResponse(responseCode = "400",
                            description = "Неверные данные запроса",
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ErrorResponse.class))
                    ),
                    @ApiResponse(responseCode = "404",
                            description = "Сценарий не найден",
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ErrorResponse.class)))})
    public Mono<ScenarioDetailResponse> getScenario(
            @RequestHeader(name = "X-UserId", required = false)
            @Parameter(
                    name = "X-UserId",
                    in = ParameterIn.HEADER,
                    schema = @Schema(type = "string", pattern = "^[A-Z0-9]{0,16}$")
            )
            String userId,
            @Parameter(description = "Уникальный идентификатор сценария (UUID)",
                    schema = @Schema(type = "string", pattern = "^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"))
            @PathVariable UUID id) {
        return Mono.fromCallable(() -> scenarioService.getScenario(userId, id))
                .subscribeOn(Schedulers.boundedElastic());
    }

    /**
     * Обновление сценария.
     * <p>
     * Обновляет название, описание и граф выполнения существующего сценария.
     *
     * @param userId Идентификатор пользователя (из заголовка X-UserId)
     * @param id     Идентификатор сценария
     * @param body   Новые данные сценария
     * @return Обновлённый сценарий
     */
    @PutMapping("/{id}")
    @Operation(
            summary = "Обновить сценарий",
            description = "Обновляет название, описание и граф выполнения существующего сценария.",
            responses = {
                    @ApiResponse(responseCode = "200",
                            description = "Сценарий успешно обновлён",
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ScenarioResponse.class))
                    ),
                    @ApiResponse(responseCode = "400",
                            description = "Неверные данные запроса",
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ErrorResponse.class))
                    ),
                    @ApiResponse(responseCode = "404",
                            description = "Сценарий не найден",
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ErrorResponse.class)))})
    public Mono<ScenarioResponse> updateScenario(
            @RequestHeader(name = "X-UserId", required = false)
            @Parameter(
                    name = "X-UserId",
                    in = ParameterIn.HEADER,
                    schema = @Schema(type = "string", pattern = "^[A-Z0-9]{0,16}$")
            )
            String userId,
            @Parameter(description = "Уникальный идентификатор сценария (UUID)",
                    schema = @Schema(type = "string", pattern = "^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"))
            @PathVariable UUID id,
            @Parameter(description = "Новые данные сценария",
                    content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                            schema = @Schema(implementation = ScenarioUpdate.class)))
            @RequestBody ScenarioUpdate body) {
        return Mono.fromCallable(() -> scenarioService.updateScenario(userId, id, body.name(), body.description(), body.graphData()))
                .subscribeOn(Schedulers.boundedElastic());
    }

    /**
     * Удаление сценария.
     * <p>
     * Удаляет сценарий и все связанные с ним результаты выполнения.
     *
     * @param userId Идентификатор пользователя (из заголовка X-UserId)
     * @param id     Идентификатор сценария
     */
    @DeleteMapping("/{id}")
    @Operation(
            summary = "Удалить сценарий",
            description = "Удаляет сценарий и все связанные с ним результаты выполнения. Операция необратима.",
            responses = {
                    @ApiResponse(responseCode = "204",
                            description = "Сценарий успешно удален"
                    ),
                    @ApiResponse(responseCode = "400",
                            description = "Неверные данные запроса",
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ErrorResponse.class))
                    ),
                    @ApiResponse(responseCode = "404",
                            description = "Сценарий не найден",
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ErrorResponse.class)))})
    public Mono<ResponseEntity<Void>> deleteScenario(
            @RequestHeader(name = "X-UserId", required = false)
            @Parameter(
                    name = "X-UserId",
                    in = ParameterIn.HEADER,
                    schema = @Schema(type = "string", pattern = "^[A-Z0-9]{0,16}$")
            )
            String userId,
            @Parameter(description = "Уникальный идентификатор сценария (UUID)",
                    schema = @Schema(type = "string", pattern = "^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"))
            @PathVariable UUID id) {
        return Mono.fromRunnable(() -> scenarioService.deleteScenario(userId, id))
                .subscribeOn(Schedulers.boundedElastic())
                .then(Mono.just(ResponseEntity.noContent().build()));
    }

    /**
     * Дублирование сценария.
     * <p>
     * Создаёт копию сценария с добавлением " (копия)" к названию.
     *
     * @param userId Идентификатор пользователя (из заголовка X-UserId)
     * @param id     Идентификатор исходного сценария
     * @return Скопированный сценарий
     */
    @PostMapping("/{id}/duplicate")
    @Operation(
            summary = "Дублировать сценарий",
            description = "Создаёт копию сценария с названием с добавлением ' (копия)'.",
            responses = {
                    @ApiResponse(responseCode = "200",
                            description = "Сценарий успешно скопирован",
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ScenarioResponse.class))
                    ),
                    @ApiResponse(responseCode = "400",
                            description = "Неверные данные запроса",
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ErrorResponse.class))
                    ),
                    @ApiResponse(responseCode = "404",
                            description = "Сценарий не найден",
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ErrorResponse.class)))})
    public Mono<ScenarioResponse> duplicateScenario(
            @RequestHeader(name = "X-UserId", required = false)
            @Parameter(
                    name = "X-UserId",
                    in = ParameterIn.HEADER,
                    schema = @Schema(type = "string", pattern = "^[A-Z0-9]{0,16}$")
            )
            String userId,
            @Parameter(description = "Уникальный идентификатор сценария (UUID)",
                    schema = @Schema(type = "string", pattern = "^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"))
            @PathVariable UUID id) {
        return Mono.fromCallable(() -> scenarioService.duplicateScenario(userId, id))
                .subscribeOn(Schedulers.boundedElastic());
    }

    /**
     * Список выполнений сценария.
     * <p>
     * Возвращает историю всех выполнений заданного сценария.
     *
     * @param userId Идентификатор пользователя (из заголовка X-UserId)
     * @param id     Идентификатор сценария
     * @return Список выполнений
     */
    @GetMapping("/{id}/runs")
    @Operation(
            summary = "Получить список выполнений сценария",
            description = "Возвращает историю всех выполнений сценария с их статусами и датами.",
            responses = {
                    @ApiResponse(responseCode = "200",
                            description = "Список выполнений получен успешно",
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    array = @ArraySchema(maxItems = 1000, schema = @Schema(implementation = ScenarioRunResponse.class)))),
                    @ApiResponse(responseCode = "400",
                            description = "Неверные данные запроса",
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ErrorResponse.class))
                    ),
                    @ApiResponse(responseCode = "404",
                            description = "Сценарий не найден",
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ErrorResponse.class)))})
    public Mono<List<ScenarioRunResponse>> listRuns(
            @RequestHeader(name = "X-UserId", required = false)
            @Parameter(
                    name = "X-UserId",
                    in = ParameterIn.HEADER,
                    schema = @Schema(type = "string", pattern = "^[A-Z0-9]{0,16}$")
            )
            String userId,
            @Parameter(description = "Уникальный идентификатор сценария (UUID)",
                    schema = @Schema(type = "string", pattern = "^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"))
            @PathVariable UUID id) {
        return Mono.fromCallable(() -> scenarioService.getScenarioRuns(userId, id))
                .subscribeOn(Schedulers.boundedElastic());
    }

    /**
     * Запуск сценария с потоковой передачей.
     * <p>
     * Выполняет сценарий и возвращает поток SSE-событий в реальном времени.
     * Поддерживает загрузку документов и пошаговый режим выполнения.
     *
     * @param userId   Идентификатор пользователя (из заголовка X-UserId)
     * @param id       Идентификатор сценария
     * @param fileFlux Поток файлов для обработки
     * @param stepMode Включить пошаговый режим (для отладки)
     * @return Поток SSE-событий, содержащий статус выполнения, прогресс, результаты шагов
     */
    @PostMapping(value = "/{id}/run",
            consumes = MediaType.MULTIPART_FORM_DATA_VALUE,
            produces = MediaType.TEXT_EVENT_STREAM_VALUE)
    @Operation(
            summary = "Запустить сценарий (SSE поток)",
            description = """
                    Выполняет сценарий с потоковой передачей событий в реальном времени.
                    
                    ## SSE-события:
                    
                    - `{"type": "status", "status": "running|completed|failed"}` — общий статус
                    - `{"type": "node_status", ...}` — статус узла (running/completed/skipped/failed)
                    - `{"type": "step_complete", ...}` — завершение шага
                    - `{"type": "step_paused", ...}` — пауза в пошаговом режиме
                    - `{"type": "upload_progress", ...}` — прогресс загрузки файлов
                    - `{"type": "upload_done", "count": N}` — завершение загрузки
                    - `{"type": "loop_progress", ...}` — прогресс цикла
                    - `{"type": "rag_search", ...}` — поиск по базе знаний
                    
                    ## Загрузка файлов (multipart/form-data):
                    
                    - `files` (array): Массив файлов для обработки (необязательно)
                    - `step_mode` (bool): Включить пошаговый режим для отладки (необязательно)
                    
                    ## Пошаговый режим:
                    
                    При `step_mode=true` выполнение останавливается после каждого узла.
                    Для продолжения используйте endpoint `/runs/{runId}/continue`.
                    """,
            responses = {
                    @ApiResponse(responseCode = "200",
                            description = "Выполнение сценария началось",
                            content = @Content(mediaType = MediaType.TEXT_EVENT_STREAM_VALUE,
                                    schema = @Schema(implementation = String.class,
                                            pattern = "^[\\w\\W]{0,4096}$"))
                    ),
                    @ApiResponse(responseCode = "400",
                            description = "Неверные данные запроса",
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ErrorResponse.class))
                    ),
                    @ApiResponse(responseCode = "404",
                            description = "Сценарий не найден",
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ErrorResponse.class)))})
    public Flux<ServerSentEvent<Map<String, Object>>> runScenario(
            @RequestHeader(name = "X-UserId", required = false)
            @Parameter(
                    name = "X-UserId",
                    in = ParameterIn.HEADER,
                    schema = @Schema(type = "string", pattern = "^[A-Z0-9]{0,16}$")
            )
            String userId,
            @Parameter(description = "Уникальный идентификатор сценария (UUID)",
                    schema = @Schema(type = "string", pattern = "^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"))
            @PathVariable UUID id,
            @Parameter(description = "Файлы для обработки (необязательные)",
                    array = @ArraySchema(
                            maxItems = 100,
                            schema = @Schema(
                                    type = "string",
                                    format = "binary",
                                    pattern = "^(1(01*0)*1|0)+$",
                                    description = "Файлы в формате binary")))
            @RequestPart(value = "files", required = false)
            Flux<FilePart> fileFlux,
            @Parameter(description = "Включить пошаговый режим для отладки (необязательно)",
                    schema = @Schema(implementation = boolean.class), example = "false")
            @RequestParam(value = "step_mode", required = false)
            Boolean stepMode) {

        // Сначала собираем файлы, затем выполняем все блокирующие операции на boundedElastic
        Mono<List<FilePart>> filesMono = fileFlux != null
                ? fileFlux.collectList()
                : Mono.just(List.of());

        return filesMono.flatMapMany(files -> {
            if (files.size() > MAX_FILES_PER_REQUEST) {
                var errorText = "Превышено максимальное количество файлов: " + files.size()
                        + ". Максимум: " + MAX_FILES_PER_REQUEST;
                log.error(errorText);
                return Flux.error(new ResponseStatusException(HttpStatus.UNPROCESSABLE_ENTITY, errorText));
            }
            return Flux.defer(() -> {
                if (!files.isEmpty()) {
                    cacheDocuments(id, files);
                }
                return scenarioService.runScenario(userId, id, stepMode);
                // разбор файлов блокирующий (block() в getDocuments) — уводим с Netty-потока
            }).subscribeOn(Schedulers.boundedElastic());
        });
    }


    /**
     * Детальная информация о выполнении.
     * <p>
     * Возвращает полную информацию о конкретном выполнении сценария,
     * включая все шаги и их результаты.
     *
     * @param userId Идентификатор пользователя (из заголовка X-UserId)
     * @param runId  Идентификатор выполнения
     * @return Детальная информация о выполнении
     */
    @GetMapping("/runs/{runId}")
    @Operation(
            summary = "Получить детальную информацию о выполнении",
            description = "Возвращает полную информацию о выполнении сценария, включая все шаги, " +
                    "их входные/выходные данные и статусы.",
            responses = {
                    @ApiResponse(responseCode = "200",
                            description = "Информация о выполнении получена",
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ScenarioRunDetailResponse.class))
                    ),
                    @ApiResponse(responseCode = "400",
                            description = "Неверные данные запроса",
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ErrorResponse.class))
                    ),
                    @ApiResponse(responseCode = "404",
                            description = "Выполнение не найдено",
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ErrorResponse.class)))})
    public Mono<ScenarioRunDetailResponse> getRunDetail(
            @RequestHeader(name = "X-UserId", required = false)
            @Parameter(
                    name = "X-UserId",
                    in = ParameterIn.HEADER,
                    schema = @Schema(type = "string", pattern = "^[A-Z0-9]{0,16}$")
            )
            String userId,
            @Parameter(description = "Уникальный идентификатор выполнения (UUID)",
                    schema = @Schema(type = "string", pattern = "^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"))
            @PathVariable UUID runId) {
        return Mono.fromCallable(() -> scenarioService.getScenarioRun(userId, runId))
                .subscribeOn(Schedulers.boundedElastic());
    }

    /**
     * Продолжение выполнения из паузы.
     * <p>
     * Продолжает выполнение после паузы в пошаговом режиме.
     *
     * @param userId Идентификатор пользователя (из заголовка X-UserId)
     * @param runId  Идентификатор выполнения
     */
    @PostMapping("/runs/{runId}/continue")
    @Operation(
            summary = "Продолжить выполнение из паузы",
            description = "Продолжает выполнение сценария после паузы в пошаговом режиме. " +
                    "Вызовите этот endpoint, когда получили событие `step_paused`.",
            responses = {
                    @ApiResponse(responseCode = "200",
                            description = "Выполнение продолжено"
                    ),
                    @ApiResponse(responseCode = "400",
                            description = "Неверные данные запроса",
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ErrorResponse.class))
                    ),
                    @ApiResponse(responseCode = "404",
                            description = "Выполнение не найдено",
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ErrorResponse.class)))})
    public Mono<Void> continueRun(
            @RequestHeader(name = "X-UserId", required = false)
            @Parameter(
                    name = "X-UserId",
                    in = ParameterIn.HEADER,
                    schema = @Schema(type = "string", pattern = "^[A-Z0-9]{0,16}$")
            )
            String userId,
            @Parameter(description = "Уникальный идентификатор выполнения (UUID)",
                    schema = @Schema(type = "string", pattern = "^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"))
            @PathVariable UUID runId) {
        return Mono.fromRunnable(() -> scenarioEngine.continueStep(runId.toString()))
                .subscribeOn(Schedulers.boundedElastic()).then();
    }

    /**
     * Отключение пошагового режима.
     * <p>
     * Отключает пошаговый режим и продолжает выполнение до конца.
     *
     * @param userId Идентификатор пользователя (из заголовка X-UserId)
     * @param runId  Идентификатор выполнения
     */
    @PostMapping("/runs/{runId}/disable-step-mode")
    @Operation(
            summary = "Отключить пошаговый режим",
            description = "Отключает пошаговый режим и продолжает выполнение до завершения. " +
                    "Все оставшиеся шаги будут выполнены без пауз.",
            responses = {
                    @ApiResponse(responseCode = "200",
                            description = "Пошаговый режим отключён"
                    ),
                    @ApiResponse(responseCode = "400",
                            description = "Неверные данные запроса",
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ErrorResponse.class))
                    ),
                    @ApiResponse(responseCode = "404",
                            description = "Выполнение не найдено",
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ErrorResponse.class)))})
    public Mono<Void> disableStepMode(
            @RequestHeader(name = "X-UserId", required = false)
            @Parameter(
                    name = "X-UserId",
                    in = ParameterIn.HEADER,
                    schema = @Schema(type = "string", pattern = "^[A-Z0-9]{0,16}$")
            )
            String userId,
            @Parameter(description = "Уникальный идентификатор выполнения (UUID)",
                    schema = @Schema(type = "string", pattern = "^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"))
            @PathVariable UUID runId) {
        return Mono.fromRunnable(() -> scenarioEngine.disableStepMode(runId.toString()))
                .subscribeOn(Schedulers.boundedElastic()).then();
    }

    /**
     * Загрузка файлов в кэш сценария.
     * <p>
     * Загружает файлы и сохраняет их в кэше по идентификатору сценария.
     * Файлы можно затем использовать при запуске сценария через endpoint /{id}/run.
     *
     * @param userId   Идентификатор пользователя (из заголовка X-UserId)
     * @param id       Идентификатор сценария
     * @param fileFlux Поток файлов для загрузки
     */
    @PostMapping(value = "/{id}/upload",
            consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @Operation(
            summary = "Загрузить файлы в кэш сценария",
            description = """
                    Загружает файлы и сохраняет их в кэше по идентификатору сценария.
                    Файлы не обрабатываются, а только сохраняются для последующего использования.
                    Endpoint не возвращает ответ.
                    """,
            responses = {
                    @ApiResponse(responseCode = "200",
                            description = "Файлы успешно загружены в кэш"
                    ),
                    @ApiResponse(responseCode = "400",
                            description = "Неверные данные запроса",
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ErrorResponse.class))
                    ),
                    @ApiResponse(responseCode = "404",
                            description = "Сценарий не найден",
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ErrorResponse.class)))})
    public Mono<Void> uploadFiles(
            @RequestHeader(name = "X-UserId", required = false)
            @Parameter(
                    name = "X-UserId",
                    in = ParameterIn.HEADER,
                    schema = @Schema(type = "string", pattern = "^[A-Z0-9]{0,16}$")
            )
            String userId,
            @Parameter(description = "Уникальный идентификатор сценария (UUID)",
                    schema = @Schema(type = "string", pattern = "^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"))
            @PathVariable UUID id,
            @Parameter(description = "Файлы для загрузки",
                    array = @ArraySchema(
                            maxItems = 100,
                            schema = @Schema(
                                    type = "string",
                                    format = "binary",
                                    pattern = "^(1(01*0)*1|0)+$",
                                    description = "Файлы в формате binary")))
            @RequestPart(value = "files")
            Flux<FilePart> fileFlux) {
        return Mono.fromCallable(() -> {
            // Сначала проверяем, что сценарий существует, затем собираем файлы
            scenarioService.getScenario(userId, id);
            List<FilePart> files = fileFlux != null
                    ? fileFlux.collectList().block()
                    : List.of();
            assert files != null;
            log.debug("Обработка {} файла(ов) для загрузки", files.size());
            if (files.size() > MAX_FILES_PER_REQUEST) {
                var errorText = "Превышено максимальное количество файлов: " + files.size()
                        + ". Максимум: " + MAX_FILES_PER_REQUEST;
                log.error(errorText);
                throw new FileException(errorText);
            }
            docsTextCacheService.clearCache(id);
            cacheDocuments(id, files);
            log.debug("Обработка {} файла(ов) для загрузки", files.size());
            return (Void) null;
        }).subscribeOn(Schedulers.boundedElastic());
    }

    /**
     * Разбирает файлы (с распаковкой ZIP) и кладёт документы в кэш сценария.
     * Тексты и имена берутся из одного списка — при распаковке архива
     * один файл может дать несколько документов.
     */
    private void cacheDocuments(UUID id, List<FilePart> files) {
        var documents = scenarioService.getDocuments(files, null);
        docsTextCacheService.cacheDocumentTexts(id,
                documents.stream().map(DocumentText::text).toList(),
                documents.stream().map(DocumentText::filename).toList(),
                List.of());
    }

    /**
     * Экспорт результата выполнения в DOCX.
     * <p>
     * Генерирует Word-документ с результатами выполнения сценария.
     *
     * @param userId Идентификатор пользователя (из заголовка X-UserId)
     * @param runId  Идентификатор выполнения
     * @return DOCX файл с результатами
     */
    @GetMapping("/runs/{runId}/export")
    @Operation(
            summary = "Экспортировать результат в DOCX",
            description = "Генерирует Word-документ (.docx) с полной информацией о выполнении: " +
                    "статус, все шаги, их результаты и итоговый результат.",
            responses = {
                    @ApiResponse(responseCode = "200",
                            description = "DOCX файл сгенерирован",
                            content = @Content(mediaType = "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                                    schema = @Schema(implementation = String.class,
                                            pattern = "^[\\w\\W]{0,4096}$"))
                    ),
                    @ApiResponse(responseCode = "400",
                            description = "Неверные данные запроса",
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ErrorResponse.class))
                    ),
                    @ApiResponse(responseCode = "404",
                            description = "Выполнение не найдено",
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ErrorResponse.class)))})
    public ResponseEntity<Resource> exportRun(
            @RequestHeader(name = "X-UserId", required = false)
            @Parameter(
                    name = "X-UserId",
                    in = ParameterIn.HEADER,
                    schema = @Schema(type = "string", pattern = "^[A-Z0-9]{0,16}$")
            )
            String userId,
            @Parameter(description = "Уникальный идентификатор выполнения (UUID)",
                    schema = @Schema(type = "string", pattern = "^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"))
            @PathVariable UUID runId,
            @Parameter(description = "Включить в файл все шаги выполнения (полные тексты "
                    + "документов и промежуточные результаты — получаются сотни страниц). "
                    + "По умолчанию выгружается только итоговый результат.")
            @RequestParam(value = "include_steps", required = false, defaultValue = "false")
            boolean includeSteps) {
        return scenarioService.extractToDocx(userId, runId, includeSteps);
    }

    /**
     * Возобновление упавшего прогона с места сбоя.
     * Результаты завершённых LLM-узлов восстанавливаются из шагов исходного прогона —
     * повторно оплачиваются только невыполненные узлы.
     *
     * @param userId идентификатор пользователя (из заголовка X-UserId)
     * @param runId  идентификатор упавшего прогона
     * @return поток SSE-событий нового прогона
     */
    @PostMapping(value = "/runs/{runId}/resume", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
    @Operation(
            summary = "Возобновить упавший прогон (SSE поток)",
            description = "Создаёт новый прогон, восстанавливая результаты завершённых LLM-узлов "
                    + "из шагов исходного; выполняются только оставшиеся узлы.")
    public Flux<ServerSentEvent<Map<String, Object>>> resumeRun(
            @RequestHeader(name = "X-UserId", required = false)
            @Parameter(
                    name = "X-UserId",
                    in = ParameterIn.HEADER,
                    schema = @Schema(type = "string", pattern = "^[A-Z0-9]{0,16}$")
            )
            String userId,
            @Parameter(description = "Уникальный идентификатор прогона (UUID)",
                    schema = @Schema(type = "string", pattern = "^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"))
            @PathVariable UUID runId) {
        return scenarioService.resumeScenarioRun(userId, runId);
    }

    /**
     * Список версий сценария.
     *
     * @param userId идентификатор пользователя (из заголовка X-UserId)
     * @param id     идентификатор сценария
     * @return версии от новых к старым (номер, имя, дата)
     */
    @GetMapping("/{id}/versions")
    @Operation(summary = "Версии сценария",
            description = "История сохранений: снапшот создаётся перед каждым изменением сценария.")
    public Mono<List<Map<String, Object>>> listVersions(
            @RequestHeader(name = "X-UserId", required = false)
            @Parameter(
                    name = "X-UserId",
                    in = ParameterIn.HEADER,
                    schema = @Schema(type = "string", pattern = "^[A-Z0-9]{0,16}$")
            )
            String userId,
            @Parameter(description = "Уникальный идентификатор сценария (UUID)",
                    schema = @Schema(type = "string", pattern = "^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"))
            @PathVariable UUID id) {
        return Mono.fromCallable(() -> scenarioService.getVersions(userId, id))
                .subscribeOn(Schedulers.boundedElastic());
    }

    /**
     * Восстановление сценария из версии.
     *
     * @param userId    идентификатор пользователя (из заголовка X-UserId)
     * @param id        идентификатор сценария
     * @param versionNo номер версии
     * @return обновлённый сценарий
     */
    @PostMapping("/{id}/versions/{versionNo}/restore")
    @Operation(summary = "Восстановить версию сценария",
            description = "Текущее состояние предварительно сохраняется как новая версия.")
    public Mono<ScenarioResponse> restoreVersion(
            @RequestHeader(name = "X-UserId", required = false)
            @Parameter(
                    name = "X-UserId",
                    in = ParameterIn.HEADER,
                    schema = @Schema(type = "string", pattern = "^[A-Z0-9]{0,16}$")
            )
            String userId,
            @Parameter(description = "Уникальный идентификатор сценария (UUID)",
                    schema = @Schema(type = "string", pattern = "^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"))
            @PathVariable UUID id,
            @Parameter(description = "Номер версии", schema = @Schema(type = "integer"))
            @PathVariable int versionNo) {
        return Mono.fromCallable(() -> scenarioService.restoreVersion(userId, id, versionNo))
                .subscribeOn(Schedulers.boundedElastic());
    }
}
