package ru.sber.cs.ai.gigame.service.scenario.executor;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.http.codec.ServerSentEvent;
import reactor.core.publisher.FluxSink;
import ru.sber.cs.ai.gigame.exception.ScenarioException;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunNode;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;
import java.util.stream.Collectors;

/**
 * Узел «Трансформация»: детерминированные операции над текстом без LLM.
 * <p>
 * Вход — тексты документов узла (если подключены) либо результаты предыдущих узлов.
 * Конфигурация — в поле rules узла (настраивается формой в UI):
 * <pre>
 * {"операции": [
 *   {"оп": "извлечь_regex", "шаблон": "№\\s*(\\d+)", "группа": 1, "все": true, "разделитель": "\n"},
 *   {"оп": "заменить", "найти": "...", "на": "...", "regex": false},
 *   {"оп": "оставить_строки", "шаблон": "..."},
 *   {"оп": "удалить_строки", "шаблон": "..."},
 *   {"оп": "json_поле", "путь": "участники[0].название"},
 *   {"оп": "слить_json_массивы"},
 *   {"оп": "взять_символы", "от": 0, "до": 1000},
 *   {"оп": "первые_строки", "n": 20},
 *   {"оп": "последние_строки", "n": 20}
 * ]}
 * </pre>
 * Операции применяются по цепочке сверху вниз.
 */
public class ScenarioExecutorTransformNode extends AbstractScenarioExecutor {

    private static final ObjectMapper MAPPER = new ObjectMapper();

    protected ScenarioExecutorTransformNode(ScenarioRunNode node) {
        super(node);
    }

    @Override
    public String execute(FluxSink<ServerSentEvent<Map<String, Object>>> sink) {
        String text = inputText();
        List<Map<String, Object>> operations = parseOperations();
        StringBuilder logView = new StringBuilder("[трансформация без LLM]\n");
        for (Map<String, Object> op : operations) {
            String name = String.valueOf(op.get("оп"));
            text = apply(name, op, text);
            logView.append("- ").append(name).append(" → ").append(text.length()).append(" символов\n");
        }
        prompt = logView.toString();
        node.getOutput().add(text);
        var input = prepareNextInput();
        for (var next : node.getChildNodeList()) {
            next.setSkip(false);
            next.getInput().addAll(input);
        }
        return text;
    }

    private String inputText() {
        if (!node.getDocList().isEmpty()) {
            return node.getDocList().stream()
                    .map(id -> node.getGraph().getDocMap().get(id).getText())
                    .collect(Collectors.joining("\n\n"));
        }
        return String.join("\n\n", node.getInput());
    }

    @SuppressWarnings("unchecked")
    private List<Map<String, Object>> parseOperations() {
        Object raw = node.getRules();
        try {
            Map<String, Object> config;
            if (raw instanceof Map) {
                config = (Map<String, Object>) raw;
            } else if (raw instanceof String s && !s.isBlank()) {
                config = MAPPER.readValue(s, Map.class);
            } else {
                throw new ScenarioException("Узел «Трансформация»: не заданы операции (настройте узел в панели)");
            }
            Object ops = config.get("операции");
            if (!(ops instanceof List<?> list) || list.isEmpty()) {
                throw new ScenarioException("Узел «Трансформация»: список операций пуст");
            }
            List<Map<String, Object>> result = new ArrayList<>();
            for (Object o : list) {
                if (o instanceof Map) {
                    result.add((Map<String, Object>) o);
                }
            }
            return result;
        } catch (ScenarioException e) {
            throw e;
        } catch (Exception e) {
            throw new ScenarioException("Узел «Трансформация»: не удалось разобрать конфигурацию: " + e.getMessage());
        }
    }

    private String apply(String name, Map<String, Object> op, String text) {
        try {
            return switch (name) {
                case "извлечь_regex" -> extractRegex(op, text);
                case "заменить" -> replaceOp(op, text);
                case "оставить_строки" -> filterLines(op, text, true);
                case "удалить_строки" -> filterLines(op, text, false);
                case "json_поле" -> jsonField(op, text);
                case "слить_json_массивы" -> mergeJsonArrays(text);
                case "взять_символы" -> substringOp(op, text);
                case "первые_строки" -> headTail(op, text, true);
                case "последние_строки" -> headTail(op, text, false);
                default -> throw new ScenarioException("Узел «Трансформация»: неизвестная операция «" + name + "»");
            };
        } catch (PatternSyntaxException e) {
            throw new ScenarioException("Узел «Трансформация», операция «" + name
                    + "»: некорректное регулярное выражение: " + e.getDescription());
        }
    }

    private String extractRegex(Map<String, Object> op, String text) {
        Pattern p = Pattern.compile(String.valueOf(op.get("шаблон")), Pattern.MULTILINE);
        int group = op.get("группа") == null ? 0 : Integer.parseInt(String.valueOf(op.get("группа")));
        boolean all = Boolean.parseBoolean(String.valueOf(op.getOrDefault("все", "true")));
        String sep = String.valueOf(op.getOrDefault("разделитель", "\n"));
        Matcher m = p.matcher(text);
        List<String> found = new ArrayList<>();
        while (m.find()) {
            found.add(m.group(Math.min(group, m.groupCount())));
            if (!all) {
                break;
            }
        }
        return String.join(sep, found);
    }

    private String replaceOp(Map<String, Object> op, String text) {
        String find = String.valueOf(op.get("найти"));
        String repl = String.valueOf(op.getOrDefault("на", ""));
        boolean regex = Boolean.parseBoolean(String.valueOf(op.getOrDefault("regex", "false")));
        return regex ? text.replaceAll(find, repl) : text.replace(find, repl);
    }

    private String filterLines(Map<String, Object> op, String text, boolean keep) {
        Pattern p = Pattern.compile(String.valueOf(op.get("шаблон")));
        return Arrays.stream(text.split("\n", -1))
                .filter(line -> p.matcher(line).find() == keep)
                .collect(Collectors.joining("\n"));
    }

    /**
     * Сливает все JSON-массивы объектов из входного текста в один массив.
     * <p>
     * Детерминированная замена LLM-слиянию: результаты нескольких групп/итераций
     * (каждая выдала свой JSON-массив) объединяются в порядке появления во входе.
     * Числа с десятичной запятой чинятся. Если ни одного массива не найдено —
     * ошибка узла.
     */
    private String mergeJsonArrays(String text) {
        List<Object> merged = new ArrayList<>();
        int arrays = 0;
        int i = 0;
        while (i < text.length()) {
            if (text.charAt(i) != '[') {
                i++;
                continue;
            }
            int end = ru.sber.cs.ai.gigame.utils.JsonCalcUtils.balancedEnd(text, i);
            if (end < 0) {
                i++;
                continue;
            }
            try {
                List<?> arr = MAPPER.readValue(
                        ru.sber.cs.ai.gigame.utils.JsonCalcUtils.sanitizeDecimalCommas(text.substring(i, end + 1)),
                        List.class);
                boolean hasObjects = arr.stream().anyMatch(Map.class::isInstance);
                if (hasObjects) {
                    for (Object o : arr) {
                        if (o instanceof Map) {
                            merged.add(o);
                        }
                    }
                    arrays++;
                    i = end + 1;
                    continue;
                }
            } catch (Exception ignored) {
                // не JSON-массив — ищем дальше
            }
            i++;
        }
        if (arrays == 0) {
            throw new ScenarioException("Узел «Трансформация», операция «слить_json_массивы»: "
                    + "во входе не найдено ни одного JSON-массива объектов");
        }
        try {
            return MAPPER.writerWithDefaultPrettyPrinter().writeValueAsString(merged);
        } catch (Exception e) {
            throw new ScenarioException("Узел «Трансформация»: не удалось сериализовать объединённый массив: "
                    + e.getMessage());
        }
    }

    private String jsonField(Map<String, Object> op, String text) {
        String path = String.valueOf(op.get("путь"));
        // переиспользуем механику выражений: {{json:...}} по текущему тексту
        return ExpressionResolver.extractJsonPathFromText(text, path);
    }

    private String substringOp(Map<String, Object> op, String text) {
        int from = op.get("от") == null ? 0 : Integer.parseInt(String.valueOf(op.get("от")));
        int to = op.get("до") == null ? text.length() : Integer.parseInt(String.valueOf(op.get("до")));
        from = Math.max(0, Math.min(from, text.length()));
        to = Math.max(from, Math.min(to, text.length()));
        return text.substring(from, to);
    }

    private String headTail(Map<String, Object> op, String text, boolean head) {
        int n = op.get("n") == null ? 10 : Integer.parseInt(String.valueOf(op.get("n")));
        String[] lines = text.split("\n", -1);
        if (lines.length <= n) {
            return text;
        }
        String[] slice = head
                ? Arrays.copyOfRange(lines, 0, n)
                : Arrays.copyOfRange(lines, lines.length - n, lines.length);
        return String.join("\n", slice);
    }
}
