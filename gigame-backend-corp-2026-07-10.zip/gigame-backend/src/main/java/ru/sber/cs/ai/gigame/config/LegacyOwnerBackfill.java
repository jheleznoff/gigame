package ru.sber.cs.ai.gigame.config;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * Backfill владельца для легаси-записей: строки с {@code user_id = NULL}
 * (созданные до появления изоляции пользователей) не проходят ни одну
 * проверку владения ({@code UserUtils.checkUserId}) — ими не может управлять
 * никто, включая создателя.
 * <p>
 * Выполняется после liquibase (таблицы гарантированно существуют),
 * идемпотентно ({@code WHERE user_id IS NULL}). В preliquibase такой backfill
 * невозможен: на пустой БД таблиц ещё нет.
 */
@Component
@RequiredArgsConstructor
@Slf4j
public class LegacyOwnerBackfill implements ApplicationRunner {

    private static final List<String> TABLES = List.of("knowledge_bases", "conversations", "documents");

    private final JdbcTemplate jdbcTemplate;

    @Override
    public void run(ApplicationArguments args) {
        for (String table : TABLES) {
            try {
                int updated = jdbcTemplate.update(
                        "UPDATE " + table + " SET user_id = 'anonymous' WHERE user_id IS NULL");
                if (updated > 0) {
                    log.info("Backfill владельца: {} записей в {} получили user_id='anonymous'", updated, table);
                }
            } catch (Exception e) {
                log.warn("Backfill владельца для {} не выполнен: {}", table, e.getMessage());
            }
        }
    }
}
