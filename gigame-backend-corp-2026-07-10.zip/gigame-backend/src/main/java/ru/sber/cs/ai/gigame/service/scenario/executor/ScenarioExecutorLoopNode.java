package ru.sber.cs.ai.gigame.service.scenario.executor;

import org.springframework.http.codec.ServerSentEvent;
import reactor.core.publisher.FluxSink;
import ru.sber.cs.ai.gigame.service.GigaChatClient;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunNode;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static ru.sber.cs.ai.gigame.service.scenario.ScenarioEventEmission.emitLoopProgressEvent;

public class ScenarioExecutorLoopNode extends AbstractScenarioExecutor {
    private static final String PROMPT_STRICT_CLASSIFY = "Определи тип документа. Верни СТРОГО ОДНУ ФРАЗУ — название класса из списка: ";
    private static final String PROMPT_CLASSIFICATION_HINT = "\nПодсказка для классификации:\n";
    private static final String PROMPT_INSTRUCTION_SUFFIX = "\nНе пиши пояснений, не повторяй задание, не добавляй знаков препинания.\n\nДокумент:\n";
    private final GigaChatClient gigaChatClient;
    private int delayBetweenIterations;
    /**
     * Лимиты текста документа для классификации: начало (шапка/титул) + конец (подписи).
     * Полный текст для определения типа не нужен и расходует токены на больших документах.
     */
    private int classifyHeadChars = 5000;
    private int classifyTailChars = 2000;

    @SuppressWarnings("unused")
    protected ScenarioExecutorLoopNode(ScenarioRunNode node) {
        super(node);
        this.gigaChatClient = null;
        this.delayBetweenIterations = 1000;
    }

    protected ScenarioExecutorLoopNode(ScenarioRunNode node,
                                       GigaChatClient gigaChatClient) {
        super(node);
        this.gigaChatClient = gigaChatClient;
        this.delayBetweenIterations = 1000;
    }

    /**
     * Sets configuration value from Spring properties.
     * Called by ScenarioExecutorFactory after bean creation.
     */
    protected void setDelayBetweenIterations(int delayBetweenIterations) {
        this.delayBetweenIterations = delayBetweenIterations;
    }

    /**
     * Sets configuration values from Spring properties.
     * Called by ScenarioExecutorFactory after bean creation.
     */
    protected void setClassifyLimits(int classifyHeadChars, int classifyTailChars) {
        this.classifyHeadChars = classifyHeadChars;
        this.classifyTailChars = classifyTailChars;
    }

    private void delayBetweenIterations() {
        try {
            Thread.sleep(delayBetweenIterations);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    /**
     * Выполняет узел цикла (Loop).
     * <p>
     * Обрабатывает каждый документ отдельно. Два режима работы:
     * <ul>
     *   <li>classify_strict=true — строгая классификация: возвращает одно слово — класс документа</li>
     *   <li>classify_strict=false — анализ: полный промпт для свободного ответа</li>
     * </ul>
     *
     * @param sink поток SSE-событий
     * @return объединённый результат по всем документам
     */
    @Override
    public String execute(FluxSink<ServerSentEvent<Map<String, Object>>> sink) {
        if ("list".equals(node.getMode())) {
            return executeOverList(sink);
        }
        var docs = node.getDocList();
        boolean classifyStrict = node.isClassifyStrict();
        String classesHint = node.getClasses();
        List<String> loopResults = new ArrayList<>();
        for (int i = 0; i < docs.size(); i++) {
            if (classifyStrict) {
                loopResults.addAll(analyzeWithClassifyStrict(sink, classesHint, i));
            } else {
                loopResults.addAll(analyzeFull(sink, i));
            }

            // Задержка между итерациями (кроме последней)
            if (i < docs.size() - 1) {
                delayBetweenIterations();
            }
        }
        if (docs.isEmpty()) {
            loopResults.addAll(analyzeSimple(sink));
        }
        node.getOutput().addAll(loopResults);
        var input = prepareNextInput();
        for (var next : node.getChildNodeList()) {
            next.setSkip(false);
            next.getInput().addAll(input);
        }
        return String.join("\n\n", loopResults);
    }

    private List<String> analyzeFull(FluxSink<ServerSentEvent<Map<String, Object>>> sink, int i) {
        // Режим анализа: полный промпт, свободный ответ
        List<String> results = new ArrayList<>();
        var docId = node.getDocList().get(i);
        var doc = node.getGraph().getDocMap().get(docId);
        // Результаты предыдущих узлов (node.getInput()) включаются в контекст каждой итерации,
        // чтобы цикл мог обрабатывать документы с опорой на выход предшественника (например, эталон).
        var contextInput = String.join("\n\n", node.getInput());
        var analyzePrompt = buildPrompt(contextInput, doc.getText(), List.of(), false);
        assert gigaChatClient != null;
        String result = gigaChatClient.chatCompletion(List.of(
                Map.of("role", "user", "content", analyzePrompt)
        ), node.getModel(), node.getTemperature());
        prompt += "\n<<" + docId + ">>\n" + analyzePrompt;
        results.add("Документ " + docId + ":\n" + result);
        emitLoopProgressEvent(sink,
                node,
                i + 1,
                node.getDocList().size(),
                docId + " - " + doc.getFilename());
        return results;
    }

    private List<String> analyzeSimple(FluxSink<ServerSentEvent<Map<String, Object>>> sink) {
        List<String> results = new ArrayList<>();
        var inputList = node.getInput();
        if (!inputList.isEmpty()) {
            var analyzePrompt = buildPrompt("", inputList.get(0), List.of(), false);
            assert gigaChatClient != null;
            String result = gigaChatClient.chatCompletion(List.of(
                    Map.of("role", "user", "content", analyzePrompt)
            ), node.getModel(), node.getTemperature());
            prompt = analyzePrompt;
            results.add(result);
            emitLoopProgressEvent(sink, node, 1, 1, "");
        }
        return results;
    }

    private List<String> analyzeWithClassifyStrict(FluxSink<ServerSentEvent<Map<String, Object>>> sink, String classesHint, int i) {
        // Строгая классификация: однословное название класса
        // Если пользователь предоставил промпт, использовать его как контекст/инструкцию
        List<String> results = new ArrayList<>();
        var docId = node.getDocList().get(i);
        var doc = node.getGraph().getDocMap().get(docId);
        String userPrompt = node.getPrompt();
        StringBuilder sb = new StringBuilder();
        sb.append(PROMPT_STRICT_CLASSIFY).append(classesHint).append(".\n");
        if (!userPrompt.isBlank()) {
            sb.append(PROMPT_CLASSIFICATION_HINT).append(userPrompt).append("\n");
        }
        sb.append(PROMPT_INSTRUCTION_SUFFIX).append(truncateForClassification(doc.getText()));
        var analyzePrompt = sb.toString();

        assert gigaChatClient != null;
        String clsRaw = gigaChatClient.chatCompletion(List.of(
                Map.of("role", "user", "content", analyzePrompt)
        ), node.getModel(), node.getTemperature());
        prompt += "<<" + docId + ">>\n" + analyzePrompt;
        var cls = extractDocClass(classesHint, clsRaw);
        results.add("<<<" + docId + "|CLASS:" + cls + ">>>\n" +
                doc.getText() + "\n<<<END_" + docId + ">>>");
        emitLoopProgressEvent(sink,
                node,
                i + 1,
                node.getDocList().size(),
                docId + " - " + doc.getFilename() + " -> классифицирован как \"" + cls + "\"");
        doc.setDocClass(cls);
        return results;
    }

    /**
     * Режим «по списку»: итерация по элементам входа, а не по документам.
     * <p>
     * Элементы: если вход — JSON-массив, его элементы; иначе вход режется
     * по разделителю из поля value узла (по умолчанию «---»). Каждый элемент
     * обрабатывается промптом узла отдельно, с контекстом результатов
     * предыдущих узлов.
     *
     * @param sink поток SSE-событий
     * @return объединённый результат по всем элементам
     */
    private String executeOverList(FluxSink<ServerSentEvent<Map<String, Object>>> sink) {
        String inputAll = String.join("\n\n", node.getInput());
        List<String> items = splitItems(inputAll);
        List<String> loopResults = new ArrayList<>();
        var contextInput = String.join("\n\n", node.getInput());
        for (int i = 0; i < items.size(); i++) {
            var analyzePrompt = buildPrompt(contextInput, "Элемент " + (i + 1) + ":\n" + items.get(i),
                    List.of(), false);
            assert gigaChatClient != null;
            String result = gigaChatClient.chatCompletion(List.of(
                    Map.of("role", "user", "content", analyzePrompt)
            ), node.getModel(), node.getTemperature());
            prompt += "\n<<ITEM_" + (i + 1) + ">>\n" + analyzePrompt;
            loopResults.add("Элемент " + (i + 1) + ":\n" + result);
            emitLoopProgressEvent(sink, node, i + 1, items.size(),
                    "элемент " + (i + 1) + " из " + items.size());
            if (i < items.size() - 1) {
                delayBetweenIterations();
            }
        }
        node.getOutput().addAll(loopResults);
        var input = prepareNextInput();
        for (var next : node.getChildNodeList()) {
            next.setSkip(false);
            next.getInput().addAll(input);
        }
        return String.join("\n\n", loopResults);
    }

    /**
     * Разбивает вход на элементы: JSON-массив в конце входа либо разделитель.
     */
    private List<String> splitItems(String inputAll) {
        Object json = null;
        try {
            String probe = ExpressionResolver.extractJsonPathFromText(inputAll, "");
            // extractJsonPathFromText с пустым путём вернёт весь корень строкой
            if (probe.startsWith("[")) {
                json = new com.fasterxml.jackson.databind.ObjectMapper().readValue(probe, List.class);
            }
        } catch (Exception ignored) {
            // не JSON — разберём по разделителю
        }
        List<String> items = new ArrayList<>();
        if (json instanceof List<?> list && !list.isEmpty()) {
            for (Object o : list) {
                items.add(o instanceof String s ? s : String.valueOf(o));
            }
            return items;
        }
        String delimiter = node.getValue() == null || node.getValue().isBlank() ? "---" : node.getValue();
        for (String part : inputAll.split(java.util.regex.Pattern.quote(delimiter))) {
            if (!part.trim().isEmpty()) {
                items.add(part.trim());
            }
        }
        if (items.isEmpty()) {
            items.add(inputAll);
        }
        return items;
    }

    /**
     * Урезает текст документа для классификации: начало (титул, шапка) и конец (подписи).
     * Тип документа определяется по этим фрагментам; полный текст не нужен.
     *
     * @param text полный текст документа
     * @return урезанный текст либо исходный, если он короче лимитов
     */
    private String truncateForClassification(String text) {
        if (text == null || text.length() <= classifyHeadChars + classifyTailChars) {
            return text;
        }
        return text.substring(0, classifyHeadChars)
                + "\n\n[... середина документа пропущена для классификации ...]\n\n"
                + text.substring(text.length() - classifyTailChars);
    }

    private String extractDocClass(String classesHint, String clsRaw) {
        String cls = "UNKNOWN";
        if (clsRaw == null || clsRaw.trim().isEmpty()) {
            return cls;
        }
        for (String hintClass : List.of(classesHint.trim().split(","))) {
            if (clsRaw.trim().toLowerCase().contains(hintClass.trim().toLowerCase())) {
                cls = hintClass.trim();
                break;
            }
        }
        return cls;
    }
}
