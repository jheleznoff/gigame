package ru.sber.cs.ai.gigame.service;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.sber.cs.ai.gigame.model.Conversation;
import ru.sber.cs.ai.gigame.model.Message;
import ru.sber.cs.ai.gigame.repository.MessageRepository;

import java.util.List;
import java.util.Map;

@Service
public class MessageService {
    private final MessageRepository messageRepository;

    public MessageService(
            MessageRepository messageRepository) {
        this.messageRepository = messageRepository;
    }

    /**
     * Сохраняет сообщение ассистента в базе данных.
     *
     * @param conversation   диалог
     * @param content        текст ответа ассистента
     */
    @Transactional
    protected void saveAssistantMessage(Conversation conversation, String content) {
        saveAssistantMessage(conversation, content, null);
    }

    /**
     * Сохраняет сообщение ассистента с источниками RAG.
     *
     * @param conversation диалог
     * @param content      текст ответа ассистента
     * @param sources      источники RAG {document_id, document_name, snippet} или {@code null}
     */
    @Transactional
    protected void saveAssistantMessage(Conversation conversation, String content,
                                        List<Map<String, String>> sources) {
        Message assistantMessage = new Message();
        assistantMessage.setConversation(conversation);
        assistantMessage.setRole("assistant");
        assistantMessage.setContent(content);
        if (sources != null && !sources.isEmpty()) {
            assistantMessage.setSources(sources);
        }
        messageRepository.save(assistantMessage);
    }
}
