package ru.sber.cs.ai.gigame.service.scenario.executor;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.http.codec.ServerSentEvent;
import reactor.core.publisher.FluxSink;
import ru.sber.cs.ai.gigame.service.EmbeddingService;
import ru.sber.cs.ai.gigame.service.GigaChatClient;
import ru.sber.cs.ai.gigame.service.scenario.enums.ScenarioNodeType;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunNode;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;

import static ru.sber.cs.ai.gigame.service.scenario.ScenarioEventEmission.emitProcessingProgressEvent;
import static ru.sber.cs.ai.gigame.service.scenario.ScenarioEventEmission.emitRagSearchEvent;

@Slf4j
public class ScenarioExecutorProcessingNode extends AbstractScenarioExecutor {
    private static final int DETAILS_MAX_LENGTH = 200;

    /** Режим data.mode: документы обрабатываются группами, один LLM-вызов на группу. */
    static final String MODE_GROUP = "group";

    /** Дефолтный ключ группы: номер договора из пути/имени файла. */
    static final String DEFAULT_GROUP_REGEX = "(?iu)(?:договор|contract)\\s*[№#]?\\s*(\\d{5,})";

    private final GigaChatClient gigaChatClient;
    private final EmbeddingService embeddingService;
    private int ragQueryMaxLength;
    private int cacheShortQueryLength;

    @SuppressWarnings("unused")
    protected ScenarioExecutorProcessingNode(ScenarioRunNode node) {
        super(node);
        this.embeddingService = null;
        this.gigaChatClient = null;
        this.ragQueryMaxLength = 800;
        this.cacheShortQueryLength = 200;
    }

    protected ScenarioExecutorProcessingNode(ScenarioRunNode node,
                                             GigaChatClient gigaChatClient,
                                             EmbeddingService embeddingService) {
        super(node);
        this.embeddingService = embeddingService;
        this.gigaChatClient = gigaChatClient;
        this.ragQueryMaxLength = 800;
        this.cacheShortQueryLength = 200;
    }

    /**
     * Sets configuration values from Spring properties.
     * Called by ScenarioExecutorFactory after bean creation.
     */
    protected void setConfiguration(int pRagQueryMaxLength, int pCacheShortQueryLength) {
        this.ragQueryMaxLength = pRagQueryMaxLength;
        this.cacheShortQueryLength = pCacheShortQueryLength;
    }

    @Override
    public String execute(FluxSink<ServerSentEvent<Map<String, Object>>> sink) {
        // Узел обработки (с опциональным RAG)
        // Если предыдущий узел Switch отфильтровал документы для этого узла, использовать отфильтрованный набор
        var docs = node.getDocList();
        List<String> resultList;
        if (!docs.isEmpty() && MODE_GROUP.equals(node.getMode())) {
            // режим группировки: один LLM-вызов на группу документов (перекрёстные проверки)
            resultList = new ArrayList<>(processDocGroups(sink, docs));
        } else {
            resultList = new ArrayList<>(processDocList(sink, docs));
            if (docs.isEmpty()) {
                if (node.getParentNodeList().get(0).getType().equals(ScenarioNodeType.LOOP_NODE)) {
                    resultList.addAll(processInputList(sink));
                } else {
                    resultList.addAll(processSimpleInput(sink));
                }
            }
        }
        node.getOutput().addAll(resultList);
        var input = prepareNextInput();
        for (var next : node.getChildNodeList()) {
            next.setSkip(false);
            next.getInput().addAll(input);
        }
        return String.join("\n\n", resultList);
    }

    /**
     * Режим группировки документов: docList разбивается на группы по ключу
     * из имени файла (первая capture-группа регэкспа из {@code data.value};
     * при пустом значении — {@link #DEFAULT_GROUP_REGEX}, номер договора из пути).
     * Все документы группы попадают в один LLM-вызов (с именами файлов) —
     * это позволяет сверять документы группы между собой (договор ↔ спецификация ↔ акт).
     * Документ без совпадения с регэкспом образует отдельную группу по своему имени.
     */
    private List<String> processDocGroups(FluxSink<ServerSentEvent<Map<String, Object>>> sink, List<String> docs) {
        java.util.regex.Pattern pattern;
        String regex = node.getValue().isBlank() ? DEFAULT_GROUP_REGEX : node.getValue();
        try {
            pattern = java.util.regex.Pattern.compile(regex);
        } catch (java.util.regex.PatternSyntaxException e) {
            throw new ru.sber.cs.ai.gigame.exception.ScenarioException(
                    "Некорректный регэксп группировки документов: " + regex, e);
        }
        Map<String, List<String>> groups = new java.util.LinkedHashMap<>();
        for (String docId : docs) {
            var doc = node.getGraph().getDocMap().get(docId);
            String key = extractGroupKey(pattern, doc.getFilename());
            groups.computeIfAbsent(key, k -> new ArrayList<>()).add(docId);
        }
        List<String> resultList = new ArrayList<>();
        int groupIndex = 0;
        for (var entry : groups.entrySet()) {
            groupIndex++;
            String groupKey = entry.getKey();
            String docsBlock = buildGroupDocsBlock(groupKey, entry.getValue());
            var contextInput = String.join("\n\n", node.getInput());
            prompt = buildPrompt(contextInput, docsBlock,
                    getKbChunks(sink, "", docsBlock), ObjectUtils.isNotEmpty(node.getKnowledgeBaseId()));
            assert gigaChatClient != null;
            String result = gigaChatClient.chatCompletion(List.of(
                    Map.of("role", "user", "content", prompt)
            ), node.getModel(), node.getTemperature());
            resultList.add("=== Группа " + groupKey + " ===\n" + result);
            emitProcessingProgressEvent(sink,
                    node,
                    groupIndex,
                    groups.size(),
                    "Группа " + groupKey + " (" + entry.getValue().size() + " док.)");
        }
        return resultList;
    }

    /**
     * Собирает блок документов группы, укладываясь в {@code docCharLimit}.
     * <p>
     * Общая обрезка блока срезала бы документы, попавшие в конец (обычно акты —
     * самые важные для проверки). Вместо этого бюджет распределяется жадно:
     * документы обходятся по возрастанию длины, каждому выделяется его доля
     * остатка бюджета — короткие (акты, УПД) входят целиком, а излишек уходит
     * длинным (договор обрезается по остаточному бюджету с маркером обрезки).
     */
    private String buildGroupDocsBlock(String groupKey, List<String> docIds) {
        // запас на заголовки документов и маркеры, чтобы buildPrompt не обрезал блок повторно
        int overhead = 200 + docIds.size() * 150;
        int budget = Math.max(getDocCharLimit() - overhead, 1000);
        Map<String, Integer> caps = new java.util.HashMap<>();
        List<String> byLength = new ArrayList<>(docIds);
        byLength.sort(java.util.Comparator.comparingInt(
                id -> node.getGraph().getDocMap().get(id).getText().length()));
        int remaining = byLength.size();
        for (String docId : byLength) {
            int share = budget / Math.max(remaining, 1);
            int len = node.getGraph().getDocMap().get(docId).getText().length();
            int use = Math.min(len, share);
            caps.put(docId, use);
            budget -= use;
            remaining--;
        }
        StringBuilder docsBlock = new StringBuilder("Группа документов: " + groupKey);
        for (String docId : docIds) {
            var doc = node.getGraph().getDocMap().get(docId);
            String text = doc.getText();
            int cap = caps.getOrDefault(docId, text.length());
            if (text.length() > cap) {
                text = text.substring(0, cap) + "\n[... документ обрезан по лимиту контекста ...]";
            }
            docsBlock.append("\n\n<<<Документ: ").append(doc.getFilename()).append(">>>\n")
                    .append(text)
                    .append("\n<<<КОНЕЦ ДОКУМЕНТА>>>");
        }
        return docsBlock.toString();
    }

    private String extractGroupKey(java.util.regex.Pattern pattern, String filename) {
        var matcher = pattern.matcher(filename);
        if (matcher.find()) {
            String key = matcher.groupCount() >= 1 ? matcher.group(1) : matcher.group();
            if (key != null && !key.isBlank()) {
                return key;
            }
        }
        return filename;
    }

    private List<String> processSimpleInput(FluxSink<ServerSentEvent<Map<String, Object>>> sink) {
        List<String> resultList = new ArrayList<>();
        var input = String.join("\n\n", node.getInput());
        prompt = buildPrompt(input, "", getKbChunks(sink, input, ""), ObjectUtils.isNotEmpty(node.getKnowledgeBaseId()));
        assert gigaChatClient != null;
        resultList.add(gigaChatClient.chatCompletion(List.of(
                Map.of("role", "user", "content", prompt)
        ), node.getModel(), node.getTemperature()));
        var details = node.getInput().stream()
                .map(s -> StringUtils.abbreviate(s, DETAILS_MAX_LENGTH))
                .collect(Collectors.joining("\n\n"));
        emitProcessingProgressEvent(sink,
                node,
                1,
                1,
                details);
        return resultList;
    }

    private List<String> processInputList(FluxSink<ServerSentEvent<Map<String, Object>>> sink) {
        List<String> resultList = new ArrayList<>();
        for (int i = 0; i < node.getInput().size(); i++) {
            var input = node.getInput().get(i);
            prompt = buildPrompt(input, "", getKbChunks(sink, input, ""), ObjectUtils.isNotEmpty(node.getKnowledgeBaseId()));
            assert gigaChatClient != null;
            resultList.add(gigaChatClient.chatCompletion(List.of(
                    Map.of("role", "user", "content", prompt)
            ), node.getModel(), node.getTemperature()));
            emitProcessingProgressEvent(sink,
                    node,
                    i + 1,
                    node.getInput().size(),
                    StringUtils.abbreviate(input, DETAILS_MAX_LENGTH));
        }
        return resultList;
    }

    private List<String> processDocList(FluxSink<ServerSentEvent<Map<String, Object>>> sink, List<String> docs) {
        List<String> resultList = new ArrayList<>();
        for (int i = 0; i < docs.size(); i++) {
            var docId = docs.get(i);
            var doc = node.getGraph().getDocMap().get(docId);
            var docText = doc.getText();
            // Результаты предыдущих узлов включаются в контекст наряду с документами узла
            var contextInput = String.join("\n\n", node.getInput());
            prompt = buildPrompt(contextInput, docText, getKbChunks(sink, "", docText), ObjectUtils.isNotEmpty(node.getKnowledgeBaseId()));
            assert gigaChatClient != null;
            resultList.add(gigaChatClient.chatCompletion(List.of(
                    Map.of("role", "user", "content", prompt)
            ), node.getModel(), node.getTemperature()));
            emitProcessingProgressEvent(sink,
                    node,
                    i + 1,
                    node.getDocList().size(),
                    docId + " - " + doc.getFilename());
        }
        return resultList;
    }

    private List<String> getKbChunks(FluxSink<ServerSentEvent<Map<String, Object>>> sink,
                                     String input,
                                     String docText) {
        List<String> kbChunks = List.of();
        if (ObjectUtils.isNotEmpty(node.getKnowledgeBaseId())) {
            try {
                kbChunks = ragSearchForNode(input, docText, node.getKnowledgeBaseId());
            } catch (Exception e) {
                log.error("RAG не удался для узла {} {}", node.getId(), e.getMessage());
                kbChunks = List.of();
            }
            emitRagSearchEvent(sink, node, kbChunks.size());
        }
        return kbChunks;
    }

    /**
     * Выполняет RAG-поиск для узла по базе знаний.
     * <p>
     * Собирает запрос из предыдущего вывода или промпта узла.
     * Кэширует эмбеддинги в рамках одного выполнения.
     *
     * @param previousOutput предыдущий вывод
     * @param documentText   текст документа
     * @param kbId           идентификатор базы знаний
     * @return список релевантных фрагментов из базы знаний
     */
    private List<String> ragSearchForNode(String previousOutput,
                                          String documentText,
                                          UUID kbId) {
        // Build query: prefer previous_output, fall back to prompt, then documents_text
        String query = previousOutput;
        if (query.isEmpty()) {
            query = node.getPrompt();
        }
        if (query.isEmpty()) {
            query = documentText;
        }
        if (query.length() > ragQueryMaxLength) {
            query = query.substring(0, ragQueryMaxLength);
        }
        if (query.isEmpty()) {
            return List.of();
        }

        try {
            String cacheKey = query.length() <= cacheShortQueryLength ? query : String.valueOf(query.hashCode());
            float[] embedding;
            var embeddingCache = node.getGraph().getEmbeddingCache();
            if (embeddingCache != null && embeddingCache.containsKey(cacheKey)) {
                embedding = embeddingCache.get(cacheKey);
            } else {
                assert gigaChatClient != null;
                embedding = gigaChatClient.getEmbeddings(List.of(query)).get(0);
                if (embeddingCache != null) {
                    embeddingCache.put(cacheKey, embedding);
                }
            }
            assert embeddingService != null;
            List<String> chunks = embeddingService.searchSimilar("kb", kbId, embedding);
            log.info("RAG: found {} chunks in KB {} for node {}", chunks.size(), kbId, node.getId());
            return chunks;
        } catch (Exception e) {
            log.error("RAG search failed for KB {}", kbId, e);
            return List.of();
        }
    }
}
