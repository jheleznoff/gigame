package ru.sber.cs.ai.gigame.ws;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.socket.WebSocketHandler;
import org.springframework.web.reactive.socket.WebSocketSession;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;
import ru.sber.cs.ai.gigame.service.scenario.ScenarioEngine;
import ru.sber.cs.ai.gigame.service.scenario.ScenarioService;

import java.time.Duration;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import static ru.sber.cs.ai.gigame.utils.UserUtils.extractUserIdFromWebSocketSession;

/**
 * WebSocket обработчик для сценариев.
 * <p>
 * Реализует WebFlux WebSocket Handler для управления выполнением сценариев
 * с потоковой передачей событий в реальном времени через WebSocket.
 * <p>
 * Принимает команды от клиентов для управления выполнением сценариев.
 * Обрабатывает команды: run, pause, continue, disable_step_mode, disconnect.
 * <p>
 * Формат входящих сообщений:
 * {
 * "type": "run|pause|continue|disable_step_mode|disconnect",
 * "data": { ... },
 * "sessionId": "optional"
 * }
 * <p>
 * Формат исходящих сообщений:
 * {
 * "type": "event_type",
 * "data": { ... },
 * "sessionId": "uuid"
 * }
 *
 * @see WebSocketSessionManager
 * @see ScenarioEngine
 */
@Component
@RequiredArgsConstructor
@Slf4j
@SuppressWarnings("unused")
public class ScenarioWebSocketHandler implements WebSocketHandler {

    private final ScenarioService scenarioService;
    private final ScenarioEngine scenarioEngine;
    private final WebSocketSessionManager sessionManager;
    private final ObjectMapper objectMapper;

    @Override
    @NonNull
    public Mono<Void> handle(@NonNull WebSocketSession session) {
        String userId = extractUserIdFromWebSocketSession(session);
        sessionManager.addSession(session, userId);

        return Mono.defer(() ->
                session.receive()
                        .doOnNext(msg -> log.debug("Received WebSocket message, payload: {}", msg.getPayloadAsText()))
                        .flatMap(message -> handleIncomingMessage(session, message, userId))
                        .then()
                        .doOnTerminate(() -> {
                            sessionManager.removeSession(session);
                            log.info("WebSocket scenario run connection closed: sessionId={}", session.getId());
                        })).subscribeOn(Schedulers.boundedElastic());
    }

    private Mono<Void> handleIncomingMessage(WebSocketSession session,
                                             org.springframework.web.reactive.socket.WebSocketMessage message,
                                             String userId) {
        String payload = message.getPayloadAsText();
        log.debug("Received scenario run message: sessionId={}, payload={}", session.getId(), payload);

        try {
            ScenarioMessage scenarioMessage = objectMapper.readValue(
                    payload,
                    ScenarioMessage.class
            );

            return processScenarioMessage(scenarioMessage, session.getId(), userId)
                    .then(Mono.empty());
        } catch (Exception e) {
            log.error("Error handling message: sessionId={}", session.getId(), e);
            return sendErrorMessage(session, "Ошибка обработки сообщения: " + e.getMessage());
        }
    }

    private Mono<Void> processScenarioMessage(ScenarioMessage message, String sessionId, String userId) {
        log.info("Processing scenario run message: sessionId={}, scenarioId={}, stepMode={}", sessionId, message.scenarioId(), message.stepMode());

        WebSocketSession wsSession = sessionManager.getSession(sessionId);
        if (wsSession == null || !wsSession.isOpen()) {
            log.warn("WebSocket session not found or closed: sessionId={}", sessionId);
            return Mono.empty();
        }
        return Flux.from(scenarioService.runScenario(
                                userId,
                                UUID.fromString(message.scenarioId()),
                                message.stepMode())
                        .map(serverSentEvent -> createStreamEvent(serverSentEvent.data()))
                        .doOnNext(event -> log.debug("Sending to client: {}", event))
                        .doOnComplete(() -> log.debug("Scenario run stream completed for sessionId={}", sessionId)))
                .map(wsSession::textMessage)
                .delayElements(Duration.ofMillis(10))
                .as(wsSession::send)
                .then();
    }

    /**
     * Преобразует данные SSE в формат StreamEvent.
     *
     * @param data данные SSE
     * @return Map в формате StreamEvent
     */
    private String createStreamEvent(Map<String, Object> data) {
        Map<String, Object> event = new HashMap<>();
        if (data != null) {
            Object type = data.get("type");
            if (type != null) {
                event.put("type", type);
            }
            Map<String, Object> dataCopy = new HashMap<>(data);
            dataCopy.remove("type");
            event.put("data", dataCopy);
        }
        try {
            return objectMapper.writeValueAsString(event);
        } catch (Exception e) {
            log.error("Error serializing StreamEvent", e);
            return "{}";
        }
    }

    private Mono<Void> sendErrorMessage(WebSocketSession session, String errorMessage) {
        if (session != null && session.isOpen()) {
            try {
                Map<String, Object> errorEvent = Map.of(
                        "session_id", session.getId(),
                        "error", errorMessage
                );
                String json = objectMapper.writeValueAsString(errorEvent);
                return session.send(Flux.just(json).map(session::textMessage));
            } catch (Exception e) {
                log.error("Error serializing error message", e);
                return Mono.error(e);
            }
        }
        return Mono.empty();
    }

    /**
     * Входное сообщение для запуска сценария.
     * <p>
     * Содержит минимальный набор параметров для инициализации выполнения сценария.
     *
     * @param scenarioId идентификатор сценария для запуска
     * @param stepMode   флаг режима пошагового выполнения (true - включить, false - выключить)
     */
    public record ScenarioMessage(
            @JsonProperty("scenario_id")
            String scenarioId,
//            List<FilePart> files,
            @JsonProperty("step_mode")
            Boolean stepMode

    ) {
    }
}
