package ru.sber.cs.ai.gigame.service.scenario.executor;

import org.springframework.http.codec.ServerSentEvent;
import reactor.core.publisher.FluxSink;
import ru.sber.cs.ai.gigame.exception.ScenarioException;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunNode;

import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Узел «Контроль» (stop-and-error): проверяет условие на входных данных и,
 * если оно НЕ выполнено, прерывает сценарий с заданным сообщением об ошибке.
 * <p>
 * Конфигурация (те же поля, что у If): field — искомая строка/поле (опционально,
 * сужает проверку до строки, содержащей поле), operator — contains / not_contains /
 * equals / greater_than / less_than, value — сравниваемое значение.
 * Текст сообщения об ошибке — в поле prompt узла.
 * При выполненном условии вход передаётся дальше без изменений.
 */
public class ScenarioExecutorControlNode extends AbstractScenarioExecutor {

    private static final Pattern NUMBER_PATTERN = Pattern.compile("-?[\\d\\s]+[,.]?\\d*");

    protected ScenarioExecutorControlNode(ScenarioRunNode node) {
        super(node);
    }

    @Override
    public String execute(FluxSink<ServerSentEvent<Map<String, Object>>> sink) {
        // после входного узла данные приходят документами, а не входом
        String inputAll = node.getInput().isEmpty() && !node.getDocList().isEmpty()
                ? node.getDocList().stream()
                        .map(id -> node.getGraph().getDocMap().get(id).getText())
                        .collect(java.util.stream.Collectors.joining("\n\n"))
                : String.join("\n\n", node.getInput());
        String field = node.getField() == null ? "" : node.getField();
        String operator = node.getOperator() == null ? "contains" : node.getOperator();
        String compareValue = node.getValue() == null ? "" : node.getValue();
        // Поле и значение принимают выражения {{output:Метка}} / {{json:Метка:путь}} —
        // тогда проверяется адресованное значение, а не поиск текста во входе
        if (ExpressionResolver.hasExpressions(compareValue)) {
            compareValue = ExpressionResolver.resolve(compareValue, node.getGraph().getNodeMap());
        }
        boolean fieldIsExpression = ExpressionResolver.hasExpressions(field);

        String textToCheck = inputAll;
        if (fieldIsExpression) {
            textToCheck = ExpressionResolver.resolve(field, node.getGraph().getNodeMap());
        } else if (!field.isEmpty()) {
            StringBuilder matched = new StringBuilder();
            for (String line : inputAll.split("\n")) {
                if (line.toLowerCase().contains(field.toLowerCase())) {
                    matched.append(line).append("\n");
                }
            }
            textToCheck = matched.toString();
        }

        boolean ok = isConditionMet(operator, textToCheck, compareValue);
        prompt = "[контроль без LLM] условие: " + (field.isEmpty() ? "вход" : "поле «" + field + "»")
                + " " + operator + " «" + compareValue + "» → " + (ok ? "выполнено" : "НАРУШЕНО");
        if (!ok) {
            String message = node.getPrompt() == null || node.getPrompt().isBlank()
                    ? "Контроль не пройден: " + (field.isEmpty() ? "вход" : "«" + field + "»")
                    + " " + operator + " «" + compareValue + "»"
                    : node.getPrompt();
            throw new ScenarioException("КОНТРОЛЬ: " + message);
        }
        String result = "✓ Контроль пройден: " + (field.isEmpty() ? "вход" : "«" + field + "»")
                + " " + operator + " «" + compareValue + "»";
        node.getOutput().add(result);
        // вход передаётся дальше без изменений (контроль прозрачен для данных)
        for (var next : node.getChildNodeList()) {
            next.setSkip(false);
            next.getInput().addAll(node.getInput());
        }
        return result;
    }

    private boolean isConditionMet(String operator, String textToCheck, String compareValue) {
        return switch (operator) {
            case OPERATOR_NOT_CONTAINS -> !textToCheck.toLowerCase().contains(compareValue.toLowerCase());
            case OPERATOR_EQUALS -> textToCheck.toLowerCase().trim().equals(compareValue.toLowerCase());
            case OPERATOR_GREATER_THAN -> compareNumeric(textToCheck, compareValue, true);
            case OPERATOR_LESS_THAN -> compareNumeric(textToCheck, compareValue, false);
            default -> textToCheck.toLowerCase().contains(compareValue.toLowerCase());
        };
    }

    private boolean compareNumeric(String text, String thresholdStr, boolean greaterThan) {
        try {
            Matcher matcher = NUMBER_PATTERN.matcher(text.replace(" ", ""));
            if (!matcher.find()) {
                return false;
            }
            double val = Double.parseDouble(matcher.group().replace(",", ".").replace(" ", ""));
            double threshold = Double.parseDouble(thresholdStr.replace(",", ".").replace(" ", ""));
            return greaterThan ? val > threshold : val < threshold;
        } catch (Exception e) {
            return false;
        }
    }
}
