---
owner: Тимлид (context owner)
updated: 2026-07-22
---
# Start Here

## Продукт
**GigaMe Backend** — Spring Boot 3.5.15 / Java 17 backend-сервис для AI-чата с GigaChat, RAG, баз знаний и графового движка сценариев (Сбер, внутренний). Версия: 1.3.0.

## Перед любой задачей

1. **Прочитай** `01-product-context.md` — пойми, для кого продукт и какие сценарии нельзя ломать.
2. **Сверься** с `05-security-and-compliance.md` (⚠️ не согласован с ИБ) и `07-anti-patterns.md` (пустой — уточнить у команды).
3. **Убедись**, что не нарушаешь архитектурные инварианты (`03-architecture.md`):
   - Reactive (WebFlux), никакого WebMVC
   - `open-in-view: false`
   - Liquibase для миграций (`ddl-auto: validate`)
   - Все эндпоинты — через `X-UserId`
4. **Проверь** конвенции кода (`checkstyle.xml`): Java records для DTO, `"constant".equals()`, без `*`-imports, без `nested try`.

## Главные запреты

- **Не менять** структуру API-ответов и WebSocket-событий без backward-compatibility.
- **Не добавлять** блокирующие вызовы в WebFlux без `boundedElastic` пула.
- **Не использовать** `spring.jpa.hibernate.ddl-auto: update` — только Liquibase.
- **Не нарушать** изоляцию `user_id` — данные одного пользователя не видны другому.
- **Не писать** секреты, ключи, сертификаты в код или репозиторий (classpath только).
- **Не превышать** 80% coverage по JaCoCo (нижняя планка).

## Куда смотреть

- **Актуальный код:** `src/main/java/ru/sber/cs/ai/gigame/`
- **API:** OpenAPI `openapi/gigame.yaml`, Swagger UI на `/gigame/swagger-ui.html`
- **WebSocket:** `/ws/chat` и `/ws/scenario` (см. `WEBSOCKET_API.md`)
- **Тесты:** `mvn test -Dtest=ClassName` (100+ существующих тестов)
- **Сырой контекст:** `_raw/ABOUT.md` — полное описание продукта (но сверяйся с кодом при расхождениях)