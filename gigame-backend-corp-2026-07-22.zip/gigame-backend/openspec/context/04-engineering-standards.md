---
owner: Тимлид
updated: 2026-07-22
---
# Engineering Standards

Стек: Java 17, Spring Boot 3.5.15 (WebFlux), Maven, PostgreSQL 15+ с pgvector, Liquibase.

Стайл-гайд: `checkstyle.xml` в корне проекта (error-level).
Ключевые правила:

| Правило | Значение |
|---------|----------|
| Line length | max 300 (исключая URL/imports) |
| Method length | max 50 строк (пустые не считаются) |
| Parameters | max 8 |
| Imports | без `*`, неиспользуемые удалять |
| Empty catch | обязателен комментарий |
| String comparison | `"constant".equals(variable)` |
| Nested try | запрещены |
| Javadoc | обязателен для всех параметров |
| Declaration order | static → instance → constructor → method |
| Annotations | каждая на отдельной строке |
| Null safety | `isBlank()`, `isNotEmpty()` для строк |

## Null safety
- Для строк использовать `isBlank()`, `isNotEmpty()`
- DTO — Java records
- Логирование — Slf4j structured logging
- Lombok — `@RequiredArgsConstructor`, `@Data`, `@Slf4j`
- Ошибки — кастомные исключения + `@ControllerAdvice`

## Запуск проверок

- **Сборка:** `mvn clean package` (включает checkstyle)
- **Линт (checkstyle):** `mvn validate` (или автоматически при `package`)
- **Тесты:** `mvn test` (или `-Dtest=ClassNameTest` для одного класса)
- **Покрытие:** `mvn test jacoco:report` (отчёт: `target/coverage-reports/`)

## Критерии готовности кода

Код готов, когда:
1. `mvn clean package` проходит без ошибок (линт + компиляция)
2. `mvn test` — зелёные тесты
3. Покрытие JaCoCo: **минимум 80% complexity**
4. Все `*`-imports удалены, нет unused imports
5. Миграция через Liquibase (если меняется схема)
6. Формат DTO — Java records (для response)