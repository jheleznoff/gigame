---
owner: Сеньор / Тимлид
updated: 2026-07-22
---
# Anti-patterns

## Deprecated API / паттерны

> TODO: [уточнить у команды — есть ли deprecated API]

## На чем спотыкаются

> TODO: [уточнить у команды — частые ошибки новичков в коде]

## Bad example

> TODO: [уточнить у команды]