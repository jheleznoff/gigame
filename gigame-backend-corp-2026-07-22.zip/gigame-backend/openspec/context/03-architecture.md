---
owner: Архитектор / Тимлид
updated: 2026-07-22
---
# Architecture

## Инварианты

1. **Reactive throughout** — весь стек на Spring WebFlux (reactive). Блокирующие вызовы (JDBC) — только в выделенных пулах. Никакого WebMVC.
2. **No `open-in-view`** — `spring.jpa.open-in-view: false`. Все запросы к БД — только в `@Transactional` контексте. Иначе — LazyInitializationException.
3. **WebSocket — одно соединение** — только через `SimpleUrlHandlerMapping` + `WebSocketSessionManager` (ConcurrentHashMap). Никакого STOMP/SockJS.
4. **UUID PK + user_id** — все JPA-сущности: `DEFAULT uuid_generate_v4()`, `TIMESTAMP WITH TIME ZONE`, мультитенантность через колонку `user_id`.
5. **Миграции через Liquibase** — `ddl-auto: validate`, никакого `update` в проде. Каждое изменение схемы — SQL-файл в Liquibase changelog.

## Обязательные / запрещенные паттерны

**Обязательно:**
- DTO — Java records (response DTO)
- Логирование — Slf4j structured logging
- Lombok — `@RequiredArgsConstructor`, `@Data`, `@Slf4j`
- Исключения — кастомные (`NotFoundException`, `ScenarioException`, ...) + `@ControllerAdvice` + `ApplicationRuntimeException`
- Миграции — Liquibase (`ddl-auto: validate`)
- JSONB — `@Type(JsonType)`, `columnDefinition = "jsonb"`

**Запрещено:**
- `*`-imports (AvoidStarImport)
- `nested try` — выносить в отдельный метод
- `variable.equals("constant")` — только `"constant".equals(variable)`
- `open-in-view: true`
- `spring.jpa.hibernate.ddl-auto: update` (на проде — только validate через Liquibase)
- Блокирующие вызовы в реактивном потоке без явного `Schedulers.boundedElastic()`

## Схема

Актуальное описание: `_raw/ABOUT.md` (полное, включая структуру кода, API, модели данных).
Обновлено: 2026-07-22.

## Ключевые интеграции и зависимости

| Система | Роль | Тип |
|---------|------|-----|
| **PostgreSQL 15+** | Основное хранилище (JPA + pgvector) | sync (пул) |
| **pgvector** | Векторный поиск (IVFFlat, 100 lists, cosine) | sync |
| **GigaChat API** | LLM-вызовы (chat + embeddings) | sync (HTTP, read-timeout 300s) |
| **GigaChat Files API** | OCR сканов | sync |
| **Liquibase** | Миграции схемы | auto (при старте)