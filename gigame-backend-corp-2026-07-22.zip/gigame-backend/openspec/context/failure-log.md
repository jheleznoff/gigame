# Failure log
> Подсказка: графа «Что обновили» обязательна — без нее цикл не замыкается, и контекст не растет.

| Дата | Задача | Что пошло не так | Тип | Какой контекст нужен | Что обновили | Owner |
|---|---|---|---|---|---|---|
| | | | missing policy / outdated / missing glossary / wrong SoT / missing example / missing test / ambiguous req | | | |
