# GigaMe Backend

**GigaMe** — это backend-сервис на **Spring Boot 3.5.15** с поддержкой **Java 17**, предоставляющий API для AI-чата, баз знаний, RAG (Retrieval-Augmented Generation) и графового движка сценариев (workflow), основанный на **GigaChat** (AI-платформа Сбера).

**Версия**: 1.3.0

---

## 📋 Содержание

- [Ключевые возможности](#-ключевые-возможности)
- [Быстрый старт](#-быстрый-старт)
- [Структура проекта](#-структура-проекта)
- [API документация](#-api-документация)
- [WebSocket API](#-websocket-api)
- [Настройка среды](#-настройка-среды)
- [Разработка](#-разработка)
- [Тестирование](#-тестирование)
- [Архитектура движка сценариев](#-архитектура-движка-сценариев)
- [Модели данных](#-модели-данных)
- [Troubleshooting](#-troubleshooting)

---

## 🚀 Ключевые возможности

- **Чат с AI**: Многоходовые диалоги с автогенерацией заголовков, потоковая передача ответов через SSE и WebSocket
- **RAG (Retrieval-Augmented Generation)**: Поиск похожих фрагментов в документах и базах знаний с использованием pgvector (косинусная близость, IVFFlat-индекс)
- **LLM-роутинг баз знаний**: Перед RAG-поиском GigaChat определяет, каких БЗ касается вопрос (fail-open — при ошибке используются все БЗ)
- **Загрузка документов**: Поддержка PDF, DOCX, XLSX, TXT с автоматическим извлечением текста (до 30MB на файл)
- **OCR для сканов**: Распознавание PDF-сканов через файловое хранилище GigaChat (POST /files)
- **Движок сценариев**: Графовый AI-воркфлоу с **16 типами узлов** и пошаговой отладкой
- **Базы знаний**: Постоянные коллекции документов с векторными эмбеддингами для RAG
- **Экспорт результатов**: Экспорт выполненных сценариев в DOCX и XLSX
- **WebSocket**: Двунаправленная связь для чата и выполнения сценариев в реальном времени

---

## 🏃 Быстрый старт

### Предварительные требования

- Java 17+
- Maven 3.6+
- PostgreSQL 15+ с расширениями `pgvector` и `uuid-ossp`
- GigaChat API credentials (сертификат, приватный ключ, scope)

### 1. Настройка базы данных

```sql
-- Подключитесь к PostgreSQL и выполните:
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "vector";
```

### 2. Установка зависимостей

```bash
mvn clean install -DskipTests
```

### 3. Запуск приложения

```bash
# С помощью Maven
mvn spring-boot:run

# Или через JAR
java -jar target/gigame-backend-1.3.0.jar
```

Приложение запустится на порту `8080` по пути `/gigame`.

---

## 📁 Структура проекта

```
src/main/java/ru/sber/cs/ai/gigame/
├── Application.java                         # Точка входа (@SpringBootApplication, @EnableAsync, @EnableScheduling)
├── config/                                  # Конфигурация Spring (6 файлов)
│   ├── JacksonConfig.java                  # ObjectMapper: JavaTimeModule, NON_NULL, без таймстампов
│   ├── LegacyOwnerBackfill.java            # Миграция: owner → user_id
│   ├── OpenApiConfig.java                  # Swagger/OpenAPI с группами (actuator, chat, documents, kb, scenarios)
│   ├── PostgresVectorConfig.java           # @EnableJpaAuditing, поддержка pgvector
│   ├── TransactionConfig.java              # @EnableTransactionManagement, JpaTransactionManager
│   └── WebSocketConfig.java                # SimpleUrlHandlerMapping для /ws/chat и /ws/scenario
├── controller/                              # REST контроллеры (4 файла)
│   ├── ConversationController.java         # Управление диалогами (+ загрузка документов в кеш)
│   ├── DocumentController.java             # Загрузка/список/удаление документов
│   ├── KnowledgeBaseController.java        # Управление БЗ (+ загрузка/удаление/переиндексация документов)
│   └── ScenarioController.java             # Управление/запуск/экспорт сценариев
├── service/                                 # Бизнес-логика (11 + подпапки)
│   ├── ChatService.java                    # Чат, SSE, авто-заголовки, RAG с LLM-роутингом БЗ, суммаризация
│   ├── DocsTextCacheService.java           # LRU in-memory кеш текстов документов
│   ├── DocumentIndexService.java           # Чанкование, эмбеддинг, индексация документов БЗ
│   ├── DocumentService.java                # Загрузка файлов, извлечение текста (PDF, DOCX, XLSX, TXT)
│   ├── EmbeddingService.java               # pgvector: создание, поиск, удаление эмбеддингов
│   ├── GigaChatClient.java                 # Wrapper над Spring AI GigaChat (chat + embeddings)
│   ├── KBMapper.java                       # Преобразования для БЗ
│   ├── KBService.java                      # CRUD для баз знаний
│   ├── MessageService.java                 # Персистентность и маппинг сообщений
│   ├── ScanOcrService.java                 # OCR PDF-сканов через GigaChat
│   └── scenario/                           # Движок сценариев
│       ├── ScenarioEngine.java             # Исполнитель графа: топологическая сортировка, обход узлов
│       ├── ScenarioService.java            # CRUD + управление запусками/дублирование/экспорт сценариев
│       ├── ScenarioRunService.java         # Жизненный цикл выполнения
│       ├── ScenarioRunStepService.java     # Создание и обновление шагов
│       ├── ScenarioEventEmission.java      # Вспомогательные методы для SSE-событий
│       ├── ScenarioMapper.java             # Entity → DTO преобразования
│       ├── ExportToDocx.java               # Экспорт результатов сценария в DOCX
│       ├── ScenarioResultToXlsx.java       # Экспорт JSON-данных в XLSX
│       ├── DocumentText.java               # Кеш текстов документов для запуска сценария
│       ├── enums/
│       │   ├── ScenarioEventType.java      # STATUS, NODE_STATUS, LOOP_PROGRESS, SWITCH_RESULT и др.
│       │   ├── ScenarioNodeType.java       # PROCESSING_NODE, IF_NODE, SWITCH_NODE, LOOP_NODE, INPUT_NODE, OUTPUT_NODE и др.
│       │   └── ScenarioStatus.java         # RUNNING, COMPLETED, FAILED, SKIPPED
│       ├── executor/                       # 16 исполнителей узлов графа
│       │   ├── AbstractScenarioExecutor.java          # Базовый класс
│       │   ├── ExpressionResolver.java               # Резолвер выражений
│       │   ├── FormulaEvaluator.java                  # Калькулятор формул
│       │   ├── ScenarioExecutorFactory.java           # Фабрика исполнителей
│       │   ├── ScenarioExecutorAggregateNode.java     # Агрегация данных
│       │   ├── ScenarioExecutorCalcNode.java          # Вычисления/формулы
│       │   ├── ScenarioExecutorControlNode.java       # Управляющий узел
│       │   ├── ScenarioExecutorIfNode.java            # Условное ветвление
│       │   ├── ScenarioExecutorInputNode.java         # Входной узел (документы)
│       │   ├── ScenarioExecutorLoopNode.java          # Цикл (classify_strict / full analysis)
│       │   ├── ScenarioExecutorOutputNode.java        # Выходной узел (TEXT_FILE / EXCEL)
│       │   ├── ScenarioExecutorProcessingNode.java    # Вызов GigaChat
│       │   ├── ScenarioExecutorSubscenarioNode.java   # Подсценарий
│       │   ├── ScenarioExecutorSwitchNode.java        # Маршрутизация
│       │   ├── ScenarioExecutorTransformNode.java     # Трансформация данных
│       │   └── ScenarioExecutorWaitNode.java          # Ожидание
│       └── graph/
│           ├── ScenarioRunDoc.java        # Документ прогона
│           ├── ScenarioRunGraph.java      # Граф прогона
│           └── ScenarioRunNode.java       # Узел прогона
├── model/                                   # JPA сущности (10 файлов)
│   ├── Conversation.java                   # Диалог
│   ├── Message.java                        # Сообщение (documentIds — JSONB)
│   ├── Document.java                       # Документ
│   ├── Embedding.java                      # Эмбеддинг (vector(1024), collectionType, chunkText)
│   ├── KnowledgeBase.java                  # База знаний
│   ├── KBDocument.java                     # Связь БЗ ↔ Документ
│   ├── Scenario.java                       # Сценарий (graphData — JSONB)
│   ├── ScenarioRun.java                    # Запуск сценария
│   ├── ScenarioRunStep.java                # Шаг выполнения (inputData, outputData — JSONB)
│   └── ScenarioVersion.java                # Версия сценария
├── repository/                              # JPA репозитории (10 файлов)
│   ├── ConversationRepository.java
│   ├── DocumentRepository.java
│   ├── EmbeddingRepository.java            # native @Query для <-> косинусного расстояния
│   ├── KBDocumentRepository.java
│   ├── KnowledgeBaseRepository.java
│   ├── MessageRepository.java
│   ├── ScenarioRepository.java
│   ├── ScenarioRunRepository.java
│   ├── ScenarioRunStepRepository.java
│   └── ScenarioVersionRepository.java
├── dto/                                     # Data Transfer Objects
│   ├── ErrorResponse.java                  # Стандартный формат ошибки
│   ├── chat/ (6): ConversationCreate, ConversationResponse, ConversationWithMessages,
│   │             MessageResponse, RagSource, SendMessageRequest
│   ├── document/ (1): DocumentViewResponse
│   ├── kb/ (5): KBCreate, KBDetailResponse, KBDocumentResponse, KBResponse, KBUpdate
│   └── scenario/ (10 + graph/8):
│       ├── ScenarioCreate, ScenarioDetailResponse, ScenarioResponse,
│       │   ScenarioRunDetailResponse, ScenarioRunResponse,
│       │   ScenarioRunStepInputDataResponse, ScenarioRunStepOutputDataResponse,
│       │   ScenarioRunStepResponse, ScenarioUpdate
│       └── graph/: EdgeDataDto, EdgeDto, GraphDataDto, GraphDataMapper,
│                   MeasuredDto, NodeDataDto, NodeDto, PositionDto
├── exception/                               # Исключения и глобальный обработчик (7 файлов)
│   ├── AccessDeniedException.java          # HTTP 403
│   ├── ApplicationErrorHandler.java        # @ControllerAdvice со всеми обработчиками
│   ├── ApplicationRuntimeException.java    # Базовое исключение с statusCode
│   ├── FileException.java                  # HTTP 500
│   ├── GigaChatException.java              # HTTP 500
│   ├── NotFoundException.java              # HTTP 404
│   └── ScenarioException.java              # HTTP 400
├── ws/                                      # WebSocket обработчики
│   ├── ChatWebSocketHandler.java           # /ws/chat: приём сообщений, поток SSE-ответов
│   ├── ScenarioWebSocketHandler.java       # /ws/scenario: запуск сценария, SSE-события
│   ├── WebSocketSessionManager.java        # ConcurrentHashMap: sessionId → WebSocketSession + userId
│   └── enums/ActionType.java               # Типы WebSocket-действий
└── utils/                                   # Утилиты (5 файлов)
    ├── FileUtils.java                      # Content-Type, InputStream
    ├── JsonCalcUtils.java                  # JSON path evaluation
    ├── TextSplitter.java                   # Чанкование текста с перекрытием
    ├── UserUtils.java                      # Извлечение и валидация X-UserId
    └── ZipExtractor.java                   # Распаковка архивов
```

---

## 📖 API документация

После запуска приложения документация доступна по:

- **OpenAPI JSON**: `http://localhost:8080/gigame/sample-api-docs`
- **Swagger UI**: `http://localhost:8080/gigame/swagger-ui.html`
- **Actuator**: `http://localhost:8080/gigame/actuator`

### Основные endpoints

#### Диалоги (Conversations)

| Метод | Endpoint | Описание |
|-------|----------|----------|
| `GET` | `/api/conversations?q=` | Список диалогов (опциональный поиск по заголовку) |
| `POST` | `/api/conversations` | Создать диалог |
| `GET` | `/api/conversations/{id}` | Получить диалог с сообщениями |
| `PUT` | `/api/conversations/{id}` | Обновить заголовок диалога |
| `DELETE` | `/api/conversations/{id}` | Удалить диалог |
| `POST` | `/api/conversations/{id}/messages` | Отправить сообщение (SSE поток) |
| `POST` | `/api/conversations/{id}/messages/upload` | Отправить сообщение с файлами (multipart + SSE) |
| `POST` | `/api/conversations/{id}/upload` | Загрузить документы в кеш (без ответа AI) |

#### Документы (Documents)

| Метод | Endpoint | Описание |
|-------|----------|----------|
| `GET` | `/api/documents` | Список всех документов |
| `POST` | `/api/documents` | Загрузить документ |
| `DELETE` | `/api/documents/{id}` | Удалить документ |

#### Базы знаний (Knowledge Bases)

| Метод | Endpoint | Описание |
|-------|----------|----------|
| `GET` | `/api/knowledge-bases?q=` | Список баз знаний |
| `POST` | `/api/knowledge-bases` | Создать базу знаний |
| `GET` | `/api/knowledge-bases/{id}` | Получить БЗ с документами |
| `PUT` | `/api/knowledge-bases/{id}` | Обновить БЗ |
| `DELETE` | `/api/knowledge-bases/{id}` | Удалить БЗ |
| `POST` | `/api/knowledge-bases/{id}/documents` | Загрузить документ в БЗ (multipart) |
| `POST` | `/api/knowledge-bases/{id}/documents/{docId}/reindex` | Переиндексировать документ в БЗ |
| `DELETE` | `/api/knowledge-bases/{id}/documents/{docId}` | Удалить документ из БЗ |

#### Сценарии (Scenarios)

| Метод | Endpoint | Описание |
|-------|----------|----------|
| `GET` | `/api/scenarios` | Список сценариев |
| `POST` | `/api/scenarios` | Создать сценарий |
| `GET` | `/api/scenarios/{id}` | Получить детали сценария |
| `PUT` | `/api/scenarios/{id}` | Обновить сценарий |
| `DELETE` | `/api/scenarios/{id}` | Удалить сценарий |
| `POST` | `/api/scenarios/{id}/duplicate` | Дублировать сценарий |
| `GET` | `/api/scenarios/{id}/runs` | Список выполнений сценария |
| `POST` | `/api/scenarios/{id}/run` | Запустить сценарий с файлами (SSE поток) |
| `POST` | `/api/scenarios/{id}/upload` | Загрузить файлы в кеш сценария |
| `GET` | `/api/scenarios/runs/{runId}` | Получить детали выполнения |
| `POST` | `/api/scenarios/runs/{runId}/continue` | Продолжить приостановленный запуск |
| `POST` | `/api/scenarios/runs/{runId}/disable-step-mode` | Отключить пошаговый режим |
| `GET` | `/api/scenarios/runs/{runId}/export` | Экспорт результатов в DOCX |

---

## 🔌 WebSocket API

Приложение поддерживает два WebSocket эндпоинта для двунаправленной связи в реальном времени. Полная документация — в файле [`WEBSOCKET_API.md`](WEBSOCKET_API.md).

### `/ws/chat` (ChatWebSocketHandler)

Принимает сообщения и возвращает потоковые ответы AI через SSE-события.

**Вход** (JSON):
```json
{
  "conversation_id": "uuid",
  "content": "текст сообщения",
  "document_ids": ["uuid1", "uuid2"]
}
```

**Выход** (поток JSON-событий):
```json
{"conversation_id": "uuid", "content": "токен", "usage": null, "document_ids": null, "done": false, "error": null}
```
```json
{"conversation_id": "uuid", "content": "", "usage": {"total_tokens": 150}, "document_ids": ["uuid1"], "done": true, "error": null}
```

**Аутентификация**: `X-UserId` в заголовках WebSocket handshake.

### `/ws/scenario` (ScenarioWebSocketHandler)

Принимает запрос на запуск сценария и возвращает поток SSE-событий с прогрессом выполнения.

**Вход** (JSON):
```json
{
  "scenario_id": "uuid",
  "step_mode": false
}
```

**Выход** (поток событий с полем `type`):
- `status` — изменение статуса выполнения
- `node_status` — статус текущего узла
- `step_complete` — шаг выполнен
- `step_paused` — шаг приостановлен (пошаговый режим)
- `loop_progress` — прогресс цикла (i/n)
- `rag_search` — результаты RAG-поиска
- `file_output` — результат в виде файла

---

## ⚙️ Настройка среды

Создайте файл `.env` или установите переменные окружения:

```bash
# База данных
DATABASE_URL=jdbc:postgresql://localhost:5432/gigame
db.username=your_user
db.password=your_password
DATABASE_SCHEMA=public

# GigaChat API
GIGACHAT_URL=https://gigachat-ift.sberdevices.delta.sbrf.ru/v1
GIGACHAT_SERT=classpath:giga_ift.pem
GIGACHAT_KEY=classpath:giga_ift.key
GIGACHAT_SCOPE=GIGACHAT_API_CORP
GIGACHAT_MODEL=GigaChat-2-Max
GIGACHAT_TEMPERATURE=0.7
GIGACHAT_TOP_P=0.9
GIGACHAT_PENALTY=1.05
GIGACHAT_UPDATE_INTERVAL=0.5

# Настройки приложения
PORT=8080
CONTEXT_CHAR_LIMIT=200000
MAX_HISTORY_MESSAGES=20
AUTO_TITLE_LENGTH=100
CHAT_SUMMARY_ENABLED=true
RAG_ROUTER_ENABLED=true          # LLM-роутинг баз знаний
TOPK=5
RAG_DISTANCE_DELTA=0.08
CHUNK_SIZE=1000
OVERLAP=200
BATCH_SIZE=50
CHAR_LIMIT=12000
DOCUMENT_MIN_PARSED_CHARS=40
OCR_VIA_GIGACHAT=false           # OCR PDF-сканов
SCENARIO_MAX_DOCUMENTS=500
SCENARIO_GROUP_PARALLELISM=1
DELAY_BETWEEN_ITERATIONS_MILLIS=1000
CACHE_SHORT_QUERY_LENGTH=200
```

### Конфигурация GigaChat

Для работы с GigaChat API необходимы:
- `giga_ift.pem` — сертификат (должен быть в `src/main/resources/`)
- `giga_ift.key` — приватный ключ (должен быть в `src/main/resources/`)

---

## 💻 Разработка

### Сборка проекта

```bash
mvn clean package
```

### Запуск с DEBUG логами

```bash
java -jar target/gigame-backend-1.3.0.jar \
  --logging.level.ru.sber.cs.ai.gigame=DEBUG \
  --logging.level.org.springframework.web=DEBUG
```

### Checkstyle

Проверка стиля кода осуществляется автоматически при сборке (конфигурация в `checkstyle.xml`):

```bash
mvn validate
```

### Правила кодирования (checkstyle.xml)

| Правило | Значение |
|---------|----------|
| **Длина строки** | максимум 300 символов (кроме URL/imports) |
| **Длина метода** | максимум 50 строк (пустые не считаются) |
| **Параметры метода** | максимум 8 |
| **Import'ы** | без `*`, неиспользуемые удалять |
| **Empty catch** | обязателен комментарий |
| **Сравнение строк** | `"constant".equals(variable)` |
| **Nested try** | запрещены (выносить в отдельный метод) |
| **Javadoc** | обязателен для всех параметров |
| **Порядок объявлений** | static → instance → constructor → method |
| **Аннотации** | каждая на отдельной строке |
| **Severity** | `error` (по умолчанию) |

- **Null safety**: Использовать `isBlank()`, `isNotEmpty()` для строк
- **DTO**: Использовать Java records для response DTO
- **Логирование**: Slf4j со structured logging
- **Lombok**: `@RequiredArgsConstructor`, `@Data`, `@Slf4j`
- **Ошибки**: Кастомные исключения с `@ControllerAdvice`

---

## 🧪 Тестирование

### Запуск тестов

```bash
# Запуск всех тестов (100+ тестов)
mvn test

# Запуск конкретного класса тестов
mvn test -Dtest=ChatServiceTest
mvn test -Dtest=ScenarioEngineTest
mvn test -Dtest=ScenarioExecutorProcessingNodeTest

# Отчёт о покрытии кода
mvn test jacoco:report
```

### Структура тестов (100+ тестов)

| Уровень | Примеры |
|---------|---------|
| **config** (5) | JacksonConfig, OpenApiConfig, WebSocketConfig |
| **controller** (7) | ConversationController (3), ScenarioController, KBController, ExceptionHandler |
| **exception** (7) | Каждое исключение + ErrorResponse |
| **dto** (20+) | Все DTO: chat (5), kb (5), scenario (10+), graph (8) |
| **model** (9) | Conversation, Message, Document, Embedding, Scenario, ScenarioRun, ScenarioRunStep и др. |
| **repository** (10) | ConversationRepository, EmbeddingRepository, PersistenceLayerIntegration и др. |
| **service** (10) | ChatService, DocumentService, DocumentIndexService, KBService, EmbeddingService, GigaChatClient, MessageService, DocsTextCacheService и др. |
| **scenario** (5) | Engine, ExportToDocx, ExecutionService, Mapper, RunStepService |
| **executors** (12+) | Каждый executor + фабрика + FormulaEvaluator, ExpressionResolver |
| **utils** (3) | FileUtils, TextSplitter, UserUtils |
| **ws** (1) | ChatWebSocketHandler |

### Требования к покрытию

- Минимальное покрытие по сложности: **70%** (JaCoCo)
- Отчёт: `target/coverage-reports/`

---

## 🧠 Архитектура движка сценариев

### Типы узлов (16 исполнителей)

| Узел | Исполнитель | Описание |
|------|-------------|----------|
| **InputNode** | `ScenarioExecutorInputNode` | Пробрасывает documentsText на выход. Без AI. |
| **OutputNode** | `ScenarioExecutorOutputNode` | Объединяет выходы предшественников. Поддерживает TEXT_FILE/EXCEL. |
| **ProcessingNode** | `ScenarioExecutorProcessingNode` | Вызов GigaChat с промптом, контекстом и RAG + group-режим. |
| **LoopNode** | `ScenarioExecutorLoopNode` | Циклическая обработка: classify_strict / full analysis. |
| **SwitchNode** | `ScenarioExecutorSwitchNode` | Маршрутизация по классификации (от Loop) или правилам. |
| **IfNode** | `ScenarioExecutorIfNode` | Условное ветвление (contains, equals, greater_than и др.). |
| **CalcNode** | `ScenarioExecutorCalcNode` | Вычисления и формулы. |
| **AggregateNode** | `ScenarioExecutorAggregateNode` | Агрегация данных. |
| **TransformNode** | `ScenarioExecutorTransformNode` | Трансформация данных (в т.ч. merge). |
| **SubscenarioNode** | `ScenarioExecutorSubscenarioNode` | Запуск подсценария. |
| **ControlNode** | `ScenarioExecutorControlNode` | Управляющий узел. |
| **WaitNode** | `ScenarioExecutorWaitNode` | Ожидание/пауза. |

### Алгоритм выполнения

1. **Топологическая сортировка**: `ScenarioEngine` строит порядок обхода графа
2. **Фабрика**: `ScenarioExecutorFactory` по типу узла создаёт нужный исполнитель
3. **Исполнение**: `AbstractScenarioExecutor.execute()` → вызов GigaChat / вычисление / трансформация
4. **SkipSet**: при ветвлении (Switch/If) проигравшие ветки и их потомки помечаются `skipped`
5. **SSE-события**: `ScenarioEventEmission` отправляет `status`, `node_status`, `loop_progress`, `rag_search` и др.

### Режимы LoopNode

- `classify_strict`: каждый документ классифицируется GigaChat в один из заданных классов
- `full analysis`: каждый документ обрабатывается через GigaChat с полным промптом
- Между итерациями — настраиваемая задержка (`delay-between-iterations: 1000ms`)
- SSE-событие `loop_progress` по каждой итерации

### Параллельность

- `group-parallelism` (по умолчанию 1) — параллельность LLM-вызовов групп в ProcessingNode
- Группы: `sequential`, `batch` — управляют кол-вом одновременных запросов к GigaChat

---

## 🗄️ Модели данных

### JPA сущности (10)

Все сущности используют UUID PK с `uuid_generate_v4()` и `TIMESTAMP WITH TIME ZONE`.

| Сущность | Таблица | Ключевые поля |
|----------|---------|---------------|
| `Conversation` | `conversations` | user_id, title, metadata (JSONB) |
| `Message` | `messages` | conversation_id (FK), role, content, document_ids (JSONB) |
| `Document` | `documents` | user_id, filename, file_size, extracted_text |
| `Embedding` | `embeddings` | vector(1024) via pgvector, collection_type ('doc'/'kb'), collection_id, chunk_text |
| `KnowledgeBase` | `knowledge_bases` | user_id, name, description |
| `KBDocument` | `kb_documents` | kb_id (FK), document_id (FK) |
| `Scenario` | `scenarios` | user_id, name, graph_data (JSONB) |
| `ScenarioRun` | `scenario_runs` | scenario_id (FK), status, step_mode |
| `ScenarioRunStep` | `scenario_run_steps` | run_id (FK), node_id, input_data (JSONB), output_data (JSONB) |
| `ScenarioVersion` | `scenario_versions` | scenario_id (FK), version_num |

### pgvector

- **Размерность**: 1024
- **Индекс**: IVFFlat с `vector_cosine_ops` (100 lists)
- **Поиск**: косинусное расстояние (`<->` оператор)
- **Фильтры**: RAG_DISTANCE_DELTA (отсев БЗ), RAG_MAX_DISTANCE (абсолютный порог)

---

## 🔧 Troubleshooting

### Проблема: Ошибки аутентификации сертификата

**Решение**: Убедитесь, что `giga_ift.pem` и `giga_ift.key` находятся в `src/main/resources/`. Сертификаты должны быть в формате PEM (не PKCS#12).

### Проблема: Поиск похожести возвращает пустоту

**Решение**: Проверьте, что расширение `pgvector` установлено и создан IVFFlat индекс:

```sql
CREATE INDEX IF NOT EXISTS idx_embeddings_vector
ON embeddings USING ivfflat (embedding vector_cosine_ops) WITH (lists = 100);
```

### Проблема: JPA LazyInitializationException

**Решение**: Убедитесь, что запросы выполняются в `@Transactional` контексте. В конфигурации установлено `open-in-view: false`.

### Проблема: Ошибки при загрузке файлов (500)

**Решение**: Максимальный размер файла — 30MB, максимальный размер запроса — 100MB. Убедитесь, что размер файлов не превышает лимиты.

### Проблема: GigaChat API timeout

**Решение**: Увеличьте таймауты в `application.yaml`:

```yaml
spring:
  ai:
    gigachat:
      internal:
        connect-timeout: 30s
        read-timeout: 300s
```

### Проблема: Миграции Liquibase не применяются

**Решение**: Проверьте, что PostgreSQL расширения `uuid-ossp` и `vector` установлены. Liquibase выполняет миграции автоматически при старте (`ddl-auto: validate`).

### Проблема: Недостаточно документов для сценария

**Решение**: Максимум 500 документов на прогон. Большие наборы догружаются партиями:

```bash
curl -X POST .../api/scenarios/{id}/upload?append=true
```

---

## 📝 Лицензия

© Сбербанк 2026. Все права защищены.