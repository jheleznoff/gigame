# WebSocket API

Приложение поддерживает два WebSocket-канала для потоковой передачи данных в реальном времени:

1. `/ws/chat` — для чат-интерфейса с потоковой передачей ответов AI
2. `/ws/scenario` — для управления выполнением сценариев с потоковой передачей событий

---

## Общий формат сообщений

Все WebSocket-сообщения передаются в виде JSON-строк. Для успешного подключения клиент должен передать `X-UserId` в заголовках handshake.

```
WebSocket URL: ws://localhost:8080/ws/{endpoint}
Headers:
  X-UserId: user-id-uuid
```

---

## 1. Чат WebSocket (`/ws/chat`)

### Входные параметры (Client → Server)

Клиент отправляет сообщения формата `ChatMessage`:

```json
{
  "conversation_id": "uuid-диалога",
  "content": "Текст сообщения пользователя",
  "document_ids": ["uuid-документа-1", "uuid-документа-2"]
}
```

**Поля:**

| Поле | Тип | Обязательное | Описание |
|------|-----|--------------|----------|
| `conversation_id` | `string` (UUID) | Да | UUID диалога, в котором происходит общение |
| `content` | `string` | Да | Текст сообщения пользователя (может быть `null` для RAG-запросов без текста) |
| `document_ids` | `array` (UUID) | Нет | Список UUID документов, прикреплённых к сообщению для RAG |

**Пример запроса:**

```json
{
  "conversation_id": "123e4567-e89b-12d3-a456-426614174000",
  "content": "Как работает RAG?",
  "document_ids": ["abc12345-1234-1234-1234-123456789012"]
}
```

---

### Выходные параметры (Server → Client)

Сервер отправляет поток событий в формате `StreamEvent`:

```json
{
  "conversation_id": "uuid-диалога",
  "content": "Фрагмент ответа AI",
  "usage": {
    "prompt_tokens": 100,
    "completion_tokens": 50,
    "total_tokens": 150
  },
  "document_ids": ["uuid-документа-1"],
  "done": true,
  "error": "Сообщение об ошибке"
}
```

**Поля:**

| Поле | Тип | Обязательное | Описание |
|------|-----|--------------|----------|
| `conversation_id` | `string` (UUID) | Нет | UUID диалога |
| `content` | `string` | Нет | Фрагмент ответа AI (поставляется по частям во время стриминга) |
| `usage` | `object` | Нет | Статистика использования токенов GigaChat |
| `document_ids` | `array` (UUID) | Нет | Список документов, использованных для генерации ответа (RAG) |
| `done` | `boolean` | Нет | Флаг завершения потока (`true` — ответ полностью сгенерирован) |
| `error` | `string` | Нет | Сообщение об ошибке (если произошла ошибка) |

**Примеры ответов:**

**1. Фрагмент ответа (во время генерации):**
```json
{
  "conversation_id": "123e4567-e89b-12d3-a456-426614174000",
  "content": "RAG (Retrieval-Augmented Generation) — это"
}
```

**2. Продолжение ответа:**
```json
{
  "conversation_id": "123e4567-e89b-12d3-a456-426614174000",
  "content": " технология, которая объединяет поиск релевантных документов"
}
```

**3. Завершение ответа с метриками:**
```json
{
  "conversation_id": "123e4567-e89b-12d3-a456-426614174000",
  "usage": {
    "prompt_tokens": 250,
    "completion_tokens": 120,
    "total_tokens": 370
  },
  "done": true
}
```

**4. Ошибка:**
```json
{
  "error": "Conversation not found: 123e4567-e89b-12d3-a456-426614174000"
}
```

---

## 2. Scenario WebSocket (`/ws/scenario`)

### Входные параметры (Client → Server)

Клиент отправляет команды формата `ScenarioMessage`:

```json
{
  "scenario_id": "uuid-сценария",
  "step_mode": true
}
```

**Поля:**

| Поле | Тип | Обязательное | Описание |
|------|-----|--------------|----------|
| `scenario_id` | `string` (UUID) | Да | UUID сценария для запуска |
| `step_mode` | `boolean` | Да | Режим пошагового выполнения (`true` — включить паузы между шагами для отладки, `false` — выполнить сразу) |

**Пример запроса:**

```json
{
  "scenario_id": "123e4567-e89b-12d3-a456-426614174000",
  "step_mode": true
}
```

---

### Выходные параметры (Server → Client)

Сервер отправляет поток SSE-событий, преобразованных в формат `StreamEvent`:

```json
{
  "type": "event_type",
  "data": {
    "step": 1,
    "node_id": "node-123",
    "status": "running",
    "message": "Начало выполнения",
    "output": "Результат узла",
    "rag_search": {
      "query": "Поисковый запрос",
      "results": 3
    }
  },
  "session_id": "uuid-сессии"
}
```

**Возможные типы событий (`type`):**

| Тип события | Описание |
|-------------|----------|
| `status` | Общее состояние выполнения (running, paused, completed, failed) |
| `node_status` | Статус конкретного узла графа (start, complete, error) |
| `step_complete` | Завершение шага в пошаговом режиме |
| `step_paused` | Пауза перед следующим шагом (только в `step_mode=true`) |
| `loop_progress` | Прогресс цикла (для узлов типа `loop`) |
| `rag_search` | Поиск по базе знаний (RAG) |

**Структура `data` зависит от `type`:**

**1. `status` — общее состояние:**
```json
{
  "type": "status",
  "data": {
    "message": "Выполнение сценария",
    "current_step": 1,
    "total_steps": 5
  }
}
```

**2. `node_status` — статус узла:**
```json
{
  "type": "node_status",
  "data": {
    "node_id": "input-1",
    "node_type": "input",
    "status": "complete",
    "output": {
      "user_query": "Как работает RAG?"
    }
  }
}
```

**3. `rag_search` — поиск по базе знаний:**
```json
{
  "type": "rag_search",
  "data": {
    "query": "RAG технология",
    "results": [
      {
        "document_id": "abc123",
        "chunk_id": "chunk-456",
        "score": 0.92,
        "text": "Retrieval-Augmented Generation..."
      }
    ]
  }
}
```

**4. `step_paused` — пауза перед следующим шагом:**
```json
{
  "type": "step_paused",
  "data": {
    "node_id": "node-789",
    "continue_command": "continue"
  }
}
```

**5. `step_complete` — шаг завершён:**
```json
{
  "type": "step_complete",
  "data": {
    "node_id": "node-789",
    "output": "Результат выполнения"
  }
}
```

**6. `loop_progress` — прогресс цикла:**
```json
{
  "type": "loop_progress",
  "data": {
    "node_id": "loop-1",
    "iteration": 2,
    "total_iterations": 5
  }
}
```

**7. Завершение сценария:**
```json
{
  "type": "status",
  "data": {
    "message": "Сценарий завершён успешно",
    "status": "completed",
    "total_time_ms": 1250
  }
}
```

**8. Ошибка:**
```json
{
  "type": "status",
  "data": {
    "message": "Ошибка выполнения узла: node-123",
    "status": "failed",
    "error": "NodeId node-123: GigaChat API timeout"
  }
}
```

---

## Описание сессий

### Управление сессиями

WebSocket-сервер использует `WebSocketSessionManager` для управления сессиями:

- **Добавление сессии:** При подключении клиента сессия добавляется в `ConcurrentHashMap`
- **Удаление сессии:** При отключении клиента сессия удаляется автоматически
- **Сопоставление:** Каждой сессии сопоставляется `userId` из заголовка `X-UserId`

### Закрытие соединения

Соединение закрывается автоматически при:

1. Отключении клиента (WebSocket `close` событие)
2. Ошибке при обработке сообщения
3. Завершении потока (SSE completed или error)

---

## Обработка ошибок

### Ошибки JSON-парсинга

Сервер отправляет сообщение об ошибке:

```json
{
  "session_id": "uuid-сессии",
  "error": "Ошибка обработки сообщения: ..."
}
```

### Ошибки бизнес-логики

Ошибки из сервисов (например, `NotFoundException`) передаются через поле `error` в соответствующем потоке:

```json
{
  "error": "Conversation not found: uuid"
}
```

### Закрытая сессия

Если сессия закрыта, сервер логирует предупреждение и прерывает поток.

---

## Технические детали

### Конфигурация

- **Класс конфигурации:** `WebSocketConfig`
- **WebSocket Handler:** `ChatWebSocketHandler`, `ScenarioWebSocketHandler`
- **Менеджер сессий:** `WebSocketSessionManager`
- **Транспорт:** Spring WebFlux WebSocket (Reactor Netty)
- **Планировщик:** `boundedElastic` (для блокирующих операций)

### Группировка событий

События группируются с задержкой 10 мс для оптимизации производительности:

```java
.delayElements(Duration.ofMillis(10))
```

### Потоковая передача

- **Чат:** `Flux<ServerSentEvent<Map<String, Object>>>` → `Flux<WebSocketMessage>`
- **Сценарии:** `Flux<ServerSentEvent<Map<String, Object>>>` → `Flux<WebSocketMessage>`

---

## Примеры клиентского кода

### Chat WebSocket (JavaScript)

```javascript
const ws = new WebSocket('ws://localhost:8080/ws/chat', [], {
  headers: {
    'X-UserId': 'user-uuid'
  }
});

ws.onopen = () => {
  ws.send(JSON.stringify({
    conversation_id: '123e4567-e89b-12d3-a456-426614174000',
    content: 'Привет, как работает RAG?',
    document_ids: []
  }));
};

ws.onmessage = (event) => {
  const message = JSON.parse(event.data);
  
  if (message.content) {
    console.log('AI:', message.content);
  }
  
  if (message.usage) {
    console.log('Tokens:', message.usage);
  }
  
  if (message.done) {
    console.log('Stream completed');
  }
  
  if (message.error) {
    console.error('Error:', message.error);
  }
};
```

### Scenario WebSocket (JavaScript)

```javascript
const ws = new WebSocket('ws://localhost:8080/ws/scenario', [], {
  headers: {
    'X-UserId': 'user-uuid'
  }
});

ws.onopen = () => {
  ws.send(JSON.stringify({
    scenario_id: '123e4567-e89b-12d3-a456-426614174000',
    step_mode: true
  }));
};

ws.onmessage = (event) => {
  const message = JSON.parse(event.data);
  
  if (message.type === 'node_status') {
    console.log(`Node ${message.data.node_id}: ${message.data.status}`);
  }
  
  if (message.type === 'rag_search') {
    console.log(`Found ${message.data.results.length} results`);
  }
  
  if (message.type === 'step_paused') {
    console.log('Step paused, waiting for continue');
    // ws.send(JSON.stringify({ command: 'continue' }));
  }
  
  if (message.type === 'status' && message.data.status === 'completed') {
    console.log('Scenario completed');
  }
};
```

---

## Связанные файлы

| Файл | Описание |
|------|----------|
| `WebSocketConfig.java` | Конфигурация WebSocket endpoints |
| `ChatWebSocketHandler.java` | Обработчик чат WebSocket |
| `ScenarioWebSocketHandler.java` | Обработчик сценарий WebSocket |
| `WebSocketSessionManager.java` | Управление WebSocket сессиями |
| `ChatService.java` | Сервис чат-диалогов |
| `ScenarioService.java` | Сервис управления сценариями |
| `ScenarioEngine.java` | Движок выполнения сценариев |
