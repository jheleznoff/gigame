package ru.sber.cs.ai.gigame.utils;

import ru.sber.cs.ai.gigame.exception.ScenarioException;

import java.math.BigDecimal;

/**
 * Общие хелперы для детерминированных узлов (calc, aggregate):
 * терпимый разбор чисел и JSON-фрагментов из текстовых ответов LLM.
 */
public final class JsonCalcUtils {

    private JsonCalcUtils() {
    }

    /**
     * Чинит десятичные запятые в числах JSON («: 18196721,31» → «: 18196721.31»):
     * модели на русском регулярно пишут запятую как разделитель дробной части.
     * Замена выполняется только вне строковых значений.
     *
     * @param json фрагмент JSON
     * @return фрагмент с точками в числах
     */
    public static String sanitizeDecimalCommas(String json) {
        StringBuilder sb = new StringBuilder(json.length());
        for (int i = 0; i < json.length(); i++) {
            char c = json.charAt(i);
            if (c == '"') {
                i = appendStringLiteral(json, i, sb);
            } else if (isDecimalComma(json, i)) {
                sb.append('.');
            } else {
                sb.append(c);
            }
        }
        return sb.toString();
    }

    /** Запятая между двумя цифрами — десятичный разделитель, который надо заменить точкой. */
    private static boolean isDecimalComma(String json, int i) {
        return json.charAt(i) == ',' && i > 0 && i + 1 < json.length()
                && Character.isDigit(json.charAt(i - 1))
                && Character.isDigit(json.charAt(i + 1));
    }

    /**
     * Копирует строковый литерал (начиная с открывающей кавычки в позиции {@code start})
     * как есть, с учётом экранирования.
     *
     * @return индекс закрывающей кавычки (или конец текста, если литерал не закрыт)
     */
    private static int appendStringLiteral(String json, int start, StringBuilder sb) {
        sb.append('"');
        for (int i = start + 1; i < json.length(); i++) {
            char c = json.charAt(i);
            sb.append(c);
            if (c == '\\' && i + 1 < json.length()) {
                sb.append(json.charAt(++i));
            } else if (c == '"') {
                return i;
            }
        }
        return json.length();
    }

    /**
     * Индекс закрывающей скобки, парной открывающей в позиции {@code start}
     * ('{' или '['), с учётом строковых литералов.
     *
     * @return индекс закрывающей скобки или -1, если блок не сбалансирован
     */
    public static int balancedEnd(String text, int start) {
        char open = text.charAt(start);
        char close = open == '{' ? '}' : ']';
        int depth = 0;
        for (int i = start; i < text.length(); i++) {
            char c = text.charAt(i);
            if (c == '"') {
                i = skipStringLiteral(text, i);
            } else if (c == open) {
                depth++;
            } else if (c == close) {
                depth--;
                if (depth == 0) {
                    return i;
                }
            }
        }
        return -1;
    }

    /**
     * Пропускает строковый литерал (начиная с открывающей кавычки в позиции {@code start})
     * с учётом экранирования.
     *
     * @return индекс закрывающей кавычки (или конец текста, если литерал не закрыт)
     */
    private static int skipStringLiteral(String text, int start) {
        for (int i = start + 1; i < text.length(); i++) {
            char c = text.charAt(i);
            if (c == '\\') {
                i++;
            } else if (c == '"') {
                return i;
            }
        }
        return text.length();
    }

    /**
     * Терпимое преобразование в BigDecimal: убирает пробелы (в т.ч. неразрывные),
     * запятую считает десятичной точкой.
     *
     * @param raw  значение (число или строка)
     * @param what описание значения для сообщения об ошибке
     * @throws ScenarioException если значение не является числом
     */
    public static BigDecimal toDecimal(Object raw, String what) {
        try {
            // убираем любые пробельные разделители разрядов (включая NBSP/узкий NBSP)
            String s = String.valueOf(raw).replaceAll("[\\s\\u00A0\\u202F\\u2009]+", "").replace(",", ".");
            return new BigDecimal(s);
        } catch (Exception e) {
            throw new ScenarioException("Не удалось прочитать число («" + raw + "») для: " + what);
        }
    }

    /**
     * Число без экспоненты и без хвостовых нулей: 1080360.000 → 1080360; 0.850 → 0.85.
     */
    public static String fmtPlain(BigDecimal v) {
        BigDecimal s = v.stripTrailingZeros();
        if (s.scale() < 0) {
            s = s.setScale(0);
        }
        return s.toPlainString();
    }
}
