package ru.sber.cs.ai.gigame.service.scenario;

import ru.sber.cs.ai.gigame.dto.scenario.ScenarioDetailResponse;
import ru.sber.cs.ai.gigame.dto.scenario.ScenarioResponse;
import ru.sber.cs.ai.gigame.dto.scenario.ScenarioRunResponse;
import ru.sber.cs.ai.gigame.dto.scenario.ScenarioRunStepInputDataResponse;
import ru.sber.cs.ai.gigame.dto.scenario.ScenarioRunStepOutputDataResponse;
import ru.sber.cs.ai.gigame.dto.scenario.ScenarioRunStepResponse;
import ru.sber.cs.ai.gigame.dto.scenario.graph.GraphDataMapper;
import ru.sber.cs.ai.gigame.model.Scenario;
import ru.sber.cs.ai.gigame.model.ScenarioRun;
import ru.sber.cs.ai.gigame.model.ScenarioRunStep;

import static ru.sber.cs.ai.gigame.service.scenario.ScenarioRunStepService.KEY_DOCUMENTS_TEXT;
import static ru.sber.cs.ai.gigame.service.scenario.ScenarioRunStepService.KEY_ERROR;
import static ru.sber.cs.ai.gigame.service.scenario.ScenarioRunStepService.KEY_PREVIOUS_OUTPUT;
import static ru.sber.cs.ai.gigame.service.scenario.ScenarioRunStepService.KEY_RESULT;

public class ScenarioMapper {
    private ScenarioMapper() {
    }

    /**
     * Преобразует сущность Scenario в DTO для ответа клиенту.
     *
     * @param s сущность сценария
     * @return DTO с метаданными сценария
     */
    static ScenarioResponse toResponse(Scenario s) {
        return new ScenarioResponse(
                s.getId(),
                s.getName(),
                s.getDescription(),
                s.getCreatedAt(),
                s.getUpdatedAt()
        );
    }

    /**
     * Преобразует сущность Scenario в DTO с полными данными графа.
     *
     * @param s сущность сценария
     * @return DTO с полной информацией о сценарии
     */
    static ScenarioDetailResponse toDetailResponse(Scenario s) {
        return new ScenarioDetailResponse(
                s.getId(),
                s.getName(),
                s.getDescription(),
                s.getCreatedAt(),
                s.getUpdatedAt(),
                GraphDataMapper.toDto(s.getGraphData())
        );
    }

    /**
     * Преобразует сущность ScenarioRun в DTO для ответа клиенту.
     *
     * @param r сущность запуска
     * @return DTO с метаданными запуска
     */
    static ScenarioRunResponse toRunResponse(ScenarioRun r) {
        return new ScenarioRunResponse(
                r.getId(),
                r.getScenarioId(),
                r.getStatus(),
                r.getInputDocumentIds(),
                r.getResult(),
                r.getStartedAt(),
                r.getCompletedAt()
        );
    }

    /**
     * Преобразует сущность ScenarioRunStep в DTO для ответа клиенту.
     *
     * @param s сущность шага запуска
     * @return DTO с данными шага
     */
    static ScenarioRunStepResponse toStepResponse(ScenarioRunStep s) {
        return new ScenarioRunStepResponse(
                s.getId(),
                s.getNodeId(),
                s.getNodeType(),
                s.getStatus(),
                getScenarioRunStepInputDataResponse(s),
                getScenarioRunStepOutputDataResponse(s),
                s.getPromptUsed(),
                s.getTokensUsed(),
                s.getStartedAt(),
                s.getCompletedAt()
        );
    }

    private static ScenarioRunStepOutputDataResponse getScenarioRunStepOutputDataResponse(ScenarioRunStep s) {
        if (s.getOutputData() == null) {
            return null;
        }
        return new ScenarioRunStepOutputDataResponse(
                s.getOutputData().get(KEY_RESULT),
                s.getOutputData().get(KEY_ERROR)
        );
    }

    private static ScenarioRunStepInputDataResponse getScenarioRunStepInputDataResponse(ScenarioRunStep s) {
        if (s.getInputData() == null) {
            return null;
        }
        return new ScenarioRunStepInputDataResponse(
                s.getInputData().get(KEY_DOCUMENTS_TEXT),
                s.getInputData().get(KEY_PREVIOUS_OUTPUT)
        );
    }
}
