package ru.sber.cs.ai.gigame.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import ru.sber.cs.ai.gigame.model.ScenarioRunStep;

import java.util.List;
import java.util.UUID;

/**
 * Репозиторий для работы с шагами выполнения сценариев.
 * <p>
 * Предоставляет методы для получения истории выполнения узлов сценария.
 *
 * @see ScenarioRunStep
 */
@Repository
public interface ScenarioRunStepRepository extends JpaRepository<ScenarioRunStep, UUID> {

    /**
     * Возвращает все шаги указанного запуска, отсортированные по времени начала (хронологический порядок).
     *
     * @param runId идентификатор запуска сценария
     * @return список шагов выполнения
     */
    List<ScenarioRunStep> findByRunIdOrderByStartedAtAsc(UUID runId);
}
