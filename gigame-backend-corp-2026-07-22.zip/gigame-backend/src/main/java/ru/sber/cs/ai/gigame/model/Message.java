package ru.sber.cs.ai.gigame.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;

import java.time.OffsetDateTime;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Сущность сообщения в диалоге.
 * <p>
 * Сохраняет переписку между пользователем и ассистентом, включая
 * привязанные документы и историю общения.
 *
 * @see Conversation
 */
@Entity
@Table(name = "messages")

@Getter
@Setter
@NoArgsConstructor
public class Message {

    /**
     * Уникальный идентификатор сообщения (UUID).
     */
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;

    /**
     * Диалог, к которому относится сообщение.
     */
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "conversation_id", nullable = false)
    private Conversation conversation;

    /**
     * Роль отправителя сообщения ("user" или "assistant").
     */
    @Column(nullable = false, length = 50)
    private String role;

    /**
     * Текстовое содержимое сообщения.
     */
    @Column(nullable = false, columnDefinition = "TEXT")
    private String content;

    /**
     * Список идентификаторов документов, прикреплённых к сообщению.
     * Хранится в формате JSONB.
     */
    @JdbcTypeCode(SqlTypes.JSON)
    @Column(name = "document_ids", columnDefinition = "jsonb")
    private List<String> documentIds;

    /**
     * Источники RAG, использованные при генерации ответа ассистента (JSONB).
     * Каждый элемент: {document_id, document_name, snippet}.
     */
    @JdbcTypeCode(SqlTypes.JSON)
    @Column(name = "sources", columnDefinition = "jsonb")
    private List<Map<String, String>> sources;
    /**
     * Дата и время создания сообщения (автоматически устанавливается).
     */
    @CreationTimestamp
    @Column(name = "created_at", nullable = false, updatable = false)
    private OffsetDateTime createdAt;
}
