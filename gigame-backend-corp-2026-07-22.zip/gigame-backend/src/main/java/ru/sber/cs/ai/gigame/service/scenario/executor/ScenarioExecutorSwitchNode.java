package ru.sber.cs.ai.gigame.service.scenario.executor;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.http.codec.ServerSentEvent;
import reactor.core.publisher.FluxSink;
import ru.sber.cs.ai.gigame.service.scenario.enums.ScenarioNodeType;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunNode;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import static ru.sber.cs.ai.gigame.service.scenario.ScenarioEventEmission.emitSwitchResultEvent;

@Slf4j
public class ScenarioExecutorSwitchNode extends AbstractScenarioExecutor {
    private static final int DETAILS_MAX_LENGTH = 200;
    private static final String LABEL_DEFAULT = "default";
    private static final String LABEL_ELSE = "else";
    private static final String LABEL_OTHER_RU = "прочее";
    private static final String LABEL_ANOTHER_RU = "другое";
    private static final String LABEL_OTHERWISE_RU = "иначе";
    private static final String LABEL_WILDCARD = "*";
    private static final ObjectMapper objectMapper = new ObjectMapper();
    private final Set<String> defaultLabelSet = Set.of(LABEL_ELSE, LABEL_OTHER_RU, LABEL_ANOTHER_RU, LABEL_OTHERWISE_RU, LABEL_WILDCARD, LABEL_DEFAULT);

    protected ScenarioExecutorSwitchNode(ScenarioRunNode node) {
        super(node);
    }

    /**
     * Преобразует объект в строку, убирая null и пробельные символы.
     *
     * @param obj объект для преобразования
     * @return строковое представление или пустая строка
     */
    private static String strVal(Object obj) {
        if (obj == null) {
            return "";
        }
        return obj.toString().trim();
    }

    private static List<String> matchText(String input, List<Map<String, Object>> rules, String mode) {
        List<String> result = new ArrayList<>();
        String textToMatch = input.toLowerCase();
        for (Map<String, Object> rule : rules) {
            String value = strVal(rule.get("value")).toLowerCase();
            String operator = strVal(rule.getOrDefault("operator", "contains"));
            String label = strVal(rule.getOrDefault("label", value));

            boolean matched = ("equals".equals(operator) && textToMatch.trim().equals(value)) ||
                    (OPERATOR_CONTAINS.equals(operator) && textToMatch.contains(value)) ||
                    (OPERATOR_STARTSWITH.equals(operator) && textToMatch.trim().startsWith(value));

            if (matched) {
                result.add(label);
                if ("first".equals(mode)) {
                    break;
                }
            }
        }
        return result;
    }

    /**
     * Выполняет узел переключения (Switch).
     * <p>
     * Анализирует предыдущий вывод и выбирает подходящие ветки на основе правил.
     * Поддерживает два режима:
     * <ul>
     *   <li>Классификация документов из Loop (structurred output)</li>
     *   <li>Текстовое сопоставление с правилами</li>
     * </ul>
     *
     * @param sink поток SSE-событий
     * @return строка с результатом переключения
     */
    @Override
    public String execute(FluxSink<ServerSentEvent<Map<String, Object>>> sink) {
        String output = "Switch → ";
        var parentNode = node.getParentNodeList().get(0);
        if (parentNode.isClassifyStrict()) {
            processClassifyStrict(sink);
            output += "\n[Строгая классификация документов → ветки получат только свои документы]";
        } else {
            if (node.getParentNodeList().get(0).getType().equals(ScenarioNodeType.LOOP_NODE)) {
                processWhenParentLoop(sink);
            } else {
                processSimple(sink);
            }
            output += "\n[Проверка правил → ветки получат только свои данные]";
        }
        output += "\n";
        output += node.getOutput();
        return output;
    }

    private ScenarioRunNode getDefaultNode() {
        return node.getChildNodeList().stream()
                .filter(next -> {
                    var edgeData = node.getGraph().getEdgeMap().get(Pair.of(node.getId(), next.getId()));
                    var edgeLabel = (null == edgeData) ? "" : strVal(edgeData.label());
                    return defaultLabelSet.contains(edgeLabel.toLowerCase());
                }).findFirst().orElse(null);
    }

    private void processSimple(FluxSink<ServerSentEvent<Map<String, Object>>> sink) {
        List<Map<String, Object>> rules = parseRules(node.getRules());
        var inputAll = String.join("\n", node.getInput());
        var matchedLabels = matchText(inputAll, rules, node.getMode());
        for (var next : node.getChildNodeList()) {
            var edgeLabel = getEdgeLabel(next);
            if (matchedLabels.contains(edgeLabel)) {
                next.getInput().add(inputAll);
                emitSwitchResultEvent(sink, node, edgeLabel + "\" -> " + StringUtils.abbreviate(inputAll, DETAILS_MAX_LENGTH));
                return;
            }
        }
        var defaultNode = getDefaultNode();
        if (defaultNode != null) {
            defaultNode.getInput().add(inputAll);
            emitSwitchResultEvent(sink, node, "default\" -> " + StringUtils.abbreviate(inputAll, DETAILS_MAX_LENGTH));
            defaultNode.setSkip(false);
        }
        emitSkippedEdgeEven(sink);
    }

    private void processWhenParentLoop(FluxSink<ServerSentEvent<Map<String, Object>>> sink) {
        List<Map<String, Object>> rules = parseRules(node.getRules());
        var inputList = new ArrayList<>(node.getInput());
        for (var input : inputList) {
            var matchedLabels = matchText(input, rules, node.getMode());
            for (var next : node.getChildNodeList()) {
                var edgeLabel = getEdgeLabel(next);
                if (matchedLabels.contains(edgeLabel)) {
                    next.getInput().add(input);
                    emitSwitchResultEvent(sink, node, edgeLabel + "\" -> " + StringUtils.abbreviate(input, DETAILS_MAX_LENGTH));
                    inputList.remove(input);
                }
            }
        }
        var defaultNode = getDefaultNode();
        if (defaultNode != null && !inputList.isEmpty()) {
            defaultNode.getInput().addAll(inputList);
            defaultNode.setSkip(false);
            emitSwitchResultEvent(sink, node, "default\" -> " + StringUtils.abbreviate(String.join("\n", inputList), DETAILS_MAX_LENGTH));
        }
        emitSkippedEdgeEven(sink);
    }

    private void emitSkippedEdgeEven(FluxSink<ServerSentEvent<Map<String, Object>>> sink) {
        node.getChildNodeList().stream()
                .filter(ScenarioRunNode::getSkip)
                .forEach(next -> emitSwitchResultEvent(sink, node, getEdgeLabel(next) + "\" -> ветка пропущена"));
    }

    private String getEdgeLabel(ScenarioRunNode next) {
        var edgeData = node.getGraph().getEdgeMap().get(Pair.of(node.getId(), next.getId()));
        return (null == edgeData) ? "" : strVal(edgeData.label());
    }

    private void processClassifyStrict(FluxSink<ServerSentEvent<Map<String, Object>>> sink) {
        List<String> docList = new ArrayList<>();
        for (var next : node.getChildNodeList()) {
            var edgeLabel = getEdgeLabel(next);
            next.getDocList().addAll(node.getGraph().getDocMap().entrySet().stream()
                    .filter(entry -> edgeLabel.equals(entry.getValue().getDocClass()))
                    .map(entry -> {
                        emitSwitchResultEvent(sink, node, edgeLabel + "\" -> " + entry.getKey() + " - " + entry.getValue().getFilename());
                        return entry.getKey();
                    }).toList());
            next.setSkip(next.getDocList().isEmpty());
            if (next.getDocList().isEmpty()) {
                emitSwitchResultEvent(sink, node, edgeLabel + "\" -> ветка пропущена");
            } else {
                docList.addAll(next.getDocList());
            }
        }
        var defaultNode = getDefaultNode();
        if (defaultNode != null) {
            defaultNode.getDocList().addAll(node.getGraph().getDocMap().entrySet().stream()
                    .filter(entry -> !docList.contains(entry.getKey()))
                    .map(entry -> {
                        emitSwitchResultEvent(sink, node, "default\" -> " + entry.getKey() + " - " + entry.getValue().getFilename());
                        return entry.getKey();
                    }).toList());
            defaultNode.setSkip(false);
        }
    }

    /**
     * Парсит правила для узла Switch.
     * <p>
     * Поддерживает вход в виде List или String (JSON).
     *
     * @param rulesRaw сырые правила
     * @return список правил как Map
     */
    @SuppressWarnings("unchecked")
    private List<Map<String, Object>> parseRules(Object rulesRaw) {
        if (rulesRaw instanceof List) {
            return (List<Map<String, Object>>) rulesRaw;
        }
        if (rulesRaw instanceof String rulesStr) {
            try {
                return objectMapper.readValue(rulesStr, new TypeReference<>() {
                });
            } catch (Exception e) {
                log.warn("Failed to parse switch rules: {}", rulesStr);
                return List.of();
            }
        }
        return List.of();
    }
}
