package ru.sber.cs.ai.gigame.exception;

import lombok.Getter;

import java.util.Map;

/**
 * Базовое пользовательское исключение приложения.
 * Все пользовательские исключения должны наследоваться от этого класса.
 */
@Getter
public abstract class ApplicationRuntimeException extends RuntimeException {

    private final int statusCode;
    private final Map<String, String> details;

    protected ApplicationRuntimeException(String message, int statusCode, Map<String, String> details) {
        super(message);
        this.statusCode = statusCode;
        this.details = details;
    }

    protected ApplicationRuntimeException(String message, int statusCode) {
        super(message);
        this.statusCode = statusCode;
        this.details = null;
    }

    protected ApplicationRuntimeException(String message, Throwable cause, int statusCode, Map<String, String> details) {
        super(message, cause);
        this.statusCode = statusCode;
        this.details = details;
    }

    protected ApplicationRuntimeException(String message, Throwable cause, int statusCode) {
        super(message, cause);
        this.statusCode = statusCode;
        this.details = null;
    }
}
