package ru.sber.cs.ai.gigame.dto.chat;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Schema;

import java.time.OffsetDateTime;
import java.util.List;
import java.util.UUID;

/**
 * DTO для представления информации о беседе.
 * Возвращает полную информацию о существующей беседе, включая метаданные и связи.
 *
 * @param id               Уникальный идентификатор беседы
 * @param title            Название беседы
 * @param knowledgeBaseId  Идентификатор связанной базы знаний (устаревшее поле)
 * @param knowledgeBaseIds Идентификаторы связанных баз знаний
 * @param model            Модель GigaChat для диалога (null — по умолчанию)
 * @param temperature      Температура генерации (null — по умолчанию)
 * @param createdAt        Дата и время создания беседы
 * @param updatedAt        Дата и время последнего обновления
 * @see ConversationCreate
 * @see ConversationWithMessages
 */
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
@Schema(
        description = "Информация о беседе в чате",
        additionalProperties = Schema.AdditionalPropertiesValue.FALSE
)
public record ConversationResponse(
        @Schema(
                description = "Уникальный идентификатор беседы",
                example = "550e8400-e29b-41d4-a716-446655440000",
                pattern = "^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"
        )
        UUID id,

        @Schema(
                description = "Название беседы",
                example = "Обсуждение проекта",
                pattern = "^[\\w\\W]{0,64}$"
        )
        String title,

        @Schema(
                description = "Идентификатор связанной базы знаний (устаревшее, см. knowledge_base_ids)",
                example = "550e8400-e29b-41d4-a716-446655440000",
                pattern = "^[\\w\\W]{0,64}$"
        )
        String knowledgeBaseId,

        @ArraySchema(
                schema = @Schema(description = "Идентификаторы связанных баз знаний",
                        pattern = "^[\\w\\W]{0,64}$"),
                maxItems = 20
        )
        List<String> knowledgeBaseIds,

        @Schema(
                description = "Модель GigaChat для диалога (null — модель по умолчанию)",
                example = "GigaChat-2-Max",
                pattern = "^[\\w\\W]{0,64}$"
        )
        String model,

        @Schema(
                description = "Температура генерации (null — значение по умолчанию)",
                example = "0.7"
        )
        Double temperature,

        @Schema(
                description = "Дата и время создания беседы"
        )
        OffsetDateTime createdAt,

        @Schema(
                description = "Дата и время последнего обновления"
        )
        OffsetDateTime updatedAt
) {
}
