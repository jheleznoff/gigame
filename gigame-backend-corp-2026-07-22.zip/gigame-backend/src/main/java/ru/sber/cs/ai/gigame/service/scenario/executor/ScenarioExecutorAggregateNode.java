package ru.sber.cs.ai.gigame.service.scenario.executor;

import com.fasterxml.jackson.core.json.JsonReadFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.json.JsonMapper;
import org.springframework.http.codec.ServerSentEvent;
import reactor.core.publisher.FluxSink;
import ru.sber.cs.ai.gigame.exception.ScenarioException;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunNode;
import ru.sber.cs.ai.gigame.utils.JsonCalcUtils;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Узел «Агрегация»: детерминированное суммирование числового поля по строкам
 * JSON-массива из результата предыдущего узла, без LLM.
 * <p>
 * Вход — последний JSON-массив объектов во входе узла (обычно результат
 * LLM-извлечения атрибутов документов). Конфигурация — в поле rules узла:
 * <pre>
 * {"суммировать": "сумма_зачтено",
 *  "группировать_по": "договор",                                // опционально
 *  "фильтр": {"поле": "зачтено", "равно": "да"},                // опционально
 *  "порог": {"значение": 255732113, "оператор": "greater_or_equal",
 *            "метка": "50% НМЦ лота 1"}}                        // опционально
 * </pre>
 * Выход — markdown-отчёт (суммы по группам, итог, вердикт по порогу,
 * предупреждения) + JSON-блок «===РЕЗУЛЬТАТЫ РАСЧЁТА===» для адресации
 * из следующих узлов выражениями {{json:Метка:путь}}. Все вычисления —
 * BigDecimal; одинаковые входы дают байт-в-байт одинаковый результат.
 * Строки с нечисловым или отсутствующим значением поля в сумму не входят
 * и попадают в предупреждения.
 */
public class ScenarioExecutorAggregateNode extends AbstractScenarioExecutor {

    /** Терпимый парсер: допускает комментарии, хвостовые запятые, одинарные кавычки. */
    private static final ObjectMapper MAPPER = JsonMapper.builder()
            .enable(JsonReadFeature.ALLOW_JAVA_COMMENTS)
            .enable(JsonReadFeature.ALLOW_YAML_COMMENTS)
            .enable(JsonReadFeature.ALLOW_TRAILING_COMMA)
            .enable(JsonReadFeature.ALLOW_SINGLE_QUOTES)
            .build();

    protected ScenarioExecutorAggregateNode(ScenarioRunNode node) {
        super(node);
    }

    /** Промежуточное состояние агрегации: суммы, счётчики, предупреждения. */
    private static final class Aggregation {
        final Map<String, BigDecimal> groupSums = new LinkedHashMap<>();
        final Map<String, Integer> groupCounts = new LinkedHashMap<>();
        final List<String> warnings = new ArrayList<>();
        BigDecimal total = BigDecimal.ZERO;
        int summedRows;
        int totalRows;
    }

    @Override
    public String execute(FluxSink<ServerSentEvent<Map<String, Object>>> sink) {
        Map<String, Object> config = parseConfig(node.getRules());
        String sumField = stringValue(config.get("суммировать"));
        if (sumField.isBlank()) {
            throw new ScenarioException("Узел агрегации: не задано поле «суммировать» "
                    + "(настройте узел в панели конфигурации)");
        }
        String groupBy = stringValue(config.get("группировать_по"));
        Map<String, Object> filter = mapOf(config.get("фильтр"));
        Map<String, Object> threshold = mapOf(config.get("порог"));

        List<Map<String, Object>> rows = extractRows(String.join("\n\n", node.getInput()));
        Aggregation agg = aggregate(rows, sumField, groupBy, filter);

        String result = renderReport(agg, sumField, groupBy, filter, threshold);
        prompt = "[узел агрегации — расчёт выполнен кодом, без обращения к GigaChat]";
        node.getOutput().add(result);
        var input = prepareNextInput();
        for (var next : node.getChildNodeList()) {
            next.setSkip(false);
            next.getInput().addAll(input);
        }
        return result;
    }

    private Aggregation aggregate(List<Map<String, Object>> rows, String sumField,
                                  String groupBy, Map<String, Object> filter) {
        Aggregation agg = new Aggregation();
        agg.totalRows = rows.size();
        List<Map<String, Object>> accepted = applyFilter(rows, filter, agg.warnings);
        for (int i = 0; i < accepted.size(); i++) {
            Map<String, Object> row = accepted.get(i);
            BigDecimal value = rowValue(row, i, sumField, agg.warnings);
            if (value == null) {
                continue;
            }
            agg.total = agg.total.add(value);
            agg.summedRows++;
            if (!groupBy.isBlank()) {
                String key = groupKey(row, groupBy);
                agg.groupSums.merge(key, value, BigDecimal::add);
                agg.groupCounts.merge(key, 1, Integer::sum);
            }
        }
        return agg;
    }

    /**
     * Числовое значение поля суммирования строки; {@code null} — строка в сумму
     * не входит (нет значения или не число), причина добавляется в предупреждения.
     */
    private static BigDecimal rowValue(Map<String, Object> row, int index, String sumField,
                                       List<String> warnings) {
        Object raw = fuzzyGet(row, sumField);
        if (raw == null || String.valueOf(raw).isBlank()) {
            warnings.add("строка " + rowLabel(row, index) + ": нет значения поля «" + sumField
                    + "» — в сумму не включена, требуется ручная проверка");
            return null;
        }
        try {
            return JsonCalcUtils.toDecimal(raw, "поле «" + sumField + "»");
        } catch (ScenarioException e) {
            warnings.add("строка " + rowLabel(row, index) + ": значение «" + raw
                    + "» поля «" + sumField + "» не является числом — в сумму не включена, "
                    + "требуется ручная проверка");
            return null;
        }
    }

    private String renderReport(Aggregation agg, String sumField, String groupBy,
                                Map<String, Object> filter, Map<String, Object> threshold) {
        StringBuilder out = new StringBuilder("## Агрегация (детерминированный расчёт, без LLM)\n\n");
        out.append("Поле суммирования: «").append(sumField).append("»");
        if (!filter.isEmpty()) {
            out.append("; фильтр: ").append(describeFilter(filter));
        }
        out.append(". Строк во входных данных: ").append(agg.totalRows)
                .append(", учтено в сумме: ").append(agg.summedRows).append(".\n\n");

        if (!groupBy.isBlank()) {
            out.append("| ").append(groupBy).append(" | Сумма | Строк |\n|---|---|---|\n");
            for (var entry : agg.groupSums.entrySet()) {
                out.append("| ").append(entry.getKey()).append(" | ")
                        .append(JsonCalcUtils.fmtPlain(entry.getValue())).append(" | ")
                        .append(agg.groupCounts.get(entry.getKey())).append(" |\n");
            }
            out.append("\n");
        }
        out.append("**ИТОГО: ").append(JsonCalcUtils.fmtPlain(agg.total)).append("**\n");

        Boolean thresholdPassed = appendThreshold(out, agg.total, threshold);

        if (!agg.warnings.isEmpty()) {
            out.append("\n## ⚠️ Предупреждения\n\n");
            for (String w : agg.warnings) {
                out.append("- ").append(w).append("\n");
            }
        }
        appendResultJson(out, agg, groupBy, threshold, thresholdPassed);
        return out.toString();
    }

    /** @return вердикт по порогу или {@code null}, если порог не задан */
    private Boolean appendThreshold(StringBuilder out, BigDecimal total, Map<String, Object> threshold) {
        if (threshold.isEmpty()) {
            return null;
        }
        BigDecimal thresholdValue = JsonCalcUtils.toDecimal(threshold.get("значение"), "порог агрегации");
        String operator = stringValue(threshold.getOrDefault("оператор", "greater_or_equal"));
        boolean passed = compare(total, operator, thresholdValue);
        String labelText = stringValue(threshold.get("метка"));
        out.append("\nПорог");
        if (!labelText.isBlank()) {
            out.append(" («").append(labelText).append("»)");
        }
        out.append(": ").append(JsonCalcUtils.fmtPlain(thresholdValue))
                .append(", оператор: ").append(operator)
                .append(" → **").append(passed ? "СООТВЕТСТВУЕТ" : "НЕ СООТВЕТСТВУЕТ")
                .append("**\n");
        return passed;
    }

    /** JSON-блок для адресации из следующих узлов ({{json:Метка:путь}}). */
    private void appendResultJson(StringBuilder out, Aggregation agg, String groupBy,
                                  Map<String, Object> threshold, Boolean thresholdPassed) {
        Map<String, Object> resultJson = new LinkedHashMap<>();
        resultJson.put("итого", JsonCalcUtils.fmtPlain(agg.total));
        if (!groupBy.isBlank()) {
            Map<String, Object> groups = new LinkedHashMap<>();
            agg.groupSums.forEach((k, v) -> groups.put(k, JsonCalcUtils.fmtPlain(v)));
            resultJson.put("группы", groups);
        }
        if (thresholdPassed != null) {
            resultJson.put("порог", JsonCalcUtils.fmtPlain(
                    JsonCalcUtils.toDecimal(threshold.get("значение"), "порог агрегации")));
            resultJson.put("оператор", stringValue(threshold.getOrDefault("оператор", "greater_or_equal")));
            resultJson.put("соответствует", thresholdPassed ? "да" : "нет");
        }
        resultJson.put("строк_учтено", agg.summedRows);
        resultJson.put("строк_всего", agg.totalRows);
        out.append("\n===РЕЗУЛЬТАТЫ РАСЧЁТА===\n");
        try {
            out.append(MAPPER.writeValueAsString(resultJson));
        } catch (Exception e) {
            out.append("{}");
        }
        out.append("\n");
    }

    /**
     * Последний JSON-массив объектов во входе узла — строки для агрегации.
     */
    private List<Map<String, Object>> extractRows(String input) {
        for (int i = input.length() - 1; i >= 0; i--) {
            int end = input.charAt(i) == '[' ? JsonCalcUtils.balancedEnd(input, i) : -1;
            if (end < 0) {
                continue;
            }
            List<Map<String, Object>> rows = parseRowsCandidate(input.substring(i, end + 1));
            if (!rows.isEmpty()) {
                return rows;
            }
        }
        throw new ScenarioException("Узел агрегации: во входных данных не найден JSON-массив объектов — "
                + "предыдущий узел должен выдавать извлечённые строки в формате JSON-массива");
    }

    /**
     * Разбирает кандидата: объекты JSON-массива; пустой список — блок не массив
     * объектов, поиск продолжается с более раннего кандидата.
     */
    private List<Map<String, Object>> parseRowsCandidate(String json) {
        try {
            List<?> candidate = MAPPER.readValue(JsonCalcUtils.sanitizeDecimalCommas(json), List.class);
            List<Map<String, Object>> rows = new ArrayList<>();
            for (Object o : candidate) {
                if (o instanceof Map<?, ?> m) {
                    @SuppressWarnings("unchecked")
                    Map<String, Object> row = (Map<String, Object>) m;
                    rows.add(row);
                }
            }
            return rows;
        } catch (Exception ignored) {
            // не JSON — пробуем более ранний кандидат
            return List.of();
        }
    }

    private List<Map<String, Object>> applyFilter(List<Map<String, Object>> rows,
                                                  Map<String, Object> filter, List<String> warnings) {
        if (filter.isEmpty()) {
            return rows;
        }
        String field = stringValue(filter.get("поле"));
        if (field.isBlank()) {
            throw new ScenarioException("Узел агрегации: в фильтре не задано «поле»");
        }
        String equalsValue = stringValue(filter.get("равно"));
        String containsValue = stringValue(filter.get("содержит"));
        if (equalsValue.isBlank() && containsValue.isBlank()) {
            throw new ScenarioException("Узел агрегации: в фильтре не задано условие «равно» или «содержит»");
        }
        List<Map<String, Object>> accepted = new ArrayList<>();
        int filteredOut = 0;
        for (Map<String, Object> row : rows) {
            String value = stringValue(fuzzyGet(row, field)).toLowerCase(Locale.ROOT).strip();
            boolean pass = !equalsValue.isBlank()
                    ? value.equals(equalsValue.toLowerCase(Locale.ROOT).strip())
                    : value.contains(containsValue.toLowerCase(Locale.ROOT).strip());
            if (pass) {
                accepted.add(row);
            } else {
                filteredOut++;
            }
        }
        if (filteredOut > 0) {
            warnings.add("отфильтровано строк по условию " + describeFilter(filter) + ": " + filteredOut);
        }
        return accepted;
    }

    private static String describeFilter(Map<String, Object> filter) {
        String field = stringValue(filter.get("поле"));
        String equalsValue = stringValue(filter.get("равно"));
        return "«" + field + "» "
                + (equalsValue.isBlank() ? "содержит «" + stringValue(filter.get("содержит")) : "= «" + equalsValue)
                + "»";
    }

    private static boolean compare(BigDecimal total, String operator, BigDecimal threshold) {
        int cmp = total.compareTo(threshold);
        return switch (operator) {
            case "greater_than" -> cmp > 0;
            case "less_than" -> cmp < 0;
            case "less_or_equal" -> cmp <= 0;
            case "equals" -> cmp == 0;
            case "greater_or_equal" -> cmp >= 0;
            default -> throw new ScenarioException("Узел агрегации: неизвестный оператор порога «"
                    + operator + "» (допустимо: greater_or_equal, greater_than, less_or_equal, "
                    + "less_than, equals)");
        };
    }

    private String groupKey(Map<String, Object> row, String groupBy) {
        Object key = fuzzyGet(row, groupBy);
        String keyText = stringValue(key).strip();
        return keyText.isBlank() ? "БЕЗ ГРУППЫ" : keyText;
    }

    private static String rowLabel(Map<String, Object> row, int index) {
        for (String candidate : List.of("договор", "документ", "название", "имя", "акт")) {
            Object v = fuzzyGet(row, candidate);
            if (v != null && !String.valueOf(v).isBlank()) {
                return "«" + v + "»";
            }
        }
        return "№" + (index + 1);
    }

    /**
     * Поиск значения по названию поля с нормализацией (регистр, пунктуация,
     * частичное совпадение) — названия в данных и конфигурации могут
     * отличаться формой записи.
     */
    private static Object fuzzyGet(Map<String, Object> map, String key) {
        String want = normalizeKey(key);
        for (Map.Entry<String, Object> e : map.entrySet()) {
            if (normalizeKey(e.getKey()).equals(want)) {
                return e.getValue();
            }
        }
        for (Map.Entry<String, Object> e : map.entrySet()) {
            String have = normalizeKey(e.getKey());
            if (have.contains(want) || want.contains(have)) {
                return e.getValue();
            }
        }
        return null;
    }

    private static String normalizeKey(String s) {
        return s.toLowerCase(Locale.ROOT).replaceAll("[^а-яa-z0-9ё]+", "");
    }

    private static String stringValue(Object raw) {
        return raw == null ? "" : String.valueOf(raw);
    }

    @SuppressWarnings("unchecked")
    private static Map<String, Object> mapOf(Object raw) {
        return raw instanceof Map ? (Map<String, Object>) raw : Map.of();
    }

    @SuppressWarnings("unchecked")
    private Map<String, Object> parseConfig(String rules) {
        try {
            if (rules != null && !rules.isBlank() && rules.trim().startsWith("{")) {
                return MAPPER.readValue(rules, Map.class);
            }
        } catch (Exception e) {
            throw new ScenarioException("Узел агрегации: не удалось разобрать конфигурацию: " + e.getMessage());
        }
        throw new ScenarioException("Узел агрегации: не задана конфигурация "
                + "(настройте поле суммирования в панели узла)");
    }
}
