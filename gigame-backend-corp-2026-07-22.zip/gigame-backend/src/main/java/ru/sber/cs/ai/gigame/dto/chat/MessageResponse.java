package ru.sber.cs.ai.gigame.dto.chat;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Schema;

import java.time.OffsetDateTime;
import java.util.List;
import java.util.UUID;

/**
 * DTO для представления сообщения в чате.
 * Содержит информацию о сообщении, отправителе, содержимом и связанных документах.
 *
 * @param id             Уникальный идентификатор сообщения
 * @param conversationId Идентификатор беседы, к которой относится сообщение
 * @param role           Роль отправителя (например, "user", "assistant")
 * @param content        Текстовое содержимое сообщения
 * @param documentIds    Список идентификаторов связанных документов
 * @param sources        Источники RAG, использованные при генерации ответа
 * @param createdAt      Дата и время отправки сообщения
 * @see ConversationResponse
 */
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
@Schema(
        description = "Сообщение в чате",
        additionalProperties = Schema.AdditionalPropertiesValue.FALSE
)
public record MessageResponse(
        @Schema(
                description = "Уникальный идентификатор сообщения",
                example = "550e8400-e29b-41d4-a716-446655440000",
                pattern = "^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"
        )
        UUID id,

        @Schema(
                description = "Уникальный идентификатор беседы",
                example = "550e8400-e29b-41d4-a716-446655440000",
                pattern = "^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"
        )
        UUID conversationId,

        @Schema(
                description = "Роль отправителя (user, assistant, system)",
                example = "assistant",
                pattern = "^[\\w\\W]{0,16}$"
        )
        String role,

        @Schema(
                description = "Текстовое содержимое сообщения",
                example = "Привет! Как я могу помочь вам сегодня?",
                pattern = "^[\\w\\W]{0,4096}$"
        )
        String content,

        @ArraySchema(
                schema = @Schema(description = "Список идентификаторов связанных документов",
                        maxLength = 255,
                        pattern = "^[\\w\\W]{0,255}$"),
                maxItems = 100
        )
        List<String> documentIds,

        @ArraySchema(
                schema = @Schema(description = "Источник RAG: {document_id, document_name, snippet}"),
                maxItems = 20
        )
        List<RagSource> sources,

        @Schema(
                description = "Дата и время отправки сообщения"
        )
        OffsetDateTime createdAt
) {
}
