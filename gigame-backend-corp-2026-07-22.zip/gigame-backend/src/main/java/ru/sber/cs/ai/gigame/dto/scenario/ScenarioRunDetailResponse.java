package ru.sber.cs.ai.gigame.dto.scenario;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Size;

import java.time.OffsetDateTime;
import java.util.List;
import java.util.UUID;

/**
 * DTO для подробного представления запуска сценария.
 * Возвращает полную информацию о выполнении сценария со всеми шагами.
 *
 * @param id               Уникальный идентификатор запуска
 * @param scenarioId       Идентификатор выполненного сценария
 * @param status           Статус выполнения (например, "pending", "running", "completed", "failed")
 * @param inputDocumentIds Список идентификаторов входных документов
 * @param result           Результат выполнения сценария
 * @param startedAt        Дата и время начала выполнения
 * @param completedAt      Дата и время завершения выполнения
 * @param steps            Список шагов выполнения сценария
 * @see ScenarioRunResponse
 * @see ScenarioRunStepResponse
 */
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
@Schema(
        description = "Полная информация о запуске AI-сценария со всеми шагами",
        additionalProperties = Schema.AdditionalPropertiesValue.FALSE
)
public record ScenarioRunDetailResponse(
        @Schema(
                description = "Уникальный идентификатор запуска",
                example = "550e8400-e29b-41d4-a716-446655440000",
                pattern = "^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"
        )
        UUID id,

        @Schema(
                description = "Идентификатор выполненного сценария",
                example = "550e8400-e29b-41d4-a716-446655440000",
                pattern = "^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"
        )
        UUID scenarioId,

        @Schema(
                description = "Статус выполнения (pending, running, completed, failed, paused)",
                example = "completed",
                pattern = "^[\\w\\W]{0,32}$"
        )
        String status,

        @ArraySchema(
                schema = @Schema(description = "Идентификатор входного документа",
                        maxLength = 255,
                        pattern = "^[\\w\\W]{0,255}$"),
                maxItems = 100
        )
        List<String> inputDocumentIds,

        @Schema(
                description = "Результат выполнения сценария"
        )
        Object result,

        @Schema(
                description = "Дата и время начала выполнения"
        )
        OffsetDateTime startedAt,

        @Schema(
                description = "Дата и время завершения выполнения"
        )
        OffsetDateTime completedAt,

        @Schema(
                description = "Список шагов выполнения сценария (максимум 100)"
        )
        @Size(max = 100)
        @ArraySchema(
                schema = @Schema(implementation = ScenarioRunStepResponse.class),
                maxItems = 100
        )
        List<ScenarioRunStepResponse> steps
) {
}
