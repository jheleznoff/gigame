package ru.sber.cs.ai.gigame.dto.scenario;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import io.swagger.v3.oas.annotations.media.Schema;

@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
@Schema(
        description = "Выходные данные шага выполнения сценария",
        additionalProperties = Schema.AdditionalPropertiesValue.FALSE
)
public record ScenarioRunStepOutputDataResponse(
        @Schema(
                description = "Результат выполнения шага сценария",
                pattern = "^[\\w\\W]{0,4096}$",
                nullable = true
        )
        String result,
        @Schema(
                description = "Ошибка",
                pattern = "^[\\w\\W]{0,255}$",
                nullable = true
        )
        String error
) {
}
