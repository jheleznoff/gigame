package ru.sber.cs.ai.gigame.model;

import io.hypersistence.utils.hibernate.type.array.FloatArrayType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.Array;
import org.hibernate.annotations.Type;
import ru.sber.cs.ai.gigame.service.EmbeddingService;

import java.util.UUID;

/**
 * Сущность векторного представления текстового фрагмента.
 * <p>
 * Используется для хранения эмбеддингов (векторных представлений)
 * текстовых чанков с целью быстрого поиска похожих фрагментов через pgvector.
 *
 * @see EmbeddingService
 */
@Entity
@Table(name = "embeddings")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Embedding {

    /**
     * Уникальный идентификатор эмбеддинга (UUID).
     */
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;

    /**
     * Тип коллекции: "doc" (документ) или "kb" (база знаний).
     */
    @Column(name = "collection_type", nullable = false, length = 10)
    private String collectionType;

    /**
     * Идентификатор коллекции (ID документа или KB).
     */
    @Column(name = "collection_id", nullable = false)
    private UUID collectionId;

    /**
     * Идентификатор исходного документа (для чанков документов).
     * Может быть {@code null}, если эмбеддинг принадлежит KB напрямую.
     */
    @Column(name = "source_document_id")
    private UUID sourceDocumentId;

    /**
     * Порядковый номер чанка в исходном документе.
     * Используется для упорядочивания фрагментов при восстановлении.
     */
    @Column(name = "chunk_index")
    private Integer chunkIndex;

    /**
     * Исходный текстовый фрагмент, для которого вычисляется вектор.
     */
    @Column(name = "chunk_text", columnDefinition = "TEXT")
    private String chunkText;

    /**
     * Векторное представление текста (1024-мерный вектор).
     * Хранится с использованием pgvector типа {@code vector(1024)}.
     */
    @Column(name = "embedding", columnDefinition = "vector(1024)")
    @Type(FloatArrayType.class)
    @Array(length = 1024)
    private float[] vector;
}
