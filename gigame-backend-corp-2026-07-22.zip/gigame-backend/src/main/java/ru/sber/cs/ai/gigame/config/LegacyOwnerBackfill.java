package ru.sber.cs.ai.gigame.config;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

/**
 * Backfill владельца для легаси-записей: строки с {@code user_id = NULL}
 * (созданные до появления изоляции пользователей) не проходят ни одну
 * проверку владения ({@code UserUtils.checkUserId}) — ими не может управлять
 * никто, включая создателя.
 * <p>
 * Выполняется после liquibase (таблицы гарантированно существуют),
 * идемпотентно ({@code WHERE user_id IS NULL}). В preliquibase такой backfill
 * невозможен: на пустой БД таблиц ещё нет.
 */
@Component
@RequiredArgsConstructor
@Slf4j
//TODO в следующем релизе удалит класс
public class LegacyOwnerBackfill implements ApplicationRunner {

    private final JdbcTemplate jdbcTemplate;

    @Override
    public void run(ApplicationArguments args) {
        updateKb();
        updateChat();
        updateDoc();
    }

    private void updateDoc() {
        try {
            int updated = jdbcTemplate.update(
                    "UPDATE documents SET user_id = 'anonymous' WHERE user_id IS NULL");
            if (updated > 0) {
                log.info("Backfill владельца: {} записей в 'documents' получили user_id='anonymous'", updated);
            }
        } catch (Exception e) {
            log.warn("Backfill владельца для 'documents' не выполнен: {}", e.getMessage());
        }
    }

    private void updateChat() {
        try {
            int updated = jdbcTemplate.update(
                    "UPDATE conversations SET user_id = 'anonymous' WHERE user_id IS NULL");
            if (updated > 0) {
                log.info("Backfill владельца: {} записей в 'conversations' получили user_id='anonymous'", updated);
            }
        } catch (Exception e) {
            log.warn("Backfill владельца для 'conversations' не выполнен: {}", e.getMessage());
        }
    }

    private void updateKb() {
        try {
            int updated = jdbcTemplate.update(
                    "UPDATE knowledge_bases SET user_id = 'anonymous' WHERE user_id IS NULL");
            if (updated > 0) {
                log.info("Backfill владельца: {} записей в 'knowledge_bases' получили user_id='anonymous'", updated);
            }
        } catch (Exception e) {
            log.warn("Backfill владельца для 'knowledge_bases' не выполнен: {}", e.getMessage());
        }
    }
}
