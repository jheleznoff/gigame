package ru.sber.cs.ai.gigame.dto.kb;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Size;

import java.time.OffsetDateTime;
import java.util.List;
import java.util.UUID;

/**
 * DTO для подробного представления базы знаний.
 * Возвращает полную информацию о базе знаний со всеми связанными документами.
 *
 * @param id          Уникальный идентификатор базы знаний
 * @param name        Имя базы знаний
 * @param description Описание базы знаний
 * @param shared      Общая ли база (видна всем пользователям)
 * @param isOwner     Является ли запрашивающий пользователь владельцем
 * @param createdAt   Дата и время создания базы знаний
 * @param updatedAt   Дата и время последнего обновления
 * @param documents   Список документов, связанных с базой знаний
 * @see KBResponse
 * @see KBDocumentResponse
 */
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
@Schema(
        description = "Полная информация о базе знаний с документами",
        additionalProperties = Schema.AdditionalPropertiesValue.FALSE
)
public record KBDetailResponse(
        @Schema(
                description = "Уникальный идентификатор базы знаний",
                example = "550e8400-e29b-41d4-a716-446655440000",
                pattern = "^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"
        )
        UUID id,

        @Schema(
                description = "Имя базы знаний",
                example = "Техническая документация",
                pattern = "^[\\w\\W]{0,64}$"
        )
        String name,

        @Schema(
                description = "Описание базы знаний",
                example = "Документация по продукту и API",
                pattern = "^[\\w\\W]{0,255}$"
        )
        String description,

        @Schema(
                description = "Общая ли база знаний (видна всем пользователям, изменяет только владелец)"
        )
        boolean shared,

        @Schema(
                description = "Является ли запрашивающий пользователь владельцем базы"
        )
        boolean isOwner,

        @Schema(
                description = "Дата и время создания базы знаний"
        )
        OffsetDateTime createdAt,

        @Schema(
                description = "Дата и время последнего обновления"
        )
        OffsetDateTime updatedAt,

        @Schema(
                description = "Список документов в базе знаний (максимум 1000)"
        )
        @Size(max = 1000)
        @ArraySchema(
                schema = @Schema(implementation = KBDocumentResponse.class),
                maxItems = 1000
        )
        List<KBDocumentResponse> documents
) {
}
