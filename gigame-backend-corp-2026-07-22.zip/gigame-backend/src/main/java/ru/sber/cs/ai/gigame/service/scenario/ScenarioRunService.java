package ru.sber.cs.ai.gigame.service.scenario;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import ru.sber.cs.ai.gigame.model.ScenarioRun;
import ru.sber.cs.ai.gigame.repository.ScenarioRunRepository;
import ru.sber.cs.ai.gigame.service.scenario.enums.ScenarioStatus;

import java.time.OffsetDateTime;

@Service
@Slf4j
public class ScenarioRunService {
    private final ScenarioRunRepository scenarioRunRepository;

    public ScenarioRunService(ScenarioRunRepository scenarioRunRepository) {
        this.scenarioRunRepository = scenarioRunRepository;
    }

    public ScenarioRun setScenarioRunStatusRunning(ScenarioRun run) {
        run.setStatus(ScenarioStatus.RUNNING.getValue());
        return scenarioRunRepository.save(run);
    }

    public ScenarioRun setScenarioRunStatusFailed(ScenarioRun run) {
        run.setStatus(ScenarioStatus.FAILED.getValue());
        return scenarioRunRepository.save(run);
    }

    public ScenarioRun setScenarioRunStatusCompleted(ScenarioRun run, String finalResult) {
        run.setStatus(ScenarioStatus.COMPLETED.getValue());
        run.setResult(finalResult);
        run.setCompletedAt(OffsetDateTime.now());
        return scenarioRunRepository.save(run);
    }
}
