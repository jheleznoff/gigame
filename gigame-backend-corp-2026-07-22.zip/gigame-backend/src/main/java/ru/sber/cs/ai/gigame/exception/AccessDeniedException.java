package ru.sber.cs.ai.gigame.exception;

/**
 * Исключение, выбрасываемое при ошибках доступа к ресурсам.
 */
public class AccessDeniedException extends ApplicationRuntimeException {

    public AccessDeniedException(String message) {
        super(message, 403);
    }

    public AccessDeniedException() {
        super("Доступ запрещен", 403);
    }
}
