package ru.sber.cs.ai.gigame.service.scenario.executor;

import org.springframework.http.codec.ServerSentEvent;
import reactor.core.publisher.FluxSink;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunNode;

import java.util.List;
import java.util.Map;

import static ru.sber.cs.ai.gigame.service.scenario.ScenarioEventEmission.emitFileOutputEvent;


public class ScenarioExecutorOutputNode extends AbstractScenarioExecutor {

    protected ScenarioExecutorOutputNode(ScenarioRunNode node) {
        super(node);
    }

    @Override
    public String execute(FluxSink<ServerSentEvent<Map<String, Object>>> sink) {
        List<String> inputs = node.getInput();
        node.getOutput().addAll(inputs);
        var result = String.join("\n\n", inputs);
        // Отправка результата как файл через SSE, если это необходимо
        emitFileOutputEvent(sink, node, result);
        return result;
    }
}
