package ru.sber.cs.ai.gigame.model;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OrderBy;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.annotations.UpdateTimestamp;
import org.hibernate.type.SqlTypes;

import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Сущность диалога (разговора) пользователя с ассистентом.
 * <p>
 * Диалоги используются для хранения истории общения, автоматического
 * генерирования заголовков и привязки к базам знаний для RAG-поиска.
 *
 * @see Message
 * @see KnowledgeBase
 */
@Entity
@Table(name = "conversations")
@Getter
@Setter
@NoArgsConstructor
public class Conversation {

    /**
     * Уникальный идентификатор диалога (UUID).
     */
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;

    /**
     * Заголовок диалога (по умолчанию "Новый диалог").
     * Автоматически генерируется после первого сообщения.
     */
    @Column(nullable = false)
    private String title = "Новый диалог";

    /**
     * Идентификатор привязанной базы знаний для RAG-поиска.
     * Может быть {@code null}, если диалог не связан с KB.
     * Устаревшее поле, поддерживается для обратной совместимости —
     * актуальный список хранится в {@link #knowledgeBaseIds}.
     */
    @Column(name = "knowledge_base_id")
    private UUID knowledgeBaseId;

    /**
     * Список идентификаторов баз знаний для RAG-поиска (JSONB).
     * Если {@code null}, используется устаревшее поле {@link #knowledgeBaseId}.
     */
    @JdbcTypeCode(SqlTypes.JSON)
    @Column(name = "knowledge_base_ids", columnDefinition = "jsonb")
    private List<String> knowledgeBaseIds;

    /**
     * Модель GigaChat для этого диалога ({@code null} — модель по умолчанию).
     */
    @Column(name = "model", length = 64)
    private String model;

    /**
     * Температура генерации для этого диалога ({@code null} — значение по умолчанию).
     */
    @Column(name = "temperature")
    private Double temperature;

    /**
     * Краткое содержание части истории, вытесненной из контекстного окна.
     */
    @Column(name = "summary", columnDefinition = "TEXT")
    private String summary;

    /**
     * Количество старейших сообщений, покрытых {@link #summary}.
     */
    @Column(name = "summary_message_count", nullable = false)
    private int summaryMessageCount = 0;

    /**
     * Идентификатор пользователя, создавшего диалог.
     * Используется для изоляции данных между пользователями.
     */
    @Column(name = "user_id")
    private String userId;

    /**
     * Дата и время создания диалога (автоматически устанавливается).
     */
    @CreationTimestamp
    @Column(name = "created_at", nullable = false, updatable = false)
    private OffsetDateTime createdAt;

    /**
     * Дата и время последнего обновления диалога (автоматически обновляется).
     */
    @UpdateTimestamp
    @Column(name = "updated_at", nullable = false)
    private OffsetDateTime updatedAt;

    /**
     * Список сообщений диалога, отсортированных по времени создания.
     * Удаление диалога приводит к каскадному удалению всех сообщений.
     */
    @OneToMany(mappedBy = "conversation", cascade = CascadeType.ALL, orphanRemoval = true)
    @OrderBy("createdAt ASC")
    private List<Message> messages = new ArrayList<>();
}
