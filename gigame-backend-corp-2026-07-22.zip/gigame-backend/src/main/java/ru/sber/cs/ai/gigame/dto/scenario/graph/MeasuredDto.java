package ru.sber.cs.ai.gigame.dto.scenario.graph;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import io.swagger.v3.oas.annotations.media.Schema;

/**
 * DTO для размера блока(узла) на графе.
 *
 * @param width  Ширина блока графа
 * @param height Высота блока графа
 */
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
@Schema(
        description = "Размер блока(узла) на графе",
        additionalProperties = Schema.AdditionalPropertiesValue.FALSE
)
public record MeasuredDto(
        @Schema(
                description = "Ширина блока графа",
                minimum = "0",
                maximum = "1000",
                example = "400"
        )
        Integer width,

        @Schema(
                description = "Высота блока графа",
                minimum = "0",
                maximum = "1000",
                example = "30"
        )
        Integer height
) {
}
