package ru.sber.cs.ai.gigame.dto.kb;

import io.swagger.v3.oas.annotations.media.Schema;

/**
 * DTO для создания новой базы знаний.
 * Используется при инициализации новой базы знаний с указанием имени и описания.
 *
 * @param name        Имя базы знаний (максимум 64 символа)
 * @param description Описание базы знаний (максимум 255 символов)
 * @param shared      Сделать базу общей (видна всем пользователям; null — личная)
 * @see KBResponse
 * @see KBUpdate
 */
@Schema(
        description = "Запрос на создание новой базы знаний",
        additionalProperties = Schema.AdditionalPropertiesValue.FALSE
)
public record KBCreate(
        @Schema(
                description = "Имя базы знаний",
                example = "Техническая документация",
                pattern = "^[\\w\\W]{0,64}$"
        )
        String name,

        @Schema(
                description = "Описание базы знаний",
                example = "Документация по продукту и API",
                pattern = "^[\\w\\W]{0,255}$",
                nullable = true
        )
        String description,

        @Schema(
                description = "Сделать базу общей: видна всем пользователям, изменяет только владелец",
                nullable = true
        )
        Boolean shared
) {
}
