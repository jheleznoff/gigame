package ru.sber.cs.ai.gigame.service.scenario;

import org.apache.commons.lang3.ObjectUtils;
import org.springframework.http.codec.ServerSentEvent;
import reactor.core.publisher.FluxSink;
import ru.sber.cs.ai.gigame.model.ScenarioRunStep;
import ru.sber.cs.ai.gigame.service.scenario.enums.ScenarioEventType;
import ru.sber.cs.ai.gigame.service.scenario.enums.ScenarioStatus;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunNode;

import java.util.Base64;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;

public class ScenarioEventEmission {
    private static final String KEY_RUN_ID = "run_id";
    private static final String KEY_STATUS = "status";
    private static final String KEY_RESULT = "result";
    private static final String KEY_NODE_ID = "node_id";
    private static final String KEY_NODE_LABEL = "node_label";
    private static final String KEY_NODE_TYPE = "node_type";
    private static final String KEY_STEP = "step";
    private static final String KEY_TOTAL = "total";
    private static final String KEY_ERROR = "error";
    private static final String KEY_MATCHED_RULE = "matched_rule";
    private static final String KEY_ITERATION = "iteration";
    private static final String KEY_DETAIL = "detail";
    private static final String KEY_CONDITION_MET = "condition_met";
    private static final String KEY_BRANCH = "branch";
    private static final String KEY_KB_ID = "kb_id";
    private static final String KEY_CHUNKS_FOUND = "chunks_found";

    private static final String KEY_STEP_ID = "step_id";
    private static final String KEY_INPUT_DATA = "input_data";
    private static final String KEY_OUTPUT_DATA = "output_data";
    private static final String KEY_STEP_INDEX = "step_index";
    private static final String KEY_TOTAL_STEPS = "total_steps";
    private static final String KEY_PROMPT = "prompt_used";

    private static final String KEY_FILENAME = "filename";
    private static final String KEY_CONTENT = "content";
    private static final String KEY_MIME_TYPE = "mime_type";
    private static final String KEY_ENCODING = "encoding";

    private static final String MSG_UNKNOWN_ERROR = "Неизвестная ошибка";

    private ScenarioEventEmission() {
    }

    public static void emitStatusEvent(FluxSink<ServerSentEvent<Map<String, Object>>> sink,
                                       UUID runId,
                                       ScenarioStatus status,
                                       String finalResult) {
        if (sink == null) {
            return;
        }
        Map<String, Object> dataMap = new HashMap<>(Map.of(
                KEY_RUN_ID, runId.toString(),
                KEY_STATUS, status));
        if (ObjectUtils.isNotEmpty(finalResult)) {
            dataMap.put(KEY_RESULT, finalResult);
        }
        emitEvent(sink, ScenarioEventType.STATUS, dataMap);
    }

    public static void emitNodeStatusEvent(FluxSink<ServerSentEvent<Map<String, Object>>> sink,
                                           ScenarioRunNode node,
                                           ScenarioStatus status) {
        if (sink == null) {
            return;
        }
        Map<String, Object> dataMap = new HashMap<>(Map.of(
                KEY_NODE_ID, node.getId(),
                KEY_NODE_LABEL, node.getLabel(),
                KEY_NODE_TYPE, node.getType(),
                KEY_STATUS, status,
                KEY_STEP, node.getIndex(),
                KEY_TOTAL, node.getTotal()));
        emitEvent(sink, ScenarioEventType.NODE_STATUS, dataMap);
    }

    public static void emitNodeErrorEvent(FluxSink<ServerSentEvent<Map<String, Object>>> sink,
                                          ScenarioRunNode node,
                                          String errorMsg,
                                          int totalNodes) {
        if (sink == null) {
            return;
        }
        Map<String, Object> dataMap = new HashMap<>(Map.of(
                KEY_NODE_ID, node.getId(),
                KEY_NODE_LABEL, node.getLabel(),
                KEY_NODE_TYPE, node.getType(),
                KEY_STATUS, ScenarioStatus.FAILED,
                KEY_STEP, node.getIndex(),
                KEY_TOTAL, totalNodes,
                KEY_ERROR, errorMsg != null ? errorMsg : MSG_UNKNOWN_ERROR));
        emitEvent(sink, ScenarioEventType.NODE_STATUS, dataMap);
    }

    public static void emitSwitchResultEvent(FluxSink<ServerSentEvent<Map<String, Object>>> sink,
                                             ScenarioRunNode node,
                                             String matchStr) {
        if (sink == null) {
            return;
        }
        Map<String, Object> dataMap = new HashMap<>(Map.of(
                KEY_NODE_ID, node.getId(),
                KEY_NODE_LABEL, node.getLabel(),
                KEY_MATCHED_RULE, matchStr));
        emitEvent(sink, ScenarioEventType.SWITCH_RESULT, dataMap);
    }

    public static void emitLoopProgressEvent(FluxSink<ServerSentEvent<Map<String, Object>>> sink,
                                             ScenarioRunNode node,
                                             int iteration,
                                             int totalDoc,
                                             String detail) {
        if (sink == null) {
            return;
        }
        Map<String, Object> dataMap = new HashMap<>(Map.of(
                KEY_NODE_ID, node.getId(),
                KEY_NODE_LABEL, node.getLabel(),
                KEY_ITERATION, iteration,
                KEY_TOTAL, totalDoc));
        if (ObjectUtils.isNotEmpty(detail)) {
            dataMap.put(KEY_DETAIL, detail);
        }
        emitEvent(sink, ScenarioEventType.LOOP_PROGRESS, dataMap);
    }

    public static void emitIfResultEvent(FluxSink<ServerSentEvent<Map<String, Object>>> sink,
                                         ScenarioRunNode node,
                                         Boolean conditionMet,
                                         String branchName) {
        if (sink == null) {
            return;
        }
        Map<String, Object> dataMap = new HashMap<>(Map.of(
                KEY_NODE_ID, node.getId(),
                KEY_NODE_LABEL, node.getLabel(),
                KEY_CONDITION_MET, conditionMet,
                KEY_BRANCH, branchName));
        emitEvent(sink, ScenarioEventType.IF_RESULT, dataMap);
    }

    public static void emitRagSearchEvent(FluxSink<ServerSentEvent<Map<String, Object>>> sink,
                                          ScenarioRunNode node,
                                          int chunksFound) {
        Map<String, Object> dataMap = new HashMap<>(Map.of(
                KEY_NODE_ID, node.getId(),
                KEY_NODE_LABEL, node.getLabel(),
                KEY_KB_ID, node.getKnowledgeBaseId().toString(),
                KEY_CHUNKS_FOUND, chunksFound));
        emitEvent(sink, ScenarioEventType.RAG_SEARCH, dataMap);
    }

    /**
     * Отправляет результат выходного узла в виде текстового файла через SSE.
     * <p>
     * Frontend может скачать файл с указанными именем, содержимым и MIME-типом.
     *
     * @param sink   поток SSE-событий
     * @param node   выходной узел сценария
     * @param result результат выполнения узла сценария
     */
    public static void emitFileOutputEvent(FluxSink<ServerSentEvent<Map<String, Object>>> sink,
                                           ScenarioRunNode node,
                                           String result) {
        Map<String, Object> dataMap = new HashMap<>(Map.of(
                KEY_NODE_ID, node.getId(),
                KEY_NODE_LABEL, node.getLabel()));

        String mode = node.getMode();
        if (mode == null) {
            return;
        }
        if (node.getLabel().equals("Excel")) {
            mode = "excel";
        }
        switch (mode.toUpperCase()) {
            case "EXCEL" -> {
                // rules output-узла может содержать шаблон формы таблицы (фиксированные колонки)
                byte[] xlsxBytes = ScenarioResultToXlsx.jsonToXlsx(result, node.getRules());
                dataMap.put(KEY_FILENAME, "result.xlsx");
                dataMap.put(KEY_CONTENT, Base64.getEncoder().encodeToString(xlsxBytes));
                dataMap.put(KEY_MIME_TYPE, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
                dataMap.put(KEY_ENCODING, "base64");
            }
            case "TEXT_FILE" -> {
                dataMap.put(KEY_FILENAME, "result.txt");
                dataMap.put(KEY_CONTENT, result);
                dataMap.put(KEY_MIME_TYPE, "text/plain");
            }
            default -> {
                return;
            }
        }

        emitEvent(sink, ScenarioEventType.FILE_OUTPUT, dataMap);
    }

    public static void emitStepCompleteEvent(FluxSink<ServerSentEvent<Map<String, Object>>> sink,
                                             ScenarioRunNode node,
                                             ScenarioRunStep step) {
        if (step == null) {
            // шаг мог не сохраниться (например, под-сценарии не пишут шаги) — событие не шлём
            return;
        }
        Map<String, Object> dataMap = new LinkedHashMap<>(Map.of(
                KEY_STEP_ID, step.getId().toString(),
                KEY_NODE_ID, node.getId(),
                KEY_NODE_LABEL, node.getLabel(),
                KEY_NODE_TYPE, step.getNodeType(),
                KEY_INPUT_DATA, step.getInputData(),
                KEY_OUTPUT_DATA, step.getOutputData(),
                KEY_PROMPT, step.getPromptUsed(),
                KEY_STEP_INDEX, node.getIndex(),
                KEY_TOTAL_STEPS, node.getTotal()));
        // LinkedHashMap: tokens_used может быть null (детерминированные узлы)
        dataMap.put("tokens_used", step.getTokensUsed());
        emitEvent(sink, ScenarioEventType.STEP_COMPLETE, dataMap);
    }

    public static void emitStepPausedEvent(FluxSink<ServerSentEvent<Map<String, Object>>> sink,
                                           ScenarioRunNode node,
                                           int totalNodes) {
        Map<String, Object> dataMap = new HashMap<>(Map.of(
                KEY_NODE_ID, node.getId(),
                KEY_NODE_LABEL, node.getLabel(),
                KEY_NODE_TYPE, node.getType(),
                KEY_TOTAL_STEPS, totalNodes));
        emitEvent(sink, ScenarioEventType.STEP_PAUSED, dataMap);
    }

    public static void emitProcessingProgressEvent(FluxSink<ServerSentEvent<Map<String, Object>>> sink,
                                             ScenarioRunNode node,
                                             int iteration,
                                             int totalDoc,
                                             String detail) {
        if (sink == null) {
            return;
        }
        Map<String, Object> dataMap = new HashMap<>(Map.of(
                KEY_NODE_ID, node.getId(),
                KEY_NODE_LABEL, node.getLabel(),
                KEY_ITERATION, iteration,
                KEY_TOTAL, totalDoc));
        if (ObjectUtils.isNotEmpty(detail)) {
            dataMap.put(KEY_DETAIL, detail);
        }
        emitEvent(sink, ScenarioEventType.PROCESSING_PROGRESS, dataMap);
    }

    /**
     * Генерирует и отправляет SSE-событие.
     * <p>
     * Добавляет поле "type" в payload для идентификации типа события на frontend.
     *
     * @param sink      поток SSE-событий
     * @param eventType тип события (например, "status", "node_status", "rag_search")
     * @param data      данные события
     */
    private static void emitEvent(FluxSink<ServerSentEvent<Map<String, Object>>> sink,
                                  ScenarioEventType eventType,
                                  Map<String, Object> data) {
        // Build mutable map that includes the "type" field
        Map<String, Object> payload = new LinkedHashMap<>(data);
        payload.put("type", eventType);

        // Don't set .event() — frontend uses generic onmessage handler
        // and parses "type" from the data JSON, not from SSE event field
        sink.next(ServerSentEvent.<Map<String, Object>>builder()
                .data(payload)
                .build());
    }
}
