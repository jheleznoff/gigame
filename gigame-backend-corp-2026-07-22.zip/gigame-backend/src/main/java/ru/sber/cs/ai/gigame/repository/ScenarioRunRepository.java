package ru.sber.cs.ai.gigame.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import ru.sber.cs.ai.gigame.model.ScenarioRun;

import java.util.List;
import java.util.UUID;

/**
 * Репозиторий для работы с запусками сценариев.
 * <p>
 * Предоставляет методы для управления выполнением сценариев.
 *
 * @see ScenarioRun
 */
@Repository
public interface ScenarioRunRepository extends JpaRepository<ScenarioRun, UUID> {

    /**
     * Возвращает все запуски указанного сценария, отсортированные по времени начала (новые первыми).
     *
     * @param scenarioId идентификатор сценария
     * @return список запусков сценария
     */
    List<ScenarioRun> findByScenarioIdOrderByStartedAtDesc(UUID scenarioId);
}
