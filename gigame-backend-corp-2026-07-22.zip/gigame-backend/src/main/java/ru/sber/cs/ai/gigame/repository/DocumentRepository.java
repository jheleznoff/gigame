package ru.sber.cs.ai.gigame.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import ru.sber.cs.ai.gigame.model.Document;

import java.util.UUID;

/**
 * Репозиторий для работы с загруженными документами.
 * <p>
 * Предоставляет стандартные CRUD-операции для сущности Document.
 *
 * @see Document
 */
@Repository
public interface DocumentRepository extends JpaRepository<Document, UUID> {
}
