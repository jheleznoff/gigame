package ru.sber.cs.ai.gigame.service.scenario.graph;

import lombok.Getter;
import lombok.Setter;

@Getter
public class ScenarioRunDoc {
    private final String filename;
    private final String text;
    @Setter
    private String docClass;

    public ScenarioRunDoc(String filename,String text) {
        this.filename = filename;
        this.text = text;
    }
}
