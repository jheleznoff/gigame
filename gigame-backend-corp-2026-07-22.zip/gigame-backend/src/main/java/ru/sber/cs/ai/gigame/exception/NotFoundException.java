package ru.sber.cs.ai.gigame.exception;

/**
 * Исключение, выбрасываемое, когда запрашиваемый ресурс не найден.
 */
public class NotFoundException extends ApplicationRuntimeException {

    public NotFoundException(String message) {
        super(message, 404);
    }

    public NotFoundException() {
        super("Ресурс не найден", 404);
    }
}
