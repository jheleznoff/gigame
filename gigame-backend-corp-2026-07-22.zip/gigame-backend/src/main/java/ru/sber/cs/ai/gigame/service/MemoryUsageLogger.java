package ru.sber.cs.ai.gigame.service;

import jakarta.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

/**
 * Периодический вывод потребления JVM-памяти в лог (каждые 30 секунд).
 */
@Slf4j
@Component
public class MemoryUsageLogger {

    @PostConstruct
    void logStartup() {
        logMemory();
    }

    @Scheduled(fixedRate = 10_000)
    void logMemory() {
        var runtime = Runtime.getRuntime();
        var totalMb = runtime.totalMemory() / (1024.0 * 1024.0);
        var freeMb = runtime.freeMemory() / (1024.0 * 1024.0);
        var usedMb = totalMb - freeMb;
        var maxMb = runtime.maxMemory() / (1024.0 * 1024.0);

        log.info("Memory — used: {}", String.format("%.1f MB | free: %.1f MB | total: %.1f MB | max: %.1f MB",
                usedMb, freeMb, totalMb, maxMb));
    }
}