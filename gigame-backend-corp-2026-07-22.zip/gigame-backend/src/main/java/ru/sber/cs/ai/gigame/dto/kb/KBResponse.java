package ru.sber.cs.ai.gigame.dto.kb;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import io.swagger.v3.oas.annotations.media.Schema;

import java.time.OffsetDateTime;
import java.util.UUID;

/**
 * DTO для краткого представления базы знаний.
 * Возвращает основную информацию о базе знаний без деталей документов.
 *
 * @param id          Уникальный идентификатор базы знаний
 * @param name        Имя базы знаний
 * @param description Описание базы знаний
 * @param shared      Общая ли база (видна всем пользователям)
 * @param isOwner     Является ли запрашивающий пользователь владельцем
 * @param createdAt   Дата и время создания базы знаний
 * @param updatedAt   Дата и время последнего обновления
 * @see KBDetailResponse
 * @see KBCreate
 */
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
@Schema(
        description = "Краткая информация о базе знаний",
        additionalProperties = Schema.AdditionalPropertiesValue.FALSE
)
public record KBResponse(
        @Schema(
                description = "Уникальный идентификатор базы знаний",
                example = "550e8400-e29b-41d4-a716-446655440000",
                pattern = "^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"
        )
        UUID id,

        @Schema(
                description = "Имя базы знаний",
                example = "Техническая документация",
                pattern = "^[\\w\\W]{0,64}$"
        )
        String name,

        @Schema(
                description = "Описание базы знаний",
                example = "Документация по продукту и API",
                pattern = "^[\\w\\W]{0,255}$"
        )
        String description,

        @Schema(
                description = "Общая ли база знаний (видна всем пользователям, изменяет только владелец)"
        )
        boolean shared,

        @Schema(
                description = "Является ли запрашивающий пользователь владельцем базы"
        )
        boolean isOwner,

        @Schema(
                description = "Дата и время создания базы знаний"
        )
        OffsetDateTime createdAt,

        @Schema(
                description = "Дата и время последнего обновления"
        )
        OffsetDateTime updatedAt
) {
}
