package ru.sber.cs.ai.gigame.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.OffsetDateTime;
import java.util.UUID;

/**
 * Сущность связи документа с базой знаний.
 * <p>
 * Хранит информацию о включении документа в KB, статусе обработки,
 * количестве чанков и возможных ошибках.
 *
 * @see KnowledgeBase
 * @see Document
 */
@Entity
@Table(name = "kb_documents")

@Getter
@Setter
@NoArgsConstructor
public class KBDocument {

    /**
     * Уникальный идентификатор связи (UUID).
     */
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;

    /**
     * Идентификатор базы знаний, к которой относится документ.
     */
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "knowledge_base_id", nullable = false)
    private KnowledgeBase knowledgeBase;

    /**
     * Идентификатор документа.
     * Используется как внешний ключ без возможности изменения.
     */
    @Column(name = "document_id", nullable = false, insertable = false, updatable = false)
    private UUID documentId;

    /**
     * Связанный объект документа (ленивая загрузка).
     */
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "document_id", nullable = false)
    private Document document;

    /**
     * Количество чанков, на которые был разбит документ для RAG-поиска.
     */
    @Column(name = "chunk_count")
    private Integer chunkCount = 0;

    /**
     * Статус обработки документа в KB.
     * Возможные значения: "processing", "ready", "failed".
     */
    @Column(nullable = false, length = 50)
    private String status = "processing";

    /**
     * Сообщение об ошибке, если обработка завершилась неудачей.
     */
    @Column(name = "error_message", columnDefinition = "TEXT")
    private String errorMessage;

    /**
     * Дата и время создания связи (автоматически устанавливается).
     */
    @CreationTimestamp
    @Column(name = "created_at", nullable = false, updatable = false)
    private OffsetDateTime createdAt;

    /**
     * Дата и время последнего обновления (автоматически обновляется).
     */
    @UpdateTimestamp
    @Column(name = "updated_at", nullable = false)
    private OffsetDateTime updatedAt;

    /**
     * Возвращает имя файла документа.
     * <p>
     * Метод обращается к связанному объекту Document и извлекает его имя.
     * Возвращает {@code null}, если документ не загружен.
     */
    @Transient
    public String getFilename() {
        return document != null ? document.getFilename() : null;
    }
}
