package ru.sber.cs.ai.gigame.service;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import jakarta.annotation.PostConstruct;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;

/**
 * Сервис для кэширования текстов загруженных документов по идентификаторам диалогов или сценариев.
 * <p>
 * Кэш ограничен по размеру ({@code cache.max-size}, по умолчанию 200 записей).
 * Записи, к которым не было обращений дольше {@code cache.ttl-minutes} (по умолчанию 10 минут),
 * автоматически удаляются фоновой задачей раз в минуту.
 * Если при добавлении новой записи размер превышает максимум, удаляется самая старая запись.
 */
@Service
@Slf4j
public class DocsTextCacheService {

    /**
     * Максимальное количество диалогов/сценариев в кэше.
     */
    @Value("${cache.max-size:200}")
    private int maxSize;

    /**
     * Время жизни записи в минутах с момента последнего обращения.
     */
    @Value("${cache.ttl-minutes:10}")
    private int ttlMinutes;

    /**
     * Хранит тексты загруженных документов для каждого диалога или сценария.
     * Ключ: идентификатор диалога или сценария, Значение: список текстов документов.
     */
    private final Map<UUID, CacheEntry<List<String>>> documentTextsCache = new ConcurrentHashMap<>();
    private final Map<UUID, CacheEntry<List<String>>> fileNamesCache = new ConcurrentHashMap<>();
    private final Map<UUID, CacheEntry<List<String>>> docIdsCache = new ConcurrentHashMap<>();

    @PostConstruct
    void init() {
        log.info("DocsTextCacheService: maxSize={}, ttl={}min", maxSize, ttlMinutes);
    }

    /**
     * Сохраняет тексты документов для указанного id.
     *
     * @param id            идентификатор диалога или сценария
     * @param documentTexts список текстов документов
     */
    public void cacheDocumentTexts(UUID id, List<String> documentTexts, List<String> fileNames, List<String> docIds) {
        log.debug("Кэширование {} текстов документов для диалога {}", documentTexts.size(), id);
        evictIfNeeded(documentTextsCache, id);
        evictIfNeeded(fileNamesCache, id);
        evictIfNeeded(docIdsCache, id);
        documentTextsCache.put(id, new CacheEntry<>(documentTexts));
        fileNamesCache.put(id, new CacheEntry<>(fileNames));
        docIdsCache.put(id, new CacheEntry<>(docIds));
    }

    /**
     * Догружает тексты документов к уже закэшированным (для больших наборов,
     * которые не помещаются в один multipart-запрос: партии по ~100 файлов).
     * Если кэша для id ещё нет — эквивалентно {@link #cacheDocumentTexts}.
     * <p>
     * Использует ConcurrentHashMap.compute для атомарного обновления без
     * synchronized-блокировки всего сервиса.
     *
     * @param id            идентификатор сценария
     * @param documentTexts тексты новых документов
     * @param fileNames     имена новых документов
     * @param docIds        идентификаторы новых документов
     * @return суммарное число документов в кэше после догрузки
     */
    public int appendDocumentTexts(UUID id, List<String> documentTexts,
                                   List<String> fileNames, List<String> docIds) {
        documentTextsCache.compute(id, (key, existing) -> {
            List<String> merged = existing != null
                    ? new ArrayList<>(existing.value)
                    : new ArrayList<>();
            merged.addAll(documentTexts);
            return new CacheEntry<>(merged);
        });
        fileNamesCache.compute(id, (key, existing) -> {
            List<String> merged = existing != null
                    ? new ArrayList<>(existing.value)
                    : new ArrayList<>();
            merged.addAll(fileNames);
            return new CacheEntry<>(merged);
        });
        docIdsCache.compute(id, (key, existing) -> {
            List<String> merged = existing != null
                    ? new ArrayList<>(existing.value)
                    : new ArrayList<>();
            merged.addAll(docIds);
            return new CacheEntry<>(merged);
        });
        int total = documentTextsCache.get(id).value.size();
        log.debug("Догрузка кэша документов {}: +{}, всего {}", id, documentTexts.size(), total);
        return total;
    }

    /**
     * Получает тексты документов для указанного id.
     *
     * @param id идентификатор диалога или сценария
     * @return список текстов документов или пустой список, если кэш пуст
     */
    public List<String> getCachedDocumentTexts(UUID id) {
        CacheEntry<List<String>> entry = documentTextsCache.get(id);
        if (entry != null) {
            entry.touch();
            return entry.value;
        }
        return List.of();
    }

    /**
     * Получает список файлов для указанного id.
     *
     * @param id идентификатор диалога или сценария
     * @return список текстов документов или null, если кэш пуст
     */
    public List<String> getCachedFileNames(UUID id) {
        var entry = fileNamesCache.get(id);
        if (entry != null) {
            entry.touch();
            return entry.value;
        }
        return List.of();
    }

    /**
     * Получает список идентификаторов документов для указанного id.
     *
     * @param id идентификатор диалога или сценария
     * @return список идентификаторов документов или пустой список, если кэш пуст
     */
    public List<String> getCachedDocIds(UUID id) {
        CacheEntry<List<String>> entry = docIdsCache.get(id);
        if (entry != null) {
            entry.touch();
            return entry.value;
        }
        return List.of();
    }

    /**
     * Удаляет кэш текстов документов для указанного диалога или сценария.
     *
     * @param id идентификатор диалога или сценария
     */
    public void clearCache(UUID id) {
        log.debug("Очистка кэша документов для диалога {}", id);
        documentTextsCache.remove(id);
        fileNamesCache.remove(id);
        docIdsCache.remove(id);
    }

    /**
     * Очищает весь кэш документов.
     */
    @SuppressWarnings("unused")
    public void clearAllCache() {
        log.debug("Очистка всего кэша документов");
        documentTextsCache.clear();
        fileNamesCache.clear();
        docIdsCache.clear();
    }

    /**
     * Фоновая задача: раз в минуту удаляет записи, срок жизни которых истёк.
     */
    @Scheduled(fixedRateString = "${cache.eviction-rate-ms:60000}")
    public void evictStaleEntries() {
        long now = System.nanoTime();
        long ttlNanos = TimeUnit.NANOSECONDS.convert(ttlMinutes, TimeUnit.MINUTES);
        int removed = 0;
        removed += evictStale(documentTextsCache, now, ttlNanos);
        removed += evictStale(fileNamesCache, now, ttlNanos);
        removed += evictStale(docIdsCache, now, ttlNanos);
        if (removed > 0) {
            log.debug("Evicted {} stale cache entries", removed);
        }
    }

    private <V> int evictStale(Map<UUID, CacheEntry<V>> cache, long nowNanos, long ttlNanos) {
        int[] removed = {0};
        cache.entrySet().removeIf(e -> {
            boolean stale = nowNanos - e.getValue().lastAccessNanos > ttlNanos;
            if (stale) {
                removed[0]++;
            }
            return stale;
        });
        return removed[0];
    }

    /**
     * Если размер мапы превышает maxSize, удаляет самый старый элемент
     * (не совпадающий с {@code idToKeep}).
     */
    private <V> void evictIfNeeded(Map<UUID, CacheEntry<V>> cache, UUID idToKeep) {
        if (cache.size() >= maxSize && !cache.containsKey(idToKeep)) {
            cache.entrySet().stream()
                    .min(Map.Entry.comparingByValue(
                            (a, b) -> Long.compare(a.lastAccessNanos, b.lastAccessNanos)))
                    .ifPresent(oldest -> {
                        if (!oldest.getKey().equals(idToKeep)) {
                            cache.remove(oldest.getKey());
                            log.debug("Evicted oldest cache entry: {}", oldest.getKey());
                        }
                    });
        }
    }

    /**
     * Обёртка для значения кэша с меткой времени последнего доступа.
     */
    private static final class CacheEntry<V> {
        final V value;
        volatile long lastAccessNanos;

        CacheEntry(V value) {
            this.value = value;
            this.lastAccessNanos = System.nanoTime();
        }

        void touch() {
            this.lastAccessNanos = System.nanoTime();
        }
    }
}
