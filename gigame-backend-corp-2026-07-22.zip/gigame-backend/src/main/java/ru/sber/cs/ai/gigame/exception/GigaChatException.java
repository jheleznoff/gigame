package ru.sber.cs.ai.gigame.exception;

/**
 * Исключение, выбрасываемое при ошибках работы с GigaChat API.
 */
public class GigaChatException extends ApplicationRuntimeException {

    public GigaChatException(String message) {
        super(message, 503);
    }

    public GigaChatException(String message, Throwable cause) {
        super(message, cause, 503);
    }
}
