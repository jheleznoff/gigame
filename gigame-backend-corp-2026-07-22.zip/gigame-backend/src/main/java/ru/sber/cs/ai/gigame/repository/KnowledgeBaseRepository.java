package ru.sber.cs.ai.gigame.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import ru.sber.cs.ai.gigame.model.KnowledgeBase;

import java.util.List;
import java.util.UUID;

/**
 * Репозиторий для работы с базами знаний.
 * <p>
 * Предоставляет методы для управления KB и поиска по пользователю и названию.
 *
 * @see KnowledgeBase
 */
@Repository
public interface KnowledgeBaseRepository extends JpaRepository<KnowledgeBase, UUID> {

    /**
     * Возвращает все базы знаний пользователя, отсортированные по дате последнего обновления (новые первыми).
     *
     * @param userId идентификатор пользователя
     * @return список баз знаний пользователя
     */
    List<KnowledgeBase> findAllByUserIdOrderByUpdatedAtDesc(String userId);

    /**
     * Возвращает базы знаний пользователя, названия которых содержат указанный поисковый запрос,
     * отсортированные по дате обновления (регистронезависимый поиск).
     *
     * @param userId идентификатор пользователя
     * @param search поисковый запрос в названии KB
     * @return список соответствующих баз знаний
     */
    List<KnowledgeBase> findByUserIdAndNameContainingIgnoreCaseOrderByUpdatedAtDesc(String userId, String search);

    /**
     * Возвращает базы знаний, доступные пользователю: собственные и общие,
     * отсортированные по дате обновления (новые первыми).
     *
     * @param userId идентификатор пользователя
     * @return список доступных баз знаний
     */
    List<KnowledgeBase> findByUserIdOrSharedTrueOrderByUpdatedAtDesc(String userId);

    /**
     * Ищет доступные пользователю базы знаний (собственные и общие)
     * по частичному совпадению названия (регистронезависимо).
     *
     * @param userId идентификатор пользователя
     * @param search поисковый запрос в названии KB
     * @return список соответствующих баз знаний
     */
    @Query("""
            SELECT kb FROM KnowledgeBase kb
            WHERE (kb.userId = :userId OR kb.shared = true)
              AND LOWER(kb.name) LIKE LOWER(CONCAT('%', :search, '%'))
            ORDER BY kb.updatedAt DESC
            """)
    List<KnowledgeBase> searchAccessible(@Param("userId") String userId, @Param("search") String search);
}
