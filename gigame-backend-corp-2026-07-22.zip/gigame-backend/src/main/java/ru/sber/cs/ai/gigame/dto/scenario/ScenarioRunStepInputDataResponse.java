package ru.sber.cs.ai.gigame.dto.scenario;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import io.swagger.v3.oas.annotations.media.Schema;

@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
@Schema(
        description = "Входные данные для шага выполнения сценария",
        additionalProperties = Schema.AdditionalPropertiesValue.FALSE
)
public record ScenarioRunStepInputDataResponse(
        @Schema(
                description = "Тексты документов",
                pattern = "^[\\w\\W]{0,4096}$",
                nullable = true
        )
        String documentsText,
        @Schema(
                description = "Ответ на предыдущий шаг сценария",
                pattern = "^[\\w\\W]{0,4096}$",
                nullable = true
        )
        String previousOutput
) {
}
