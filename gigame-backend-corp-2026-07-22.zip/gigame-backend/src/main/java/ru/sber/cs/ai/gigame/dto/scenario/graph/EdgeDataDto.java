package ru.sber.cs.ai.gigame.dto.scenario.graph;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import io.swagger.v3.oas.annotations.media.Schema;

/**
 * DTO для данных ребра графа.
 *
 * @param label Опциональная метка для ребра
 */
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
@Schema(
        description = "Данные, связанные с ребром графа",
        additionalProperties = Schema.AdditionalPropertiesValue.FALSE
)
public record EdgeDataDto(
        @Schema(
                description = "Текст метки для ребра",
                example = "ТЗ",
                pattern = "^[\\w\\W]{0,255}$"
        )
        String label
) {
}
