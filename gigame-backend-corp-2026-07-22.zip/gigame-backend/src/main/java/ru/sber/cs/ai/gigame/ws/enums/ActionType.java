package ru.sber.cs.ai.gigame.ws.enums;

import lombok.Getter;

@Getter
public enum ActionType {
    REGENERATE,
    EDIT,
    SEND;
}
