package ru.sber.cs.ai.gigame.service.scenario.graph;

import lombok.Getter;
import lombok.Setter;
import org.springframework.util.ObjectUtils;
import ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDto;
import ru.sber.cs.ai.gigame.service.scenario.enums.ScenarioNodeType;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Getter
public class ScenarioRunNode {
    private final NodeDto dto;
    private final List<ScenarioRunNode> parentNodeList;
    private final List<ScenarioRunNode> childNodeList;
    private final List<String> docList;
    private final List<String> input;
    private final List<String> output;
    @Setter
    private Boolean completed;
    @Setter
    private Boolean skip;
    private ScenarioRunGraph graph;
    private int index;

    public ScenarioRunNode(NodeDto dto) {
        this.dto = dto;
        // Синхронизированные списки: при параллельном выполнении ветвей несколько
        // родителей могут одновременно дописывать вход/документы этого узла
        this.output = Collections.synchronizedList(new ArrayList<>());
        this.input = Collections.synchronizedList(new ArrayList<>());
        parentNodeList = new ArrayList<>();
        childNodeList = new ArrayList<>();
        docList = Collections.synchronizedList(new ArrayList<>());
        completed = false;
        skip = true;
    }

    public static ScenarioRunNode fromDto(int index, NodeDto dto, ScenarioRunGraph graph) {
        if (dto == null) {
            return null;
        }
        var node = new ScenarioRunNode(dto);

        node.graph = graph;
        node.index = index;
        return node;
    }

    public int getTotal() {
        if (graph == null) {
            return 0;
        }
        if (graph.getNodeMap() == null) {
            return 0;
        }
        return graph.getNodeMap().size();
    }

    public String getId() {
        return dto.id();
    }

    public ScenarioNodeType getType() {
        return ObjectUtils.isEmpty(dto.type()) ? ScenarioNodeType.UNKNOWN : ScenarioNodeType.valueOfNodeType(dto.type());
    }

    public String getLabel() {
        return (ObjectUtils.isEmpty(dto.data()) || ObjectUtils.isEmpty(dto.data().label())) ? getType().toString() : dto.data().label();
    }

    public String getRules() {
        return (ObjectUtils.isEmpty(dto.data()) || ObjectUtils.isEmpty(dto.data().rules())) ? "[]" : dto.data().rules();
    }

    public String getMode() {
        return (ObjectUtils.isEmpty(dto.data()) || ObjectUtils.isEmpty(dto.data().mode())) ? "all" : dto.data().mode();
    }

    public String getPrompt() {
        return (ObjectUtils.isEmpty(dto.data()) || ObjectUtils.isEmpty(dto.data().prompt())) ? "" : dto.data().prompt();
    }

    public boolean isClassifyStrict() {
        var classifyStrictStr = (ObjectUtils.isEmpty(dto.data()) || ObjectUtils.isEmpty(dto.data().classifyStrict())) ? "false" : dto.data().classifyStrict();
        return Boolean.parseBoolean(classifyStrictStr);
    }

    public String getClasses() {
        return (ObjectUtils.isEmpty(dto.data()) || ObjectUtils.isEmpty(dto.data().classes())) ? "" : dto.data().classes();
    }

    public String getField() {
        return (ObjectUtils.isEmpty(dto.data()) || ObjectUtils.isEmpty(dto.data().field())) ? "" : dto.data().field();
    }

    public String getOperator() {
        return (ObjectUtils.isEmpty(dto.data()) || ObjectUtils.isEmpty(dto.data().operator())) ? "contains" : dto.data().operator();
    }

    public String getValue() {
        return (ObjectUtils.isEmpty(dto.data()) || ObjectUtils.isEmpty(dto.data().value())) ? "" : dto.data().value();
    }

    public UUID getKnowledgeBaseId() {
        return (ObjectUtils.isEmpty(dto.data()) || ObjectUtils.isEmpty(dto.data().knowledgeBaseId())) ? null : UUID.fromString(dto.data().knowledgeBaseId());
    }

    /**
     * Модель GigaChat для этого узла (null — модель по умолчанию).
     */
    public String getModel() {
        return (ObjectUtils.isEmpty(dto.data()) || ObjectUtils.isEmpty(dto.data().model())) ? null : dto.data().model();
    }

    /**
     * Температура генерации для этого узла (null — значение по умолчанию).
     */
    public Double getTemperature() {
        if (ObjectUtils.isEmpty(dto.data()) || ObjectUtils.isEmpty(dto.data().temperature())) {
            return null;
        }
        try {
            return Double.parseDouble(dto.data().temperature().replace(",", "."));
        } catch (NumberFormatException e) {
            return null;
        }
    }

    /**
     * Поведение при ошибке узла: stop (по умолчанию) / continue / branch.
     */
    public String getOnError() {
        return (ObjectUtils.isEmpty(dto.data()) || ObjectUtils.isEmpty(dto.data().onError())) ? "stop" : dto.data().onError();
    }

    /**
     * Собирает тексты всех документов, привязанных к данному узлу, в одну строку.
     * <p>
     * Каждый документ отделяется от следующего двумя переносами строки.
     * Если документов нет, возвращает пустую строку.
     *
     * @return объединённый текст всех документов узла
     */
    public String getAllDocTexts() {
        return docList.stream()
                .map(docId -> graph.getDocMap().get(docId))
                .filter(doc -> doc != null && doc.getText() != null)
                .map(ScenarioRunDoc::getText)
                .collect(Collectors.joining("\n\n"));
    }
}