package ru.sber.cs.ai.gigame.service.scenario;

import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.apache.poi.xwpf.usermodel.XWPFRun;
import org.apache.poi.xwpf.usermodel.XWPFTable;
import org.apache.poi.xwpf.usermodel.XWPFTableCell;
import org.apache.poi.xwpf.usermodel.XWPFTableRow;
import org.springframework.core.io.InputStreamResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import ru.sber.cs.ai.gigame.dto.scenario.ScenarioRunDetailResponse;
import ru.sber.cs.ai.gigame.dto.scenario.ScenarioRunStepResponse;
import ru.sber.cs.ai.gigame.exception.FileException;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ExportToDocx {

    private ExportToDocx() {
    }

    /**
     * Генерирует DOCX с результатом выполнения.
     *
     * @param runId        идентификатор запуска
     * @param runDetail    детали запуска
     * @param includeSteps включать ли все шаги выполнения (полные тексты документов
     *                     и промежуточные результаты дают сотни страниц); по умолчанию
     *                     выгружается только итоговый результат
     * @return DOCX-файл
     */
    static ResponseEntity<Resource> generateDocx(UUID runId, ScenarioRunDetailResponse runDetail,
                                                 boolean includeSteps) {
        try (XWPFDocument doc = new XWPFDocument();
             ByteArrayOutputStream baos = new ByteArrayOutputStream()) {

            // Title
            XWPFParagraph titlePara = doc.createParagraph();
            XWPFRun titleRun = titlePara.createRun();
            titleRun.setBold(true);
            titleRun.setFontSize(16);
            titleRun.setText("Результат сценария");

            // Status
            XWPFParagraph statusPara = doc.createParagraph();
            XWPFRun statusRun = statusPara.createRun();
            statusRun.setText("Статус: " + runDetail.status());

            // Steps
            if (includeSteps && runDetail.steps() != null && !runDetail.steps().isEmpty()) {
                XWPFParagraph stepsHeader = doc.createParagraph();
                XWPFRun stepsHeaderRun = stepsHeader.createRun();
                stepsHeaderRun.setBold(true);
                stepsHeaderRun.setFontSize(14);
                stepsHeaderRun.setText("Шаги выполнения");

                for (ScenarioRunStepResponse step : runDetail.steps()) {
                    XWPFParagraph stepPara = doc.createParagraph();
                    XWPFRun stepRun = stepPara.createRun();
                    stepRun.setBold(true);
                    stepRun.setText("Узел: " + step.nodeId() + " (" + step.nodeType() + ") — " + step.status());

                    if (step.outputData() != null) {
                        String stepText = step.outputData().toString();
                        writeMarkdownToDocx(doc, stepText);
                    }
                }
            }

            // Result
            if (runDetail.result() != null) {
                XWPFParagraph resultHeader = doc.createParagraph();
                XWPFRun resultHeaderRun = resultHeader.createRun();
                resultHeaderRun.setBold(true);
                resultHeaderRun.setFontSize(14);
                resultHeaderRun.setText("Итоговый результат");

                writeMarkdownToDocx(doc, runDetail.result().toString());
            }

            doc.write(baos);

            String filename = "result_" + runId.toString().substring(0, 8) + ".docx";
            return ResponseEntity.ok()
                    .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + filename + "\"")
                    .contentType(MediaType.parseMediaType(
                            "application/vnd.openxmlformats-officedocument.wordprocessingml.document"))
                    .body(new InputStreamResource(new ByteArrayInputStream(baos.toByteArray())));
        } catch (IOException e) {
            throw new FileException("Не удалось сгенерировать экспорт в DOCX", e);
        }
    }

    private static void writeMarkdownToDocx(XWPFDocument doc, String markdown) {
        String[] lines = markdown.split("\n");
        List<String[]> tableRows = new ArrayList<>();

        for (String line : lines) {
            if (isTableRow(line)) {
                addTableRow(line, tableRows);
            } else if (!tableRows.isEmpty()) {
                writeTable(doc, tableRows);
                tableRows.clear();
                processNonTableLine(doc, line);
            } else {
                processNonTableLine(doc, line);
            }
        }

        if (!tableRows.isEmpty()) {
            writeTable(doc, tableRows);
        }
    }

    private static boolean isTableRow(String line) {
        return line.trim().startsWith("|") && line.trim().endsWith("|");
    }

    private static void addTableRow(String line, List<String[]> tableRows) {
        if (line.contains("---")) {
            // separator row
            return;
        }
        String[] cells = Arrays.stream(line.split("\\|"))
                .map(String::trim)
                .filter(trim -> !trim.isEmpty())
                .toArray(String[]::new);
        tableRows.add(cells);
    }

    private static void processNonTableLine(XWPFDocument doc, String line) {
        if (line.trim().isEmpty()) {
            doc.createParagraph();
        } else if (line.startsWith("### ")) {
            writeHeading3(doc, line);
        } else if (line.startsWith("## ")) {
            writeHeading2(doc, line);
        } else if (line.startsWith("# ")) {
            writeHeading1(doc, line);
        } else if (line.startsWith("- ") || line.startsWith("* ")) {
            writeBulletPoint(doc, line);
        } else {
            writeRegularLine(doc, line);
        }
    }

    private static void writeHeading1(XWPFDocument doc, String line) {
        XWPFParagraph p = doc.createParagraph();
        XWPFRun r = p.createRun();
        r.setBold(true);
        r.setFontSize(16);
        r.setText(line.substring(2));
    }

    private static void writeHeading2(XWPFDocument doc, String line) {
        XWPFParagraph p = doc.createParagraph();
        XWPFRun r = p.createRun();
        r.setBold(true);
        r.setFontSize(14);
        r.setText(line.substring(3));
    }

    private static void writeHeading3(XWPFDocument doc, String line) {
        XWPFParagraph p = doc.createParagraph();
        XWPFRun r = p.createRun();
        r.setBold(true);
        r.setFontSize(13);
        r.setText(line.substring(4));
    }

    private static void writeBulletPoint(XWPFDocument doc, String line) {
        XWPFParagraph p = doc.createParagraph();
        p.setIndentationLeft(400);
        XWPFRun r = p.createRun();
        r.setText("• " + stripBold(line.substring(2)));
    }

    private static void writeRegularLine(XWPFDocument doc, String line) {
        XWPFParagraph p = doc.createParagraph();
        writeBoldAwareLine(p, line);
    }

    private static void writeTable(XWPFDocument doc, List<String[]> rows) {
        if (rows.isEmpty()) {
            return;
        }
        int cols = rows.get(0).length;
        XWPFTable table = doc.createTable(rows.size(), cols);
        table.setWidth("100%");
        for (int i = 0; i < rows.size(); i++) {
            XWPFTableRow row = table.getRow(i);
            for (int j = 0; j < cols && j < rows.get(i).length; j++) {
                XWPFTableCell cell = row.getCell(j);
                cell.setText(stripBold(rows.get(i)[j]));
                if (i == 0) {
                    cell.getParagraphs().get(0).getRuns().forEach(r -> r.setBold(true));
                }
            }
        }
    }

    private static String stripBold(String text) {
        return text.replaceAll("\\*\\*(.+?)\\*\\*", "$1");
    }

    private static void writeBoldAwareLine(XWPFParagraph p, String line) {
        Pattern bold = Pattern.compile("\\*\\*(.+?)\\*\\*");
        Matcher m = bold.matcher(line);
        int last = 0;
        while (m.find()) {
            if (m.start() > last) {
                XWPFRun r = p.createRun();
                r.setText(line.substring(last, m.start()));
            }
            XWPFRun r = p.createRun();
            r.setBold(true);
            r.setText(m.group(1));
            last = m.end();
        }
        if (last < line.length()) {
            XWPFRun r = p.createRun();
            r.setText(line.substring(last));
        }
    }
}
