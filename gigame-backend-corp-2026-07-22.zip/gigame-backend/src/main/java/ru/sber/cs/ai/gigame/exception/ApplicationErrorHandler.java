package ru.sber.cs.ai.gigame.exception;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import ru.sber.cs.ai.gigame.dto.ErrorResponse;

@ControllerAdvice
public class ApplicationErrorHandler {
    @ExceptionHandler(NotFoundException.class)
    public ResponseEntity<ErrorResponse> handleNotFoundException(ApplicationRuntimeException e) {
        return handleException(e);
    }

    @ExceptionHandler(AccessDeniedException.class)
    public ResponseEntity<ErrorResponse> handleAccessDeniedException(ApplicationRuntimeException e) {
        return handleException(e);
    }

    @ExceptionHandler(FileException.class)
    public ResponseEntity<ErrorResponse> handleFileException(ApplicationRuntimeException e) {
        return handleException(e);
    }

    @ExceptionHandler(ScenarioException.class)
    public ResponseEntity<ErrorResponse> handleScenarioException(ApplicationRuntimeException e) {
        return handleException(e);
    }

    private ResponseEntity<ErrorResponse> handleException(ApplicationRuntimeException e) {
        var response = ErrorResponse.of(e);
        return ResponseEntity.status(response.getStatusCode()).body(response);
    }
}
