package ru.sber.cs.ai.gigame.service.scenario.enums;

import lombok.Getter;

// -------------------------------------------------------------------------
// SSE Event Names
// -------------------------------------------------------------------------
@Getter
public enum ScenarioEventType {
    STATUS("status"),
    NODE_STATUS("node_status"),
    LOOP_PROGRESS("loop_progress"),
    PROCESSING_PROGRESS("processing_progress"),
    SWITCH_RESULT("switch_result"),
    IF_RESULT("if_result"),
    STEP_COMPLETE("step_complete"),
    STEP_PAUSED("step_paused"),
    RAG_SEARCH("rag_search"),
    FILE_OUTPUT("file_output");

    private final String eventName;

    ScenarioEventType(String eventName) {
        this.eventName = eventName;
    }

    @Override
    public String toString() {
        return eventName;
    }
}
