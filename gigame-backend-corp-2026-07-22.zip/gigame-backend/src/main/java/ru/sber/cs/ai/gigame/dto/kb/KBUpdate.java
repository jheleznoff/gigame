package ru.sber.cs.ai.gigame.dto.kb;

import io.swagger.v3.oas.annotations.media.Schema;

/**
 * DTO для обновления базы знаний.
 * Используется при изменении имени и/или описания существующей базы знаний.
 *
 * @param name        Новое имя базы знаний (опционально, максимум 64 символа)
 * @param description Новое описание базы знаний (опционально, максимум 255 символов)
 * @param shared      Общая ли база (null — не менять)
 * @see KBCreate
 * @see KBResponse
 */
@Schema(
        description = "Запрос на обновление базы знаний",
        additionalProperties = Schema.AdditionalPropertiesValue.FALSE
)
public record KBUpdate(
        @Schema(
                description = "Новое имя базы знаний",
                example = "Обновленная документация",
                pattern = "^[\\w\\W]{0,64}$"
        )
        String name,

        @Schema(
                description = "Новое описание базы знаний",
                example = "Обновленная документация по продукту",
                pattern = "^[\\w\\W]{0,255}$"
        )
        String description,

        @Schema(
                description = "Общая ли база: видна всем пользователям (null — не менять)",
                nullable = true
        )
        Boolean shared
) {
}
