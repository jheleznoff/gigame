package ru.sber.cs.ai.gigame.dto.chat;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Schema;

import java.util.List;

/**
 * DTO для создания и обновления беседы (диалога).
 * Используется при инициализации нового чата и при изменении его настроек:
 * названия, привязанных баз знаний, модели и температуры.
 *
 * @param title            Название беседы (максимум 64 символа)
 * @param knowledgeBaseId  Идентификатор связанной базы знаний (устаревшее поле)
 * @param knowledgeBaseIds Идентификаторы связанных баз знаний
 * @param model            Модель GigaChat для диалога
 * @param temperature      Температура генерации
 * @see ConversationResponse
 */
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
@Schema(
        description = "Запрос на создание или обновление беседы в чате",
        additionalProperties = Schema.AdditionalPropertiesValue.FALSE
)
public record ConversationCreate(
        @Schema(
                description = "Название беседы",
                example = "Обсуждение проекта",
                pattern = "^[\\w\\W]{0,64}$",
                nullable = true
        )
        String title,

        @Schema(
                description = "Идентификатор связанной базы знаний (устаревшее, используйте knowledge_base_ids)",
                example = "550e8400-e29b-41d4-a716-446655440000",
                pattern = "^[\\w\\W]{0,64}$",
                nullable = true
        )
        String knowledgeBaseId,

        @ArraySchema(
                schema = @Schema(description = "Идентификаторы связанных баз знаний",
                        pattern = "^[\\w\\W]{0,64}$"),
                maxItems = 20
        )
        List<String> knowledgeBaseIds,

        @Schema(
                description = "Модель GigaChat для диалога (пустая строка — сброс на модель по умолчанию, null — не менять)",
                example = "GigaChat-2-Max",
                pattern = "^[\\w\\W]{0,64}$",
                nullable = true
        )
        String model,

        @Schema(
                description = "Температура генерации 0..2 (отрицательное значение — сброс на значение по умолчанию, null — не менять)",
                example = "0.7",
                nullable = true
        )
        Double temperature
) {
}
