package ru.sber.cs.ai.gigame.service;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.sber.cs.ai.gigame.model.Embedding;
import ru.sber.cs.ai.gigame.repository.EmbeddingRepository;

import java.util.List;
import java.util.UUID;
import java.util.stream.IntStream;

/**
 * Сервис управления векторными эмбеддингами и поиска похожих фрагментов.
 * <p>
 * Использует pgvector для хранения векторов и выполнения поиска по косинусному расстоянию.
 *
 * @see Embedding
 * @see EmbeddingRepository
 */
@Service
@Slf4j
public class EmbeddingService {

    private final EmbeddingRepository embeddingRepository;
    @Value("${app.embedding.topK:5}")
    private int topK;

    public EmbeddingService(EmbeddingRepository embeddingRepository) {
        this.embeddingRepository = embeddingRepository;
    }


    /**
     * Сохраняет фрагменты документа с векторными эмбеддингами.
     * <p>
     * Используется для индексации документов в коллекции типа "doc".
     *
     * @param documentId UUID документа (используется как collection_id и source_document_id)
     * @param chunks     текстовые фрагменты
     * @param embeddings соответствующие векторные эмбеддинги
     */
    @Transactional
    public void storeDocumentChunks(UUID documentId, List<String> chunks, List<float[]> embeddings) {
        var embeddingList = IntStream.range(0, chunks.size())
                .mapToObj(idx -> new Embedding(
                        null,
                        "doc",
                        documentId,
                        documentId,
                        idx,
                        chunks.get(idx),
                        embeddings.get(idx)))
                .toList();
        
        embeddingRepository.saveAll(embeddingList);
        log.info("Сохранено {} фрагментов документа для документа {}", chunks.size(), documentId);
    }

    /**
     * Сохраняет фрагменты базы знаний с векторными эмбеддингами.
     * <p>
     * Используется для индексации документов в коллекции типа "kb".
     *
     * @param kbId             UUID базы знаний (collection_id)
     * @param sourceDocumentId UUID исходного документа
     * @param chunks           текстовые фрагменты
     * @param embeddings       соответствующие векторные эмбеддинги
     */
    @Transactional
    public void storeKBChunks(UUID kbId, UUID sourceDocumentId, List<String> chunks, List<float[]> embeddings) {
        var embeddingList = IntStream.range(0, chunks.size())
                .mapToObj(idx -> new Embedding(
                        null,
                        "kb",
                        kbId,
                        sourceDocumentId,
                        idx,
                        chunks.get(idx),
                        embeddings.get(idx)))
                .toList();
        
        embeddingRepository.saveAll(embeddingList);
        log.info("Сохранено {} фрагментов БЗ для БЗ={} документ={}", chunks.size(), kbId, sourceDocumentId);
    }

    /**
     * Ищет топ-K наиболее похожих фрагментов по косинусному расстоянию pgvector.
     *
     * @param collectionType тип коллекции ("doc" или "kb")
     * @param collectionId   UUID документа или базы знаний
     * @param queryEmbedding вектор запроса
     * @return список текстов фрагментов, отсортированных по схожести
     */
    public List<String> searchSimilar(String collectionType, UUID collectionId,
                                      float[] queryEmbedding) {
        return embeddingRepository.searchSimilar(collectionType, collectionId, queryEmbedding, topK);
    }

    /**
     * Найденный фрагмент с метаданными источника.
     *
     * @param text             текст фрагмента
     * @param sourceDocumentId UUID исходного документа
     * @param distance         косинусное расстояние до запроса (меньше — ближе)
     */
    public record ChunkHit(String text, UUID sourceDocumentId, double distance) {
    }

    /**
     * Ищет топ-K похожих фрагментов с указанием документа-источника и расстояния.
     * Расстояние позволяет корректно сливать результаты нескольких коллекций.
     *
     * @param collectionType тип коллекции ("doc" или "kb")
     * @param collectionId   UUID документа или базы знаний
     * @param queryEmbedding вектор запроса
     * @return список фрагментов, отсортированных по схожести
     */
    public List<ChunkHit> searchSimilarWithSources(String collectionType, UUID collectionId,
                                                   float[] queryEmbedding) {
        return embeddingRepository.searchSimilarWithSource(collectionType, collectionId, queryEmbedding, topK)
                .stream()
                .map(row -> new ChunkHit(
                        (String) row[0],
                        row[1] != null ? UUID.fromString(row[1].toString()) : null,
                        row[2] != null ? ((Number) row[2]).doubleValue() : Double.MAX_VALUE))
                .toList();
    }

    /**
     * Возвращает настроенный размер выдачи topK.
     *
     * @return topK
     */
    public int getTopK() {
        return topK;
    }

    /**
     * Удаляет все векторные эмбеддинги для указанного документа.
     *
     * @param documentId UUID документа
     */
    @Transactional
    public void deleteDocumentChunks(UUID documentId) {
        embeddingRepository.deleteByCollection("doc", documentId);
        log.info("Удалены фрагменты документа для документа {}", documentId);
    }

    /**
     * Удаляет фрагменты конкретного документа из коллекции базы знаний.
     *
     * @param kbId       UUID базы знаний
     * @param documentId UUID документа
     */
    @Transactional
    public void deleteKBDocumentChunks(UUID kbId, UUID documentId) {
        embeddingRepository.deleteKBDocumentChunks(kbId, documentId);
        log.info("Удалены фрагменты БЗ для БЗ={} документ={}", kbId, documentId);
    }

    /**
     * Удаляет все эмбеддинги для всей базы знаний.
     *
     * @param kbId UUID базы знаний
     */
    @Transactional
    public void deleteKBCollection(UUID kbId) {
        embeddingRepository.deleteByCollection("kb", kbId);
        log.info("Удалена вся коллекция БЗ {}", kbId);
    }
}
