package ru.sber.cs.ai.gigame.dto.chat;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import io.swagger.v3.oas.annotations.media.Schema;

import java.util.UUID;

@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public record RagSource(
        @Schema(
                description = "Идентификатор документа",
                example = "550e8400-e29b-41d4-a716-446655440000",
                pattern = "^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"
        )
        UUID documentId,
        @Schema(
                description = "Наименование документа",
                example = "document.docx",
                pattern = "^[\\w\\W]{0,255}$"
        )
        String documentName,
        @Schema(
                description = "Сниппет RAG",
                pattern = "^[\\w\\W]{0,4096}$"
        )
        String snippet
) {
}
