package ru.sber.cs.ai.gigame.dto.kb;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Size;

import java.time.OffsetDateTime;
import java.util.UUID;

/**
 * DTO для представления документа в базе знаний.
 * Содержит информацию о связи документа с базой знаний и статусе обработки.
 *
 * @param id           Уникальный идентификатор связи
 * @param documentId   Идентификатор связанного документа
 * @param filename     Имя файла документа
 * @param contentType  MIME-тип файла
 * @param sizeBytes    Размер файла в байтах
 * @param chunkCount   Количество чанков (частей) при обработке текста
 * @param status       Статус обработки документа (например, "ready", "error")
 * @param errorMessage Сообщение об ошибке (если есть проблемы с обработкой)
 * @param createdAt    Дата и время добавления документа в базу знаний
 * @see KBDetailResponse
 */
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
@Schema(
        description = "Документ, связанный с базой знаний",
        additionalProperties = Schema.AdditionalPropertiesValue.FALSE
)
public record KBDocumentResponse(
        @Schema(
                description = "Уникальный идентификатор связи",
                example = "550e8400-e29b-41d4-a716-446655440000",
                pattern = "^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"
        )
        UUID id,

        @Schema(
                description = "Уникальный идентификатор связанного документа",
                example = "550e8400-e29b-41d4-a716-446655440000",
                pattern = "^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"
        )
        UUID documentId,

        @Schema(
                description = "Имя файла документа",
                example = "документ.pdf",
                pattern = "^[^\\\\\\/:\\*\\?\"<>\\|]{0,255}$"
        )
        String filename,

        @Schema(
                description = "MIME-тип файла",
                example = "application/pdf",
                pattern = "^[\\w\\W]{0,64}$"
        )
        String contentType,

        @Schema(
                description = "Размер файла в байтах",
                example = "1024",
                minimum = "-1"
        )
        @Size()
        int sizeBytes,

        @Schema(
                description = "Количество чанков (частей) при обработке текста",
                example = "5"
        )
        @Size()
        int chunkCount,

        @Schema(
                description = "Статус обработки документа",
                example = "ready",
                pattern = "^[\\w\\W]{0,32}$"
        )
        String status,

        @Schema(
                description = "Сообщение об ошибке (если есть проблемы с обработкой)",
                example = "Ошибка при извлечении текста",
                pattern = "^[\\w\\W]{0,255}$"
        )
        String errorMessage,

        @Schema(
                description = "Дата и время добавления документа в базу знаний"
        )
        OffsetDateTime createdAt
) {
}
