package ru.sber.cs.ai.gigame.service.scenario.executor;

import com.fasterxml.jackson.core.json.JsonReadFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.json.JsonMapper;
import lombok.extern.slf4j.Slf4j;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunNode;
import ru.sber.cs.ai.gigame.utils.JsonCalcUtils;

import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Выражения в промптах узлов — адресный доступ к выходам конкретных узлов:
 * <ul>
 *   <li>{@code {{output:Метка узла}}} — полный текст выхода узла с такой меткой (или id);</li>
 *   <li>{@code {{json:Метка узла:путь.к.полю}}} — значение поля из JSON-блока в выходе узла;
 *       путь — через точку, элементы массивов — {@code поле[0]}.</li>
 * </ul>
 * Если узел или поле не найдены, в текст подставляется явная пометка об ошибке —
 * автор сценария увидит её в результате шага.
 */
@Slf4j
public final class ExpressionResolver {

    private static final Pattern EXPR = Pattern.compile(
            "\\{\\{\\s*(output|json)\\s*:\\s*([^:}]+?)\\s*(?::\\s*([^}]+?)\\s*)?}}");

    /** Токен пути: имя поля и индексы; притяжательные квантификаторы — без бэктрекинга. */
    private static final Pattern PATH_TOKEN = Pattern.compile("^([^\\[\\]]*+)((?:\\[\\d+])*+)$");

    private static final Pattern PATH_INDEX = Pattern.compile("\\[(\\d+)]");

    private static final ObjectMapper MAPPER = JsonMapper.builder()
            .enable(JsonReadFeature.ALLOW_JAVA_COMMENTS)
            .enable(JsonReadFeature.ALLOW_YAML_COMMENTS)
            .enable(JsonReadFeature.ALLOW_TRAILING_COMMA)
            .enable(JsonReadFeature.ALLOW_SINGLE_QUOTES)
            .build();

    private ExpressionResolver() {
    }

    /**
     * Есть ли в шаблоне выражения.
     *
     * @param template текст промпта
     * @return true, если найдено хотя бы одно выражение
     */
    public static boolean hasExpressions(String template) {
        return template != null && EXPR.matcher(template).find();
    }

    /**
     * Подставляет значения выражений в шаблон.
     *
     * @param template текст промпта с выражениями
     * @param nodeMap  карта узлов графа (id → узел)
     * @return текст с подставленными значениями
     */
    public static String resolve(String template, Map<String, ScenarioRunNode> nodeMap) {
        Matcher m = EXPR.matcher(template);
        StringBuilder sb = new StringBuilder();
        while (m.find()) {
            String kind = m.group(1);
            String label = m.group(2).trim();
            String path = m.group(3) == null ? null : m.group(3).trim();
            m.appendReplacement(sb, Matcher.quoteReplacement(evaluate(kind, label, path, nodeMap)));
        }
        m.appendTail(sb);
        return sb.toString();
    }

    private static String evaluate(String kind, String label, String path,
                                   Map<String, ScenarioRunNode> nodeMap) {
        ScenarioRunNode src = findNode(label, nodeMap);
        if (src == null) {
            return "[выражение: узел «" + label + "» не найден]";
        }
        String output = String.join("\n\n", src.getOutput());
        if ("output".equals(kind)) {
            return output;
        }
        if (path == null || path.isBlank()) {
            return "[выражение json: не указан путь к полю]";
        }
        return extractJsonPath(output, path, label);
    }

    private static ScenarioRunNode findNode(String label, Map<String, ScenarioRunNode> nodeMap) {
        ScenarioRunNode byId = nodeMap.get(label);
        if (byId != null) {
            return byId;
        }
        for (ScenarioRunNode n : nodeMap.values()) {
            if (label.equalsIgnoreCase(String.valueOf(n.getLabel()).trim())) {
                return n;
            }
        }
        return null;
    }

    /**
     * Извлекает значение по пути из JSON-блока в произвольном тексте
     * (используется также узлом «Трансформация»).
     *
     * @param text текст с JSON-блоком
     * @param path путь через точку, элементы массивов — {@code поле[0]}
     * @return значение либо пометка об ошибке
     */
    public static String extractJsonPathFromText(String text, String path) {
        return extractJsonPath(text, path, "«текст»");
    }

    /**
     * Извлекает значение по пути из JSON-блока в тексте выхода узла.
     * Берётся последний разбираемый JSON-объект/массив в тексте
     * (данные обычно завершают выход узла).
     */
    private static String extractJsonPath(String output, String path, String label) {
        Object root = findJson(output);
        if (root == null) {
            return "[выражение json: в выходе узла «" + label + "» нет разбираемого JSON]";
        }
        Object current = root;
        for (String rawToken : path.split("\\.")) {
            current = step(current, rawToken.trim(), path);
            if (current instanceof PathError error) {
                return error.message();
            }
        }
        return stringify(current);
    }

    /** Пометка об ошибке разбора пути (отличает ошибку от легитимного значения). */
    private record PathError(String message) {
    }

    /** Один шаг пути: поле токена (если есть), затем индексы массивов. */
    private static Object step(Object current, String token, String path) {
        Matcher idx = PATH_TOKEN.matcher(token);
        if (!idx.matches()) {
            return new PathError("[выражение json: некорректный путь «" + path + "»]");
        }
        Object value = current;
        String field = idx.group(1);
        if (!field.isEmpty()) {
            if (!(value instanceof Map<?, ?> map) || !map.containsKey(field)) {
                return new PathError("[выражение json: поле «" + field + "» не найдено (путь «"
                        + path + "»)]");
            }
            value = map.get(field);
        }
        return applyIndexes(value, idx.group(2), path);
    }

    /** Применяет цепочку индексов «[0][1]…» к значению. */
    private static Object applyIndexes(Object value, String indexes, String path) {
        Object current = value;
        Matcher arr = PATH_INDEX.matcher(indexes);
        while (arr.find()) {
            int i = Integer.parseInt(arr.group(1));
            if (!(current instanceof List<?> list) || i >= list.size()) {
                return new PathError("[выражение json: индекс [" + i + "] вне диапазона (путь «"
                        + path + "»)]");
            }
            current = list.get(i);
        }
        return current;
    }

    private static Object findJson(String text) {
        // с начала текста — первый '{' или '[', с которого разбирается сбалансированный блок
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            if (c != '{' && c != '[') {
                continue;
            }
            int end = c == '{' || c == '[' ? JsonCalcUtils.balancedEnd(text, i) : -1;
            if (end < 0) {
                continue;
            }
            try {
                return MAPPER.readValue(JsonCalcUtils.sanitizeDecimalCommas(text.substring(i, end + 1)), Object.class);
            } catch (Exception ignored) {
                // пробуем следующий кандидат
            }
        }
        return null;
    }

    private static String stringify(Object value) {
        if (value == null) {
            return "";
        }
        if (value instanceof String s) {
            return s;
        }
        if (value instanceof Map || value instanceof List) {
            try {
                return MAPPER.writeValueAsString(value);
            } catch (Exception e) {
                return String.valueOf(value);
            }
        }
        return String.valueOf(value);
    }
}
