package ru.sber.cs.ai.gigame.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.codec.multipart.FilePart;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;
import ru.sber.cs.ai.gigame.dto.ErrorResponse;
import ru.sber.cs.ai.gigame.dto.kb.KBCreate;
import ru.sber.cs.ai.gigame.dto.kb.KBDetailResponse;
import ru.sber.cs.ai.gigame.dto.kb.KBDocumentResponse;
import ru.sber.cs.ai.gigame.dto.kb.KBResponse;
import ru.sber.cs.ai.gigame.dto.kb.KBUpdate;
import ru.sber.cs.ai.gigame.service.DocumentIndexService;
import ru.sber.cs.ai.gigame.service.KBService;

import jakarta.validation.constraints.Size;
import java.util.List;
import java.util.UUID;

/**
 * Контроллер для управления базами знаний.
 * <p>
 * Базы знаний — это коллекции документов, проиндексированных для векторного поиска (RAG).
 * Документы в базе знаний используются для контекста при ответах на вопросы в диалогах.
 */
@RestController
@RequestMapping("/api/knowledge-bases")
@RequiredArgsConstructor
@Tag(name = "knowledge-base", description = "Базы знаний для RAG-поиска")
@SuppressWarnings("unused")
public class KnowledgeBaseController {

    private final KBService kbService;
    private final DocumentIndexService indexService;

    /**
     * Список всех баз знаний.
     * <p>
     * Возвращает список всех доступных баз знаний, к которым у пользователя есть доступ.
     * Поддерживает поиск по частичному совпадению названия.
     *
     * @param userId Идентификатор пользователя (из заголовка X-UserId)
     * @param search Поисковый запрос в названии базы знаний (необязательный)
     * @return Список баз знаний
     */
    @GetMapping
    @Operation(
            summary = "Получить список баз знаний",
            description = "Возвращает список всех доступных баз знаний. " +
                    "При передаче параметра 'search' выполняется поиск по частичному совпадению названия.",
            responses = {
                    @ApiResponse(responseCode = "200",
                            description = "Список баз знаний получен успешно",
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    array = @ArraySchema(maxItems = 1000, schema = @Schema(implementation = KBResponse.class)))),
                    @ApiResponse(responseCode = "400",
                            description = "Неверные данные запроса",
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ErrorResponse.class)))})
    public Mono<List<KBResponse>> listKnowledgeBases(
            @RequestHeader(name = "X-UserId", required = false)
            @Parameter(
                    name = "X-UserId",
                    in = ParameterIn.HEADER,
                    schema = @Schema(type = "string", pattern = "^[A-Z0-9]{0,16}$")
            )
            String userId,
            @Parameter(description = "Поисковый запрос в названии базы знаний (необязательный)",
                    schema = @Schema(type = "string", pattern = "^[\\w\\W]{0,128}$"))
            @RequestParam(value = "q", defaultValue = "") String search) {
        return Mono.fromCallable(() -> kbService.getKnowledgeBases(userId, search))
                .subscribeOn(Schedulers.boundedElastic());
    }

    /**
     * Создание новой базы знаний.
     * <p>
     * Создаёт пустую базу знаний для последующего добавления документов.
     * Документы в базе знаний используются для контекста при ответах на вопросы в диалогах.
     *
     * @param userId Идентификатор пользователя (из заголовка X-UserId)
     * @param body   Данные для создания базы знаний (название и описание)
     * @return Созданная база знаний с уникальным идентификатором
     */
    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    @Operation(
            summary = "Создать новую базу знаний",
            description = "Создаёт пустую базу знаний для последующего добавления документов.",
            responses = {
                    @ApiResponse(responseCode = "201",
                            description = "База знаний успешно создана",
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = KBResponse.class))
                    ),
                    @ApiResponse(responseCode = "400",
                            description = "Неверные данные запроса",
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ErrorResponse.class)))})
    public Mono<KBResponse> createKnowledgeBase(
            @RequestHeader(name = "X-UserId", required = false)
            @Parameter(
                    name = "X-UserId",
                    in = ParameterIn.HEADER,
                    schema = @Schema(type = "string", pattern = "^[A-Z0-9]{0,16}$")
            )
            String userId,
            @Parameter(description = "Данные для создания базы знаний (название и описание)",
                    content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                            schema = @Schema(implementation = KBCreate.class)))
            @RequestBody KBCreate body) {
        return Mono.fromCallable(() -> kbService.createKnowledgeBase(userId, body.name(), body.description(), body.shared()))
                .subscribeOn(Schedulers.boundedElastic());
    }

    /**
     * Получение базы знаний с деталями.
     * <p>
     * Возвращает базу знаний вместе со списком документов и их статусом индексации.
     *
     * @param userId Идентификатор пользователя (из заголовка X-UserId)
     * @param id     Идентификатор базы знаний
     * @return Детальная информация о базе знаний
     */
    @GetMapping("/{id}")
    @Operation(
            summary = "Получить базу знаний с деталями",
            description = "Возвращает базу знаний с полной информацией: " +
                    "документы в базе, статус их обработки и количество чанков.",
            responses = {
                    @ApiResponse(responseCode = "200",
                            description = "База знаний найдена",
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = KBDetailResponse.class))
                    ),
                    @ApiResponse(responseCode = "400",
                            description = "Неверные данные запроса",
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ErrorResponse.class))
                    ),
                    @ApiResponse(responseCode = "404",
                            description = "База знаний не найдена",
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ErrorResponse.class)))})
    public Mono<KBDetailResponse> getKnowledgeBase(
            @RequestHeader(name = "X-UserId", required = false)
            @Parameter(
                    name = "X-UserId",
                    in = ParameterIn.HEADER,
                    schema = @Schema(type = "string", pattern = "^[A-Z0-9]{0,16}$")
            )
            String userId,
            @Parameter(description = "Уникальный идентификатор базы знаний (UUID)",
                    schema = @Schema(type = "string", pattern = "^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"))
            @PathVariable UUID id) {
        return Mono.fromCallable(() -> kbService.getKnowledgeBase(userId, id))
                .subscribeOn(Schedulers.boundedElastic());
    }

    /**
     * Обновление базы знаний.
     * <p>
     * Обновляет название и описание существующей базы знаний.
     *
     * @param userId Идентификатор пользователя (из заголовка X-UserId)
     * @param id     Идентификатор базы знаний
     * @param body   Новые данные базы знаний (название и описание)
     * @return Обновлённая база знаний
     */
    @PutMapping("/{id}")
    @Operation(
            summary = "Обновить базу знаний",
            description = "Обновляет название и описание существующей базы знаний.",
            responses = {
                    @ApiResponse(responseCode = "200",
                            description = "База знаний успешно обновлена",
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = KBResponse.class))
                    ),
                    @ApiResponse(responseCode = "400",
                            description = "Неверные данные запроса",
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ErrorResponse.class))
                    ),
                    @ApiResponse(responseCode = "404",
                            description = "База знаний не найдена",
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ErrorResponse.class)))})
    public Mono<KBResponse> updateKnowledgeBase(
            @RequestHeader(name = "X-UserId", required = false)
            @Parameter(
                    name = "X-UserId",
                    in = ParameterIn.HEADER,
                    schema = @Schema(type = "string", pattern = "^[A-Z0-9]{0,16}$")
            )
            String userId,
            @Parameter(description = "Уникальный идентификатор базы знаний (UUID)",
                    schema = @Schema(type = "string", pattern = "^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"))
            @PathVariable UUID id,
            @Parameter(description = "Новые данные базы знаний (название и описание)",
                    content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                            schema = @Schema(implementation = KBUpdate.class)))
            @RequestBody KBUpdate body) {
        return Mono.fromCallable(() -> kbService.updateKnowledgeBase(userId, id, body.name(), body.description(), body.shared()))
                .subscribeOn(Schedulers.boundedElastic());
    }

    /**
     * Удаление базы знаний.
     * <p>
     * Удаляет базу знаний и все связанные векторные данные.
     *
     * @param userId Идентификатор пользователя (из заголовка X-UserId)
     * @param id     Идентификатор базы знаний
     */
    @DeleteMapping("/{id}")
    @Operation(
            summary = "Удалить базу знаний",
            description = "Удаляет базу знаний и все связанные с ней векторные индексы. " +
                    "Документы при этом не удаляются из системы - они просто исключаются из KB.",
            responses = {
                    @ApiResponse(responseCode = "204",
                            description = "База знаний успешно удалена"
                    ),
                    @ApiResponse(responseCode = "400",
                            description = "Неверные данные запроса",
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ErrorResponse.class))
                    ),
                    @ApiResponse(responseCode = "404",
                            description = "База знаний не найдена",
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ErrorResponse.class)))})
    public Mono<ResponseEntity<Void>> deleteKnowledgeBase(
            @RequestHeader(name = "X-UserId", required = false)
            @Parameter(
                    name = "X-UserId",
                    in = ParameterIn.HEADER,
                    schema = @Schema(type = "string", pattern = "^[A-Z0-9]{0,16}$")
            )
            String userId,
            @Parameter(description = "Уникальный идентификатор базы знаний (UUID)",
                    schema = @Schema(type = "string", pattern = "^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"))
            @PathVariable UUID id) {
        return Mono.fromRunnable(() -> kbService.deleteKnowledgeBase(userId, id))
                .subscribeOn(Schedulers.boundedElastic())
                .then(Mono.just(ResponseEntity.noContent().build()));
    }

    /**
     * Загрузка документа в базу знаний.
     * <p>
     * Загружает файл и добавляет его в базу знаний. Документ автоматически индексируется.
     *
     * @param userId Идентификатор пользователя (из заголовка X-UserId)
     * @param id     Идентификатор базы знаний
     * @param file   Загружаемый файл
     * @return Метаданные документа в контексте базы знаний
     */
    @PostMapping(value = "/{id}/documents", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @ResponseStatus(HttpStatus.CREATED)
    @Operation(
            summary = "Добавить документ в базу знаний",
            description = """
                    Загружает файл и добавляет его в базу знаний. Документ автоматически:
                    - Извлекает текст из файла
                    - Разбивает текст на фрагменты
                    - Создаёт векторные эмбеддинги
                    - Индексирует для RAG-поиска
                    
                    Поддерживаемые форматы: PDF, DOCX, XLSX, TXT
                    """,
            responses = {
                    @ApiResponse(responseCode = "201",
                            description = "Документ успешно добавлен в базу знаний",
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = KBDocumentResponse.class))
                    ),
                    @ApiResponse(responseCode = "400",
                            description = "Неверные данные запроса",
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ErrorResponse.class))
                    ),
                    @ApiResponse(responseCode = "404",
                            description = "База знаний не найдена",
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ErrorResponse.class)))})
    public Mono<KBDocumentResponse> uploadDocumentToKB(
            @RequestHeader(name = "X-UserId", required = false)
            @Parameter(
                    name = "X-UserId",
                    in = ParameterIn.HEADER,
                    schema = @Schema(type = "string", pattern = "^[A-Z0-9]{0,16}$")
            )
            String userId,
            @Parameter(description = "Уникальный идентификатор базы знаний (UUID)",
                    schema = @Schema(type = "string", pattern = "^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"))
            @PathVariable UUID id,
            @Parameter(description = "Загружаемый файл",
                    schema = @Schema(
                            type = "string",
                            format = "binary",
                            pattern = "^(1(01*0)*1|0)+$",
                            description = "Файлы в формате binary"))
            @RequestPart("file")
            @Size(max = 30 * 1024 * 1024)
            FilePart file) {
        return Mono.fromCallable(() -> kbService.addDocumentToKB(userId, id, file))
                .subscribeOn(Schedulers.boundedElastic());
    }

    /**
     * Пересоздание индекса документа.
     * <p>
     * Позволяет повторно индексировать документ в базе знаний.
     * Полезно при изменении параметров индексации или после обновлений.
     *
     * @param userId Идентификатор пользователя (из заголовка X-UserId)
     * @param id     Идентификатор базы знаний
     * @param docId  Идентификатор документа
     * @return Состояние документа после пересоздания индекса
     */
    @PostMapping("/{id}/documents/{docId}/reindex")
    @Operation(
            summary = "Пересоздать индекс документа",
            description = "Повторно извлекает текст из документа, создаёт фрагменты и эмбеддинги. " +
                    "Полезно при изменении параметров индексации или после обновлений.",
            responses = {
                    @ApiResponse(responseCode = "200",
                            description = "Индекс успешно пересоздан",
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = KBDocumentResponse.class))
                    ),
                    @ApiResponse(responseCode = "400",
                            description = "Неверные данные запроса",
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ErrorResponse.class))
                    ),
                    @ApiResponse(responseCode = "404",
                            description = "База знаний или документ не найдена",
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ErrorResponse.class)))})
    public Mono<KBDocumentResponse> reindexDocument(
            @RequestHeader(name = "X-UserId", required = false)
            @Parameter(
                    name = "X-UserId",
                    in = ParameterIn.HEADER,
                    schema = @Schema(type = "string", pattern = "^[A-Z0-9]{0,16}$")
            )
            String userId,
            @Parameter(description = "Уникальный идентификатор базы знаний (UUID)",
                    schema = @Schema(type = "string", pattern = "^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"))
            @PathVariable UUID id,
            @Parameter(description = "Уникальный идентификатор документа (UUID)",
                    schema = @Schema(type = "string", pattern = "^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"))
            @PathVariable UUID docId) {
        return Mono.fromCallable(() -> {
            kbService.checkOwner(userId, id);
            return indexService.reindexDocument(id, docId);
        }).subscribeOn(Schedulers.boundedElastic());
    }

    /**
     * Удаление документа из базы знаний.
     * <p>
     * Удаляет связь между документом и базой знаний, включая векторные чанки.
     * Сам документ в системе не удаляется.
     *
     * @param userId Идентификатор пользователя (из заголовка X-UserId)
     * @param id     Идентификатор базы знаний
     * @param docId  Идентификатор документа
     */
    @DeleteMapping("/{id}/documents/{docId}")
    @Operation(
            summary = "Удалить документ из базы знаний",
            description = "Удаляет документ из базы знаний: удаляет связь и векторные чанки, " +
                    "но сам документ остаётся в системе для использования в других KB.",
            responses = {
                    @ApiResponse(responseCode = "204",
                            description = "Документ успешно удалён из базы знаний"
                    ),
                    @ApiResponse(responseCode = "400",
                            description = "Неверные данные запроса",
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ErrorResponse.class))
                    ),
                    @ApiResponse(responseCode = "404",
                            description = "База знаний или документ не найден",
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ErrorResponse.class)))})
    public Mono<ResponseEntity<Void>> removeDocumentFromKB(
            @RequestHeader(name = "X-UserId", required = false)
            @Parameter(
                    name = "X-UserId",
                    in = ParameterIn.HEADER,
                    schema = @Schema(type = "string", pattern = "^[A-Z0-9]{0,16}$")
            )
            String userId,
            @Parameter(description = "Уникальный идентификатор базы знаний (UUID)",
                    schema = @Schema(type = "string", pattern = "^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"))
            @PathVariable UUID id,
            @Parameter(description = "Уникальный идентификатор документа (UUID)",
                    schema = @Schema(type = "string", pattern = "^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"))
            @PathVariable UUID docId) {
        return Mono.fromRunnable(() -> kbService.removeDocumentFromKB(userId, id, docId))
                .subscribeOn(Schedulers.boundedElastic())
                .then(Mono.just(ResponseEntity.noContent().build()));
    }
}
