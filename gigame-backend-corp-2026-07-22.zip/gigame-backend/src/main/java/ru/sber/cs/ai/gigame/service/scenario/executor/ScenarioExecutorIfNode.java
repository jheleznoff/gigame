package ru.sber.cs.ai.gigame.service.scenario.executor;

import org.apache.commons.lang3.tuple.Pair;
import org.springframework.http.codec.ServerSentEvent;
import reactor.core.publisher.FluxSink;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunNode;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static ru.sber.cs.ai.gigame.service.scenario.ScenarioEventEmission.emitIfResultEvent;

public class ScenarioExecutorIfNode extends AbstractScenarioExecutor {
    private static final Pattern NUMBER_PATTERN = Pattern.compile("[\\d\\s]+[,.]?\\d*");
    private static final Set<String> TRUE_LABELS = Set.of("true", "да", "истина", "yes");

    protected ScenarioExecutorIfNode(ScenarioRunNode node) {
        super(node);
    }

    private static String getTextToCheck(String previousOutput, String field) {
        var splittedLines = previousOutput.split("\n");
        // Первая строка может быть заголовком вида "=== РЕЗУЛЬТАТ ОТ \"...\" ===".
        // Удаляем её только в том случае, если она похожа на заголовок.
        if (splittedLines.length > 1 && isHeaderLine(splittedLines[0])) {
            splittedLines = Arrays.copyOfRange(splittedLines, 1, splittedLines.length);
        }
        if (!field.isEmpty()) {
            for (String line : splittedLines) {
                if (line.toLowerCase().contains(field.toLowerCase())) {
                    return line;
                }
            }
        }
        return String.join("\n", splittedLines);
    }

    private static boolean isHeaderLine(String line) {
        return line.startsWith("=== ") && line.endsWith(" ===");
    }

    /**
     * Выполняет узел условия (If).
     * <p>
     * Оценивает условие на основе поля и оператора. Поддерживаемые операторы:
     * <ul>
     *   <li>contains — содержит подстроку</li>
     *   <li>not_contains — не содержит подстроку</li>
     *   <li>equals — равен значению</li>
     *   <li>greater_than — больше значения (числовое сравнение)</li>
     *   <li>less_than — меньше значения (числовое сравнение)</li>
     * </ul>
     * Выбирает ветку "true"/"false" на основе результата условия.
     *
     * @param sink поток SSE-событий
     * @return строка с результатом условия
     */
    @Override
    public String execute(FluxSink<ServerSentEvent<Map<String, Object>>> sink) {
        List<String> resultList = new ArrayList<>();
        String field = node.getField();
        String operator = node.getOperator();
        String compareValue = node.getValue();
        // Поле и значение принимают выражения {{output:Метка}} / {{json:Метка:путь}} —
        // тогда условие проверяет адресованное значение (например, конкретный
        // результат узла «Расчёт»), а не ищет текст во входе
        if (ExpressionResolver.hasExpressions(compareValue)) {
            compareValue = ExpressionResolver.resolve(compareValue, node.getGraph().getNodeMap());
        }
        if (ExpressionResolver.hasExpressions(field)) {
            String resolved = ExpressionResolver.resolve(field, node.getGraph().getNodeMap());
            return processResolvedValue(sink, resolved, operator, compareValue);
        }
        var parentNodeList = node.getParentNodeList();
        boolean classifyStrict = !parentNodeList.isEmpty() && parentNodeList.get(0).isClassifyStrict();
        if (classifyStrict) {
            // строгая классификация - добавляем документы
            resultList.addAll(processClassifyStrict(sink, field, operator, compareValue));
        } else {
            // обрабатываем предыдущие результаты
            resultList.addAll(processSimple(sink, field, operator, compareValue));
        }
        node.getOutput().addAll(resultList);
        return String.join("\n\n", resultList);
    }

    /**
     * Проверка условия над резолвленным значением выражения: условие вычисляется
     * один раз, вход целиком уходит в ветку true либо false.
     */
    private String processResolvedValue(FluxSink<ServerSentEvent<Map<String, Object>>> sink,
                                        String resolvedValue, String operator, String compareValue) {
        boolean met = isConditionMet(operator, resolvedValue, compareValue);
        List<String> resultList = new ArrayList<>();
        for (var next : node.getChildNodeList()) {
            var edgeData = node.getGraph().getEdgeMap().get(Pair.of(node.getId(), next.getId()));
            String edgeLabel = (null == edgeData) ? "" : edgeData.label();
            boolean isTrueBranch = TRUE_LABELS.contains(edgeLabel);
            if (met == isTrueBranch) {
                next.setSkip(false);
                next.getInput().addAll(node.getInput());
                String msg = "If (" + resolvedValue + " " + operator + " " + compareValue + ") → "
                        + met + ". Ветка «" + (isTrueBranch ? "true" : "false") + "» активирована.";
                resultList.add(msg);
                emitIfResultEvent(sink, node, isTrueBranch, msg);
            } else {
                emitIfResultEvent(sink, node, isTrueBranch, "Условие не выполнено. Узел пропущен.");
            }
        }
        node.getOutput().addAll(resultList);
        return String.join("\n\n", resultList);
    }

    private List<String> processSimple(FluxSink<ServerSentEvent<Map<String, Object>>> sink, String field, String operator, String compareValue) {
        List<String> resultList = new ArrayList<>();
        for (var next : node.getChildNodeList()) {
            var edgeData = node.getGraph().getEdgeMap().get(Pair.of(node.getId(), next.getId()));
            String edgeLabel = (null == edgeData) ? "" : edgeData.label();
            resultList.addAll(processSimpleInput(TRUE_LABELS.contains(edgeLabel), sink, field, operator, compareValue, next));
        }
        return resultList;
    }

    private List<String> processSimpleInput(Boolean isTrueBranch, FluxSink<ServerSentEvent<Map<String, Object>>> sink, String field, String operator, String compareValue, ScenarioRunNode next) {
        List<String> resultList = new ArrayList<>();
        var inputList = node.getInput().stream()
                .filter(input -> {
                    var textToCheck = getTextToCheck(input, field);
                    return isTrueBranch == isConditionMet(operator, textToCheck, compareValue);
                }).toList();
        if (inputList.isEmpty()) {
            emitIfResultEvent(sink, node, isTrueBranch, "Условие не выполнено. Узел пропущен.");
        } else {
            next.setSkip(false);
            next.getInput().addAll(inputList);
            resultList.add("If (" + field + " " + operator + " " + compareValue + ") → true. Result: [" + String.join(", ", inputList) + "]");
            emitIfResultEvent(sink, node, isTrueBranch, "Result: [" + String.join(", ", inputList) + "]");
        }
        return resultList;
    }

    private List<String> processClassifyStrict(FluxSink<ServerSentEvent<Map<String, Object>>> sink, String field, String operator, String compareValue) {
        List<String> resultList = new ArrayList<>();
        for (var next : node.getChildNodeList()) {
            var edgeData = node.getGraph().getEdgeMap().get(Pair.of(node.getId(), next.getId()));
            String edgeLabel = (null == edgeData) ? "" : edgeData.label();
            resultList.addAll(processClassifyStrictDocs(TRUE_LABELS.contains(edgeLabel), sink, field, operator, compareValue, next));
        }
        return resultList;
    }

    private List<String> processClassifyStrictDocs(Boolean isTrueBranch, FluxSink<ServerSentEvent<Map<String, Object>>> sink, String field, String operator, String compareValue, ScenarioRunNode next) {
        List<String> resultList = new ArrayList<>();
        var docList = node.getGraph().getDocMap().entrySet().stream()
                .filter(entry -> {
                    if ("docClass".equalsIgnoreCase(field)) {
                        return isTrueBranch == isConditionMet(operator, entry.getValue().getDocClass(), compareValue);
                    }
                    var textToCheck = getTextToCheck(entry.getValue().getText(), field);
                    return isTrueBranch == isConditionMet(operator, textToCheck, compareValue);
                })
                .map(Map.Entry::getKey).toList();
        if (docList.isEmpty()) {
            emitIfResultEvent(sink, node, isTrueBranch, "Условие не выполнено. Узел пропущен.");
        } else {
            next.setSkip(false);
            next.getDocList().addAll(docList);
            resultList.add("If (" + field + " " + operator + " " + compareValue + ") → " + isTrueBranch + ". Docs: [" + String.join(", ", docList) + "]");
            emitIfResultEvent(sink, node, isTrueBranch, "Docs: [" + String.join(", ", docList) + "]");
        }
        return resultList;
    }

    private boolean isConditionMet(String operator, String textToCheck, String compareValue) {
        return switch (operator) {
            case OPERATOR_NOT_CONTAINS -> !textToCheck.toLowerCase().contains(compareValue.toLowerCase());
            case OPERATOR_EQUALS -> textToCheck.toLowerCase().trim().equals(compareValue.toLowerCase());
            case OPERATOR_GREATER_THAN -> compareNumeric(textToCheck, compareValue, true);
            case OPERATOR_LESS_THAN -> compareNumeric(textToCheck, compareValue, false);
            default /*OPERATOR_CONTAINS*/ -> textToCheck.toLowerCase().contains(compareValue.toLowerCase());
        };
    }

    /**
     * Сравнивает числовые значения в тексте с порогом.
     * <p>
     * Используется в узле If для операторов greater_than и less_than.
     * Извлекает первое число из текста и сравнивает с порогом.
     *
     * @param text         текст, содержащий число
     * @param thresholdStr строка с пороговым значением
     * @param greaterThan  true для greater_than, false для less_than
     * @return true если условие выполнено
     */
    private boolean compareNumeric(String text, String thresholdStr, boolean greaterThan) {
        try {
            Matcher matcher = NUMBER_PATTERN.matcher(text.replace(" ", ""));
            if (!matcher.find()) {
                return false;
            }
            double val = Double.parseDouble(matcher.group().replace(",", ".").replace(" ", ""));
            double threshold = Double.parseDouble(thresholdStr.replace(",", ".").replace(" ", ""));
            return greaterThan ? val > threshold : val < threshold;
        } catch (Exception e) {
            return false;
        }
    }
}
