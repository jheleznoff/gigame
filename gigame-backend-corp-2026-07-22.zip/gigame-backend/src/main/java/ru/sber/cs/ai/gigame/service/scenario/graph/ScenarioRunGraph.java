package ru.sber.cs.ai.gigame.service.scenario.graph;

import lombok.Getter;
import org.apache.commons.lang3.tuple.Pair;
import ru.sber.cs.ai.gigame.dto.scenario.graph.EdgeDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.GraphDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDto;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

@Getter
public class ScenarioRunGraph {
    private final Map<String, ScenarioRunNode> nodeMap;
    private final Map<Pair<String, String>, EdgeDataDto> edgeMap = new HashMap<>();
    private final ScenarioRunNode startNode;
    private final Map<String, ScenarioRunDoc> docMap;
    private final Map<String, float[]> embeddingCache;

    public ScenarioRunGraph(GraphDataDto graphData) {
        AtomicInteger idx = new AtomicInteger();
        this.nodeMap = graphData.nodes().stream()
                .collect(Collectors.toMap(NodeDto::id, node -> {
                    idx.getAndIncrement();
                    return ScenarioRunNode.fromDto(idx.get(), node, this);
                }));
        for (var edge : graphData.edges()) {
            String src = edge.source();
            String tgt = edge.target();
            nodeMap.get(src).getChildNodeList().add(nodeMap.get(tgt));
            nodeMap.get(tgt).getParentNodeList().add(nodeMap.get(src));
            var edgeData = edge.data();
            edgeMap.put(Pair.of(src, tgt), edgeData);
        }
        startNode = nodeMap.values().stream()
                .filter(node -> node.getParentNodeList().isEmpty())
                .findFirst().orElseThrow();
        docMap = new HashMap<>();
        embeddingCache = new HashMap<>();
    }

    public void addDocs(List<String> documentTextList, List<String> filenameList) {
        if (documentTextList != null && !documentTextList.isEmpty()) {
            for (int i = 0; i < documentTextList.size(); i++) {
                docMap.put("DOC_" + (i + 1), new ScenarioRunDoc(filenameList.get(i), documentTextList.get(i)));
            }
        }
    }
}
