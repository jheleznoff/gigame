package ru.sber.cs.ai.gigame.repository;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import ru.sber.cs.ai.gigame.model.Message;

import java.util.List;
import java.util.UUID;

/**
 * Репозиторий для работы с сообщениями диалогов.
 * <p>
 * Предоставляет методы для сохранения сообщений и получения истории переписки.
 *
 * @see Message
 */
@Repository
public interface MessageRepository extends JpaRepository<Message, UUID> {

    /**
     * Возвращает все сообщения диалога, отсортированные по времени создания (хронологический порядок).
     *
     * @param conversationId идентификатор диалога
     * @return список сообщений диалога
     */
    List<Message> findByConversationIdOrderByCreatedAtAsc(UUID conversationId);

    /**
     * Возвращает сообщения диалога с пагинацией, отсортированные по времени создания.
     *
     * @param conversationId идентификатор диалога
     * @param pageable объект пагинации (PageRequest с лимитом)
     * @return список сообщений диалога
     */
    List<Message> findByConversationIdOrderByCreatedAtAsc(UUID conversationId, Pageable pageable);

    /**
     * Возвращает сообщения диалога от новых к старым с пагинацией.
     * Используется для честного скользящего окна «последних N» сообщений.
     *
     * @param conversationId идентификатор диалога
     * @param pageable       объект пагинации (PageRequest с лимитом)
     * @return список сообщений от новых к старым
     */
    List<Message> findByConversationIdOrderByCreatedAtDesc(UUID conversationId, Pageable pageable);

    /**
     * Возвращает количество сообщений в диалоге.
     *
     * @param conversationId идентификатор диалога
     * @return число сообщений
     */
    long countByConversationId(UUID conversationId);
}
