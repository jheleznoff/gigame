-- Test database schema for integration tests

-- Drop tables if they exist (in correct order due to foreign keys)
DROP TABLE IF EXISTS scenario_run_steps CASCADE;
DROP TABLE IF EXISTS scenario_runs CASCADE;
DROP TABLE IF EXISTS scenarios CASCADE;
DROP TABLE IF EXISTS kb_documents CASCADE;
DROP TABLE IF EXISTS embeddings CASCADE;
DROP TABLE IF EXISTS messages CASCADE;
DROP TABLE IF EXISTS documents CASCADE;
DROP TABLE IF EXISTS knowledge_bases CASCADE;
DROP TABLE IF EXISTS conversations CASCADE;

-- Conversations table
CREATE TABLE conversations (
    id UUID PRIMARY KEY,
    title VARCHAR(255) NOT NULL DEFAULT 'Новый диалог',
    knowledge_base_id UUID,
    knowledge_base_ids JSONB,
    model VARCHAR(64),
    temperature DOUBLE PRECISION,
    summary TEXT,
    summary_message_count INTEGER NOT NULL DEFAULT 0,
    user_id VARCHAR(255),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL
);

-- Messages table
CREATE TABLE messages (
    id UUID PRIMARY KEY,
    conversation_id UUID NOT NULL,
    role VARCHAR(50) NOT NULL,
    content TEXT NOT NULL,
    document_ids JSONB,
    sources JSONB,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL,
    FOREIGN KEY (conversation_id) REFERENCES conversations (id) ON DELETE CASCADE
);

-- Documents table
CREATE TABLE documents (
    id UUID PRIMARY KEY,
    filename VARCHAR(500) NOT NULL,
    content_type VARCHAR(255),
    extracted_text TEXT,
    size_bytes INTEGER,
    user_id VARCHAR(255),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL
);

-- Knowledge bases table
CREATE TABLE knowledge_bases (
    id UUID PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    user_id VARCHAR(255),
    shared BOOLEAN NOT NULL DEFAULT FALSE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL
);

-- KB documents table
CREATE TABLE kb_documents (
    id UUID PRIMARY KEY,
    knowledge_base_id UUID NOT NULL,
    document_id UUID NOT NULL,
    chunk_count INTEGER DEFAULT 0,
    status VARCHAR(50) NOT NULL DEFAULT 'processing',
    error_message TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL,
    FOREIGN KEY (knowledge_base_id) REFERENCES knowledge_bases (id) ON DELETE CASCADE,
    FOREIGN KEY (document_id) REFERENCES documents (id) ON DELETE CASCADE
);

-- Embeddings table with pgvector
CREATE TABLE embeddings (
    id UUID PRIMARY KEY,
    collection_type VARCHAR(10) NOT NULL,
    collection_id UUID NOT NULL,
    source_document_id UUID,
    chunk_index INTEGER,
    chunk_text TEXT,
    embedding varchar(4096)
);

-- Scenario tables
CREATE TABLE scenarios (
    id UUID PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    graph_data JSONB,
    user_id VARCHAR(255),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL
);

CREATE TABLE scenario_runs (
    id UUID PRIMARY KEY,
    scenario_id UUID NOT NULL,
    status VARCHAR(50) NOT NULL DEFAULT 'pending',
    input_document_ids JSONB,
    result TEXT,
    started_at TIMESTAMP WITH TIME ZONE NOT NULL,
    completed_at TIMESTAMP WITH TIME ZONE,
    FOREIGN KEY (scenario_id) REFERENCES scenarios (id) ON DELETE CASCADE
);

CREATE TABLE scenario_run_steps (
    id UUID PRIMARY KEY,
    run_id UUID NOT NULL,
    node_id VARCHAR(255),
    node_type VARCHAR(100),
    status VARCHAR(50) NOT NULL DEFAULT 'pending',
    input_data JSONB,
    output_data JSONB,
    prompt_used TEXT,
    tokens_used INTEGER,
    started_at TIMESTAMP WITH TIME ZONE,
    completed_at TIMESTAMP WITH TIME ZONE,
    FOREIGN KEY (run_id) REFERENCES scenario_runs (id) ON DELETE CASCADE
);

