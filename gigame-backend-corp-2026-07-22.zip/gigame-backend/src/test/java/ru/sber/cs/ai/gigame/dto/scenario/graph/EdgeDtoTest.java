package ru.sber.cs.ai.gigame.dto.scenario.graph;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

class EdgeDtoTest {

    @Test
    void testConstruction_withAllFields() {
        var edgeData = new EdgeDataDto("edge_label");
        var dto = new EdgeDto("e1", "node_0", "node_1", edgeData);

        assertEquals("e1", dto.id());
        assertEquals("node_0", dto.source());
        assertEquals("node_1", dto.target());
        assertEquals("edge_label", dto.data().label());
    }

    @Test
    void testConstruction_withNullData() {
        var dto = new EdgeDto("e1", "node_0", "node_1", null);

        assertEquals("e1", dto.id());
        assertEquals("node_0", dto.source());
        assertEquals("node_1", dto.target());
        assertNull(dto.data());
    }
}