package ru.sber.cs.ai.gigame.dto.kb;

import org.junit.jupiter.api.Test;

import java.time.OffsetDateTime;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

class KBResponseTest {

    @Test
    void testConstruction_withAllFields() {
        var id = UUID.randomUUID();
        var now = OffsetDateTime.now();
        var dto = new KBResponse(id, "KB Name", "Description", true, false, now, now);
        assertEquals(id, dto.id());
        assertEquals("KB Name", dto.name());
        assertEquals("Description", dto.description());
        assertTrue(dto.shared());
        assertFalse(dto.isOwner());
        assertEquals(now, dto.createdAt());
        assertEquals(now, dto.updatedAt());
    }

    @Test
    void testConstruction_withNullFields() {
        var dto = new KBResponse(null, null, null, false, true, null, null);
        assertNull(dto.id());
        assertNull(dto.name());
        assertNull(dto.description());
        assertFalse(dto.shared());
        assertTrue(dto.isOwner());
        assertNull(dto.createdAt());
        assertNull(dto.updatedAt());
    }
}
