package ru.sber.cs.ai.gigame.service.scenario.executor;

import org.junit.jupiter.api.Test;
import org.springframework.http.codec.ServerSentEvent;
import reactor.core.publisher.FluxSink;
import ru.sber.cs.ai.gigame.dto.scenario.graph.GraphDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.PositionDto;
import ru.sber.cs.ai.gigame.exception.ScenarioException;
import ru.sber.cs.ai.gigame.service.scenario.enums.ScenarioNodeType;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunGraph;

import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.mock;

/**
 * Тесты операции «слить_json_массивы» узла «Трансформация» —
 * детерминированное объединение результатов групп без LLM.
 */
class ScenarioExecutorTransformNodeMergeTest {

    @SuppressWarnings("unchecked")
    private final FluxSink<ServerSentEvent<Map<String, Object>>> sink = mock(FluxSink.class);

    private static ScenarioRunGraph graph() {
        var dto = NodeDto.builder()
                .id("t1")
                .type(ScenarioNodeType.TRANSFORM_NODE.toString())
                .data(NodeDataDto.builder()
                        .label("Слияние")
                        .rules("{\"операции\": [{\"оп\": \"слить_json_массивы\"}]}")
                        .build())
                .position(new PositionDto(0, 0))
                .build();
        return new ScenarioRunGraph(new GraphDataDto(List.of(dto), List.of()));
    }

    @Test
    void mergesArraysFromSeveralGroupResults() {
        var node = graph().getNodeMap().get("t1");
        node.getInput().add("""
                === Группа 111 ===
                Вот результат:
                [{"договор": "111", "сумма": 10,5}]
                === Группа 222 ===
                [{"договор": "222", "сумма": 20},
                 {"договор": "222", "сумма": 30}]
                """);

        String result = new ScenarioExecutorTransformNode(node).execute(sink);

        assertTrue(result.trim().startsWith("["));
        assertEquals(3, result.split("\"договор\"").length - 1);
        // десятичная запятая починена
        assertTrue(result.contains("10.5"));
    }

    @Test
    void skipsNonObjectArraysAndBrokenJson() {
        var node = graph().getNodeMap().get("t1");
        node.getInput().add("шкала [1, 2, 3] мусор [не json "
                + "и наконец [{\"имя\": \"строка\"}]");

        String result = new ScenarioExecutorTransformNode(node).execute(sink);

        assertEquals(1, result.split("\"имя\"").length - 1);
    }

    @Test
    void noArrays_throws() {
        var node = graph().getNodeMap().get("t1");
        node.getInput().add("текст без массивов");
        var executor = new ScenarioExecutorTransformNode(node);

        assertThrows(ScenarioException.class, () -> executor.execute(sink));
    }
}
