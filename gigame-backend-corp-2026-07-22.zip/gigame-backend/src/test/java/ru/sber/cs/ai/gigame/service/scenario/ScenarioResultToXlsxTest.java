package ru.sber.cs.ai.gigame.service.scenario;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.ValueSource;
import org.springframework.core.io.ByteArrayResource;
import ru.sber.cs.ai.gigame.dto.scenario.ScenarioRunDetailResponse;
import ru.sber.cs.ai.gigame.dto.scenario.ScenarioRunStepInputDataResponse;
import ru.sber.cs.ai.gigame.dto.scenario.ScenarioRunStepOutputDataResponse;
import ru.sber.cs.ai.gigame.dto.scenario.ScenarioRunStepResponse;
import ru.sber.cs.ai.gigame.exception.FileException;

import java.lang.reflect.Method;
import java.time.OffsetDateTime;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertInstanceOf;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

class ScenarioResultToXlsxTest {

    private static String invokeFormatValue(Object value) throws Exception {
        Method method = ScenarioResultToXlsx.class.getDeclaredMethod("formatValue", Object.class);
        method.setAccessible(true);
        return (String) method.invoke(null, value);
    }

    @SuppressWarnings("unchecked")
    private static List<Map<String, Object>> invokeParseJsonToList(String json) throws Exception {
        try {
            Method method = ScenarioResultToXlsx.class.getDeclaredMethod("parseJsonToList", String.class);
            method.setAccessible(true);
            return (List<Map<String, Object>>) method.invoke(null, json);
        } catch (java.lang.reflect.InvocationTargetException e) {
            if (e.getCause() instanceof RuntimeException re) {
                throw re;
            }
            throw e;
        }
    }

    @Test
    void testGenerateXlsx_withCompleteRun() {
        UUID runId = UUID.randomUUID();
        OffsetDateTime now = OffsetDateTime.now();
        ScenarioRunStepResponse step1 = new ScenarioRunStepResponse(
                UUID.randomUUID(),
                "node1",
                "input",
                "completed",
                new ScenarioRunStepInputDataResponse("", "input data"),
                new ScenarioRunStepOutputDataResponse("[{\"first \nname\": \"John\"}, {\"first \nname\": \"Jane\"}]", null),
                "prompt",
                100,
                now,
                now
        );

        ScenarioRunDetailResponse runDetail = new ScenarioRunDetailResponse(
                runId,
                UUID.randomUUID(),
                "completed",
                List.of(),
                "Final result",
                now,
                now,
                List.of(step1, step1)
        );

        var response = ScenarioResultToXlsx.generateXlsx(runId, runDetail);

        assertNotNull(response);
        assertEquals(200, response.getStatusCode().value());
        assertNotNull(response.getBody());
        assertInstanceOf(ByteArrayResource.class, response.getBody());
    }

    @Test
    void testGenerateXlsx_withMultipleSteps() {
        UUID runId = UUID.randomUUID();
        OffsetDateTime now = OffsetDateTime.now();
        ScenarioRunStepResponse step1 = new ScenarioRunStepResponse(
                UUID.randomUUID(),
                "node1",
                "input",
                "completed",
                new ScenarioRunStepInputDataResponse("", "input data"),
                new ScenarioRunStepOutputDataResponse("{\"name\": \"John\", \"age\": 30}", null),
                "prompt",
                100,
                now,
                now
        );
        ScenarioRunStepResponse step2 = new ScenarioRunStepResponse(
                UUID.randomUUID(),
                "node2",
                "processing",
                "completed",
                new ScenarioRunStepInputDataResponse("", "input data"),
                new ScenarioRunStepOutputDataResponse("{\"name\": \"Jane\", \"age\": 25}", null),
                "prompt",
                200,
                now,
                now
        );

        ScenarioRunDetailResponse runDetail = new ScenarioRunDetailResponse(
                runId,
                UUID.randomUUID(),
                "completed",
                List.of(),
                "Final result",
                now,
                now,
                List.of(step1, step2)
        );

        var response = ScenarioResultToXlsx.generateXlsx(runId, runDetail);

        assertNotNull(response);
        assertEquals(200, response.getStatusCode().value());
        assertNotNull(response.getBody());
    }

    @Test
    void testGenerateXlsx_withEmptySteps_returnsNull() {
        UUID runId = UUID.randomUUID();
        OffsetDateTime now = OffsetDateTime.now();
        ScenarioRunDetailResponse detail = new ScenarioRunDetailResponse(
                runId,
                UUID.randomUUID(),
                "completed",
                List.of(),
                "Result",
                now,
                now,
                List.of()
        );

        var response = ScenarioResultToXlsx.generateXlsx(runId, detail);

        // Когда steps.size() < 2, метод возвращает null
        assertNull(response);
    }

    @Test
    void testGenerateXlsx_withNullSteps() {
        UUID runId = UUID.randomUUID();
        OffsetDateTime now = OffsetDateTime.now();
        ScenarioRunDetailResponse detail = new ScenarioRunDetailResponse(
                runId,
                UUID.randomUUID(),
                "completed",
                List.of(),
                "Result",
                now,
                now,
                null
        );

        NullPointerException exception = assertThrows(NullPointerException.class, () -> ScenarioResultToXlsx.generateXlsx(runId, detail));

        assertTrue(exception.getMessage().contains("Cannot invoke"));
    }

    @Test
    void testGenerateXlsx_contentType() {
        UUID runId = UUID.randomUUID();
        OffsetDateTime now = OffsetDateTime.now();
        ScenarioRunStepResponse step1 = new ScenarioRunStepResponse(
                UUID.randomUUID(),
                "node1",
                "input",
                "completed",
                new ScenarioRunStepInputDataResponse("", "input data"),
                new ScenarioRunStepOutputDataResponse("{\"name\": \"John\"}", null),
                "prompt",
                100,
                now,
                now
        );

        ScenarioRunDetailResponse runDetail = new ScenarioRunDetailResponse(
                runId,
                UUID.randomUUID(),
                "completed",
                List.of(),
                "Final result",
                now,
                now,
                List.of(step1, step1)
        );

        var response = ScenarioResultToXlsx.generateXlsx(runId, runDetail);

        assertNotNull(response);
        assertNotNull(response.getHeaders().getContentType());
        assertTrue(response.getHeaders().getContentType().toString().contains("spreadsheetml.sheet"));
    }

    @Test
    void testGenerateXlsx_hasContentDispositionHeader() {
        UUID runId = UUID.randomUUID();
        OffsetDateTime now = OffsetDateTime.now();
        ScenarioRunStepResponse step1 = new ScenarioRunStepResponse(
                UUID.randomUUID(),
                "node1",
                "input",
                "completed",
                new ScenarioRunStepInputDataResponse("", "input data"),
                new ScenarioRunStepOutputDataResponse("{\"name\": \"John\"}", null),
                "prompt",
                100,
                now,
                now
        );

        ScenarioRunDetailResponse runDetail = new ScenarioRunDetailResponse(
                runId,
                UUID.randomUUID(),
                "completed",
                List.of(),
                "Final result",
                now,
                now,
                List.of(step1, step1)
        );

        var response = ScenarioResultToXlsx.generateXlsx(runId, runDetail);

        assertNotNull(response);
        assertNotNull(response.getHeaders().getContentDisposition());
        String filename = response.getHeaders().getContentDisposition().getFilename();
        assertNotNull(filename);
        assertTrue(filename.startsWith("result_"));
        assertTrue(filename.endsWith(".xlsx"));
    }

    @Test
    void testGenerateXlsx_filenameFormat() {
        UUID runId = UUID.randomUUID();
        OffsetDateTime now = OffsetDateTime.now();
        ScenarioRunStepResponse step1 = new ScenarioRunStepResponse(
                UUID.randomUUID(),
                "node1",
                "input",
                "completed",
                new ScenarioRunStepInputDataResponse("", "input data"),
                new ScenarioRunStepOutputDataResponse("{\"name\": \"John\"}", null),
                "prompt",
                100,
                now,
                now
        );

        ScenarioRunDetailResponse runDetail = new ScenarioRunDetailResponse(
                runId,
                UUID.randomUUID(),
                "completed",
                List.of(),
                "Final result",
                now,
                now,
                List.of(step1, step1)
        );

        var response = ScenarioResultToXlsx.generateXlsx(runId, runDetail);

        assertNotNull(response);
        String filename = response.getHeaders().getContentDisposition().getFilename();
        assertNotNull(filename);
        assertTrue(filename.startsWith("result_"));
        assertTrue(filename.endsWith(".xlsx"));
        // The filename uses runId.toString().substring(0, 8) which is 8 characters
        assertEquals(8, filename.substring(7, 15).length());
    }

    @Test
    void testGenerateXlsx_withRunningStatus() {
        UUID runId = UUID.randomUUID();
        OffsetDateTime now = OffsetDateTime.now();
        ScenarioRunStepResponse step1 = new ScenarioRunStepResponse(
                UUID.randomUUID(),
                "node1",
                "input",
                "running",
                new ScenarioRunStepInputDataResponse("", "input data"),
                new ScenarioRunStepOutputDataResponse("{\"name\": \"John\"}", null),
                "prompt",
                100,
                now,
                null
        );

        ScenarioRunDetailResponse runDetail = new ScenarioRunDetailResponse(
                runId,
                UUID.randomUUID(),
                "running",
                List.of(),
                "Final result",
                now,
                null,
                List.of(step1, step1)
        );

        var response = ScenarioResultToXlsx.generateXlsx(runId, runDetail);

        assertNotNull(response);
        assertEquals(200, response.getStatusCode().value());
    }

    @Test
    void testGenerateXlsx_withFailedStatus() {
        UUID runId = UUID.randomUUID();
        OffsetDateTime now = OffsetDateTime.now();
        ScenarioRunStepResponse step1 = new ScenarioRunStepResponse(
                UUID.randomUUID(),
                "node1",
                "input",
                "failed",
                new ScenarioRunStepInputDataResponse("", "input data"),
                new ScenarioRunStepOutputDataResponse("{\"name\": \"John\"}", "error"),
                "prompt",
                100,
                now,
                now
        );

        ScenarioRunDetailResponse runDetail = new ScenarioRunDetailResponse(
                runId,
                UUID.randomUUID(),
                "failed",
                List.of(),
                "Final result",
                now,
                now,
                List.of(step1, step1)
        );

        var response = ScenarioResultToXlsx.generateXlsx(runId, runDetail);

        assertNotNull(response);
        assertEquals(200, response.getStatusCode().value());
    }

    // ----- Тесты для formatValue (через рефлексию) -----

    @ParameterizedTest
    @CsvSource(
            textBlock = """
                    '[{"name": "John"}, {"name": "Jane"}]',
                    '{"name": "John", "age": 30}',
                    'Some text before {"name": "John"} text after'
                    """
    )
    void testGenerateXlsx_withJsonOutputInResult(String outputResult) {
        UUID runId = UUID.randomUUID();
        OffsetDateTime now = OffsetDateTime.now();
        ScenarioRunStepResponse step1 = new ScenarioRunStepResponse(
                UUID.randomUUID(),
                "node1",
                "input",
                "completed",
                new ScenarioRunStepInputDataResponse("", "input data"),
                new ScenarioRunStepOutputDataResponse(outputResult, null),
                "prompt",
                100,
                now,
                now
        );

        ScenarioRunDetailResponse runDetail = new ScenarioRunDetailResponse(
                runId,
                UUID.randomUUID(),
                "completed",
                List.of(),
                "Final result",
                now,
                now,
                List.of(step1, step1)
        );

        var response = ScenarioResultToXlsx.generateXlsx(runId, runDetail);

        assertNotNull(response);
        assertEquals(200, response.getStatusCode().value());
        assertNotNull(response.getBody());
    }

    @Test
    void testGenerateXlsx_withNullJsonInResult_throwsFileException() {
        UUID runId = UUID.randomUUID();
        OffsetDateTime now = OffsetDateTime.now();
        ScenarioRunStepResponse step1 = new ScenarioRunStepResponse(
                UUID.randomUUID(),
                "node1",
                "input",
                "completed",
                new ScenarioRunStepInputDataResponse("", "input data"),
                new ScenarioRunStepOutputDataResponse(null, null),
                "prompt",
                100,
                now,
                now
        );

        ScenarioRunDetailResponse runDetail = new ScenarioRunDetailResponse(
                runId,
                UUID.randomUUID(),
                "completed",
                List.of(),
                "Final result",
                now,
                now,
                List.of(step1, step1)
        );

        FileException exception = assertThrows(FileException.class, () -> ScenarioResultToXlsx.generateXlsx(runId, runDetail));

        assertTrue(exception.getMessage().contains("Ошибка при генерации XLSX-файла"));
    }

    @Test
    void testFormatValue_null_returnsEmptyString() throws Exception {
        assertEquals("", invokeFormatValue(null));
    }

    @Test
    void testFormatValue_string_returnsSameString() throws Exception {
        assertEquals("hello", invokeFormatValue("hello"));
        assertEquals("", invokeFormatValue(""));
        assertEquals("  spaces  ", invokeFormatValue("  spaces  "));
    }

    @Test
    void testFormatValue_boolean_returnsToString() throws Exception {
        assertEquals("true", invokeFormatValue(true));
        assertEquals("false", invokeFormatValue(false));
    }

    @Test
    void testFormatValue_number_returnsToString() throws Exception {
        assertEquals("42", invokeFormatValue(42));
        assertEquals("3.14", invokeFormatValue(3.14));
        assertEquals("0", invokeFormatValue(0));
        assertEquals("-1", invokeFormatValue(-1));
    }

    @Test
    void testFormatValue_list_returnsPrettyJson() throws Exception {
        var list = List.of("a", "b", "c");
        String result = invokeFormatValue(list);
        assertTrue(result.contains("\"a\""));
        assertTrue(result.contains("\"b\""));
        assertTrue(result.contains("\"c\""));
    }

    @Test
    void testFormatValue_map_returnsPrettyJson() throws Exception {
        var map = Map.of("key1", "value1", "key2", 42);
        String result = invokeFormatValue(map);
        assertTrue(result.contains("\"key1\""));
        assertTrue(result.contains("\"value1\""));
        assertTrue(result.contains("\"key2\""));
    }

    @Test
    void testFormatValue_nestedList_returnsPrettyJson() throws Exception {
        var nested = List.of(Map.of("id", 1, "name", "Alice"), Map.of("id", 2, "name", "Bob"));
        String result = invokeFormatValue(nested);
        assertTrue(result.contains("Alice"));
        assertTrue(result.contains("Bob"));
    }

    @Test
    void testFormatValue_customObject_returnsToString() throws Exception {
        Object custom = new Object() {
            @Override
            public String toString() {
                return "customValue";
            }
        };
        assertEquals("customValue", invokeFormatValue(custom));
    }

    // ----- Тесты для parseJsonToList (через рефлексию) -----

    @Test
    void testParseJsonToList_jsonArray_returnsList() throws Exception {
        String json = "[{\"name\": \"John\"}, {\"name\": \"Jane\"}]";
        List<Map<String, Object>> result = invokeParseJsonToList(json);
        assertEquals(2, result.size());
        assertEquals("John", result.get(0).get("name"));
        assertEquals("Jane", result.get(1).get("name"));
    }

    @Test
    void testParseJsonToList_singleObject_returnsSingletonList() throws Exception {
        String json = "{\"name\": \"John\", \"age\": 30}";
        List<Map<String, Object>> result = invokeParseJsonToList(json);
        assertEquals(1, result.size());
        assertEquals("John", result.get(0).get("name"));
        assertEquals(30, result.get(0).get("age"));
    }

    @Test
    void testParseJsonToList_emptyArray_returnsEmptyList() throws Exception {
        String json = "[]";
        List<Map<String, Object>> result = invokeParseJsonToList(json);
        assertTrue(result.isEmpty());
    }

    @Test
    void testParseJsonToList_emptyObject_returnsSingletonList() throws Exception {
        String json = "{}";
        List<Map<String, Object>> result = invokeParseJsonToList(json);
        assertEquals(1, result.size());
        assertTrue(result.get(0).isEmpty());
    }

    @Test
    @SuppressWarnings("unchecked")
    void testParseJsonToList_withNestedObjects() throws Exception {
        String json = "[{\"user\": {\"name\": \"Alice\", \"age\": 25}}]";
        List<Map<String, Object>> result = invokeParseJsonToList(json);
        assertEquals(1, result.size());
        Map<String, Object> nestedUser = (Map<String, Object>) result.get(0).get("user");
        assertEquals("Alice", nestedUser.get("name"));
        assertEquals(25, nestedUser.get("age"));
    }

    @Test
    @SuppressWarnings("unchecked")
    void testParseJsonToList_withArrayOfPrimitives() throws Exception {
        String json = "[{\"values\": [1, 2, 3]}]";
        List<Map<String, Object>> result = invokeParseJsonToList(json);
        assertEquals(1, result.size());
        List<Integer> values = (List<Integer>) result.get(0).get("values");
        assertEquals(List.of(1, 2, 3), values);
    }

    @ParameterizedTest
    @ValueSource(strings = {"[{invalid}", "{invalid}", "just plain text"})
    void testParseJsonToList_invalidJson_throwsFileException(String json) {
        FileException exception = assertThrows(FileException.class, () -> invokeParseJsonToList(json));
        assertEquals("Неверный формат JSON: ожидается объект или массив", exception.getMessage());
    }

    @Test
    void testGenerateXlsx_withInvalidJsonInResult_throwsFileException() {
        UUID runId = UUID.randomUUID();
        OffsetDateTime now = OffsetDateTime.now();
        ScenarioRunStepResponse step1 = new ScenarioRunStepResponse(
                UUID.randomUUID(),
                "node1",
                "input",
                "completed",
                new ScenarioRunStepInputDataResponse("", "input data"),
                new ScenarioRunStepOutputDataResponse("not a json at all", null),
                "prompt",
                100,
                now,
                now
        );

        ScenarioRunDetailResponse runDetail = new ScenarioRunDetailResponse(
                runId,
                UUID.randomUUID(),
                "completed",
                List.of(),
                "Final result",
                now,
                now,
                List.of(step1, step1)
        );

        FileException exception = assertThrows(FileException.class, () -> ScenarioResultToXlsx.generateXlsx(runId, runDetail));

        assertTrue(exception.getMessage().contains("Ошибка при генерации XLSX-файла"));
    }
}
