package ru.sber.cs.ai.gigame.exception;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

class ScenarioExceptionTest {

    @Test
    void testScenarioException_withMessage() {
        ScenarioException ex = new ScenarioException("Scenario error");

        assertEquals("Scenario error", ex.getMessage());
        assertEquals(400, ex.getStatusCode());
        assertNull(ex.getDetails());
    }

    @Test
    void testScenarioException_withCause() {
        Exception cause = new Exception("Inner error");
        ScenarioException ex = new ScenarioException("Scenario error", cause);

        assertEquals("Scenario error", ex.getMessage());
        assertEquals(400, ex.getStatusCode());
        assertEquals(cause, ex.getCause());
    }
}
