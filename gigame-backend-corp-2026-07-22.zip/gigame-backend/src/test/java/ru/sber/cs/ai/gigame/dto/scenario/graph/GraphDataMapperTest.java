package ru.sber.cs.ai.gigame.dto.scenario.graph;

import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.Map;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

class GraphDataMapperTest {

    // ------------------ toDto (Map -> DTO) ------------------

    @Test
    void testToDto_withFullGraph() {
        var node = Map.of(
                "id", "n1",
                "type", "input",
                "data", Map.of(
                        "label", "Test Node",
                        "prompt", "Prompt text",
                        "mode", "all"
                ),
                "position", Map.of("x", 100, "y", 200)
        );
        var edge = Map.of(
                "id", "e1",
                "source", "n1",
                "target", "n2",
                "data", Map.of("label", "edge-label")
        );

        var graphData = Map.<String, Object>of(
                "nodes", List.of(node),
                "edges", List.of(edge)
        );

        var dto = GraphDataMapper.toDto(graphData);

        assertNotNull(dto);
        assertEquals(1, dto.nodes().size());
        assertEquals(1, dto.edges().size());

        var n = dto.nodes().get(0);
        assertEquals("n1", n.id());
        assertEquals("input", n.type());
        assertEquals("Test Node", n.data().label());
        assertEquals("Prompt text", n.data().prompt());
        assertEquals("all", n.data().mode());
        assertEquals(Integer.valueOf(100), n.position().x());
        assertEquals(Integer.valueOf(200), n.position().y());

        var e = dto.edges().get(0);
        assertEquals("e1", e.id());
        assertEquals("n1", e.source());
        assertEquals("n2", e.target());
        assertEquals("edge-label", e.data().label());
    }

    @Test
    void testToDto_withNullInput() {
        var dto = GraphDataMapper.toDto(null);
        assertNotNull(dto);
        assertTrue(dto.nodes().isEmpty());
        assertTrue(dto.edges().isEmpty());
    }

    @Test
    void testToDto_withEmptyGraph() {
        var dto = GraphDataMapper.toDto(Map.of());
        assertNotNull(dto);
        assertTrue(dto.nodes().isEmpty());
        assertTrue(dto.edges().isEmpty());
    }

    @Test
    void testToDto_withMissingKeys() {
        var graphData = Map.<String, Object>of(
                "nodes", List.of(Map.of("id", "n1", "type", "input"))
        );
        var dto = GraphDataMapper.toDto(graphData);

        assertEquals(1, dto.nodes().size());
        assertEquals("n1", dto.nodes().get(0).id());
        assertEquals("input", dto.nodes().get(0).type());
        assertNull(dto.nodes().get(0).data().label());
    }

    @Test
    void testToDto_withAllNodeDataFields() {
        var data = Map.of(
                "label", "Label",
                "prompt", "Prompt",
                "classes", "classes",
                "rules", "[{\"key\": \"val\"}]",
                "classify_strict", "true",
                "mode", "all",
                "field", "field",
                "operator", "contains",
                "value", "value",
                "knowledge_base_id", UUID.randomUUID().toString()
        );
        var node = Map.of(
                "id", "n1",
                "type", "processing",
                "data", data
        );
        var graphData = Map.<String, Object>of("nodes", List.of(node));
        var dto = GraphDataMapper.toDto(graphData);

        var n = dto.nodes().get(0);
        assertEquals("Label", n.data().label());
        assertEquals("Prompt", n.data().prompt());
        assertEquals("classes", n.data().classes());
        assertEquals("[{\"key\": \"val\"}]", n.data().rules());
        assertEquals("true", n.data().classifyStrict());
        assertEquals("all", n.data().mode());
        assertEquals("field", n.data().field());
        assertEquals("contains", n.data().operator());
        assertEquals("value", n.data().value());
        assertNotNull(n.data().knowledgeBaseId());
    }

    @Test
    void testToDto_withIntegerPositionValues() {
        var node = Map.of(
                "id", "n1",
                "type", "input",
                "position", Map.of("x", 100, "y", 200)
        );
        var graphData = Map.<String, Object>of("nodes", List.of(node));
        var dto = GraphDataMapper.toDto(graphData);

        assertEquals(Integer.valueOf(100), dto.nodes().get(0).position().x());
        assertEquals(Integer.valueOf(200), dto.nodes().get(0).position().y());
    }

    @Test
    void testToDto_withStringPositionValues() {
        var node = Map.of(
                "id", "n1",
                "type", "input",
                "position", Map.of("x", 100, "y", 200)
        );
        var graphData = Map.<String, Object>of("nodes", List.of(node));
        var dto = GraphDataMapper.toDto(graphData);

        assertEquals(100, dto.nodes().get(0).position().x());
        assertEquals(200, dto.nodes().get(0).position().y());
    }

    // ------------------ fromDto (DTO -> Map) ------------------

    @Test
    void testFromDto_withFullGraph() {
        var node = new NodeDto(
                "n1", "input",
                new NodeDataDto("Label", "Prompt", null, null, null, null, null, null, null, null, null, null, null),
                new PositionDto(100, 200),
                null
        );
        var edge = new EdgeDto("e1", "n1", "n2", new EdgeDataDto("edge-label"));
        var graphDto = new GraphDataDto(List.of(node), List.of(edge));

        var result = GraphDataMapper.fromDto(graphDto);

        assertNotNull(result);
        assertTrue(result.containsKey("nodes"));
        assertTrue(result.containsKey("edges"));

        @SuppressWarnings("unchecked")
        var nodes = (List<Map<String, Object>>) result.get("nodes");
        assertEquals(1, nodes.size());
        assertEquals("n1", nodes.get(0).get("id"));
        assertEquals("input", nodes.get(0).get("type"));

        @SuppressWarnings("unchecked")
        var edges = (List<Map<String, Object>>) result.get("edges");
        assertEquals(1, edges.size());
        assertEquals("e1", edges.get(0).get("id"));
        assertEquals("n1", edges.get(0).get("source"));
        assertEquals("n2", edges.get(0).get("target"));
    }

    @Test
    void testFromDto_withNullInput() {
        var result = GraphDataMapper.fromDto(null);
        assertTrue(result.isEmpty());
    }

    @Test
    void testFromDto_withNullNodes() {
        var graphDto = new GraphDataDto(null, null);
        var result = GraphDataMapper.fromDto(graphDto);

        assertNotNull(result.get("nodes"));
        assertNotNull(result.get("edges"));
    }

    @Test
    void testRoundTrip() {
        var originalNode = new NodeDto(
                "n1", "processing",
                new NodeDataDto("Label", "Prompt", "classes", "rules", "true", "all", "field", "contains", "value", null, null, null, null),
                new PositionDto(100, 200),
                new MeasuredDto(300, 150)
        );
        var originalEdge = new EdgeDto("e1", "n1", "n2", new EdgeDataDto("edge-label"));
        var original = new GraphDataDto(List.of(originalNode), List.of(originalEdge));

        var map = GraphDataMapper.fromDto(original);
        var restored = GraphDataMapper.toDto(map);

        assertEquals(1, restored.nodes().size());
        assertEquals(1, restored.edges().size());

        var rn = restored.nodes().get(0);
        assertEquals("n1", rn.id());
        assertEquals("processing", rn.type());
        assertEquals("Label", rn.data().label());
        assertEquals("Prompt", rn.data().prompt());
        assertEquals("classes", rn.data().classes());
        assertEquals("rules", rn.data().rules());
        assertEquals("true", rn.data().classifyStrict());
        assertEquals("all", rn.data().mode());
        assertEquals("field", rn.data().field());
        assertEquals("contains", rn.data().operator());
        assertEquals("value", rn.data().value());
        assertEquals(Integer.valueOf(100), rn.position().x());
        assertEquals(Integer.valueOf(200), rn.position().y());
        assertEquals(Integer.valueOf(300), rn.measured().width());
        assertEquals(Integer.valueOf(150), rn.measured().height());

        var re = restored.edges().get(0);
        assertEquals("e1", re.id());
        assertEquals("n1", re.source());
        assertEquals("n2", re.target());
        assertEquals("edge-label", re.data().label());
    }
}