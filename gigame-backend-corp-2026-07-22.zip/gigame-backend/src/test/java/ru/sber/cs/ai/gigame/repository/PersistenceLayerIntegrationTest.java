package ru.sber.cs.ai.gigame.repository;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.context.annotation.Import;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.jdbc.Sql;
import ru.sber.cs.ai.gigame.config.TestDataSourceConfig;
import ru.sber.cs.ai.gigame.model.Conversation;
import ru.sber.cs.ai.gigame.model.Document;
import ru.sber.cs.ai.gigame.model.Embedding;
import ru.sber.cs.ai.gigame.model.KBDocument;
import ru.sber.cs.ai.gigame.model.KnowledgeBase;
import ru.sber.cs.ai.gigame.model.Message;
import ru.sber.cs.ai.gigame.model.Scenario;
import ru.sber.cs.ai.gigame.model.ScenarioRun;
import ru.sber.cs.ai.gigame.model.ScenarioRunStep;

import jakarta.persistence.EntityManager;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Integration test that verifies the entire persistence layer with actual database.
 */
@DataJpaTest
@TestPropertySource(properties = {
        "spring.liquibase.enabled=false",
        "spring.jpa.hibernate.ddl-auto=create-drop"
}, locations = "classpath:test-application.yaml")
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
@Import(TestDataSourceConfig.class)
@Sql(scripts = "classpath:db/test-schema.sql")
class PersistenceLayerIntegrationTest {

    @Autowired
    private ConversationRepository conversationRepository;

    @Autowired
    private MessageRepository messageRepository;

    @Autowired
    private DocumentRepository documentRepository;

    @Autowired
    private KnowledgeBaseRepository knowledgeBaseRepository;

    @Autowired
    private KBDocumentRepository kbDocumentRepository;

    @Autowired
    private EmbeddingRepository embeddingRepository;

    @Autowired
    private ScenarioRepository scenarioRepository;

    @Autowired
    private ScenarioRunRepository scenarioRunRepository;

    @Autowired
    private ScenarioRunStepRepository scenarioRunStepRepository;

    @Autowired
    private EntityManager entityManager;

    private String userId;

    @BeforeEach
    void setUp() {
        userId = "testUser";
    }

    @Test
    void testFullConversationFlow() {
        // Create conversation
        Conversation conversation = new Conversation();
        conversation.setTitle("Integration Test Conversation");
        conversation.setUserId(userId);
        conversation = conversationRepository.save(conversation);
        assertNotNull(conversation.getId());

        // Create messages
        Message userMessage = new Message();
        userMessage.setConversation(conversation);
        userMessage.setRole("user");
        userMessage.setContent("Hello");
        userMessage = messageRepository.save(userMessage);
        assertNotNull(userMessage.getId());

        Message assistantMessage = new Message();
        assistantMessage.setConversation(conversation);
        assistantMessage.setRole("assistant");
        assistantMessage.setContent("Hi there");
        assistantMessage = messageRepository.save(assistantMessage);
        assertNotNull(assistantMessage.getId());

        // Retrieve conversation with messages
        Conversation found = conversationRepository.findById(conversation.getId()).orElse(null);
        assertNotNull(found);

        List<Message> messages = messageRepository.findByConversationIdOrderByCreatedAtAsc(found.getId());
        assertEquals(2, messages.size());
    }

    @Test
    void testDocumentFlow() {
        // Create document
        Document document = new Document();
        document.setFilename("test-document.pdf");
        document.setContentType("pdf");
        document.setExtractedText("Test document content for integration testing");
        document.setSizeBytes(1024);
        document.setUserId(userId);
        document = documentRepository.save(document);
        assertNotNull(document.getId());

        // Retrieve document
        Document found = documentRepository.findById(document.getId()).orElse(null);
        assertNotNull(found);
        assertEquals("test-document.pdf", found.getFilename());
    }

    @Test
    void testKnowledgeBaseFlow() {
        // Create knowledge base
        KnowledgeBase knowledgeBase = new KnowledgeBase();
        knowledgeBase.setName("Integration Test KB");
        knowledgeBase.setDescription("Test KB for persistence layer");
        knowledgeBase.setUserId(userId);
        knowledgeBase = knowledgeBaseRepository.save(knowledgeBase);
        assertNotNull(knowledgeBase.getId());

        // Create KB document
        KBDocument kbDocument = new KBDocument();
        kbDocument.setKnowledgeBase(knowledgeBase);
        kbDocument.setDocumentId(UUID.randomUUID());
        kbDocument.setStatus("processing");
        kbDocument = kbDocumentRepository.save(kbDocument);
        assertNotNull(kbDocument.getId());

        // Retrieve KB with documents
        KnowledgeBase found = knowledgeBaseRepository.findById(knowledgeBase.getId()).orElse(null);
        assertNotNull(found);
    }

    @Test
    void testEmbeddingFlow() {
        UUID docId = UUID.randomUUID();

        // Create embeddings
        Embedding embedding1 = new Embedding();
        embedding1.setCollectionType("doc");
        embedding1.setCollectionId(docId);
        embedding1.setSourceDocumentId(docId);
        embedding1.setChunkIndex(0);
        embedding1.setChunkText("Test chunk 1");
        embedding1.setVector(new float[10]);
        embedding1 = embeddingRepository.save(embedding1);
        assertNotNull(embedding1.getId());

        Embedding embedding2 = new Embedding();
        embedding2.setCollectionType("doc");
        embedding2.setCollectionId(docId);
        embedding2.setSourceDocumentId(docId);
        embedding2.setChunkIndex(1);
        embedding2.setChunkText("Test chunk 2");
        embedding2.setVector(new float[10]);
        embedding2 = embeddingRepository.save(embedding2);
        assertNotNull(embedding2.getId());

        // Retrieve embeddings
        List<Embedding> embeddings = embeddingRepository.findAll();
        assertEquals(2, embeddings.size());
    }

    @Test
    void testScenarioFlow() {
        // Create scenario
        Scenario scenario = new Scenario();
        scenario.setName("Integration Test Scenario");
        scenario.setDescription("Test scenario for persistence layer");
        scenario.setUserId(userId);
        scenario.setGraphData(Map.of("nodes", List.of(), "edges", List.of()));
        scenario = scenarioRepository.save(scenario);
        assertNotNull(scenario.getId());

        // Create scenario run
        ScenarioRun run = new ScenarioRun();
        run.setScenarioId(scenario.getId());
        run.setStatus("pending");
        run.setStartedAt(java.time.OffsetDateTime.now());
        run = scenarioRunRepository.save(run);
        assertNotNull(run.getId());

        // Create scenario run step
        ScenarioRunStep step = new ScenarioRunStep();
        step.setRunId(run.getId());
        step.setNodeId("node1");
        step.setNodeType("input");
        step.setStatus("pending");
        step = scenarioRunStepRepository.save(step);
        assertNotNull(step.getId());

        // Retrieve scenario with runs
        Scenario found = scenarioRepository.findById(scenario.getId()).orElse(null);
        assertNotNull(found);
    }

    @Test
    void testCascadeDeleteConversation() {
        // Create conversation with message
        Conversation conversation = new Conversation();
        conversation.setTitle("To Delete");
        conversation.setUserId(userId);

        Message message = new Message();
        message.setConversation(conversation);
        message.setRole("user");
        message.setContent("Message to delete");
        conversation.getMessages().add(message);

        conversation = conversationRepository.save(conversation);
        assertTrue(conversationRepository.findById(conversation.getId()).isPresent());

        // Delete conversation (CascadeType.ALL will cascade delete messages)
        conversationRepository.delete(conversation);
        entityManager.flush();
        entityManager.clear();

        // Verify message is cascade deleted
        assertFalse(messageRepository.findById(message.getId()).isPresent());
    }

    @Test
    void testCascadeDeleteKnowledgeBase() {
        // Create KB with KBDocument
        KnowledgeBase knowledgeBase = new KnowledgeBase();
        knowledgeBase.setName("To Delete");
        knowledgeBase.setUserId(userId);
        knowledgeBase = knowledgeBaseRepository.save(knowledgeBase);

        // Create a Document first (FK constraint on kb_documents.document_id)
        Document document = new Document();
        document.setFilename("test-doc.pdf");
        document.setContentType("pdf");
        document.setExtractedText("Test content");
        document.setSizeBytes(100);
        document.setUserId(userId);
        document = documentRepository.save(document);

        KBDocument kbDocument = new KBDocument();
        kbDocument.setKnowledgeBase(knowledgeBase);
        kbDocument.setDocument(document);
        kbDocument.setStatus("processing");
        kbDocument = kbDocumentRepository.save(kbDocument);
        assertTrue(kbDocumentRepository.findById(kbDocument.getId()).isPresent());

        // Flush and clear to detach all entities
        entityManager.flush();
        entityManager.clear();

        // Re-attach knowledgeBase for deletion
        knowledgeBase = knowledgeBaseRepository.findById(knowledgeBase.getId()).orElse(null);
        assertNotNull(knowledgeBase);

        // Delete knowledge base (orphanRemoval will cascade delete KBDocument)
        knowledgeBaseRepository.delete(knowledgeBase);
        entityManager.flush();
        entityManager.clear();

        // Verify KBDocument is cascade deleted
        assertFalse(kbDocumentRepository.findById(kbDocument.getId()).isPresent());
    }
}
