package ru.sber.cs.ai.gigame.dto.scenario.graph;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;

class GraphDataDtoTest {

    @Test
    void testConstruction_withNodesAndEdges() {
        var node = new NodeDto("n1", "input", null, null, null);
        var edge = new EdgeDto("e1", "n1", "n2", null);

        var dto = new GraphDataDto(
                java.util.List.of(node),
                java.util.List.of(edge)
        );

        assertNotNull(dto);
        assertEquals(1, dto.nodes().size());
        assertEquals(1, dto.edges().size());
        assertEquals("n1", dto.nodes().get(0).id());
        assertEquals("e1", dto.edges().get(0).id());
    }

    @Test
    void testConstruction_withEmptyLists() {
        var dto = new GraphDataDto(java.util.List.of(), java.util.List.of());
        assertNotNull(dto);
        assertEquals(0, dto.nodes().size());
        assertEquals(0, dto.edges().size());
    }

    @Test
    void testConstruction_withNullLists() {
        var dto = new GraphDataDto(null, null);
        assertNull(dto.nodes());
        assertNull(dto.edges());
    }
}