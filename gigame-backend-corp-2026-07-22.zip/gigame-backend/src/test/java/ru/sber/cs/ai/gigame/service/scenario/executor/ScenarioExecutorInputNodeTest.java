package ru.sber.cs.ai.gigame.service.scenario.executor;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import ru.sber.cs.ai.gigame.dto.scenario.graph.GraphDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.PositionDto;
import ru.sber.cs.ai.gigame.service.scenario.enums.ScenarioNodeType;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunDoc;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunGraph;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunNode;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

class ScenarioExecutorInputNodeTest {

    private ScenarioRunGraph structure;
    private ScenarioRunNode node;

    @BeforeEach
    void setUp() {
        NodeDto dto = NodeDto.builder()
                .id("input-1")
                .type(ScenarioNodeType.INPUT_NODE.toString())
                .data(NodeDataDto.builder().label("Input").build())
                .position(new PositionDto(100, 100))
                .build();

        GraphDataDto graphData = new GraphDataDto(
                List.of(dto),
                List.of()
        );
        structure = new ScenarioRunGraph(graphData);
        node = structure.getNodeMap().get("input-1");
    }

    // ----------------------------------------------------------------
    // Basic execution
    // ----------------------------------------------------------------

    @Test
    void testExecute_whenNoDocs_returnsEmptyString() {
        ScenarioExecutorInputNode executor = new ScenarioExecutorInputNode(node);

        String result = executor.execute(null);

        assertNotNull(result);
        assertEquals("", result);
    }

    @Test
    void testExecute_whenSingleDoc_returnsFormattedDocText() {
        structure.getDocMap().put("DOC_1", new ScenarioRunDoc("test.txt", "Hello world"));

        ScenarioExecutorInputNode executor = new ScenarioExecutorInputNode(node);

        String result = executor.execute(null);

        assertNotNull(result);
        assertTrue(result.contains("<<<DOC_1>>>"));
        assertTrue(result.contains("Hello world"));
        assertTrue(result.contains("<<<END_DOC_1>>>"));
    }

    @Test
    void testExecute_whenMultipleDocs_returnsAllFormattedDocs() {
        structure.getDocMap().put("DOC_1", new ScenarioRunDoc("a.txt", "Content A"));
        structure.getDocMap().put("DOC_2", new ScenarioRunDoc("b.txt", "Content B"));

        ScenarioExecutorInputNode executor = new ScenarioExecutorInputNode(node);

        String result = executor.execute(null);

        assertNotNull(result);
        assertTrue(result.contains("<<<DOC_1>>>"));
        assertTrue(result.contains("Content A"));
        assertTrue(result.contains("<<<END_DOC_1>>>"));
        assertTrue(result.contains("<<<DOC_2>>>"));
        assertTrue(result.contains("Content B"));
        assertTrue(result.contains("<<<END_DOC_2>>>"));
    }

    @Test
    void testExecute_docsAreJoinedByDoubleNewline() {
        structure.getDocMap().put("DOC_1", new ScenarioRunDoc("a.txt", "A"));
        structure.getDocMap().put("DOC_2", new ScenarioRunDoc("b.txt", "B"));

        ScenarioExecutorInputNode executor = new ScenarioExecutorInputNode(node);

        String result = executor.execute(null);

        // Both doc blocks are present, separated by double newline
        assertTrue(result.contains("<<<DOC_1>>>\nA\n<<<END_DOC_1>>>"));
        assertTrue(result.contains("<<<DOC_2>>>\nB\n<<<END_DOC_2>>>"));
        // There should be a double newline between the two doc blocks
        long docCount = result.split("<<<END_DOC_").length - 1;
        assertEquals(2, docCount);
    }

    @Test
    void testExecute_docsAreSeparatedBySingleNewlineWithinDoc() {
        structure.getDocMap().put("DOC_1", new ScenarioRunDoc("a.txt", "A"));
        structure.getDocMap().put("DOC_2", new ScenarioRunDoc("b.txt", "B"));

        ScenarioExecutorInputNode executor = new ScenarioExecutorInputNode(node);

        String result = executor.execute(null);

        assertTrue(result.contains("<<<DOC_1>>>\nA\n<<<END_DOC_1>>>"));
        assertTrue(result.contains("<<<DOC_2>>>\nB\n<<<END_DOC_2>>>"));
    }

    // ----------------------------------------------------------------
    // Document propagation to child nodes
    // ----------------------------------------------------------------

    @Test
    void testExecute_propagatesDocIdsToChildNodes() {
        NodeDto childDto = NodeDto.builder()
                .id("child-1")
                .type(ScenarioNodeType.INPUT_NODE.toString())
                .data(NodeDataDto.builder().label("Child").build())
                .position(new PositionDto(200, 100))
                .build();
        ScenarioRunNode childNode = ScenarioRunNode.fromDto(1, childDto, structure);
        node.getChildNodeList().add(childNode);

        structure.getDocMap().put("DOC_1", new ScenarioRunDoc("a.txt", "Content A"));

        ScenarioExecutorInputNode executor = new ScenarioExecutorInputNode(node);

        executor.execute(null);

        assertTrue(childNode.getDocList().contains("DOC_1"));
    }

    @Test
    void testExecute_propagatesAllDocIdsToAllChildren() {
        NodeDto child1Dto = NodeDto.builder()
                .id("child-1")
                .type(ScenarioNodeType.INPUT_NODE.toString())
                .data(NodeDataDto.builder().label("Child1").build())
                .position(new PositionDto(200, 100))
                .build();
        NodeDto child2Dto = NodeDto.builder()
                .id("child-2")
                .type(ScenarioNodeType.INPUT_NODE.toString())
                .data(NodeDataDto.builder().label("Child2").build())
                .position(new PositionDto(200, 200))
                .build();
        ScenarioRunNode child1 = ScenarioRunNode.fromDto(1, child1Dto, structure);
        ScenarioRunNode child2 = ScenarioRunNode.fromDto(2, child2Dto, structure);

        node.getChildNodeList().add(child1);
        node.getChildNodeList().add(child2);

        structure.getDocMap().put("DOC_1", new ScenarioRunDoc("a.txt", "A"));
        structure.getDocMap().put("DOC_2", new ScenarioRunDoc("b.txt", "B"));

        ScenarioExecutorInputNode executor = new ScenarioExecutorInputNode(node);

        executor.execute(null);

        assertTrue(child1.getDocList().containsAll(List.of("DOC_1", "DOC_2")));
        assertTrue(child2.getDocList().containsAll(List.of("DOC_1", "DOC_2")));
    }

    @Test
    void testExecute_whenNoChildren_noExceptionThrown() {
        structure.getDocMap().put("DOC_1", new ScenarioRunDoc("a.txt", "A"));

        ScenarioExecutorInputNode executor = new ScenarioExecutorInputNode(node);

        // should not throw even though there are no children
        String result = executor.execute(null);

        assertNotNull(result);
        assertTrue(result.contains("DOC_1"));
    }

    @Test
    void testExecute_whenNoDocs_doesNotPropagateAnything() {
        NodeDto childDto = NodeDto.builder()
                .id("child-1")
                .type(ScenarioNodeType.INPUT_NODE.toString())
                .data(NodeDataDto.builder().label("Child").build())
                .position(new PositionDto(200, 100))
                .build();
        ScenarioRunNode childNode = ScenarioRunNode.fromDto(1, childDto, structure);
        node.getChildNodeList().add(childNode);

        ScenarioExecutorInputNode executor = new ScenarioExecutorInputNode(node);

        executor.execute(null);

        assertTrue(childNode.getDocList().isEmpty());
    }

    // ----------------------------------------------------------------
    // Edge cases
    // ----------------------------------------------------------------

    @Test
    void testExecute_docWithNoText_returnsEmptyTagContent() {
        structure.getDocMap().put("DOC_1", new ScenarioRunDoc("empty.txt", ""));

        ScenarioExecutorInputNode executor = new ScenarioExecutorInputNode(node);

        String result = executor.execute(null);

        assertTrue(result.contains("<<<DOC_1>>>"));
        assertTrue(result.contains("<<<END_DOC_1>>>"));
    }

    @Test
    void testExecute_docWithMultilineText() {
        String multiline = "Line 1\nLine 2\nLine 3";
        structure.getDocMap().put("DOC_1", new ScenarioRunDoc("multi.txt", multiline));

        ScenarioExecutorInputNode executor = new ScenarioExecutorInputNode(node);

        String result = executor.execute(null);

        assertTrue(result.contains("<<<DOC_1>>>\nLine 1\nLine 2\nLine 3\n<<<END_DOC_1>>>"));
    }

    @Test
    void testExecute_doesNotModifyNodeDocList() {
        structure.getDocMap().put("DOC_1", new ScenarioRunDoc("a.txt", "A"));

        ScenarioExecutorInputNode executor = new ScenarioExecutorInputNode(node);

        executor.execute(null);

        // node's own docList should remain empty (only child docs are modified)
        assertTrue(node.getDocList().isEmpty());
    }
}