package ru.sber.cs.ai.gigame.dto.kb;

import org.junit.jupiter.api.Test;

import java.time.OffsetDateTime;
import java.util.List;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

class KBDetailResponseTest {

    @Test
    void testConstruction_withAllFields() {
        var id = UUID.randomUUID();
        var now = OffsetDateTime.now();
        var doc = new KBDocumentResponse(UUID.randomUUID(), UUID.randomUUID(), "doc.pdf",
                "application/pdf", 1024, 5, "ready", null, now);
        var dto = new KBDetailResponse(id, "KB Name", "Description", true, true, now, now, List.of(doc));
        assertEquals(id, dto.id());
        assertEquals("KB Name", dto.name());
        assertEquals("Description", dto.description());
        assertTrue(dto.shared());
        assertTrue(dto.isOwner());
        assertEquals(now, dto.createdAt());
        assertEquals(now, dto.updatedAt());
        assertEquals(1, dto.documents().size());
        assertEquals("doc.pdf", dto.documents().get(0).filename());
    }

    @Test
    void testConstruction_withNullFields() {
        var dto = new KBDetailResponse(null, null, null, false, false, null, null, null);
        assertNull(dto.id());
        assertNull(dto.name());
        assertNull(dto.description());
        assertFalse(dto.shared());
        assertFalse(dto.isOwner());
        assertNull(dto.createdAt());
        assertNull(dto.updatedAt());
        assertNull(dto.documents());
    }

    @Test
    void testConstruction_withEmptyDocuments() {
        var dto = new KBDetailResponse(null, null, null, false, false, null, null, List.of());
        assertTrue(dto.documents().isEmpty());
    }
}
