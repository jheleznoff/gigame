package ru.sber.cs.ai.gigame.model;

import org.junit.jupiter.api.Test;

import java.time.OffsetDateTime;
import java.util.List;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

class MessageTest {

    @Test
    void testMessageDefaultValues() {
        Message message = new Message();
        assertNull(message.getId());
        assertNull(message.getConversation());
        assertNull(message.getRole());
        assertNull(message.getContent());
        assertNull(message.getDocumentIds());
        assertNull(message.getCreatedAt());
    }

    @Test
    void testMessageWithAllFields() {
        OffsetDateTime createdAt = OffsetDateTime.now();
        List<String> docIds = List.of(UUID.randomUUID().toString(), UUID.randomUUID().toString());
        var conversation = new Conversation();
        Message message = new Message();
        message.setId(UUID.randomUUID());
        message.setConversation(conversation);
        message.setRole("user");
        message.setContent("Hello, world!");
        message.setDocumentIds(docIds);
        message.setCreatedAt(createdAt);

        assertEquals(conversation.getId(), message.getConversation().getId());
        assertEquals("user", message.getRole());
        assertEquals("Hello, world!", message.getContent());
        assertEquals(docIds, message.getDocumentIds());
        assertEquals(createdAt, message.getCreatedAt());
    }

    @Test
    void testMessageWithEmptyDocumentIds() {
        Message message = new Message();
        message.setDocumentIds(List.of());

        assertTrue(message.getDocumentIds().isEmpty());
    }

    @Test
    void testMessageWithNullDocumentIds() {
        Message message = new Message();
        message.setDocumentIds(null);

        assertNull(message.getDocumentIds());
    }

    @Test
    void testMessageWithAssistantRole() {
        Message message = new Message();
        message.setRole("assistant");
        message.setContent("This is a response");

        assertEquals("assistant", message.getRole());
    }

    @Test
    void testToString() {
        Message message = new Message();
        String str = message.toString();
        assertNotNull(str);
        assertTrue(str.contains("Message"));
    }
}
