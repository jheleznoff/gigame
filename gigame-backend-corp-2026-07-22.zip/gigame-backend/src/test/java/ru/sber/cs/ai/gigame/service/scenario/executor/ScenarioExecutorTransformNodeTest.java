package ru.sber.cs.ai.gigame.service.scenario.executor;

import org.junit.jupiter.api.Test;
import org.springframework.http.codec.ServerSentEvent;
import reactor.core.publisher.FluxSink;
import ru.sber.cs.ai.gigame.dto.scenario.graph.GraphDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.PositionDto;
import ru.sber.cs.ai.gigame.exception.ScenarioException;
import ru.sber.cs.ai.gigame.service.scenario.enums.ScenarioNodeType;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunDoc;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunGraph;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunNode;

import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.mock;

/**
 * Тесты всех операций узла «Трансформация».
 */
class ScenarioExecutorTransformNodeTest {

    @SuppressWarnings("unchecked")
    private final FluxSink<ServerSentEvent<Map<String, Object>>> sink = mock(FluxSink.class);

    // ---------------------------------------------------------------
    // Helper — строит одноузловой граф с правилами
    // ---------------------------------------------------------------

    private static ScenarioRunNode node(String rules, String... inputs) {
        var dto = NodeDto.builder()
                .id("t1")
                .type(ScenarioNodeType.TRANSFORM_NODE.toString())
                .data(NodeDataDto.builder()
                        .label("Трансформ")
                        .rules(rules)
                        .build())
                .position(new PositionDto(0, 0))
                .build();
        var graph = new ScenarioRunGraph(new GraphDataDto(List.of(dto), List.of()));
        var node = graph.getNodeMap().get("t1");
        for (String in : inputs) {
            node.getInput().add(in);
        }
        return node;
    }

    @Test
    void testExtractRegex_regular() {
        var node = node("{\"операции\": [{\"оп\": \"извлечь_regex\", \"шаблон\": \"\\\\d+\"}]}",
                "Номер: 12345, Номер: 67890");
        var exec = new ScenarioExecutorTransformNode(node);
        String result = exec.execute(sink);

        // default: все=true, разделитель=\n
        assertEquals("12345\n67890", result.trim());
    }

    @Test
    void testExtractRegex_withGroup() {
        var node = node("{\"операции\": [{\"оп\": \"извлечь_regex\", \"шаблон\": \"№ (\\\\d+)\", \"группа\": 1}]}",
                "№ 777, № 888");
        var exec = new ScenarioExecutorTransformNode(node);
        String result = exec.execute(sink);

        assertEquals("777\n888", result.trim());
    }

    @Test
    void testExtractRegex_allFalse_onlyFirst() {
        var node = node("{\"операции\": [{\"оп\": \"извлечь_regex\", \"шаблон\": \"\\\\d+\", \"все\": false}]}",
                "a1 b2 c3");
        var exec = new ScenarioExecutorTransformNode(node);
        String result = exec.execute(sink);

        assertEquals("1", result.trim());
    }

    // ---------------------------------------------------------------
    // replace (plain)
    // ---------------------------------------------------------------

    @Test
    void testReplace_plain() {
        var node = node("{\"операции\": [{\"оп\": \"заменить\", \"найти\": \"старое\", \"на\": \"новое\"}]}",
                "старое слово");
        var exec = new ScenarioExecutorTransformNode(node);
        String result = exec.execute(sink);

        assertEquals("новое слово", result.trim());
    }

    @Test
    void testReplace_withRegex() {
        var node = node("{\"операции\": [{\"оп\": \"заменить\", \"найти\": \"\\\\d+\", \"на\": \"ЧИСЛО\", \"regex\": true}]}",
                "abc 123 def");
        var exec = new ScenarioExecutorTransformNode(node);
        String result = exec.execute(sink);

        assertEquals("abc ЧИСЛО def", result.trim());
    }

    @Test
    void testReplace_defaultReplacementIsEmpty() {
        var node = node("{\"операции\": [{\"оп\": \"заменить\", \"найти\": \"лишнее\"}]}",
                "удалить лишнее слово");
        var exec = new ScenarioExecutorTransformNode(node);
        String result = exec.execute(sink);

        assertEquals("удалить  слово", result.trim());
    }

    // ---------------------------------------------------------------
    // filterLines — оставить/удалить строки
    // ---------------------------------------------------------------

    @Test
    void testKeepLines_matching() {
        var node = node("{\"операции\": [{\"оп\": \"оставить_строки\", \"шаблон\": \"ERROR\"}]}",
                "INFO: ok\nERROR: fail\nDEBUG: skip");
        var exec = new ScenarioExecutorTransformNode(node);
        String result = exec.execute(sink);

        assertEquals("ERROR: fail", result.trim());
    }

    @Test
    void testRemoveLines_matching() {
        var node = node("{\"операции\": [{\"оп\": \"удалить_строки\", \"шаблон\": \"\\\\[INFO\\\\]\"}]}",
                "[INFO] start\n[WARN] middle\n[INFO] end");
        var exec = new ScenarioExecutorTransformNode(node);
        String result = exec.execute(sink);

        assertEquals("[WARN] middle", result.trim());
    }

    // ---------------------------------------------------------------
    // jsonField — путь по JSON
    // ---------------------------------------------------------------

    @Test
    void testJsonField_extractsField() {
        var node = node("{\"операции\": [{\"оп\": \"json_поле\", \"путь\": \"name\"}]}",
                "{\"name\": \"Alice\", \"age\": 30}");
        var exec = new ScenarioExecutorTransformNode(node);
        String result = exec.execute(sink);

        assertEquals("Alice", result);
    }

    @Test
    void testJsonField_nestedPath() {
        var node = node("{\"операции\": [{\"оп\": \"json_поле\", \"путь\": \"address.city\"}]}",
                "{\"address\": {\"city\": \"Moscow\"}}");
        var exec = new ScenarioExecutorTransformNode(node);
        String result = exec.execute(sink);

        assertEquals("Moscow", result);
    }

    // ---------------------------------------------------------------
    // substring — взять_символы
    // ---------------------------------------------------------------

    @Test
    void testSubstring_defaultsToFull() {
        var node = node("{\"операции\": [{\"оп\": \"взять_символы\"}]}",
                "Hello World");
        var exec = new ScenarioExecutorTransformNode(node);
        String result = exec.execute(sink);

        assertEquals("Hello World", result);
    }

    @Test
    void testSubstring_range() {
        var node = node("{\"операции\": [{\"оп\": \"взять_символы\", \"от\": 0, \"до\": 5}]}",
                "Hello World");
        var exec = new ScenarioExecutorTransformNode(node);
        String result = exec.execute(sink);

        assertEquals("Hello", result);
    }

    @Test
    void testSubstring_clampsToBounds() {
        var node = node("{\"операции\": [{\"оп\": \"взять_символы\", \"от\": -5, \"до\": 200}]}",
                "Short");
        var exec = new ScenarioExecutorTransformNode(node);
        String result = exec.execute(sink);

        assertEquals("Short", result);
    }

    // ---------------------------------------------------------------
    // headTail — первые/последние строки
    // ---------------------------------------------------------------

    @Test
    void testHead_firstLines() {
        var node = node("{\"операции\": [{\"оп\": \"первые_строки\", \"n\": 2}]}",
                "a\nb\nc\nd");
        var exec = new ScenarioExecutorTransformNode(node);
        String result = exec.execute(sink);

        assertEquals("a\nb", result);
    }

    @Test
    void testTail_lastLines() {
        var node = node("{\"операции\": [{\"оп\": \"последние_строки\", \"n\": 2}]}",
                "a\nb\nc\nd");
        var exec = new ScenarioExecutorTransformNode(node);
        String result = exec.execute(sink);

        assertEquals("c\nd", result);
    }

    @Test
    void testHeadTail_defaultN() {
        var node = node("{\"операции\": [{\"оп\": \"первые_строки\"}]}",
                "a\nb\nc\nd\ne\nf\ng\nh\ni\nj\nk\nl");
        var exec = new ScenarioExecutorTransformNode(node);
        String result = exec.execute(sink);

        assertEquals("a\nb\nc\nd\ne\nf\ng\nh\ni\nj", result);
    }

    // ---------------------------------------------------------------
    // chain — несколько операций подряд
    // ---------------------------------------------------------------

    @Test
    void testChainedOperations() {
        var node = node("{" +
                "\"операции\": [" +
                "  {\"оп\": \"извлечь_regex\", \"шаблон\": \"\\\\d+\"}," +
                "  {\"оп\": \"заменить\", \"найти\": \"123\", \"на\": \"999\"}" +
                "]" +
                "}", "id: 123");
        var exec = new ScenarioExecutorTransformNode(node);
        String result = exec.execute(sink);

        assertEquals("999", result.trim());
    }

    @Test
    void testUsesDocListWhenDocIdsPresent() {
        var dto = NodeDto.builder()
                .id("t1")
                .type(ScenarioNodeType.TRANSFORM_NODE.toString())
                .data(NodeDataDto.builder()
                        .label("Док")
                        .rules("{\"операции\": [{\"оп\": \"извлечь_regex\", \"шаблон\": \"\\\\d+\"}]}")
                        .build())
                .position(new PositionDto(0, 0))
                .build();
        var graph = new ScenarioRunGraph(new GraphDataDto(List.of(dto), List.of()));
        var node = graph.getNodeMap().get("t1");
        // Привязываем документ
        node.getDocList().add("doc1");
        // Добавляем текст документа в docMap
        graph.getDocMap().put("doc1", new ScenarioRunDoc("file.txt", "Текст с номером 12345"));

        var exec = new ScenarioExecutorTransformNode(node);
        String result = exec.execute(sink);

        assertEquals("12345", result.trim());
    }

    // ---------------------------------------------------------------
    // unknown operation → ScenarioException
    // ---------------------------------------------------------------

    @Test
    void testUnknownOperation_throws() {
        var node = node("{\"операции\": [{\"оп\": \"неизвестная\"}]}",
                "текст");
        var exec = new ScenarioExecutorTransformNode(node);

        assertThrows(ScenarioException.class, () -> exec.execute(sink));
    }

    @Test
    void testEmptyOperations_throws() {
        var node = node("{\"операции\": []}", "текст");
        var exec = new ScenarioExecutorTransformNode(node);

        assertThrows(ScenarioException.class, () -> exec.execute(sink));
    }

    @Test
    void testNoOperations_throws() {
        assertThrows(ScenarioException.class, () -> {
            var node = node("{}", "текст");
            new ScenarioExecutorTransformNode(node).execute(sink);
        });
    }

    @Test
    void testBadRegex_throws() {
        var node = node("{\"операции\": [{\"оп\": \"извлечь_regex\", \"шаблон\": \"[\"}]}",
                "text");
        var exec = new ScenarioExecutorTransformNode(node);

        assertThrows(ScenarioException.class, () -> exec.execute(sink));
    }
}