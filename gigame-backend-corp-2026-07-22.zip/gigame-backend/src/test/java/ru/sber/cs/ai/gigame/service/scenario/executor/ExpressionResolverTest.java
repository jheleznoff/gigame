package ru.sber.cs.ai.gigame.service.scenario.executor;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import ru.sber.cs.ai.gigame.dto.scenario.graph.GraphDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.PositionDto;
import ru.sber.cs.ai.gigame.service.scenario.enums.ScenarioNodeType;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunGraph;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunNode;

import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Тесты {@link ExpressionResolver}: подстановка выражений {{output:…}} и {{json:…}}
 * в промптах узлов сценария.
 */
class ExpressionResolverTest {

    private Map<String, ScenarioRunNode> nodeMap;

    @BeforeEach
    void setUp() {
        var nodeDto = NodeDto.builder()
                .id("node-1")
                .type(ScenarioNodeType.PROCESSING_NODE.toString())
                .data(NodeDataDto.builder()
                        .label("Extractor")
                        .prompt("какой-то промпт")
                        .build())
                .position(new PositionDto(100, 100))
                .build();
        var gd = new GraphDataDto(List.of(nodeDto), List.of());
        var graph = new ScenarioRunGraph(gd);
        nodeMap = graph.getNodeMap();
    }

    // ================================================================
    // hasExpressions
    // ================================================================

    @Test
    void testHasExpressions_withOutput() {
        assertTrue(ExpressionResolver.hasExpressions("{{output:Extractor}}"));
    }

    @Test
    void testHasExpressions_withJson() {
        assertTrue(ExpressionResolver.hasExpressions("{{json:Extractor:цена}}"));
    }

    @Test
    void testHasExpressions_withLeadingTrailingSpaces() {
        assertTrue(ExpressionResolver.hasExpressions("  {{ output : Extractor }}  "));
    }

    @Test
    void testHasExpressions_withoutExpression() {
        assertFalse(ExpressionResolver.hasExpressions("просто текст без выражений"));
    }

    @Test
    void testHasExpressions_withEmptyTemplate() {
        assertFalse(ExpressionResolver.hasExpressions(""));
    }

    @Test
    void testHasExpressions_withNullTemplate() {
        assertFalse(ExpressionResolver.hasExpressions(null));
    }

    @Test
    void testHasExpressions_withJsonPath() {
        assertTrue(ExpressionResolver.hasExpressions("{{json:Узел:путь.к[0].полю}}"));
    }

    // ================================================================
    // resolve — output
    // ================================================================

    @Test
    void testResolve_output_simple() {
        ScenarioRunNode src = nodeMap.get("node-1");
        src.getOutput().add("результат работы узла");

        String resolved = ExpressionResolver.resolve("Контекст: {{output:node-1}}", nodeMap);

        assertEquals("Контекст: результат работы узла", resolved);
    }

    @Test
    void testResolve_output_byLabel() {
        ScenarioRunNode src = nodeMap.get("node-1");
        src.getOutput().add("результат");

        String resolved = ExpressionResolver.resolve("{{output:Extractor}}", nodeMap);

        assertEquals("результат", resolved);
    }

    @Test
    void testResolve_output_multipleLines() {
        ScenarioRunNode src = nodeMap.get("node-1");
        src.getOutput().add("строка 1");
        src.getOutput().add("строка 2");

        String resolved = ExpressionResolver.resolve("{{output:node-1}}", nodeMap);

        assertTrue(resolved.contains("строка 1"));
        assertTrue(resolved.contains("строка 2"));
    }

    @Test
    void testResolve_output_nodeNotFound() {
        String resolved = ExpressionResolver.resolve("{{output:Несуществующий}}", nodeMap);

        assertTrue(resolved.contains("не найден"));
    }

    @Test
    void testResolve_output_usesFirstMatchingLabel() {
        var gd = new GraphDataDto(List.of(
                NodeDto.builder()
                        .id("n1")
                        .type(ScenarioNodeType.PROCESSING_NODE.toString())
                        .data(NodeDataDto.builder().label("Extractor").prompt("").build())
                        .position(new PositionDto(0, 0))
                        .build(),
                NodeDto.builder()
                        .id("n2")
                        .type(ScenarioNodeType.PROCESSING_NODE.toString())
                        .data(NodeDataDto.builder().label("Extractor").prompt("").build())
                        .position(new PositionDto(100, 0))
                        .build()
        ), List.of());
        var graph = new ScenarioRunGraph(gd);
        var nm = graph.getNodeMap();

        nm.get("n1").getOutput().add("один");
        nm.get("n2").getOutput().add("два");

        String resolved = ExpressionResolver.resolve("{{output:Extractor}}", nm);

        // находит первый узел с подходящей меткой
        assertEquals("один", resolved);
    }

    // ================================================================
    // resolve — json
    // ================================================================

    @Test
    void testResolve_json_simpleField() {
        ScenarioRunNode src = nodeMap.get("node-1");
        src.getOutput().add("какой-то текст\n{\"цена\": 1250.5, \"количество\": 320}\nхвост");

        String resolved = ExpressionResolver.resolve("Цена: {{json:node-1:цена}}", nodeMap);

        assertEquals("Цена: 1250.5", resolved);
    }

    @Test
    void testResolve_json_nestedField() {
        ScenarioRunNode src = nodeMap.get("node-1");
        src.getOutput().add("{\"участник\": {\"имя\": \"Альфа\", \"балл\": 95}}");

        String resolved = ExpressionResolver.resolve("{{json:node-1:участник.имя}}", nodeMap);

        assertEquals("Альфа", resolved);
    }

    @Test
    void testResolve_json_arrayItem() {
        ScenarioRunNode src = nodeMap.get("node-1");
        src.getOutput().add("{\"позиции\": [{\"имя\": \"Первая\"}, {\"имя\": \"Вторая\"}]}");

        String resolved = ExpressionResolver.resolve("{{json:node-1:позиции[0].имя}}", nodeMap);

        assertEquals("Первая", resolved);
    }

    @Test
    void testResolve_json_indexOutOfBounds() {
        ScenarioRunNode src = nodeMap.get("node-1");
        src.getOutput().add("{\"список\": [1, 2]}");

        String resolved = ExpressionResolver.resolve("{{json:node-1:список[99]}}", nodeMap);

        assertTrue(resolved.contains("вне диапазона"));
    }

    @Test
    void testResolve_json_nodeNotFound() {
        String resolved = ExpressionResolver.resolve("{{json:Несущ:поле}}", nodeMap);

        assertTrue(resolved.contains("не найден"));
    }

    @Test
    void testResolve_json_noJsonInOutput() {
        ScenarioRunNode src = nodeMap.get("node-1");
        src.getOutput().add("просто текст без JSON");

        String resolved = ExpressionResolver.resolve("{{json:node-1:поле}}", nodeMap);

        assertTrue(resolved.contains("нет разбираемого JSON"));
    }

    @Test
    void testResolve_json_fieldNotFound() {
        ScenarioRunNode src = nodeMap.get("node-1");
        src.getOutput().add("{\"цена\": 100}");

        String resolved = ExpressionResolver.resolve("{{json:node-1:нетТакогоПоля}}", nodeMap);

        assertTrue(resolved.contains("не найдено"));
    }

    @Test
    void testResolve_json_emptyOutput() {

        String resolved = ExpressionResolver.resolve("{{json:node-1:поле}}", nodeMap);

        assertTrue(resolved.contains("нет разбираемого JSON"));
    }

    @Test
    void testResolve_json_withoutPath() {
        ScenarioRunNode src = nodeMap.get("node-1");
        src.getOutput().add("{\"цена\": 100}");

        // {{json:label}} без пути
        String resolved = ExpressionResolver.resolve("{{json:node-1}}", nodeMap);

        assertTrue(resolved.contains("не указан путь к полю"));
    }

    // ================================================================
    // resolve — несколько выражений в одном шаблоне
    // ================================================================

    @Test
    void testResolve_multipleExpressionsInTemplate() {
        // создаём два узла
        var gd = new GraphDataDto(List.of(
                NodeDto.builder()
                        .id("n1")
                        .type(ScenarioNodeType.PROCESSING_NODE.toString())
                        .data(NodeDataDto.builder().label("Цены").prompt("").build())
                        .position(new PositionDto(0, 0))
                        .build(),
                NodeDto.builder()
                        .id("n2")
                        .type(ScenarioNodeType.PROCESSING_NODE.toString())
                        .data(NodeDataDto.builder().label("Расчёт").prompt("").build())
                        .position(new PositionDto(100, 0))
                        .build()
        ), List.of());
        var graph = new ScenarioRunGraph(gd);
        var nm = graph.getNodeMap();
        nm.get("n1").getOutput().add("{\"цена\": 100}");
        nm.get("n2").getOutput().add("текст вывода");

        String resolved = ExpressionResolver.resolve("Поле: {{json:Цены:цена}}, Вывод: {{output:Расчёт}}", nm);

        assertEquals("Поле: 100, Вывод: текст вывода", resolved);
    }

    @Test
    void testResolve_outputAndJsonMixed() {
        ScenarioRunNode src = nodeMap.get("node-1");
        src.getOutput().add("{\"цена\": 200}");

        String resolved = ExpressionResolver.resolve("{{output:node-1}} | {{json:node-1:цена}}", nodeMap);

        assertTrue(resolved.contains("цена"));
        assertTrue(resolved.contains("200"));
    }

    // ================================================================
    // resolve — выражений нет, шаблон не меняется
    // ================================================================

    @Test
    void testResolve_withoutExpressions_unchanged() {
        String template = "просто промпт без выражений";

        String resolved = ExpressionResolver.resolve(template, nodeMap);

        assertEquals(template, resolved);
    }

    @Test
    void testResolve_withEmptyTemplate_unchanged() {
        String resolved = ExpressionResolver.resolve("", nodeMap);

        assertEquals("", resolved);
    }

    // ================================================================
    // extractJsonPathFromText — статический метод, доступный напрямую
    // ================================================================

    @Test
    void testExtractJsonPathFromText_deepNestedWithArrays() {
        String text = "{\"data\": [{\"items\": [{\"value\": 42}]}]}";

        String result = ExpressionResolver.extractJsonPathFromText(text, "data[0].items[0].value");

        assertEquals("42", result);
    }

    @Test
    void testExtractJsonPathFromText_noJson_returnsError() {
        String text = "просто текст";

        String result = ExpressionResolver.extractJsonPathFromText(text, "поле");

        assertTrue(result.contains("нет разбираемого JSON"));
    }

    @Test
    void testExtractJsonPathFromText_stringValue() {
        String text = "{\"имя\": \"Альфа\"}";

        String result = ExpressionResolver.extractJsonPathFromText(text, "имя");

        assertEquals("Альфа", result);
    }

    @Test
    void testExtractJsonPathFromText_numberValue() {
        String text = "{\"цена\": 1250.5}";

        String result = ExpressionResolver.extractJsonPathFromText(text, "цена");

        assertEquals("1250.5", result);
    }

    @Test
    void testExtractJsonPathFromText_nullValue() {
        String text = "{\"поле\": null}";

        String result = ExpressionResolver.extractJsonPathFromText(text, "поле");

        assertEquals("", result);
    }

    @Test
    void testExtractJsonPathFromText_objectValue() {
        String text = "{\"объект\": {\"внутри\": true}}";

        String result = ExpressionResolver.extractJsonPathFromText(text, "объект");

        assertTrue(result.contains("внутри"));
        assertTrue(result.contains("true"));
    }

    @Test
    void testExtractJsonPathFromText_arrayValue() {
        String text = "{\"массив\": [1, 2, 3]}";

        String result = ExpressionResolver.extractJsonPathFromText(text, "массив");

        assertTrue(result.contains("1"));
        assertTrue(result.contains("3"));
    }

    @Test
    void testExtractJsonPathFromText_withCommasInDecimals() {
        String text = "{\"цена\": 1250,5}";

        String result = ExpressionResolver.extractJsonPathFromText(text, "цена");

        assertEquals("1250.5", result);
    }
}