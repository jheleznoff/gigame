package ru.sber.cs.ai.gigame.dto.scenario;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

class ScenarioRunStepInputDataResponseTest {

    @Test
    void testConstruction_withAllFields() {
        var dto = new ScenarioRunStepInputDataResponse("documents text", "previous output");
        assertEquals("documents text", dto.documentsText());
        assertEquals("previous output", dto.previousOutput());
    }

    @Test
    void testConstruction_withNullFields() {
        var dto = new ScenarioRunStepInputDataResponse(null, null);
        assertNull(dto.documentsText());
        assertNull(dto.previousOutput());
    }
}