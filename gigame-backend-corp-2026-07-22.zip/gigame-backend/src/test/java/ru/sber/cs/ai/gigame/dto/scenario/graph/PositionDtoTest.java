package ru.sber.cs.ai.gigame.dto.scenario.graph;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

class PositionDtoTest {

    @Test
    void testConstruction_withCoordinates() {
        var dto = new PositionDto(100, 200);
        assertEquals(Integer.valueOf(100), dto.x());
        assertEquals(Integer.valueOf(200), dto.y());
    }

    @Test
    void testConstruction_withNullCoordinates() {
        var dto = new PositionDto(null, null);
        assertNull(dto.x());
        assertNull(dto.y());
    }
}