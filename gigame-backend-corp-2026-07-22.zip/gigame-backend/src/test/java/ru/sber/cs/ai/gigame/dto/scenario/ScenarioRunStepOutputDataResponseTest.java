package ru.sber.cs.ai.gigame.dto.scenario;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

class ScenarioRunStepOutputDataResponseTest {

    @Test
    void testConstruction_withAllFields() {
        var dto = new ScenarioRunStepOutputDataResponse("result text", "error text");
        assertEquals("result text", dto.result());
        assertEquals("error text", dto.error());
    }

    @Test
    void testConstruction_withNullFields() {
        var dto = new ScenarioRunStepOutputDataResponse(null, null);
        assertNull(dto.result());
        assertNull(dto.error());
    }
}