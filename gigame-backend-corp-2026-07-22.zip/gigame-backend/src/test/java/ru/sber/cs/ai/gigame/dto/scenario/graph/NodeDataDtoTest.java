package ru.sber.cs.ai.gigame.dto.scenario.graph;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

class NodeDataDtoTest {

    @Test
    void testBuilder_withAllFields() {
        var dto = NodeDataDto.builder()
                .label("Test Label")
                .prompt("Test prompt")
                .classes("class1,class2")
                .rules("[{\"key\": \"value\"}]")
                .classifyStrict("true")
                .mode("all")
                .field("fieldName")
                .operator("contains")
                .value("testValue")
                .knowledgeBaseId("550e8400-e29b-41d4-a716-446655440000")
                .build();

        assertEquals("Test Label", dto.label());
        assertEquals("Test prompt", dto.prompt());
        assertEquals("class1,class2", dto.classes());
        assertEquals("[{\"key\": \"value\"}]", dto.rules());
        assertEquals("true", dto.classifyStrict());
        assertEquals("all", dto.mode());
        assertEquals("fieldName", dto.field());
        assertEquals("contains", dto.operator());
        assertEquals("testValue", dto.value());
        assertEquals("550e8400-e29b-41d4-a716-446655440000", dto.knowledgeBaseId());
    }

    @Test
    void testBuilder_withDefaults() {
        var dto = NodeDataDto.builder().build();
        assertNull(dto.label());
        assertNull(dto.prompt());
        assertNull(dto.classes());
        assertNull(dto.rules());
        assertNull(dto.classifyStrict());
        assertNull(dto.mode());
        assertNull(dto.field());
        assertNull(dto.operator());
        assertNull(dto.value());
        assertNull(dto.knowledgeBaseId());
    }

    @Test
    void testBuilder_withPartialFields() {
        var dto = NodeDataDto.builder()
                .label("Label")
                .prompt("Prompt")
                .build();

        assertEquals("Label", dto.label());
        assertEquals("Prompt", dto.prompt());
        assertNull(dto.classes());
    }
}