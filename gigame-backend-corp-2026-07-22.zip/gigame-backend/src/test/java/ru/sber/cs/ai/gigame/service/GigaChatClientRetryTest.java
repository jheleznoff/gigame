package ru.sber.cs.ai.gigame.service;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.ai.chat.messages.AssistantMessage;
import org.springframework.ai.chat.model.ChatModel;
import org.springframework.ai.chat.model.ChatResponse;
import org.springframework.ai.chat.model.Generation;
import org.springframework.ai.chat.prompt.Prompt;
import org.springframework.ai.embedding.EmbeddingModel;
import org.springframework.test.util.ReflectionTestUtils;
import reactor.core.publisher.Mono;
import ru.sber.cs.ai.gigame.exception.GigaChatException;

import java.util.List;
import java.util.Map;
import java.util.function.Supplier;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * Тесты для {@link GigaChatClient#withRetry(Supplier)} — проверка,
 * что новый retry на {@link Mono#fromCallable} + {@link reactor.util.retry.Retry#fixedDelay}
 * не блокирует потоки через {@code Thread.sleep()}, а использует реактивный retry.
 * <p>
 * Все тесты — быстрые (delayMillis = 1ms), без реального ожидания между retry.
 */
@ExtendWith(MockitoExtension.class)
class GigaChatClientRetryTest {

    @Mock
    private ChatModel chatModel;

    @Mock
    private EmbeddingModel embeddingModel;

    @Captor
    private ArgumentCaptor<Prompt> promptCaptor;

    private GigaChatClient gigaChatClient;

    private static final ChatResponse SUCCESS_RESPONSE = createResponse("OK after retry");

    @BeforeEach
    void setUp() {
        gigaChatClient = new GigaChatClient(chatModel, embeddingModel);
        // Minimal delays для быстрых тестов
        ReflectionTestUtils.setField(gigaChatClient, "retryMaxAttempts", 3);
        ReflectionTestUtils.setField(gigaChatClient, "retryDelayMillis", 1);
        ReflectionTestUtils.setField(gigaChatClient, "retryDelay429Millis", 1);
    }

    // =====================================================================
    // 1. withRetry — базовый успешный вызов (1 попытка)
    // =====================================================================

    @Test
    void testWithRetry_successOnFirstAttempt() {
        when(chatModel.call(any(Prompt.class))).thenReturn(SUCCESS_RESPONSE);

        String result = gigaChatClient.chatCompletion(
                List.of(Map.of("role", "user", "content", "Hello")));

        assertEquals("OK after retry", result);
        verify(chatModel, times(1)).call(any(Prompt.class));
    }

    // =====================================================================
    // 2. withRetry — 500 повторяемый (2 попытки)
    // =====================================================================

    @Test
    void testWithRetry_retriesOn500() {
        when(chatModel.call(any(Prompt.class)))
                .thenThrow(new RuntimeException("500 Internal Error"))
                .thenReturn(SUCCESS_RESPONSE);

        String result = gigaChatClient.chatCompletion(
                List.of(Map.of("role", "user", "content", "Hello")));

        assertEquals("OK after retry", result);
        verify(chatModel, times(2)).call(any(Prompt.class));
    }

    // =====================================================================
    // 3. withRetry — 502 повторяемый (2 попытки)
    // =====================================================================

    @Test
    void testWithRetry_retriesOn502() {
        when(chatModel.call(any(Prompt.class)))
                .thenThrow(new RuntimeException("502 Bad Gateway"))
                .thenReturn(SUCCESS_RESPONSE);

        String result = gigaChatClient.chatCompletion(
                List.of(Map.of("role", "user", "content", "Hello")));

        assertEquals("OK after retry", result);
        verify(chatModel, times(2)).call(any(Prompt.class));
    }

    // =====================================================================
    // 4. withRetry — 504 повторяемый (2 попытки)
    // =====================================================================

    @Test
    void testWithRetry_retriesOn504() {
        when(chatModel.call(any(Prompt.class)))
                .thenThrow(new RuntimeException("504 Gateway Timeout"))
                .thenReturn(SUCCESS_RESPONSE);

        String result = gigaChatClient.chatCompletion(
                List.of(Map.of("role", "user", "content", "Hello")));

        assertEquals("OK after retry", result);
        verify(chatModel, times(2)).call(any(Prompt.class));
    }

    // =====================================================================
    // 5. withRetry — 429 rate-limit (2 попытки)
    // =====================================================================

    @Test
    void testWithRetry_retriesOn429() {
        when(chatModel.call(any(Prompt.class)))
                .thenThrow(new RuntimeException("429 Too Many Requests"))
                .thenReturn(SUCCESS_RESPONSE);

        String result = gigaChatClient.chatCompletion(
                List.of(Map.of("role", "user", "content", "Hello")));

        assertEquals("OK after retry", result);
        verify(chatModel, times(2)).call(any(Prompt.class));
    }

    // =====================================================================
    // 6. withRetry — 400 без повтора (1 попытка)
    // =====================================================================

    @Test
    void testWithRetry_throwsOn400() {
        when(chatModel.call(any(Prompt.class)))
                .thenThrow(new RuntimeException("400 Bad Request"));

        assertThrows(RuntimeException.class, () ->
                gigaChatClient.chatCompletion(
                        List.of(Map.of("role", "user", "content", "Hi"))));

        verify(chatModel, times(1)).call(any(Prompt.class));
    }

    // =====================================================================
    // 7. withRetry — timeout (2 попытки)
    // =====================================================================

    @Test
    void testWithRetry_retriesOnTimeout() {
        when(chatModel.call(any(Prompt.class)))
                .thenThrow(new RuntimeException("timed out"))
                .thenReturn(SUCCESS_RESPONSE);

        String result = gigaChatClient.chatCompletion(
                List.of(Map.of("role", "user", "content", "Hi")));

        assertEquals("OK after retry", result);
        verify(chatModel, times(2)).call(any(Prompt.class));
    }

    // =====================================================================
    // 8. withRetry — connection error (2 попытки)
    // =====================================================================

    @Test
    void testWithRetry_retriesOnConnectionError() {
        when(chatModel.call(any(Prompt.class)))
                .thenThrow(new RuntimeException("Connection refused"))
                .thenReturn(SUCCESS_RESPONSE);

        String result = gigaChatClient.chatCompletion(
                List.of(Map.of("role", "user", "content", "Hi")));

        assertEquals("OK after retry", result);
        verify(chatModel, times(2)).call(any(Prompt.class));
    }

    // =====================================================================
    // 9. withRetry — исчерпание попыток (3 ошибки -> пробрасывается)
    // =====================================================================

    @Test
    void testWithRetry_throwsAfterExhaustedRetries() {
        when(chatModel.call(any(Prompt.class)))
                .thenThrow(new RuntimeException("500 Internal Error"));

        assertThrows(GigaChatException.class, () ->
                gigaChatClient.chatCompletion(
                        List.of(Map.of("role", "user", "content", "Hi"))));
    }

    // =====================================================================
    // 10. withRetry — проверка, что retry не вызывает Thread.sleep
    // =====================================================================

    @Test
    void testWithRetry_noThreadSleepBlock() {
        // Проверяем, что при повторной попытке с задержкой не используется
        // Thread.sleep (был заменён на Mono.delay + Retry.fixedDelay)
        // Используем AtomicLong для проверки, что метод завершается быстро
        // (Mono.delay(1ms).block() — это ~1мс, а не произвольная задержка)
        long start = System.nanoTime();

        when(chatModel.call(any(Prompt.class)))
                .thenThrow(new RuntimeException("503 Service Unavailable"))
                .thenReturn(SUCCESS_RESPONSE);

        assertDoesNotThrow(() -> gigaChatClient.chatCompletion(
                List.of(Map.of("role", "user", "content", "Hi"))));

        long elapsed = (System.nanoTime() - start) / 1_000_000;
        // С delay=1ms на 2 попытки должно быть < 50ms (с учётом накладных расходов)
        assertTrue(elapsed < 100, "Retry should complete in < 100ms, but took " + elapsed + "ms");
    }

    // =====================================================================
    // 11. withRetry — verify(Mono.fromCallable) используется
    // =====================================================================

    @Test
    void testWithRetry_usesMonoFromCallable() {
        // Проверяем, что вызов gigaChatClient.chatCompletion() не ведёт
        // к Thread.sleep — он должен отработать без задержки
        when(chatModel.call(any(Prompt.class))).thenReturn(SUCCESS_RESPONSE);

        assertDoesNotThrow(() -> {
            String result = gigaChatClient.chatCompletion(
                    List.of(Map.of("role", "user", "content", "Hi")));
            assertEquals("OK after retry", result);
        });
    }

    // =====================================================================
    // 12. withRetry — максимальное количество попыток (5)
    // =====================================================================

    @Test
    void testWithRetry_customMaxAttempts() {
        ReflectionTestUtils.setField(gigaChatClient, "retryMaxAttempts", 5);
        when(chatModel.call(any(Prompt.class)))
                .thenThrow(new RuntimeException("503 Service Unavailable"))
                .thenThrow(new RuntimeException("502 Bad Gateway"))
                .thenThrow(new RuntimeException("504 Gateway Timeout"))
                .thenThrow(new RuntimeException("503 Service Unavailable"))
                .thenReturn(SUCCESS_RESPONSE);

        String result = gigaChatClient.chatCompletion(
                List.of(Map.of("role", "user", "content", "Hi")));

        assertEquals("OK after retry", result);
        verify(chatModel, times(5)).call(any(Prompt.class));
    }

    // =====================================================================
    // 13. withRetry — ошибки, не являющиеся временными (400, 402, 413)
    // =====================================================================

    @ParameterizedTest
    @ValueSource(strings = {
            "400 Bad Request",
            "402 Payment Required",
            "413 Request Entity Too Large"
    })
    void testWithRetry_nonRetryableErrors(String errorMessage) {
        when(chatModel.call(any(Prompt.class)))
                .thenThrow(new RuntimeException(errorMessage));

        assertThrows(RuntimeException.class, () ->
                gigaChatClient.chatCompletion(
                        List.of(Map.of("role", "user", "content", "Hi"))));

        verify(chatModel, times(1)).call(any(Prompt.class));
    }

    // =====================================================================
    // 14. withRetry — null/пустой message не вызывает retry
    // =====================================================================

    @Test
    void testWithRetry_nullMessageNotRetried() {
        when(chatModel.call(any(Prompt.class)))
                .thenThrow(new RuntimeException());

        // При null message ожидаем Exception (не GigaChatException)
        assertThrows(RuntimeException.class, () ->
                gigaChatClient.chatCompletion(
                        List.of(Map.of("role", "user", "content", "Hi"))));
    }

    // =====================================================================
    // Helper — создаёт ChatResponse с заданным текстом
    // =====================================================================

    private static ChatResponse createResponse(String text) {
        AssistantMessage assistantMsg = new AssistantMessage(text);
        Generation generation = new Generation(assistantMsg);
        return new ChatResponse(List.of(generation));
    }

    @Override
    public String toString() {
        return "GigaChatClientRetryTest";
    }
}