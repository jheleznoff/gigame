package ru.sber.cs.ai.gigame.service;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import ru.sber.cs.ai.gigame.repository.DocumentRepository;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Тесты парсинга XML-документов: УПД ФНС и generic-XML fallback.
 */
@ExtendWith(MockitoExtension.class)
class DocumentServiceXmlTest {

    private static final String UPD_XML = """
            <?xml version="1.0" encoding="UTF-8"?>
            <Файл ИдФайл="ON_NSCHFDOPPR_TEST" ВерсФорм="5.01">
              <Документ КНД="1115131" Функция="ДОП">
                <СвСчФакт НомерСчФ="SSBRF219/20" ДатаСчФ="28.09.2022">
                  <СвПрод><ИдСв><СвЮЛУч НаимОрг="ООО ГЛОУБАЙТ" ИННЮЛ="9729285230"/></ИдСв></СвПрод>
                  <СвПокуп><ИдСв><СвЮЛУч НаимОрг="ПАО СБЕРБАНК" ИННЮЛ="7707083893"/></ИдСв></СвПокуп>
                  <ИнфПолФХЖ1>
                    <ТекстИнф Идентиф="Дог" Значен="Договор вн. №_3730725_от 27.12.2021"/>
                  </ИнфПолФХЖ1>
                </СвСчФакт>
                <ТаблСчФакт>
                  <СведТов НомСтр="1" НаимТов="Работы по разработке ПО на Greenplum"
                           СтТовБезНДС="3508450.00" СтТовУчНал="4210140.00"/>
                  <ВсегоОпл СтТовБезНДСВсего="3508450.00" СтТовУчНалВсего="4210140.00"/>
                </ТаблСчФакт>
                <СвПродПер><СвПер СодОпер="передача работ">
                  <ОснПер НаимОсн="Спецификация" НомОсн="4017064" ДатаОсн="27.12.2021"/>
                </СвПер></СвПродПер>
              </Документ>
            </Файл>
            """;

    @Mock
    private DocumentRepository documentRepository;
    @Mock
    private EmbeddingService embeddingService;
    @Mock
    private DocumentIndexService indexService;

    private DocumentService service() {
        return new DocumentService(documentRepository, embeddingService, indexService);
    }

    @Test
    void parseText_updXml_extractsKeyAttributes() throws IOException {
        String text = service().parseText(
                new ByteArrayInputStream(UPD_XML.getBytes(StandardCharsets.UTF_8)), "xml");

        assertTrue(text.contains("Универсальный передаточный документ"));
        assertTrue(text.contains("SSBRF219/20"));
        assertTrue(text.contains("28.09.2022"));
        assertTrue(text.contains("ООО ГЛОУБАЙТ"));
        assertTrue(text.contains("ПАО СБЕРБАНК"));
        assertTrue(text.contains("3730725"));
        assertTrue(text.contains("Работы по разработке ПО на Greenplum"));
        assertTrue(text.contains("4210140.00"));
        assertTrue(text.contains("Спецификация 4017064"));
    }

    @Test
    void parseText_genericXml_fallsBackToPlainText() throws IOException {
        String xml = "<root attr=\"значение атрибута\"><item>текст узла</item></root>";
        String text = service().parseText(
                new ByteArrayInputStream(xml.getBytes(StandardCharsets.UTF_8)), "xml");

        assertTrue(text.contains("значение атрибута"));
        assertTrue(text.contains("текст узла"));
    }

    @Test
    void parseText_brokenXml_throwsIoException() {
        var broken = new ByteArrayInputStream("<не закрытый".getBytes(StandardCharsets.UTF_8));
        assertThrows(IOException.class, () -> service().parseText(broken, "xml"));
    }

    @Test
    void parseText_xmlWithDoctype_rejected() {
        // защита от XXE: DOCTYPE запрещён
        String xxe = "<?xml version=\"1.0\"?><!DOCTYPE foo [<!ENTITY x SYSTEM \"file:///etc/passwd\">]><foo>&x;</foo>";
        var stream = new ByteArrayInputStream(xxe.getBytes(StandardCharsets.UTF_8));
        assertThrows(IOException.class, () -> service().parseText(stream, "xml"));
    }
}
