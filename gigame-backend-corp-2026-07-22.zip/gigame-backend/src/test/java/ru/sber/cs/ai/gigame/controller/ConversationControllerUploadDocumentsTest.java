package ru.sber.cs.ai.gigame.controller;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpEntity;
import org.springframework.http.MediaType;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.reactive.server.WebTestClient;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.reactive.function.BodyInserters;
import ru.sber.cs.ai.gigame.service.ChatService;
import ru.sber.cs.ai.gigame.service.DocsTextCacheService;
import ru.sber.cs.ai.gigame.service.DocumentService;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.time.OffsetDateTime;
import java.util.Map;
import java.util.UUID;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

@WebFluxTest(controllers = ConversationController.class)
@SuppressWarnings("unused")
class ConversationControllerUploadDocumentsTest {

    @MockitoBean
    DocsTextCacheService docsTextCacheService;
    @Autowired
    private WebTestClient webClient;
    @MockitoBean
    private ChatService chatService;
    @MockitoBean
    private DocumentService documentService;

    private static MultiValueMap<String, HttpEntity<?>> getMockMultipartBody(String filename, String fileText, String contentType) {
        // Подготовка multipart тела с использованием ByteArrayResource
        MultiValueMap<String, HttpEntity<?>> body = new LinkedMultiValueMap<>();

        // Добавляем файл
        ByteArrayResource resource = new ByteArrayResource(fileText.getBytes(StandardCharsets.UTF_8)) {
            @Override
            public String getFilename() {
                return filename;
            }
        };

        LinkedMultiValueMap<String, String> fileHeaders = new LinkedMultiValueMap<>();
        fileHeaders.add("Content-Type", contentType);
        body.add("files", new HttpEntity<>(resource, fileHeaders));
        return body;
    }

    @Test
    void uploadDocuments_ShouldProcessFilesAndCacheTexts() throws IOException {
        // Given
        String userId = "USER123";
        UUID conversationId = UUID.randomUUID();
        String filename = "test.pdf";
        String fileText = "Текст из PDF файла.";

        // Мокируем извлечение текста из файла
        when(documentService.parseText(any(InputStream.class), eq("application/pdf")))
                .thenReturn(fileText);

        // Мокируем, что диалог существует
        when(documentService.parseText(any(), any())).thenReturn(fileText);

        when(documentService.uploadDocument(any(), eq(userId))).thenReturn(
                new DocumentService.DocumentResponse(
                        UUID.randomUUID(),
                        filename,
                        "application/pdf",
                        100,
                        fileText.length(),
                        fileText,
                        OffsetDateTime.now(),
                        OffsetDateTime.now()));
        // Подготовка multipart тела
        MultiValueMap<String, HttpEntity<?>> body = getMockMultipartBody(filename, fileText, MediaType.APPLICATION_PDF.toString());

        // When & Then
        webClient.post()
                .uri("/api/conversations/{id}/upload", conversationId)
                .header("X-UserId", userId)
                .contentType(MediaType.MULTIPART_FORM_DATA)
                .body(BodyInserters.fromMultipartData(body))
                .exchange()
                .expectStatus().isOk()
                .expectBody().isEmpty();
    }

    @Test
    void uploadDocuments_ShouldProcessMultipleFilesAndCacheTexts() throws IOException {
        // Given
        String userId = "USER123";
        UUID conversationId = UUID.randomUUID();
        String filename1 = "document1.pdf";
        String fileText1 = "Текст из первого PDF файла.";
        String filename2 = "document2.docx";
        String fileText2 = "Текст из второго DOCX файла.";

        // Мокируем извлечение текста из файлов
        when(documentService.parseText(any(InputStream.class), eq("application/pdf")))
                .thenReturn(fileText1);
        when(documentService.parseText(any(InputStream.class), eq("application/vnd.openxmlformats-officedocument.wordprocessingml.document")))
                .thenReturn(fileText2);
        when(documentService.uploadDocument(any(), eq(userId))).thenReturn(
                new DocumentService.DocumentResponse(
                        UUID.randomUUID(),
                        filename1,
                        "application/pdf",
                        100,
                        fileText1.length(),
                        fileText1,
                        OffsetDateTime.now(),
                        OffsetDateTime.now()));
        // Подготовка multipart тела с двумя файлами
        MultiValueMap<String, HttpEntity<?>> body = new LinkedMultiValueMap<>();

        ByteArrayResource resource1 = new ByteArrayResource(fileText1.getBytes(StandardCharsets.UTF_8)) {
            @Override
            public String getFilename() {
                return filename1;
            }
        };

        LinkedMultiValueMap<String, String> headers1 = new LinkedMultiValueMap<>();
        headers1.add("Content-Type", MediaType.APPLICATION_PDF.toString());
        body.add("files", new HttpEntity<>(resource1, headers1));

        ByteArrayResource resource2 = new ByteArrayResource(fileText2.getBytes(StandardCharsets.UTF_8)) {
            @Override
            public String getFilename() {
                return filename2;
            }
        };

        LinkedMultiValueMap<String, String> headers2 = new LinkedMultiValueMap<>();
        headers2.add("Content-Type", "application/vnd.openxmlformats-officedocument.wordprocessingml.document");
        body.add("files", new HttpEntity<>(resource2, headers2));

        // When & Then
        webClient.post()
                .uri("/api/conversations/{id}/upload", conversationId)
                .header("X-UserId", userId)
                .contentType(MediaType.MULTIPART_FORM_DATA)
                .body(BodyInserters.fromMultipartData(body))
                .exchange()
                .expectStatus().isOk()
                .expectBody().isEmpty();
    }

    @Test
    void uploadDocuments_WithUnsupportedContentType_ShouldFailWithUnprocessableEntity() throws IOException {
        // Given
        String userId = "USER123";
        UUID conversationId = UUID.randomUUID();
        String filename = "test.xyz";
        String fileText = "Текст из файла.";

        // Мокируем вызов documentService.parseText для выброса исключения
        when(documentService.parseText(any(), any()))
                .thenThrow(new IllegalArgumentException("Неподдерживаемый тип контента: application/xyz"));

        // Подготовка multipart тела
        MultiValueMap<String, HttpEntity<?>> body = new LinkedMultiValueMap<>();

        ByteArrayResource resource = new ByteArrayResource(fileText.getBytes(StandardCharsets.UTF_8)) {
            @Override
            public String getFilename() {
                return filename;
            }
        };

        LinkedMultiValueMap<String, String> headers = new LinkedMultiValueMap<>();
        headers.add("Content-Type", "application/xyz");
        body.add("files", new HttpEntity<>(resource, headers));

        // When & Then
        webClient.post()
                .uri("/api/conversations/{id}/upload", conversationId)
                .header("X-UserId", userId)
                .contentType(MediaType.MULTIPART_FORM_DATA)
                .body(BodyInserters.fromMultipartData(body))
                .exchange()
                .expectStatus().isEqualTo(422);
    }

    @Test
    void uploadDocuments_WithTooManyFiles_ShouldFailWithUnprocessableEntity() {
        // Given
        String userId = "USER123";
        UUID conversationId = UUID.randomUUID();
        String filename = "test.txt";
        String fileText = "Текст из файла.";

        when(documentService.uploadDocument(any(), eq(userId))).thenReturn(
                new DocumentService.DocumentResponse(
                        UUID.randomUUID(),
                        filename,
                        "text/plain",
                        100,
                        fileText.length(),
                        fileText,
                        OffsetDateTime.now(),
                        OffsetDateTime.now()));

        // Подготовка multipart тела с количеством файлов, превышающим лимит
        MultiValueMap<String, HttpEntity<?>> body = new LinkedMultiValueMap<>();
        for (int i = 0; i < ConversationController.MAX_FILES_PER_REQUEST + 1; i++) {
            int idx = i;
            ByteArrayResource resource = new ByteArrayResource(fileText.getBytes(StandardCharsets.UTF_8)) {
                @Override
                public String getFilename() {
                    return idx + "_" + filename;
                }
            };
            LinkedMultiValueMap<String, String> headers = new LinkedMultiValueMap<>();
            headers.add("Content-Type", "text/plain");
            body.add("files", new HttpEntity<>(resource, headers));
        }

        // When & Then
        webClient.post()
                .uri("/api/conversations/{id}/upload", conversationId)
                .header("X-UserId", userId)
                .contentType(MediaType.MULTIPART_FORM_DATA)
                .body(BodyInserters.fromMultipartData(body))
                .exchange()
                .expectStatus().isEqualTo(422);
    }

    @Test
    void uploadDocuments_WithJsonInsteadOfMultipart_ShouldReturnUnsupportedMediaType() {
        // Given
        String userId = "USER123";
        UUID conversationId = UUID.randomUUID();
        Map<String, String> jsonBody = Map.of("key", "value");

        // When & Then
        webClient.post()
                .uri("/api/conversations/{id}/upload", conversationId)
                .header("X-UserId", userId)
                // Отправляем JSON вместо multipart
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(jsonBody)
                .exchange()
                // Expect 415 Unsupported Media Type
                .expectStatus().isEqualTo(415);
    }
}
