package ru.sber.cs.ai.gigame.model;

import org.junit.jupiter.api.Test;

import java.time.OffsetDateTime;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

class KnowledgeBaseTest {

    @Test
    void testKnowledgeBaseDefaultValues() {
        KnowledgeBase kb = new KnowledgeBase();
        assertNull(kb.getId());
        assertNull(kb.getName());
        assertNull(kb.getDescription());
        assertNull(kb.getUserId());
        assertNull(kb.getCreatedAt());
        assertNull(kb.getUpdatedAt());
        assertTrue(kb.getDocuments().isEmpty());
    }

    @Test
    void testKnowledgeBaseWithAllFields() {
        UUID id = UUID.randomUUID();
        OffsetDateTime createdAt = OffsetDateTime.now();

        KnowledgeBase kb = new KnowledgeBase();
        kb.setId(id);
        kb.setName("Test KB");
        kb.setDescription("Test description");
        kb.setUserId("user123");
        kb.setCreatedAt(createdAt);

        assertEquals(id, kb.getId());
        assertEquals("Test KB", kb.getName());
        assertEquals("Test description", kb.getDescription());
        assertEquals("user123", kb.getUserId());
        assertEquals(createdAt, kb.getCreatedAt());
    }

    @Test
    void testKnowledgeBaseAddDocument() {
        KnowledgeBase kb = new KnowledgeBase();
        KBDocument doc = new KBDocument();
        doc.setKnowledgeBase(kb);

        kb.getDocuments().add(doc);

        assertEquals(1, kb.getDocuments().size());
    }

    @Test
    void testKnowledgeBaseRemoveDocument() {
        KnowledgeBase kb = new KnowledgeBase();
        KBDocument doc = new KBDocument();
        doc.setKnowledgeBase(kb);
        kb.getDocuments().add(doc);

        assertEquals(1, kb.getDocuments().size());
        kb.getDocuments().remove(doc);
        assertTrue(kb.getDocuments().isEmpty());
    }

    @Test
    void testKnowledgeBaseEmptyName() {
        KnowledgeBase kb = new KnowledgeBase();
        kb.setName("");

        assertEquals("", kb.getName());
    }

    @Test
    void testKnowledgeBaseEmptyDescription() {
        KnowledgeBase kb = new KnowledgeBase();
        kb.setDescription("");

        assertEquals("", kb.getDescription());
    }

    @Test
    void testKnowledgeBaseNullDescription() {
        KnowledgeBase kb = new KnowledgeBase();
        kb.setDescription(null);

        assertNull(kb.getDescription());
    }

    @Test
    void testToString() {
        KnowledgeBase kb = new KnowledgeBase();
        String str = kb.toString();
        assertNotNull(str);
        assertTrue(str.contains("KnowledgeBase"));
    }
}
