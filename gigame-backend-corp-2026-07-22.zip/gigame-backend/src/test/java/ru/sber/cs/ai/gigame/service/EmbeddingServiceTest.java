package ru.sber.cs.ai.gigame.service;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;
import ru.sber.cs.ai.gigame.model.Embedding;
import ru.sber.cs.ai.gigame.repository.EmbeddingRepository;

import java.util.List;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class EmbeddingServiceTest {

    @Mock
    private EmbeddingRepository embeddingRepository;

    @InjectMocks
    private EmbeddingService embeddingService;

    @Captor
    private ArgumentCaptor<List<Embedding>> embeddingListCaptor;

    private UUID docId;
    private UUID kbId;

    @BeforeEach
    void setUp() {
        docId = UUID.randomUUID();
        kbId = UUID.randomUUID();
        ReflectionTestUtils.setField(embeddingService, "topK", 5);
    }

    @Test
    void testStoreDocumentChunks() {
        List<String> chunks = List.of("Chunk 1", "Chunk 2");
        List<float[]> embeddings = List.of(new float[1024], new float[1024]);

        when(embeddingRepository.saveAll(anyList())).thenReturn(null);

        embeddingService.storeDocumentChunks(docId, chunks, embeddings);

        verify(embeddingRepository).saveAll(embeddingListCaptor.capture());
        List<Embedding> saved = embeddingListCaptor.getValue();
        assertEquals(2, saved.size());
        assertEquals("doc", saved.get(0).getCollectionType());
        assertEquals(docId, saved.get(0).getCollectionId());
    }

    @Test
    void testStoreKBChunks() {
        UUID sourceDocId = UUID.randomUUID();
        List<String> chunks = List.of("Chunk 1", "Chunk 2");
        List<float[]> embeddings = List.of(new float[1024], new float[1024]);

        when(embeddingRepository.saveAll(anyList())).thenReturn(null);

        embeddingService.storeKBChunks(kbId, sourceDocId, chunks, embeddings);

        verify(embeddingRepository).saveAll(embeddingListCaptor.capture());
        List<Embedding> saved = embeddingListCaptor.getValue();
        assertEquals(2, saved.size());
        assertEquals("kb", saved.get(0).getCollectionType());
        assertEquals(kbId, saved.get(0).getCollectionId());
        assertEquals(sourceDocId, saved.get(0).getSourceDocumentId());
    }

    @Test
    void testSearchSimilar() {
        float[] queryVector = new float[1024];
        List<String> expectedResult = List.of("Similar chunk 1", "Similar chunk 2");
        when(embeddingRepository.searchSimilar(eq("doc"), eq(docId), any(float[].class), anyInt()))
                .thenReturn(expectedResult);

        List<String> result = embeddingService.searchSimilar("doc", docId, queryVector);

        assertNotNull(result);
        assertEquals(2, result.size());
        assertEquals(expectedResult, result);
        verify(embeddingRepository).searchSimilar(eq("doc"), eq(docId), any(float[].class), eq(5));
    }

    @Test
    void testDeleteDocumentChunks() {
        doNothing().when(embeddingRepository).deleteByCollection("doc", docId);

        embeddingService.deleteDocumentChunks(docId);

        verify(embeddingRepository).deleteByCollection("doc", docId);
    }

    @Test
    void testDeleteKBDocumentChunks() {
        doNothing().when(embeddingRepository).deleteKBDocumentChunks(kbId, docId);

        embeddingService.deleteKBDocumentChunks(kbId, docId);

        verify(embeddingRepository).deleteKBDocumentChunks(kbId, docId);
    }

    @Test
    void testDeleteKBCollection() {
        doNothing().when(embeddingRepository).deleteByCollection("kb", kbId);

        embeddingService.deleteKBCollection(kbId);

        verify(embeddingRepository).deleteByCollection("kb", kbId);
    }

    @Test
    void testStoreDocumentChunks_withEmptyLists() {
        List<String> chunks = List.of();
        List<float[]> embeddings = List.of();

        when(embeddingRepository.saveAll(anyList())).thenReturn(null);

        embeddingService.storeDocumentChunks(docId, chunks, embeddings);

        verify(embeddingRepository).saveAll(anyList());
    }

    @Test
    void testStoreKBChunks_withEmptyLists() {
        UUID sourceDocId = UUID.randomUUID();
        List<String> chunks = List.of();
        List<float[]> embeddings = List.of();

        when(embeddingRepository.saveAll(anyList())).thenReturn(null);

        embeddingService.storeKBChunks(kbId, sourceDocId, chunks, embeddings);

        verify(embeddingRepository).saveAll(anyList());
    }
}
