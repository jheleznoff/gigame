package ru.sber.cs.ai.gigame.config;

import org.junit.jupiter.api.Test;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;

import java.lang.annotation.Annotation;

import static org.assertj.core.api.Assertions.assertThat;

class PostgresVectorConfigTest {

    @Test
    void configShouldBeConfigurationClass() {
        assertThat(PostgresVectorConfig.class.getAnnotation(Configuration.class))
                .isNotNull();
    }

    @Test
    void configShouldHaveEnableJpaAuditing() {
        Annotation[] annotations = PostgresVectorConfig.class.getAnnotations();
        boolean hasEnableJpaAuditing = false;

        for (Annotation annotation : annotations) {
            if (annotation instanceof EnableJpaAuditing) {
                hasEnableJpaAuditing = true;
                break;
            }
        }

        assertThat(hasEnableJpaAuditing).isTrue();
    }

    @Test
    void configClassShouldExist() {
        assertThat(PostgresVectorConfig.class).isNotNull();
    }
}
