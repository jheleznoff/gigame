package ru.sber.cs.ai.gigame.dto.scenario;

import org.junit.jupiter.api.Test;

import java.time.OffsetDateTime;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

class ScenarioRunStepResponseTest {

    @Test
    void testConstruction_withAllFields() {
        var id = UUID.randomUUID();
        var now = OffsetDateTime.now();
        var input = new ScenarioRunStepInputDataResponse("docs", "prev");
        var output = new ScenarioRunStepOutputDataResponse("result", null);
        var dto = new ScenarioRunStepResponse(id, "node1", "task", "completed",
                input, output, "prompt text", 150, now, now);
        assertEquals(id, dto.id());
        assertEquals("node1", dto.nodeId());
        assertEquals("task", dto.nodeType());
        assertEquals("completed", dto.status());
        assertEquals("docs", dto.inputData().documentsText());
        assertEquals("result", dto.outputData().result());
        assertEquals("prompt text", dto.promptUsed());
        assertEquals(Integer.valueOf(150), dto.tokensUsed());
        assertEquals(now, dto.startedAt());
        assertEquals(now, dto.completedAt());
    }

    @Test
    void testConstruction_withNullFields() {
        var dto = new ScenarioRunStepResponse(null, null, null, null, null, null, null, null, null, null);
        assertNull(dto.id());
        assertNull(dto.nodeId());
        assertNull(dto.nodeType());
        assertNull(dto.status());
        assertNull(dto.inputData());
        assertNull(dto.outputData());
        assertNull(dto.promptUsed());
        assertNull(dto.tokensUsed());
        assertNull(dto.startedAt());
        assertNull(dto.completedAt());
    }
}