package ru.sber.cs.ai.gigame.utils;

import org.apache.commons.compress.archivers.sevenz.SevenZArchiveEntry;
import org.apache.commons.compress.archivers.sevenz.SevenZOutputFile;
import org.apache.commons.compress.utils.SeekableInMemoryByteChannel;
import org.junit.jupiter.api.Test;
import ru.sber.cs.ai.gigame.exception.FileException;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

class ZipExtractorTest {

    private static byte[] zipOf(Map<String, byte[]> entries) throws IOException {
        return zipOf(entries, StandardCharsets.UTF_8);
    }

    private static byte[] zipOf(Map<String, byte[]> entries, Charset charset) throws IOException {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        try (ZipOutputStream zos = new ZipOutputStream(bos, charset)) {
            for (var e : entries.entrySet()) {
                zos.putNextEntry(new ZipEntry(e.getKey()));
                zos.write(e.getValue());
                zos.closeEntry();
            }
        }
        return bos.toByteArray();
    }

    private static byte[] sevenZOf(Map<String, byte[]> entries) throws IOException {
        SeekableInMemoryByteChannel channel = new SeekableInMemoryByteChannel();
        try (SevenZOutputFile szf = new SevenZOutputFile(channel)) {
            for (var e : entries.entrySet()) {
                SevenZArchiveEntry entry = new SevenZArchiveEntry();
                entry.setName(e.getKey());
                entry.setDirectory(false);
                szf.putArchiveEntry(entry);
                szf.write(e.getValue());
                szf.closeArchiveEntry();
            }
        }
        return Arrays.copyOf(channel.array(), (int) channel.size());
    }

    @Test
    void extract_7z_returnsDocumentsWithArchivePathNames() throws IOException {
        Map<String, byte[]> entries = new LinkedHashMap<>();
        entries.put("Договор 123/договор.pdf", "pdf-bytes".getBytes());
        entries.put("Договор 123/Signature(01).sig", "junk".getBytes());
        var result = ZipExtractor.extract("архив.7z", sevenZOf(entries));

        assertEquals(1, result.files().size());
        assertEquals("архив.7z/Договор 123/договор.pdf", result.files().get(0).name());
        assertEquals("pdf-bytes", new String(result.files().get(0).content()));
        assertEquals(1, result.skippedCount());
    }

    @Test
    void extract_7zNestedInZip_unpacked() throws IOException {
        byte[] inner7z = sevenZOf(Map.of("акт.pdf", "inner-act".getBytes()));
        Map<String, byte[]> entries = new LinkedHashMap<>();
        entries.put("Спецификация/вложенный.7z", inner7z);
        entries.put("договор.pdf", "outer".getBytes());
        var result = ZipExtractor.extract("внешний.zip", zipOf(entries));

        assertEquals(2, result.files().size());
        assertTrue(result.files().stream()
                .anyMatch(f -> f.name().equals("внешний.zip/Спецификация/вложенный.7z/акт.pdf")));
    }

    @Test
    void extract_zipNestedIn7z_unpacked() throws IOException {
        byte[] innerZip = zipOf(Map.of("акт.pdf", "inner-act".getBytes()));
        var result = ZipExtractor.extract("внешний.7z",
                sevenZOf(Map.of("вложенный.zip", innerZip)));

        assertEquals(1, result.files().size());
        assertEquals("внешний.7z/вложенный.zip/акт.pdf", result.files().get(0).name());
    }

    @Test
    void extract_corrupted7z_throwsFileException() {
        byte[] notA7z = "это не 7z-архив".getBytes();
        assertThrows(FileException.class, () -> ZipExtractor.extract("bad.7z", notA7z));
    }

    @Test
    void extract_returnsDocumentsWithArchivePathNames() throws IOException {
        Map<String, byte[]> entries = new LinkedHashMap<>();
        entries.put("Договор 123/договор.pdf", "pdf-bytes".getBytes());
        entries.put("Договор 123/Спецификация 1/акт.docx", "docx-bytes".getBytes());
        var result = ZipExtractor.extract("архив.zip", zipOf(entries));

        assertEquals(2, result.files().size());
        assertEquals("архив.zip/Договор 123/договор.pdf", result.files().get(0).name());
        assertEquals("архив.zip/Договор 123/Спецификация 1/акт.docx", result.files().get(1).name());
        assertEquals("pdf-bytes", new String(result.files().get(0).content()));
    }

    @Test
    void extract_decodesCp866EntryNames() throws IOException {
        var result = ZipExtractor.extract("a.zip",
                zipOf(Map.of("Договор № 42/акт.pdf", "x".getBytes()), Charset.forName("CP866")));

        assertEquals(1, result.files().size());
        assertEquals("a.zip/Договор № 42/акт.pdf", result.files().get(0).name());
    }

    @Test
    void extract_filtersJunkFiles() throws IOException {
        Map<String, byte[]> entries = new LinkedHashMap<>();
        entries.put("договор.pdf", "keep".getBytes());
        entries.put("Signature(01).hash.sig", "junk".getBytes());
        entries.put("Signature(02).sig", "junk".getBytes());
        entries.put("подпись.sgn", "junk".getBytes());
        entries.put("договор.pdf.hash", "junk".getBytes());
        entries.put("договор.pdf.hash2012", "junk".getBytes());
        entries.put("Passport(01).txt", "junk".getBytes());
        entries.put("папка/Протокол передачи документа в электронном виде.pdf", "junk".getBytes());
        entries.put("DP_PDPOL_квитанция.xml", "junk".getBytes());
        entries.put("ON_NSCHFDOPPOK_подтверждение.xml", "junk".getBytes());
        entries.put("что-то.exe", "junk".getBytes());
        var result = ZipExtractor.extract("a.zip", zipOf(entries));

        assertEquals(1, result.files().size());
        assertEquals("a.zip/договор.pdf", result.files().get(0).name());
        assertEquals(10, result.skippedCount());
    }

    @Test
    void extract_keepsUpdXmlAndPrintedForm() throws IOException {
        Map<String, byte[]> entries = new LinkedHashMap<>();
        entries.put("ON_NSCHFDOPPR_2BK-упд.xml", "upd".getBytes());
        entries.put("папка/Печатная форма.pdf", "print".getBytes());
        var result = ZipExtractor.extract("a.zip", zipOf(entries));

        assertEquals(2, result.files().size());
        assertEquals(0, result.skippedCount());
    }

    @Test
    void extract_unpacksNestedZip() throws IOException {
        byte[] inner = zipOf(Map.of("акт.pdf", "inner-act".getBytes()));
        Map<String, byte[]> entries = new LinkedHashMap<>();
        entries.put("Спецификация/вложенный.zip", inner);
        entries.put("договор.pdf", "outer".getBytes());
        var result = ZipExtractor.extract("внешний.zip", zipOf(entries));

        assertEquals(2, result.files().size());
        assertTrue(result.files().stream()
                .anyMatch(f -> f.name().equals("внешний.zip/Спецификация/вложенный.zip/акт.pdf")));
    }

    @Test
    void extract_skipsTooDeeplyNestedZip() throws IOException {
        byte[] level3 = zipOf(Map.of("глубина3.zip",
                zipOf(Map.of("файл.pdf", "deep".getBytes()))));
        byte[] level2 = zipOf(Map.of("глубина2.zip", level3));
        var result = ZipExtractor.extract("верх.zip", zipOf(Map.of("глубина1.zip", level2)));

        // архив на глубине 3 не распаковывается, его содержимое пропущено
        assertFalse(result.files().stream().anyMatch(f -> f.name().endsWith("файл.pdf")));
        assertTrue(result.skippedCount() > 0);
    }

    @Test
    void extract_rejectsTooManyEntries() throws IOException {
        Map<String, byte[]> entries = new LinkedHashMap<>();
        for (int i = 0; i <= ZipExtractor.MAX_ENTRIES; i++) {
            entries.put("f" + i + ".txt", "x".getBytes());
        }
        byte[] zip = zipOf(entries);
        assertThrows(FileException.class, () -> ZipExtractor.extract("big.zip", zip));
    }

    @Test
    void extract_rejectsCorruptedArchive() {
        byte[] notAZip = "это не архив".getBytes();
        assertThrows(FileException.class, () -> ZipExtractor.extract("bad.zip", notAZip));
    }

    @Test
    void isJunk_documentExtensionsAreKept() {
        assertFalse(ZipExtractor.isJunk("договор.pdf"));
        assertFalse(ZipExtractor.isJunk("справка.DOCX"));
        assertFalse(ZipExtractor.isJunk("форма.xlsx"));
        assertFalse(ZipExtractor.isJunk("readme.txt"));
        assertFalse(ZipExtractor.isJunk("ON_NSCHFDOPPR_код.xml"));
        assertTrue(ZipExtractor.isJunk("passport(02).TXT"));
        assertTrue(ZipExtractor.isJunk("прочий.xml"));
        assertTrue(ZipExtractor.isJunk("без-расширения"));
    }
}
