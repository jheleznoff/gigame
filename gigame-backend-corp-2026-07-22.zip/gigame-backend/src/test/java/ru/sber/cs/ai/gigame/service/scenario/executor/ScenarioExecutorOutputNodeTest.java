package ru.sber.cs.ai.gigame.service.scenario.executor;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.springframework.http.codec.ServerSentEvent;
import reactor.core.publisher.FluxSink;
import ru.sber.cs.ai.gigame.dto.scenario.graph.EdgeDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.EdgeDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.GraphDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.PositionDto;
import ru.sber.cs.ai.gigame.service.scenario.enums.ScenarioNodeType;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunGraph;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunNode;

import java.util.List;
import java.util.Map;
import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verifyNoInteractions;

class ScenarioExecutorOutputNodeTest {

    @SuppressWarnings("unchecked")
    private final FluxSink<ServerSentEvent<Map<String, Object>>> sink = mock(FluxSink.class);
    private ScenarioRunNode node;

    private static NodeDto createNode(String id, ScenarioNodeType type, String label, int x, int y) {
        return NodeDto.builder()
                .id(id)
                .type(type.toString())
                .data(NodeDataDto.builder().label(label).build())
                .position(new PositionDto(x, y))
                .build();
    }

    @BeforeEach
    void setUp() {
        NodeDto inputNode = createNode("input-1", ScenarioNodeType.INPUT_NODE, "Input", 100, 100);
        NodeDto outputNode = createNode("output-1", ScenarioNodeType.OUTPUT_NODE, "Output", 300, 100);
        EdgeDto edge = new EdgeDto("edge-1", "input-1", "output-1", new EdgeDataDto(null));
        GraphDataDto graphData = new GraphDataDto(List.of(inputNode, outputNode), List.of(edge));

        node = ScenarioRunNode.fromDto(1, outputNode, new ScenarioRunGraph(graphData));
    }

    @Test
    void testExecute_withNoInputs() {
        ScenarioExecutorOutputNode executor = new ScenarioExecutorOutputNode(node);
        String result = executor.execute(sink);

        assertNotNull(result);
        assertEquals("", result);
        verifyNoInteractions(sink);
    }

    @ParameterizedTest
    @MethodSource("inputProvider")
    void testExecute_withSingleInput_returnsInput(String input, String expected) {
        node.getInput().add(input);

        ScenarioExecutorOutputNode executor = new ScenarioExecutorOutputNode(node);
        String result = executor.execute(sink);

        assertNotNull(result);
        assertEquals(expected, result);
    }

    @ParameterizedTest
    @MethodSource("multipleInputProvider")
    void testExecute_withMultipleInputs_returnsJoinedResults(List<String> inputs, String expected) {
        node.getInput().addAll(inputs);

        ScenarioExecutorOutputNode executor = new ScenarioExecutorOutputNode(node);
        String result = executor.execute(sink);

        assertNotNull(result);
        assertEquals(expected, result);
    }

    @Test
    void testExecute_storesOutputInNode() {
        node.getInput().add("Test input");

        ScenarioExecutorOutputNode executor = new ScenarioExecutorOutputNode(node);
        executor.execute(sink);

        assertTrue(node.getOutput().contains("Test input"));
    }

    @Test
    void testExecute_multipleInputs_storesAllInNode() {
        node.getInput().addAll(List.of("First", "Second", "Third"));

        ScenarioExecutorOutputNode executor = new ScenarioExecutorOutputNode(node);
        executor.execute(sink);

        assertEquals(3, node.getOutput().size());
        assertTrue(node.getOutput().contains("First"));
        assertTrue(node.getOutput().contains("Second"));
        assertTrue(node.getOutput().contains("Third"));
    }

    static Stream<Arguments> inputProvider() {
        return Stream.of(
                Arguments.arguments("Input result", "Input result"),
                Arguments.arguments("   ", "   "),
                Arguments.arguments("Test text", "Test text")
        );
    }

    static Stream<Arguments> multipleInputProvider() {
        return Stream.of(
                Arguments.arguments(List.of("First result", "Second result"), "First result\n\nSecond result"),
                Arguments.arguments(List.of("A", "B", "C"), "A\n\nB\n\nC"),
                Arguments.arguments(List.of("Result A", "Result B"), "Result A\n\nResult B")
        );
    }
}