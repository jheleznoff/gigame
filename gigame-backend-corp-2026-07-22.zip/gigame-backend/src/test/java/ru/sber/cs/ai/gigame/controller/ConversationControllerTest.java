package ru.sber.cs.ai.gigame.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.reactive.server.WebTestClient;
import ru.sber.cs.ai.gigame.TestConfiguration;
import ru.sber.cs.ai.gigame.dto.chat.ConversationCreate;
import ru.sber.cs.ai.gigame.dto.chat.ConversationResponse;
import ru.sber.cs.ai.gigame.dto.chat.ConversationWithMessages;
import ru.sber.cs.ai.gigame.service.ChatService;
import ru.sber.cs.ai.gigame.service.DocsTextCacheService;
import ru.sber.cs.ai.gigame.service.DocumentService;

import java.time.OffsetDateTime;
import java.util.List;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = {ConversationController.class, TestConfiguration.class})
@WebFluxTest(controllers = ConversationController.class)
@SuppressWarnings("unused")
class ConversationControllerTest {

    @MockitoBean
    DocsTextCacheService docsTextCacheService;
    @Autowired
    private WebTestClient webClient;
    @Autowired
    private ObjectMapper objectMapper;
    @MockitoBean
    private ChatService chatService;
    @MockitoBean
    private DocumentService documentService;
    private UUID userId;
    private UUID conversationId;
    private ConversationResponse conversationResponse;

    @BeforeEach
    void setUp() {
        userId = UUID.randomUUID();
        conversationId = UUID.randomUUID();
        conversationResponse = new ConversationResponse(
                conversationId,
                "Test Conversation",
                null,
                List.of(),
                null,
                null,
                OffsetDateTime.now(),
                OffsetDateTime.now()
        );
        ReflectionTestUtils.setField(chatService, "contextCharLimit", 200000);
        ReflectionTestUtils.setField(chatService, "maxHistoryMessages", 20);
        ReflectionTestUtils.setField(chatService, "maxAutoTitleLength", 100);
        ReflectionTestUtils.setField(documentService, "charLimit", 12000);
    }

    @Test
    void testListConversations() {
        when(chatService.getConversations(any(), eq(""))).thenReturn(List.of(conversationResponse));

        webClient.get()
                .uri("/api/conversations")
                .header("X-UserId", userId.toString())
                .accept(MediaType.APPLICATION_JSON)
                .exchange()
                .expectStatus().isOk()
                .expectHeader().contentType(MediaType.APPLICATION_JSON)
                .expectBody(List.class)
                .value(result -> {
                    assertNotNull(result);
                    assertEquals(1, result.size());
                });
    }

    @Test
    void testListConversations_withSearch() {
        when(chatService.getConversations(any(), eq("test"))).thenReturn(List.of(conversationResponse));

        webClient.get()
                .uri(uriBuilder -> uriBuilder
                        .path("/api/conversations")
                        .queryParam("q", "test")
                        .build())
                .header("X-UserId", userId.toString())
                .accept(MediaType.APPLICATION_JSON)
                .exchange()
                .expectStatus().isOk();
    }

    @Test
    void testCreateConversation() {
        ConversationCreate body = new ConversationCreate("New Conversation", null, null, null, null);
        when(chatService.createConversation(any(), any(ConversationCreate.class)))
                .thenReturn(conversationResponse);

        webClient.post()
                .uri("/api/conversations")
                .header("X-UserId", userId.toString())
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(body)
                .exchange()
                .expectStatus().isCreated()
                .expectHeader().contentType(MediaType.APPLICATION_JSON)
                .expectBody(ConversationResponse.class);
    }

    @Test
    void testGetConversation() {
        ConversationWithMessages result = new ConversationWithMessages(
                conversationId,
                "Test Conversation",
                null,
                List.of(),
                null,
                null,
                OffsetDateTime.now(),
                OffsetDateTime.now(),
                List.of()
        );

        when(chatService.getConversation(any(), eq(conversationId))).thenReturn(result);

        webClient.get()
                .uri("/api/conversations/{id}", conversationId)
                .header("X-UserId", userId.toString())
                .accept(MediaType.APPLICATION_JSON)
                .exchange()
                .expectStatus().isOk()
                .expectHeader().contentType(MediaType.APPLICATION_JSON)
                .expectBody(ConversationWithMessages.class);
    }

    @Test
    void testDeleteConversation() {
        doNothing().when(chatService).deleteConversation(any(), eq(conversationId));

        webClient.delete()
                .uri("/api/conversations/{id}", conversationId)
                .header("X-UserId", userId.toString())
                .exchange()
                .expectStatus().isEqualTo(204);
    }

    @Test
    void testUpdateConversation() {
        ConversationCreate body = new ConversationCreate("Updated Title", null, null, null, null);
        when(chatService.updateConversation(any(), eq(conversationId), any(ConversationCreate.class)))
                .thenReturn(conversationResponse);

        webClient.put()
                .uri("/api/conversations/{id}", conversationId)
                .header("X-UserId", userId.toString())
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(body)
                .exchange()
                .expectStatus().isOk()
                .expectHeader().contentType(MediaType.APPLICATION_JSON)
                .expectBody(ConversationResponse.class);
    }
}
