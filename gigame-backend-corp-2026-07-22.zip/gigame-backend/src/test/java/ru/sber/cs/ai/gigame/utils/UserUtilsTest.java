package ru.sber.cs.ai.gigame.utils;

import org.junit.jupiter.api.Test;
import ru.sber.cs.ai.gigame.exception.AccessDeniedException;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

class UserUtilsTest {

    @Test
    void testGetUserId_withNull_returnsAnonymous() {
        String result = UserUtils.getUserId(null);
        assertEquals("anonymous", result);
    }

    @Test
    void testGetUserId_withEmptyString_returnsAnonymous() {
        String result = UserUtils.getUserId("");
        assertEquals("anonymous", result);
    }

    @Test
    void testGetUserId_withValidUserId_returnsUserId() {
        String result = UserUtils.getUserId("user123");
        assertEquals("user123", result);
    }

    @Test
    void testCheckUserId_withMatchingIds_doesNotThrow() {
        assertDoesNotThrow(() -> UserUtils.checkUserId("user123", "user123"));
    }

    @Test
    void testCheckUserId_withNonMatchingIds_throwsAccessDeniedException() {
        assertThrows(AccessDeniedException.class,
                () -> UserUtils.checkUserId("user123", "user456"));
    }

    @Test
    void testCheckUserId_withNullUserId_andNonMatchingActual_throwsAccessDeniedException() {
        assertThrows(AccessDeniedException.class,
                () -> UserUtils.checkUserId(null, "user456"));
    }

    @Test
    void testCheckUserId_withNullUserId_andMatchingActual_doesNotThrow() {
        assertDoesNotThrow(() -> UserUtils.checkUserId(null, "anonymous"));
    }
}
