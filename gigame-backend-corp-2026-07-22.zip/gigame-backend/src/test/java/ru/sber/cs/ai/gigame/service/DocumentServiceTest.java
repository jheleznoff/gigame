package ru.sber.cs.ai.gigame.service;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.xslf.usermodel.XMLSlideShow;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.core.io.buffer.DataBuffer;
import org.springframework.core.io.buffer.DefaultDataBuffer;
import org.springframework.core.io.buffer.DefaultDataBufferFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.codec.multipart.FilePart;
import org.springframework.test.util.ReflectionTestUtils;
import reactor.core.publisher.Flux;
import ru.sber.cs.ai.gigame.exception.FileException;
import ru.sber.cs.ai.gigame.exception.NotFoundException;
import ru.sber.cs.ai.gigame.model.Document;
import ru.sber.cs.ai.gigame.repository.DocumentRepository;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.Optional;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class DocumentServiceTest {

    @Mock
    private DocumentRepository documentRepository;

    @Mock
    private EmbeddingService embeddingService;

    @Mock
    private DocumentIndexService indexService;

    @InjectMocks
    private DocumentService documentService;

    private Document document;

    @BeforeEach
    void setUp() {
        document = new Document();
        document.setId(UUID.randomUUID());
        document.setUserId("user1");
        document.setExtractedText("Test content");
        ReflectionTestUtils.setField(documentService, "charLimit", 12000);
    }

    @Test
    void testParseText_PDF() throws Exception {
        InputStream inputStream = getClass().getClassLoader().getResourceAsStream("test.pdf");
        assertNotNull(inputStream, "Файл test.pdf не найден в resources");
        String result = documentService.parseText(inputStream, "pdf");
        assertEquals("Это тестовый файл для проверки парсинга \n", result);
    }

    @Test
    void testParseText_DOCX() throws Exception {
        var expected = """
                Заголовок
                Это тестовый файл для проверки парсинга
                
                [ < 1 |  | 3 >
                < Нужна | Для проверки | Третий
                [ < Вложенная | Таблица >
                < Первый | Второй > ]
                столбец > ]
                
                Таблица с переменными
                [ < 1 | 15 919 275,00 | Рубль > ]
                
                Жирный текст после таблицы.
                Курсив тоже нужно проверить.""";
        InputStream inputStream = getClass().getClassLoader().getResourceAsStream("test.docx");
        assertNotNull(inputStream, "Файл test.docx не найден в resources");
        String result = documentService.parseText(inputStream, "docx");
        assertEquals(expected, result);
    }

    @Test
    void testParseText_XLSX() throws Exception {
        InputStream inputStream = getClass().getClassLoader().getResourceAsStream("test.xlsx");
        assertNotNull(inputStream, "Файл test.xlsx не найден в resources");
        String result = documentService.parseText(inputStream, "xlsx");
        assertEquals("это | тестовый | документ | для | проверки | парсинга\n1 | 2 |  | 4 | 5 | 12\n", result);
    }

    @Test
    void testParseText_TXT() throws Exception {
        InputStream inputStream = getClass().getClassLoader().getResourceAsStream("test.txt");
        assertNotNull(inputStream, "Файл test.txt не найден в resources");
        String result = documentService.parseText(inputStream, "txt");
        assertEquals("Это тестовый документ для проверки парсинга", result);
    }

    @Test
    void testParseText_withUnsupportedType_throwsException() {
        InputStream inputStream = new ByteArrayInputStream("test".getBytes());

        assertThrows(IllegalArgumentException.class,
                () -> documentService.parseText(inputStream, "unsupported"));
    }

    @Test
    void testDeleteDocument() {
        when(documentRepository.findById(any())).thenReturn(Optional.of(document));
        doNothing().when(embeddingService).deleteDocumentChunks(any());

        documentService.deleteDocument(document.getId());

        verify(embeddingService).deleteDocumentChunks(document.getId());
        verify(documentRepository).delete(document);
    }

    @Test
    void testDeleteDocument_withNonExistingDocument_throwsNotFoundException() {
        when(documentRepository.findById(any())).thenReturn(Optional.empty());
        var uuid = UUID.randomUUID();
        assertThrows(NotFoundException.class,
                () -> documentService.deleteDocument(uuid));
    }

    @Test
    void testUploadDocument() {
        String userId = "user1";
        String filename = "test.txt";
        String content = "Test document content";
        byte[] bytes = content.getBytes();

        DefaultDataBuffer dataBuffer = DefaultDataBufferFactory.sharedInstance.wrap(bytes);
        Flux<DataBuffer> flux = Flux.just(dataBuffer);

        FilePart filePart = mock(FilePart.class);
        HttpHeaders headersMock = mock(HttpHeaders.class);

        lenient().when(filePart.filename()).thenReturn(filename);
        lenient().when(filePart.name()).thenReturn("file");
        lenient().when(filePart.headers()).thenReturn(headersMock);
        lenient().when(headersMock.getContentLength()).thenReturn(100L);
        lenient().when(filePart.content()).thenReturn(flux);

        Document savedDoc = new Document();
        savedDoc.setId(UUID.randomUUID());
        savedDoc.setFilename(filename);
        savedDoc.setContentType("txt");
        savedDoc.setExtractedText(content);
        savedDoc.setSizeBytes(bytes.length);
        savedDoc.setUserId(userId);

        when(documentRepository.save(any())).thenReturn(savedDoc);
        doNothing().when(indexService).indexDocument(any(), any());

        ReflectionTestUtils.setField(documentService, "charLimit", 10);

        DocumentService.DocumentResponse result = documentService.uploadDocument(filePart, userId);

        assertNotNull(result);
        assertEquals(filename, result.filename());
        assertEquals("txt", result.contentType());
        assertEquals(bytes.length, result.sizeBytes());
        assertEquals(content.length(), result.textLength());
        verify(documentRepository).save(any(Document.class));
        verify(indexService).indexDocument(savedDoc.getId(), content);
    }

    @Test
    void testUploadDocument_withLongDocument_triggersIndexing() {
        String userId = "user1";
        String filename = "long.txt";
        String longContent = "A".repeat(15000);
        byte[] bytes = longContent.getBytes();

        DefaultDataBuffer dataBuffer = DefaultDataBufferFactory.sharedInstance.wrap(bytes);
        Flux<DataBuffer> flux = Flux.just(dataBuffer);

        FilePart filePart = mock(FilePart.class);
        HttpHeaders headersMock = mock(HttpHeaders.class);

        lenient().when(filePart.filename()).thenReturn(filename);
        lenient().when(filePart.name()).thenReturn("file");
        lenient().when(filePart.headers()).thenReturn(headersMock);
        lenient().when(headersMock.getContentLength()).thenReturn(100L);
        lenient().when(filePart.content()).thenReturn(flux);

        Document savedDoc = new Document();
        savedDoc.setId(UUID.randomUUID());
        savedDoc.setFilename(filename);
        savedDoc.setContentType("txt");
        savedDoc.setExtractedText(longContent);
        savedDoc.setSizeBytes(bytes.length);
        savedDoc.setUserId(userId);

        when(documentRepository.save(any())).thenReturn(savedDoc);
        doNothing().when(indexService).indexDocument(any(), any());

        DocumentService.DocumentResponse result = documentService.uploadDocument(filePart, userId);

        assertNotNull(result);
        assertEquals(15000, result.textLength());
        verify(indexService).indexDocument(savedDoc.getId(), longContent);
    }

    @Test
    void testUploadDocument_withShortDocument_skipsIndexing() {
        String userId = "user1";
        String filename = "short.txt";
        String shortContent = "Short";
        byte[] bytes = shortContent.getBytes();

        DefaultDataBuffer dataBuffer = DefaultDataBufferFactory.sharedInstance.wrap(bytes);
        Flux<DataBuffer> flux = Flux.just(dataBuffer);

        FilePart filePart = mock(FilePart.class);
        HttpHeaders headersMock = mock(HttpHeaders.class);

        lenient().when(filePart.filename()).thenReturn(filename);
        lenient().when(filePart.name()).thenReturn("file");
        lenient().when(filePart.headers()).thenReturn(headersMock);
        lenient().when(headersMock.getContentLength()).thenReturn(100L);
        lenient().when(filePart.content()).thenReturn(flux);

        Document savedDoc = new Document();
        savedDoc.setId(UUID.randomUUID());
        savedDoc.setFilename(filename);
        savedDoc.setContentType("txt");
        savedDoc.setExtractedText(shortContent);
        savedDoc.setSizeBytes(bytes.length);
        savedDoc.setUserId(userId);

        when(documentRepository.save(any())).thenReturn(savedDoc);

        DocumentService.DocumentResponse result = documentService.uploadDocument(filePart, userId);

        assertNotNull(result);
        assertEquals(5, result.textLength());
        verify(indexService, never()).indexDocument(any(), any());
    }

    @Test
    void testUploadDocument_withNullFilename() {
        String userId = "user1";
        String content = "Test content";
        byte[] bytes = content.getBytes();

        DefaultDataBuffer dataBuffer = DefaultDataBufferFactory.sharedInstance.wrap(bytes);
        Flux<DataBuffer> flux = Flux.just(dataBuffer);

        FilePart filePart = mock(FilePart.class);
        HttpHeaders headersMock = mock(HttpHeaders.class);

        lenient().when(filePart.filename()).thenReturn("");
        lenient().when(filePart.name()).thenReturn("file");
        lenient().when(filePart.headers()).thenReturn(headersMock);
        lenient().when(headersMock.getContentLength()).thenReturn((long) bytes.length);
        lenient().when(filePart.content()).thenReturn(flux);

        assertThrows(FileException.class,
                () -> documentService.uploadDocument(filePart, userId));
    }

    @Test
    void testUploadDocument_withParsingError_throwsFileException() {
        String userId = "user1";
        String filename = "test.xyz";

        FilePart filePart = mock(FilePart.class);
        HttpHeaders headersMock = mock(HttpHeaders.class);

        lenient().when(filePart.filename()).thenReturn(filename);
        lenient().when(filePart.name()).thenReturn("file");
        lenient().when(filePart.headers()).thenReturn(headersMock);
        lenient().when(headersMock.getContentLength()).thenReturn(100L);

        // Simulate content stream (optional - depends on whether parseText is called)
        DefaultDataBuffer dataBuffer = DefaultDataBufferFactory.sharedInstance.allocateBuffer(0);
        lenient().when(filePart.content()).thenReturn(Flux.just(dataBuffer));

        assertThrows(FileException.class,
                () -> documentService.uploadDocument(filePart, userId));
    }

    @Test
    void testParseText_XLS_binary() throws Exception {
        // Бинарный XLS генерируется на лету — раньше .xls направлялся в XLSX-парсер и падал
        var out = new java.io.ByteArrayOutputStream();
        try (var wb = new HSSFWorkbook()) {
            var sheet = wb.createSheet("Данные");
            var row = sheet.createRow(0);
            row.createCell(0).setCellValue("Поставщик");
            row.createCell(1).setCellValue("Цена");
            var row2 = sheet.createRow(1);
            row2.createCell(0).setCellValue("Оптима");
            row2.createCell(1).setCellValue(1234.5);
            wb.write(out);
        }
        String result = documentService.parseText(new ByteArrayInputStream(out.toByteArray()), "xls");
        assertNotNull(result);
        assertEquals(true, result.contains("Поставщик | Цена"));
        assertEquals(true, result.contains("Оптима"));
    }

    @Test
    void testParseText_PPTX() throws Exception {
        var out = new java.io.ByteArrayOutputStream();
        try (var ppt = new XMLSlideShow()) {
            var slide = ppt.createSlide();
            var box = slide.createTextBox();
            box.setAnchor(new java.awt.Rectangle(50, 50, 400, 100));
            box.setText("Заголовок презентации");
            var slide2 = ppt.createSlide();
            var box2 = slide2.createTextBox();
            box2.setAnchor(new java.awt.Rectangle(50, 50, 400, 100));
            box2.setText("Второй слайд");
            var table = slide2.createTable();
            table.setAnchor(new java.awt.Rectangle(50, 200, 400, 100));
            var headerRow = table.addRow();
            headerRow.addCell().setText("Колонка 1");
            headerRow.addCell().setText("Колонка 2");
            var dataRow = table.addRow();
            dataRow.addCell().setText("Значение 1");
            dataRow.addCell().setText("Значение 2");
            ppt.write(out);
        }
        String result = documentService.parseText(new ByteArrayInputStream(out.toByteArray()), "pptx");
        assertNotNull(result);
        assertEquals(true, result.contains("=== Слайд 1 ==="));
        assertEquals(true, result.contains("Заголовок презентации"));
        assertEquals(true, result.contains("=== Слайд 2 ==="));
        assertEquals(true, result.contains("Второй слайд"));
    }

}
