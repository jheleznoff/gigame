package ru.sber.cs.ai.gigame.service.scenario.graph;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

class ScenarioRunDocTest {

    @Test
    void testConstructor_withTextAndFilename() {
        var doc = new ScenarioRunDoc("test.txt", "content");
        assertEquals("test.txt", doc.getFilename());
        assertEquals("content", doc.getText());
        assertNull(doc.getDocClass());
    }

    @Test
    void testConstructor_withNullValues() {
        var doc = new ScenarioRunDoc(null, null);
        assertNull(doc.getFilename());
        assertNull(doc.getText());
        assertNull(doc.getDocClass());
    }

    @Test
    void testSetDocClass() {
        var doc = new ScenarioRunDoc("doc.txt", "text");
        assertNull(doc.getDocClass());

        doc.setDocClass("ТЗ");
        assertEquals("ТЗ", doc.getDocClass());

        doc.setDocClass(null);
        assertNull(doc.getDocClass());
    }
}