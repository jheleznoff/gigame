package ru.sber.cs.ai.gigame.dto.scenario.graph;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

class NodeDtoTest {

    @Test
    void testConstruction_withAllFields() {
        var data = new NodeDataDto("label", "prompt", null, null, null, "all", null, null, null, null, null, null, null);
        var pos = new PositionDto(100, 200);
        var measured = new MeasuredDto(300, 150);

        var dto = new NodeDto("n1", "input", data, pos, measured);

        assertEquals("n1", dto.id());
        assertEquals("input", dto.type());
        assertEquals("label", dto.data().label());
        assertEquals("prompt", dto.data().prompt());
        assertEquals(100, dto.position().x());
        assertEquals(200, dto.position().y());
        assertEquals(300, dto.measured().width());
        assertEquals(150, dto.measured().height());
    }

    @Test
    void testConstruction_withMinimalFields() {
        var dto = new NodeDto("n1", "input", null, null, null);
        assertEquals("n1", dto.id());
        assertEquals("input", dto.type());
        assertNull(dto.data());
        assertNull(dto.position());
        assertNull(dto.measured());
    }

    @Test
    void testBuilder() {
        var dto = NodeDto.builder()
                .id("n1")
                .type("processing")
                .data(new NodeDataDto("Test", null, null, null, null, null, null, null, null, null, null, null, null))
                .position(new PositionDto(50, 50))
                .build();

        assertEquals("n1", dto.id());
        assertEquals("processing", dto.type());
        assertEquals("Test", dto.data().label());
        assertEquals(50, dto.position().x());
    }
}