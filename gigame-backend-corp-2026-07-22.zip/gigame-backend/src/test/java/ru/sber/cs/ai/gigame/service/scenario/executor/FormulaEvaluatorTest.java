package ru.sber.cs.ai.gigame.service.scenario.executor;

import org.junit.jupiter.api.Test;
import ru.sber.cs.ai.gigame.exception.ScenarioException;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertInstanceOf;
import static org.junit.jupiter.api.Assertions.assertThrows;

/**
 * Тесты {@link FormulaEvaluator}: вычисление формул в стиле Excel для узла «Расчёт».
 * <p>
 * Покрытие: арифметика, сравнения, строки, функции (в т.ч. агрегатные, ЗНАЧ, ВПР),
 * ошибки (неизвестная переменная, деление на ноль, синтаксис).
 */
class FormulaEvaluatorTest {

    // ================================================================
    // Простая арифметика
    // ================================================================

    @Test
    void testSimpleAddition() {
        assertEval("2 + 3", "5");
    }

    @Test
    void testSimpleSubtraction() {
        assertEval("10 - 4", "6");
    }

    @Test
    void testSimpleMultiplication() {
        assertEval("3 * 4", "12");
    }

    @Test
    void testSimpleDivision() {
        assertEval("10 / 2", "5");
    }

    @Test
    void testMultiplicationSign() {
        assertEval("3 × 4", "12");
    }

    @Test
    void testDivisionSign() {
        assertEval("10 ÷ 2", "5");
    }

    @Test
    void testUnaryMinus() {
        assertEval("-5 + 3", "-2");
    }

    @Test
    void testNestedUnaryMinus() {
        assertEval("--5", "5");
    }

    @Test
    void testParentheses() {
        assertEval("(2 + 3) * 4", "20");
    }

    @Test
    void testOperatorPrecedence() {
        assertEval("2 + 3 * 4", "14");
    }

    @Test
    void testDecimalSeparatorWithComma() {
        assertEval("2,5 + 1,5", "4.0");
    }

    // ================================================================
    // Сравнения
    // ================================================================

    @Test
    void testComparisonLess() {
        assertEval("2 < 3", "1");
    }

    @Test
    void testComparisonLessOrEqual() {
        assertEval("2 <= 2", "1");
    }

    @Test
    void testComparisonGreater() {
        assertEval("3 > 2", "1");
    }

    @Test
    void testComparisonGreaterOrEqual() {
        assertEval("3 >= 3", "1");
    }

    @Test
    void testComparisonEqual() {
        assertEval("2 == 2", "1");
    }

    @Test
    void testComparisonNotEqual() {
        assertEval("2 != 3", "1");
    }

    @Test
    void testComparisonStringEqual() {
        assertEvalRaw("\"abc\" = \"abc\"", BigDecimal.ONE);
    }

    @Test
    void testComparisonStringNotEqual() {
        assertEvalRaw("\"abc\" <> \"xyz\"", BigDecimal.ONE);
    }

    @Test
    void testComparisonStringEqualIgnoreCase() {
        assertEvalRaw("\"ABC\" = \"abc\"", BigDecimal.ONE);
    }

    @Test
    void testComparisonStringNotEqualIgnoreCase() {
        assertEvalRaw("\"ABC\" <> \"ABC\"", BigDecimal.ZERO);
    }

    // ================================================================
    // Функции
    // ================================================================

    @Test
    void testIfTrue() {
        assertEval("ЕСЛИ(1; 10; 20)", "10");
    }

    @Test
    void testIfFalse() {
        assertEval("ЕСЛИ(0; 10; 20)", "20");
    }

    @Test
    void testIfEnglish() {
        assertEval("IF(1; 10; 20)", "10");
    }

    @Test
    void testRound() {
        assertEval("ОКРУГЛ(3.14159; 2)", "3.14");
    }

    @Test
    void testRoundDefault() {
        assertEval("ОКРУГЛ(3.5)", "4");
    }

    @Test
    void testAbs() {
        assertEval("МОДУЛЬ(-10)", "10");
    }

    @Test
    void testAbsEnglish() {
        assertEval("ABS(-10)", "10");
    }

    @Test
    void testNotZero() {
        assertEval("НЕ(1)", "0");
    }

    @Test
    void testNotOne() {
        assertEval("НЕ(0)", "1");
    }

    @Test
    void testAndTrue() {
        assertEval("И(1; 1; 1)", "1");
    }

    @Test
    void testAndFalse() {
        assertEval("И(1; 0; 1)", "0");
    }

    @Test
    void testOrTrue() {
        assertEval("ИЛИ(0; 0; 1)", "1");
    }

    @Test
    void testOrFalse() {
        assertEval("ИЛИ(0; 0; 0)", "0");
    }

    @Test
    void testContainsTrue() {
        assertEval("СОДЕРЖИТ(\"привет мир\"; \"мир\")", "1");
    }

    @Test
    void testContainsFalse() {
        assertEval("СОДЕРЖИТ(\"привет мир\"; \"пока\")", "0");
    }

    @Test
    void testContainsEnglish() {
        assertEval("CONTAINS(\"hello world\"; \"world\")", "1");
    }

    // ================================================================
    // Агрегатные функции
    // ================================================================

    @Test
    void testMin() {
        assertEval("МИН(5; 3; 8; 1)", "1");
    }

    @Test
    void testMax() {
        assertEval("МАКС(5; 3; 8; 1)", "8");
    }

    @Test
    void testSum() {
        assertEval("СУММ(5; 3; 8; 1)", "17");
    }

    @Test
    void testAvg() {
        assertEval("СРЗНАЧ(2; 4; 6)", "4");
    }

    @Test
    void testCount() {
        assertEval("КОЛ(5; 3; 8; 1)", "4");
    }

    @Test
    void testMinEnglish() {
        assertEval("MIN(5; 3; 8; 1)", "1");
    }

    @Test
    void testSumEnglish() {
        assertEval("SUM(5; 3; 8; 1)", "17");
    }

    @Test
    void testAvgEnglish() {
        assertEval("AVG(2; 4; 6)", "4");
    }

    @Test
    void testCountEnglish() {
        assertEval("COUNT(5; 3; 8; 1)", "4");
    }

    @Test
    void testEmptyMinThrows() {
        assertThrows(ScenarioException.class, () -> eval("МИН()"));
    }

    @Test
    void testEmptyMaxThrows() {
        assertThrows(ScenarioException.class, () -> eval("МАКС()"));
    }

    // ================================================================
    // Переменные
    // ================================================================

    @Test
    void testVariable() {
        assertEval("цена + налог", "125", ctx("цена", "100", "налог", "25"));
    }

    @Test
    void testUnknownVariable() {
        assertThrows(ScenarioException.class, () -> eval("неизвестная", Map.of()));
    }

    // ================================================================
    // ЗНАЧ (VAL) — значение по умолчанию
    // ================================================================

    @Test
    void testValWithValue() {
        assertEval("ЗНАЧ(сумма; 0)", "100", ctx("сумма", "100"));
    }

    @Test
    void testValWithDefault() {
        assertEval("ЗНАЧ(неизвестно; 50)", "50");
    }

    // ================================================================
    // ВПР (VLOOKUP)
    // ================================================================

    // ================================================================
    // ВПР (VLOOKUP) — найденные значения
    // ================================================================

    @Test
    void testVlookupFindsValue() {
        var ctx = new FormulaEvaluator.Context() {
            @Override
            public Object variable(String name) {
                return null;
            }

            @Override
            public List<Object> column(String name) {
                return null;
            }

            @Override
            public void warn(String message) {
            }

            @Override
            public Object lookup(String table, String keyColumn, Object keyValue, String valueColumn) {
                if ("таблица1".equals(table) && "ключ".equals(keyColumn) && "знач".equals(valueColumn)
                        && "42".equals(String.valueOf(keyValue))) {
                    return "найдено";
                }
                return null;
            }
        };

        Object result = FormulaEvaluator.evalRaw("ВПР(таблица1; ключ; 42; знач)", ctx);
        assertEquals("найдено", result);
    }

    @Test
    void testVlookupNotFound() {
        assertThrows(ScenarioException.class,
                () -> eval("ВПР(таблица1; ключ; 42; знач)"));
    }

    // ================================================================
    // Агрегат по колонке (диапазон)
    // ================================================================

    @Test
    void testMinByColumn() {
        assertEval("МИН(цена)", "100",
                ctxWithColumns("цена", List.of("100", "200", "300")));
    }

    @Test
    void testMaxByColumn() {
        assertEval("МАКС(цена)", "300",
                ctxWithColumns("цена", List.of("100", "200", "300")));
    }

    @Test
    void testSumByColumn() {
        assertEval("СУММ(цена)", "600",
                ctxWithColumns("цена", List.of("100", "200", "300")));
    }

    @Test
    void testAvgByColumn() {
        assertEval("СРЗНАЧ(цена)", "200",
                ctxWithColumns("цена", List.of("100", "200", "300")));
    }

    @Test
    void testCountByColumn() {
        assertEval("КОЛ(цена)", "3",
                ctxWithColumns("цена", List.of("100", "200", "300")));
    }

    @Test
    void testMinByColumnNameNotExists() {
        assertEval("МИН(цена)", "10",
                ctx("цена", "10"));
    }

    // ================================================================
    // Ошибки
    // ================================================================

    @Test
    void testDivisionByZero() {
        assertThrows(ScenarioException.class, () -> eval("10 / 0"));
    }

    @Test
    void testUnclosedParen() {
        assertThrows(ScenarioException.class, () -> eval("(2 + 3"));
    }

    @Test
    void testUnclosedString() {
        assertThrows(ScenarioException.class, () -> eval("\"не закрыто"));
    }

    @Test
    void testUnknownFunction() {
        assertThrows(ScenarioException.class, () -> eval("НЕСУЩЕСТВУЮЩАЯ(1)"));
    }

    @Test
    void testGarbageAfterExpression() {
        assertThrows(ScenarioException.class, () -> eval("2 + 3 abc"));
    }

    @Test
    void testWrongArgCount() {
        assertThrows(ScenarioException.class, () -> eval("ЕСЛИ(1)"));
    }

    // ================================================================
    // Строковые литералы
    // ================================================================

    @Test
    void testStringLiteral() {
        assertEvalRaw("\"hello\"", "hello");
    }

    @Test
    void testStringLiteralSingleQuote() {
        assertEvalRaw("'hello'", "hello");
    }

    // ================================================================
    // evalRaw — возвращает строку
    // ================================================================

    @Test
    void testEvalRawReturnsString() {
        Object result = FormulaEvaluator.evalRaw("\"abc\"", null);
        assertInstanceOf(String.class, result);
        assertEquals("abc", result);
    }

    @Test
    void testEvalRawReturnsNumber() {
        Object result = FormulaEvaluator.evalRaw("42", null);
        assertInstanceOf(BigDecimal.class, result);
        assertEquals(new BigDecimal("42"), result);
    }

    // ================================================================
    // Хелперы
    // ================================================================

    private static BigDecimal eval(String expr) {
        return FormulaEvaluator.eval(expr, simpleCtx(Map.of()));
    }

    private static BigDecimal eval(String expr, Map<String, Object> vars) {
        return FormulaEvaluator.eval(expr, simpleCtx(vars));
    }

    private static Object evalRaw(String expr) {
        return FormulaEvaluator.evalRaw(expr, simpleCtx(Map.of()));
    }

    private static Object evalRaw(String expr, Map<String, Object> vars) {
        return FormulaEvaluator.evalRaw(expr, simpleCtx(vars));
    }

    private static void assertEval(String expr, String expected) {
        assertEquals(new BigDecimal(expected), FormulaEvaluator.eval(expr, simpleCtx(Map.of())));
    }

    private static void assertEval(String expr, String expected, Map<String, Object> vars) {
        assertEquals(new BigDecimal(expected), FormulaEvaluator.eval(expr, simpleCtx(vars)));
    }

    private static void assertEvalRaw(String expr, Object expected) {
        assertEquals(expected, FormulaEvaluator.evalRaw(expr, simpleCtx(Map.of())));
    }

    private static void assertEvalRaw(String expr, Object expected, Map<String, Object> vars) {
        assertEquals(expected, FormulaEvaluator.evalRaw(expr, simpleCtx(vars)));
    }

    @SafeVarargs
    private static Map<String, Object> ctx(String... pairs) {
        if (pairs.length % 2 != 0) {
            throw new IllegalArgumentException();
        }
        Map<String, Object> m = new java.util.HashMap<>();
        for (int i = 0; i < pairs.length; i += 2) {
            m.put(pairs[i], pairs[i + 1]);
        }
        return m;
    }

    private static Map<String, Object> ctxWithColumns(String colName, List<Object> values) {
        return Map.of(colName, values);
    }

    private static FormulaEvaluator.Context simpleCtx(Map<String, Object> vars) {
        return new FormulaEvaluator.Context() {
            @Override
            public Object variable(String name) {
                Object v = vars.get(name);
                if (v instanceof List) {
                    // Для агрегатов по колонкам — значения колонки
                    return v;
                }
                return v;
            }

            @Override
            @SuppressWarnings("unchecked")
            public List<Object> column(String name) {
                Object v = vars.get(name);
                if (v instanceof List) {
                    return (List<Object>) v;
                }
                return null;
            }

            @Override
            public void warn(String message) {
                // no-op
            }

            @Override
            public Object lookup(String table, String keyColumn, Object keyValue, String valueColumn) {
                return null;
            }
        };
    }

    private static FormulaEvaluator.Context ctxLookup(String table, String keyCol,
                                                      Object keyVal, String valCol, String result) {
        return new FormulaEvaluator.Context() {
            @Override
            public Object variable(String name) {
                return null;
            }

            @Override
            public List<Object> column(String name) {
                return null;
            }

            @Override
            public void warn(String message) {
            }

            @Override
            public Object lookup(String t, String kc, Object kv, String vc) {
                if (table.equals(t) && keyCol.equals(kc) && valCol.equals(vc)) {
                    return result;
                }
                return null;
            }
        };
    }
}