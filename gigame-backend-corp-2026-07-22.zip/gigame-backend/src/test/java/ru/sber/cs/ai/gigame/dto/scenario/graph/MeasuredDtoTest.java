package ru.sber.cs.ai.gigame.dto.scenario.graph;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

class MeasuredDtoTest {

    @Test
    void testConstruction_withDimensions() {
        var dto = new MeasuredDto(300, 150);
        assertEquals(Integer.valueOf(300), dto.width());
        assertEquals(Integer.valueOf(150), dto.height());
    }

    @Test
    void testConstruction_withNullDimensions() {
        var dto = new MeasuredDto(null, null);
        assertNull(dto.width());
        assertNull(dto.height());
    }
}