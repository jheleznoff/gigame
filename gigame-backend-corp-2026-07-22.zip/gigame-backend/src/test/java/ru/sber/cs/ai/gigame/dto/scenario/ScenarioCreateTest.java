package ru.sber.cs.ai.gigame.dto.scenario;

import org.junit.jupiter.api.Test;
import ru.sber.cs.ai.gigame.dto.scenario.graph.GraphDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDto;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;

class ScenarioCreateTest {

    @Test
    void testConstruction_withAllFields() {
        var graph = new GraphDataDto(List.of(), List.of());
        var dto = new ScenarioCreate("Test Scenario", "Description", graph);
        assertEquals("Test Scenario", dto.name());
        assertEquals("Description", dto.description());
        assertNotNull(dto.graphData());
    }

    @Test
    void testConstruction_withNullFields() {
        var dto = new ScenarioCreate(null, null, null);
        assertNull(dto.name());
        assertNull(dto.description());
        assertNull(dto.graphData());
    }

    @Test
    void testConstruction_withGraphDataContainingNodes() {
        var node = new NodeDto("n1", "input", null, null, null);
        var graph = new GraphDataDto(List.of(node), List.of());
        var dto = new ScenarioCreate("Scenario", null, graph);
        assertEquals(1, dto.graphData().nodes().size());
        assertEquals("n1", dto.graphData().nodes().get(0).id());
    }
}