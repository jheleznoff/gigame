package ru.sber.cs.ai.gigame.service.scenario;

import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.jupiter.api.Test;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Тесты шаблона формы XLSX (rules output-узла): фиксированные колонки,
 * двухуровневая шапка, обратная совместимость.
 */
class ScenarioResultToXlsxTemplateTest {

    private static final String DATA_JSON = """
            [
              {"исполнитель": "ООО ГлоуБайт", "договор": "3730725", "сумма": 4210140,
               "лишний_ключ": "игнорируется"},
              {"исполнитель": "ООО ГлоуБайт", "сумма": 7840320}
            ]
            """;

    private static Sheet readSheet(byte[] xlsx) throws IOException {
        return new XSSFWorkbook(new ByteArrayInputStream(xlsx)).getSheetAt(0);
    }

    @Test
    void template_fixedColumnsInOrder_missingKeysEmpty() throws IOException {
        String rules = """
                {"колонки": [
                  {"ключ": "договор", "заголовок": "Реквизиты договора"},
                  {"ключ": "исполнитель", "заголовок": "Наименование участника"},
                  {"ключ": "сумма", "заголовок": "Сумма, руб."}
                ]}
                """;
        Sheet sheet = readSheet(ScenarioResultToXlsx.jsonToXlsx(DATA_JSON, rules));

        // одна строка шапки (групп нет)
        var header = sheet.getRow(0);
        assertEquals("Реквизиты договора", header.getCell(0).getStringCellValue());
        assertEquals("Наименование участника", header.getCell(1).getStringCellValue());
        assertEquals("Сумма, руб.", header.getCell(2).getStringCellValue());
        // данные: порядок по шаблону, отсутствующий ключ — пустая ячейка, лишний игнорируется
        // числа пишутся ЧИСЛОВЫМИ ячейками (для Excel-аналитики и локали пользователя)
        var row1 = sheet.getRow(1);
        assertEquals("3730725", row1.getCell(0).getStringCellValue());
        assertEquals("ООО ГлоуБайт", row1.getCell(1).getStringCellValue());
        assertEquals(4210140.0, row1.getCell(2).getNumericCellValue());
        assertEquals(3, (int) row1.getLastCellNum());
        var row2 = sheet.getRow(2);
        assertEquals("", row2.getCell(0).getStringCellValue());
        assertEquals(7840320.0, row2.getCell(2).getNumericCellValue());
    }

    @Test
    void template_twoLevelHeader_mergesAdjacentGroups() throws IOException {
        String rules = """
                {"лист": "Форма 3",
                 "колонки": [
                  {"ключ": "исполнитель", "заголовок": "Участник", "группа": "Основные данные"},
                  {"ключ": "договор", "заголовок": "Договор", "группа": "Основные данные"},
                  {"ключ": "сумма", "заголовок": "Сумма", "группа": "Квалификация"}
                ]}
                """;
        Sheet sheet = readSheet(ScenarioResultToXlsx.jsonToXlsx(DATA_JSON, rules));

        assertEquals("Форма 3", sheet.getSheetName());
        // строка 0 — группы, строка 1 — заголовки, строка 2 — первая строка данных
        assertEquals("Основные данные", sheet.getRow(0).getCell(0).getStringCellValue());
        assertEquals("Квалификация", sheet.getRow(0).getCell(2).getStringCellValue());
        assertEquals("Участник", sheet.getRow(1).getCell(0).getStringCellValue());
        assertEquals("ООО ГлоуБайт", sheet.getRow(2).getCell(0).getStringCellValue());
        // объединение соседних одинаковых групп: A1:B1
        List<CellRangeAddress> merged = sheet.getMergedRegions();
        assertTrue(merged.stream().anyMatch(r ->
                r.getFirstRow() == 0 && r.getLastRow() == 0
                        && r.getFirstColumn() == 0 && r.getLastColumn() == 1));
    }

    @Test
    void largeDecimalNumbers_renderedAsNumericCells() throws IOException {
        String rules = "{\"колонки\": [{\"ключ\": \"сумма\", \"заголовок\": \"Сумма\"}]}";
        String data = "[{\"сумма\": 12137779.5}, {\"сумма\": 7840320.0}]";
        Sheet sheet = readSheet(ScenarioResultToXlsx.jsonToXlsx(data, rules));

        assertEquals(12137779.5, sheet.getRow(1).getCell(0).getNumericCellValue());
        assertEquals(7840320.0, sheet.getRow(2).getCell(0).getNumericCellValue());
    }

    @Test
    void decimalStrings_becomeNumericCells_integerStringsStayText() throws IOException {
        // суммы-строки «986724.24» из LLM-JSON → числовые ячейки (Excel показывает
        // по локали — с запятой в русской); целые строки (номера, ИНН) — текст
        String rules = """
                {"колонки": [
                  {"ключ": "сумма", "заголовок": "Сумма"},
                  {"ключ": "номер", "заголовок": "Номер договора"}
                ]}
                """;
        String data = "[{\"сумма\": \"986724.24\", \"номер\": \"50005020373\"}]";
        Sheet sheet = readSheet(ScenarioResultToXlsx.jsonToXlsx(data, rules));

        assertEquals(986724.24, sheet.getRow(1).getCell(0).getNumericCellValue());
        assertEquals("50005020373", sheet.getRow(1).getCell(1).getStringCellValue());
    }

    @Test
    void withoutTemplate_dynamicColumnsPreserved() throws IOException {
        // прежнее поведение: колонки из ключей JSON
        Sheet sheet = readSheet(ScenarioResultToXlsx.jsonToXlsx(DATA_JSON, null));
        assertEquals("исполнитель", sheet.getRow(0).getCell(0).getStringCellValue());
        assertEquals("Данные", sheet.getSheetName());
    }

    @Test
    void defaultRulesArray_treatedAsNoTemplate() throws IOException {
        // getRules() по умолчанию возвращает "[]" — шаблоном не считается
        Sheet sheet = readSheet(ScenarioResultToXlsx.jsonToXlsx(DATA_JSON, "[]"));
        assertEquals("исполнитель", sheet.getRow(0).getCell(0).getStringCellValue());
    }

    @Test
    void foreignRulesFormat_treatedAsNoTemplate() throws IOException {
        // rules другого узла (например, calc) не ломают экспорт
        Sheet sheet = readSheet(ScenarioResultToXlsx.jsonToXlsx(DATA_JSON,
                "{\"критерии\": [{\"название\": \"Цена\"}]}"));
        assertEquals("исполнитель", sheet.getRow(0).getCell(0).getStringCellValue());
    }
}
