package ru.sber.cs.ai.gigame.dto.kb;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;

class KBUpdateTest {

    @Test
    void testConstruction_withAllFields() {
        var dto = new KBUpdate("New Name", "New Description", false);
        assertEquals("New Name", dto.name());
        assertEquals("New Description", dto.description());
        assertFalse(dto.shared());
    }

    @Test
    void testConstruction_withNullFields() {
        var dto = new KBUpdate(null, null, null);
        assertNull(dto.name());
        assertNull(dto.description());
        assertNull(dto.shared());
    }
}
