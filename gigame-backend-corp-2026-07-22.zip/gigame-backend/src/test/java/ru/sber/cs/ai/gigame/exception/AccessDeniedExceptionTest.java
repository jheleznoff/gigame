package ru.sber.cs.ai.gigame.exception;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

class AccessDeniedExceptionTest {

    @Test
    void testAccessDeniedException_withMessage() {
        AccessDeniedException ex = new AccessDeniedException("Access denied");

        assertEquals("Access denied", ex.getMessage());
        assertEquals(403, ex.getStatusCode());
        assertNull(ex.getDetails());
    }

    @Test
    void testAccessDeniedException_withoutMessage() {
        AccessDeniedException ex = new AccessDeniedException();

        assertEquals("Доступ запрещен", ex.getMessage());
        assertEquals(403, ex.getStatusCode());
    }
}
