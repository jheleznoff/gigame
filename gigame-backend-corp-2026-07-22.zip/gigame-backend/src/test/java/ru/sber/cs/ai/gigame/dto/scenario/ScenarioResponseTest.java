package ru.sber.cs.ai.gigame.dto.scenario;

import org.junit.jupiter.api.Test;

import java.time.OffsetDateTime;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

class ScenarioResponseTest {

    @Test
    void testConstruction_withAllFields() {
        var id = UUID.randomUUID();
        var now = OffsetDateTime.now();
        var dto = new ScenarioResponse(id, "Scenario", "Description", now, now);
        assertEquals(id, dto.id());
        assertEquals("Scenario", dto.name());
        assertEquals("Description", dto.description());
        assertEquals(now, dto.createdAt());
        assertEquals(now, dto.updatedAt());
    }

    @Test
    void testConstruction_withNullFields() {
        var dto = new ScenarioResponse(null, null, null, null, null);
        assertNull(dto.id());
        assertNull(dto.name());
        assertNull(dto.description());
        assertNull(dto.createdAt());
        assertNull(dto.updatedAt());
    }
}