package ru.sber.cs.ai.gigame.exception;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

class GigaChatExceptionTest {

    @Test
    void testGigaChatException_withMessage() {
        GigaChatException ex = new GigaChatException("GigaChat error");

        assertEquals("GigaChat error", ex.getMessage());
        assertEquals(503, ex.getStatusCode());
        assertNull(ex.getDetails());
    }

    @Test
    void testGigaChatException_withCause() {
        Exception cause = new Exception("Inner error");
        GigaChatException ex = new GigaChatException("GigaChat error", cause);

        assertEquals("GigaChat error", ex.getMessage());
        assertEquals(503, ex.getStatusCode());
        assertEquals(cause, ex.getCause());
    }
}
