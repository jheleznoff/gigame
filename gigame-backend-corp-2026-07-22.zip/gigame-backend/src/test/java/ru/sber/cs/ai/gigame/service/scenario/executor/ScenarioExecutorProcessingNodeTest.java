package ru.sber.cs.ai.gigame.service.scenario.executor;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.http.codec.ServerSentEvent;
import org.springframework.test.util.ReflectionTestUtils;
import reactor.core.publisher.FluxSink;
import ru.sber.cs.ai.gigame.dto.scenario.graph.EdgeDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.EdgeDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.GraphDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.PositionDto;
import ru.sber.cs.ai.gigame.service.EmbeddingService;
import ru.sber.cs.ai.gigame.service.GigaChatClient;
import ru.sber.cs.ai.gigame.service.scenario.enums.ScenarioNodeType;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunGraph;

import java.util.List;
import java.util.Map;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

class ScenarioExecutorProcessingNodeTest {

    private GigaChatClient gigaChatClient;
    private EmbeddingService embeddingService;
    @SuppressWarnings("unchecked")
    private final FluxSink<ServerSentEvent<Map<String, Object>>> sink = mock(FluxSink.class);

    /**
     * Input string long enough (>= 200 chars) for {@code substring(0, DETAILS_MAX_LENGTH)}.
     */
    private static final String LONG_INPUT = "This is a long input text that provides enough characters for the substring operation with the DETAILS_MAX_LENGTH limit of two hundred characters to ensure that the test will not fail with a StringIndexOutOfBoundsException when running executor.";

    @BeforeEach
    void setUp() {
        gigaChatClient = mock(GigaChatClient.class);
        embeddingService = mock(EmbeddingService.class);
    }

    // ================================================================
    // Constructor
    // ================================================================

    @Test
    void testConstructor_withoutServices() {
        var graph = createGraph("process-1", null, "prompt");
        var node = graph.getNodeMap().get("process-1");
        var executor = new ScenarioExecutorProcessingNode(node);
        assertNotNull(executor);
    }

    @Test
    void testConstructor_withServices() {
        var graph = createGraph("process-1", null, "prompt");
        var node = graph.getNodeMap().get("process-1");
        var executor = new ScenarioExecutorProcessingNode(node, gigaChatClient, embeddingService);
        assertNotNull(executor);
    }

    // ================================================================
    // execute - simple input (parent is not loop)
    // ================================================================

    @Test
    void testExecute_simpleInput_callsGigaChat() {
        when(gigaChatClient.chatCompletion(anyList(), any(), any())).thenReturn("Processed result");
        var graph = createGraphWithParent("process-1", null, "Analyze this");
        var node = graph.getNodeMap().get("process-1");
        node.getInput().add(LONG_INPUT);
        var executor = new ScenarioExecutorProcessingNode(node, gigaChatClient, embeddingService);

        String result = executor.execute(sink);

        assertNotNull(result);
        assertTrue(result.contains("Processed result"));
        verify(gigaChatClient, times(1)).chatCompletion(anyList(), any(), any());
    }

    @Test
    void testExecute_simpleInput_storesOutputInNode() {
        when(gigaChatClient.chatCompletion(anyList(), any(), any())).thenReturn("Output text");
        var graph = createGraphWithParent("process-1", null, "prompt");
        var node = graph.getNodeMap().get("process-1");
        node.getInput().add(LONG_INPUT);
        var executor = new ScenarioExecutorProcessingNode(node, gigaChatClient, embeddingService);

        executor.execute(sink);

        assertFalse(node.getOutput().isEmpty());
        assertEquals("Output text", node.getOutput().get(0));
    }

    @Test
    void testExecute_simpleInput_passesOutputToChildNodes() {
        when(gigaChatClient.chatCompletion(anyList(), any(), any())).thenReturn("Result");
        var inputDto = NodeDto.builder()
                .id("input-1")
                .type(ScenarioNodeType.INPUT_NODE.toString())
                .data(NodeDataDto.builder().label("Input").build())
                .position(new PositionDto(0, 100))
                .build();
        var processDto = NodeDto.builder()
                .id("process-1")
                .type(ScenarioNodeType.PROCESSING_NODE.toString())
                .data(NodeDataDto.builder().label("Proc").prompt("prompt").build())
                .position(new PositionDto(100, 100))
                .build();
        var outputDto = NodeDto.builder()
                .id("output-1")
                .type(ScenarioNodeType.OUTPUT_NODE.toString())
                .data(NodeDataDto.builder().label("Output").build())
                .position(new PositionDto(200, 100))
                .build();
        var gd = new GraphDataDto(List.of(inputDto, processDto, outputDto),
                List.of(
                        new EdgeDto("e-in", "input-1", "process-1", new EdgeDataDto(null)),
                        new EdgeDto("e-out", "process-1", "output-1", new EdgeDataDto(null))
                ));
        var graph = new ScenarioRunGraph(gd);
        var node = graph.getNodeMap().get("process-1");
        node.getInput().add(LONG_INPUT);
        var executor = new ScenarioExecutorProcessingNode(node, gigaChatClient, embeddingService);

        executor.execute(sink);

        var child = graph.getNodeMap().get("output-1");
        assertFalse(child.getInput().isEmpty());
        assertTrue(child.getInput().get(0).contains("Proc"));
    }

    // ================================================================
    // execute - process doc list
    // ================================================================

    @Test
    void testExecute_withDocuments_processesEachDoc() {
        when(gigaChatClient.chatCompletion(anyList(), any(), any())).thenReturn("Doc result");
        var graph = createGraphWithParent("process-1", null, "prompt");
        var node = graph.getNodeMap().get("process-1");
        graph.addDocs(List.of("Doc 1 text", "Doc 2 text"), List.of("f1.pdf", "f2.pdf"));
        node.getDocList().addAll(List.of("DOC_1", "DOC_2"));
        var executor = new ScenarioExecutorProcessingNode(node, gigaChatClient, embeddingService);

        String result = executor.execute(sink);

        assertNotNull(result);
        verify(gigaChatClient, times(2)).chatCompletion(anyList(), any(), any());
    }

    // ================================================================
    // execute - input list (parent is LOOP_NODE)
    // ================================================================

    @Test
    void testExecute_inputList_fromLoopNode() {
        when(gigaChatClient.chatCompletion(anyList(), any(), any())).thenReturn("Loop item result");
        var loopDto = NodeDto.builder()
                .id("loop-1")
                .type(ScenarioNodeType.LOOP_NODE.toString())
                .data(NodeDataDto.builder().label("Loop").build())
                .position(new PositionDto(100, 100))
                .build();
        var processDto = NodeDto.builder()
                .id("process-1")
                .type(ScenarioNodeType.PROCESSING_NODE.toString())
                .data(NodeDataDto.builder().label("Proc").prompt("prompt").build())
                .position(new PositionDto(200, 100))
                .build();
        var gd = new GraphDataDto(List.of(loopDto, processDto),
                List.of(new EdgeDto("e1", "loop-1", "process-1", new EdgeDataDto(null))));
        var graph = new ScenarioRunGraph(gd);
        var node = graph.getNodeMap().get("process-1");
        node.getInput().add(LONG_INPUT);
        node.getInput().add(LONG_INPUT);
        var executor = new ScenarioExecutorProcessingNode(node, gigaChatClient, embeddingService);

        String result = executor.execute(sink);

        assertNotNull(result);
        verify(gigaChatClient, times(2)).chatCompletion(anyList(), any(), any());
    }

    // ================================================================
    // execute - with RAG (knowledge base)
    // ================================================================

    @Test
    void testExecute_withRag_kbChunksIncludedInPrompt() {
        float[] embedding = new float[1024];
        String kbId = UUID.randomUUID().toString();
        when(gigaChatClient.getEmbeddings(anyList())).thenReturn(List.of(embedding));
        when(embeddingService.searchSimilar(eq("kb"), any(UUID.class), any()))
                .thenReturn(List.of("RAG chunk 1", "RAG chunk 2"));
        when(gigaChatClient.chatCompletion(anyList(), any(), any())).thenReturn("RAG result");

        var graph = createGraphWithParent("process-1", kbId, "prompt");
        var node = graph.getNodeMap().get("process-1");
        node.getInput().add(LONG_INPUT);
        var executor = new ScenarioExecutorProcessingNode(node, gigaChatClient, embeddingService);
        ReflectionTestUtils.setField(executor, "ragQueryMaxLength", 800);
        ReflectionTestUtils.setField(executor, "cacheShortQueryLength", 200);

        String result = executor.execute(sink);

        assertNotNull(result);
        assertTrue(result.contains("RAG result"));
        verify(gigaChatClient, times(1)).getEmbeddings(anyList());
        verify(embeddingService, times(1)).searchSimilar(eq("kb"), any(UUID.class), any());
    }

    @Test
    void testExecute_withRagSearchFailure_fallsBackGracefully() {
        String kbId = UUID.randomUUID().toString();
        when(gigaChatClient.getEmbeddings(anyList())).thenThrow(new RuntimeException("Embedding failed"));
        when(gigaChatClient.chatCompletion(anyList(), any(), any())).thenReturn("Result without RAG");

        var graph = createGraphWithParent("process-1", kbId, "prompt");
        var node = graph.getNodeMap().get("process-1");
        node.getInput().add(LONG_INPUT);
        var executor = new ScenarioExecutorProcessingNode(node, gigaChatClient, embeddingService);

        String result = executor.execute(sink);

        assertNotNull(result);
        assertTrue(result.contains("Result without RAG"));
    }

    @Test
    void testExecute_withRagSearch_WithEmptyQuery() {
        String kbId = UUID.randomUUID().toString();
        when(gigaChatClient.getEmbeddings(anyList())).thenThrow(new RuntimeException("Embedding failed"));
        when(gigaChatClient.chatCompletion(anyList(), any(), any())).thenReturn("Result without RAG");

        var graph = createGraphWithParent("process-1", kbId, "");
        var node = graph.getNodeMap().get("process-1");
        var executor = new ScenarioExecutorProcessingNode(node, gigaChatClient, embeddingService);

        String result = executor.execute(sink);

        assertNotNull(result);
        assertTrue(result.contains("Result without RAG"));
    }

    @Test
    void testExecute_withRag_embeddingsAreCached() {
        float[] embedding = new float[1024];
        String kbId = UUID.randomUUID().toString();
        when(gigaChatClient.getEmbeddings(anyList())).thenReturn(List.of(embedding));
        when(embeddingService.searchSimilar(eq("kb"), any(UUID.class), any()))
                .thenReturn(List.of("cached chunk"));
        when(gigaChatClient.chatCompletion(anyList(), any(), any())).thenReturn("Result");

        var graph = createGraphWithParent("process-1", kbId, "prompt");
        var node = graph.getNodeMap().get("process-1");
        node.getInput().add(LONG_INPUT);
        var executor = new ScenarioExecutorProcessingNode(node, gigaChatClient, embeddingService);
        ReflectionTestUtils.setField(executor, "ragQueryMaxLength", 800);
        ReflectionTestUtils.setField(executor, "cacheShortQueryLength", 200);

        executor.execute(sink);

        verify(gigaChatClient, times(1)).getEmbeddings(anyList());
        verify(embeddingService, times(1)).searchSimilar(eq("kb"), any(UUID.class), any());
    }

    // ================================================================
    // setConfiguration
    // ================================================================

    @Test
    void testSetConfiguration() {
        var graph = createGraph("process-1", null, "prompt");
        var node = graph.getNodeMap().get("process-1");
        var executor = new ScenarioExecutorProcessingNode(node, gigaChatClient, embeddingService);

        executor.setConfiguration(500, 100);

        assertEquals(500, ReflectionTestUtils.getField(executor, "ragQueryMaxLength"));
        assertEquals(100, ReflectionTestUtils.getField(executor, "cacheShortQueryLength"));
    }

    // ================================================================
    // Helpers
    // ================================================================

    private static ScenarioRunGraph createGraph(String nodeId, String kbId, String prompt) {
        var nodeDto = NodeDto.builder()
                .id(nodeId)
                .type(ScenarioNodeType.PROCESSING_NODE.toString())
                .data(NodeDataDto.builder()
                        .label("Process")
                        .prompt(prompt)
                        .knowledgeBaseId(kbId)
                        .build())
                .position(new PositionDto(100, 100))
                .build();
        var gd = new GraphDataDto(List.of(nodeDto), List.of());
        return new ScenarioRunGraph(gd);
    }

    /**
     * Creates a graph with an input node as parent of the processing node.
     * This ensures {@code node.getParentNodeList().get(0)} does not throw.
     */
    private static ScenarioRunGraph createGraphWithParent(String processNodeId, String kbId, String prompt) {
        var inputDto = NodeDto.builder()
                .id("dummy-input")
                .type(ScenarioNodeType.INPUT_NODE.toString())
                .data(NodeDataDto.builder().label("DummyInput").build())
                .position(new PositionDto(0, 0))
                .build();
        var processDto = NodeDto.builder()
                .id(processNodeId)
                .type(ScenarioNodeType.PROCESSING_NODE.toString())
                .data(NodeDataDto.builder()
                        .label("Process")
                        .prompt(prompt)
                        .knowledgeBaseId(kbId)
                        .build())
                .position(new PositionDto(200, 0))
                .build();
        var gd = new GraphDataDto(List.of(inputDto, processDto),
                List.of(new EdgeDto("e1", "dummy-input", processNodeId, new EdgeDataDto(null))));
        return new ScenarioRunGraph(gd);
    }
}