# GigaMe Backend

**GigaMe** is a **Spring Boot 3.5.15** / **Java 17** backend service providing AI-powered chat, RAG, knowledge base management, and a graph-based scenario engine, powered by **GigaChat** (Sber's AI platform).

**Version**: 1.3.0

---

## Key Technologies

| Category | Technology |
|---|---|
| **Framework** | Spring Boot 3.5.15 with Spring WebFlux (reactive) |
| **Language** | Java 17 |
| **AI** | GigaChat API (chat + embeddings) via `spring-ai-starter-model-gigachat` 1.1.4 |
| **Database** | PostgreSQL 15+ with pgvector (vector similarity search) |
| **Migrations** | Liquibase 5.0.3 (SQL-based changelog) |
| **ORM** | Spring Data JPA (Hibernate 6) |
| **Build** | Maven, JaCoCo 0.8.13 (70% min coverage), Checkstyle 3.6.0 |
| **Documents** | Apache POI 5.5.1 (DOCX/XLSX), PDFBox 3.0.7 (PDF) |
| **JSON** | Hypersistence Utils 3.9.3 (JSONB + pgvector) |
| **OpenAPI** | Springdoc 2.8.17 (WebFlux UI + API) |

---

## Architecture Summary

Micro-service-like architecture within a single Spring Boot application:

1. **Chat Service** — multi-turn conversations with SSE streaming, RAG, auto-titles, LLM routing, summarization
2. **Document Service** — file upload (PDF/DOCX/XLSX/TXT), text extraction, OCR for scanned PDFs
3. **Knowledge Base Service** — CRUD + document binding + reindex
4. **Scenario Engine** — graph-based AI workflows with 16 node executors and step-by-step debugging
5. **Embedding Service** — pgvector: IVFFlat index, cosine similarity (`<->`), chunking with overlap
6. **WebSocket** — bidirectional `/ws/chat` (SSE streams) and `/ws/scenario` (SSE events)

---

## Building and Running

### Prerequisites

- Java 17+
- Maven 3.6+
- PostgreSQL 15+ with `pgvector` and `uuid-ossp` extensions
- GigaChat API credentials

### Database Setup

```sql
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "vector";
```

### Build & Run

```bash
# Build
mvn clean package -DskipTests

# Run (dev)
mvn spring-boot:run

# Run (prod JAR)
java -jar target/gigame-backend-1.3.0.jar

# Custom port
java -jar target/gigame-backend-1.3.0.jar --server.port=8080
```

### Environment Variables

```bash
# Database
DATABASE_URL=jdbc:postgresql://localhost:5432/gigame
db.username=your_user
db.password=your_password
DATABASE_SCHEMA=public

# GigaChat
GIGACHAT_URL=https://gigachat-ift.sberdevices.delta.sbrf.ru/v1
GIGACHAT_SERT=classpath:giga_ift.pem
GIGACHAT_KEY=classpath:giga_ift.key
GIGACHAT_SCOPE=GIGACHAT_API_CORP
GIGACHAT_MODEL=GigaChat-2-Max

# App (see application.yaml)
PORT=8080
CONTEXT_CHAR_LIMIT=200000
MAX_HISTORY_MESSAGES=20
TOPK=5
CHUNK_SIZE=1000
OVERLAP=200
```

### Testing

```bash
mvn test
mvn test -Dtest=ChatServiceTest
mvn test -Dtest=ScenarioEngineTest
```

### Coverage

```bash
mvn test jacoco:report
```

Min: **70%** complexity (JaCoCo). Report: `target/coverage-reports/`

---

## API Endpoints

### Conversations

| Method | Endpoint | Description |
|--------|----------|-------------|
| `GET` | `/api/conversations?q=` | List with optional title search |
| `POST` | `/api/conversations` | Create |
| `GET` | `/api/conversations/{id}` | Get with messages |
| `PUT` | `/api/conversations/{id}` | Update title |
| `DELETE` | `/api/conversations/{id}` | Delete |
| `POST` | `/api/conversations/{id}/messages` | Send message (SSE) |
| `POST` | `/api/conversations/{id}/messages/upload` | Send with files (multipart + SSE) |
| `POST` | `/api/conversations/{id}/upload` | Upload documents to cache |

### Documents

| Method | Endpoint | Description |
|--------|----------|-------------|
| `GET` | `/api/documents` | List all |
| `POST` | `/api/documents` | Upload |
| `DELETE` | `/api/documents/{id}` | Delete |

### Knowledge Bases

| Method | Endpoint | Description |
|--------|----------|-------------|
| `GET` | `/api/knowledge-bases?q=` | List |
| `POST` | `/api/knowledge-bases` | Create |
| `GET` | `/api/knowledge-bases/{id}` | Get with documents |
| `PUT` | `/api/knowledge-bases/{id}` | Update |
| `DELETE` | `/api/knowledge-bases/{id}` | Delete |
| `POST` | `/api/knowledge-bases/{id}/documents` | Upload document |
| `POST` | `/api/knowledge-bases/{id}/documents/{docId}/reindex` | Reindex |
| `DELETE` | `/api/knowledge-bases/{id}/documents/{docId}` | Remove from KB |

### Scenarios

| Method | Endpoint | Description |
|--------|----------|-------------|
| `GET` | `/api/scenarios` | List |
| `POST` | `/api/scenarios` | Create |
| `GET` | `/api/scenarios/{id}` | Get details |
| `PUT` | `/api/scenarios/{id}` | Update |
| `DELETE` | `/api/scenarios/{id}` | Delete |
| `POST` | `/api/scenarios/{id}/duplicate` | Dplicate |
| `POST` | `/api/scenarios/{id}/run` | Execute (SSE) |
| `POST` | `/api/scenarios/{id}/upload` | Upload files to cache |
| `GET` | `/api/scenarios/runs/{runId}` | Get run status|
| `POST` | `/api/scenarios/runs/{runId}/continue` | Continue paused run|
| `POST` | `/api/scenarios/runs/{runId}/disable-step-mode` | Disable step mode|

---

## Development Conventions (checkstyle.xml)

| Rule | Value |
|------|--------|
| **Line length** | max 300 (ignore URLs/imports)|
| **Method length** | max 50 (empty lines not counted)|
| **Parameters** | max 8 |
| **No `*` imports** | AvoidStarImport |
| **Unused imports** | must be removed |
| **Empty catch** | require comment |
| **String comparision** | `"constand".equals(variable)` |
| **No nested `try`** | extract to separate method |
| **JDdco** | all parameters described |
| **Declaration order** | static → instance → constructor → method |
| **Annotations** | single per line |
| **Severity** | `error` (default) |

### Naming

- DTOs: use Java records for response DTOs
- Slf4j with structured logging
- Lombok: `@RequiredArgsConstructor`, `@Data`, `@Slf4j`
- Custom exceptions with `@ControllerAdvice`

## Code Structure

### Main packages

```
ru.sber.cs.ai.gigame/
├── config/                         # 6 configuration files
├── controller/                     # 4 REST controllers
├── service/                        # 11+ services (scenario/ subpackage with 16 executors)
├── model/                          # 10 JPA entities
├── repository/                     # 10 JPA repositories
├── dto/                            # 20+ DTOs across 5 subfolders
├── ws/                             # 3 WebSocket handlers + ActionType enum
└── utils/                          # 4 utilities
```

### Services (11 + 16 + 3)

| Module | Files |
|--------|-------|
| **chat** | `ChatService.java` |
| **documents** | `DocumentService`, `DocumentIndexService`, `DocsTextCacheService`, `ScanOcrService` |
| **embeddings** | `EmbeddingService` |
| **KB** | `KBService`, `KBMapper` |
| **GigaChat** | `GigaChatClient` |
| **scenario** | `ScenarioService`, `ScenarioRunService`, `ScenarioRunStepService`, `ExportToDocx`, `ScenarioResultToXlsx`, `ScenarioMapper` |
| **executors** | `AbstractScenarioExecutor`, `ExpressionResolver`, `FormulaEvaluator`, **16** concrete executors |

---

## Database Conventions

- **UUID PKs**: `DEFAULT uuid_generate_v4()`
- **Timestamps**: `TIMESTAMP WITH TIME ZONE` with `now()` default
- **Cascading**: `ON DELETE CASCADE` / `ON DELETE SET NULL`
- **pgvector**: `vector(1024)` with `IVFFlat` index (`vector_cosine_ops`, 100 lists)
- **Multi-tenancy**: All entities include `user_id` column

### Embedding Strategy

- **chunk-size**: 1000 chars with `overlap`: 200
- **collection_type**: `'doc'` (document) / `'kb'` (knowledge base)
- **topK**: 5
- **char-limit**: 12,000 chars per embedding text

---

## Scenario Engine Details

### 16 Node Executors

| Node | Executor | Description |
|------|----------|------------|
| Input | `ScenarioExecutorInputNode` | Passes documents text through|
| Output | `ScenarioExecutorOutputNode` | Merges predecessor outputs (TEXT_FILE/EXCEL)|
| **Processing** | `ScenarioExecutorProcessingNode` | GigaChat call with prompt + RAG + group mode|
| **Loop** | `ScenarioExecutorLoopNode` | classify_strict / full analysis|
| **Switch** | `ScenarioExecutorSwitchNode` | Routing by classification or rules|
| **If** | `ScenarioExecutorIfNode` | Contains/equals/greater_than|
| **Calc** | `ScenarioExecutorCalcNode` | Formulas |
| **Aggregate** | `ScenarioExecutorAggregateNode` | Data aggregation|
| **Transform** | `ScenarioExecutorTransformNode` | Data transformation (incl. merge)|
| **Subscenario** | `ScenarioExecutorSubscenarioNode` | Recursive execution|
| **Control** | `ScenarioExecutorControlNode` | Workflow control|
| **Wait** | `ScenarioExecutorWaitNode` | Pause / delay|

### Execution Algorithm

1. **Topological sort** → build node order
2. **Factory** → `ScenarioExecutorFactory` creates executor by type
3. **AbstractScenarioExecutor.execute** → GigaChat / compute / transform
4. **SkipSet** → on branch (Switch/If), loser nodes + descendants marked `skipped`
5. **SSE events** → `ScenarioEventEmission` emits `status`, `node_status`, `loop_progress`, `rag_search` throughout the run

---

## WebSocket API (see `WEBSOCKET_API.md`)

Two endpoints:
- `/ws/chat` → receives `ChatMessage`, returns `StreamEvent` (SSE stream)
- `/ws/scenario` → receives `ScenarioMessage` with `step_mode`, returns events: `status`, `node_status`, `step_complete`, `step_paused`, `loop_progress`, `rag_search`

**Auth**: `X-UserId` header in WebSocket handshake

---

## Related Files

| File | Purpose |
|------|-------|
| `pom.xml` | Maven config (Spring Boot 3.5.15, Java 17)|
| `src/main/resources/application.yaml` | Main configuration (215+ lines) |
| `checkstyle.xml` | Code style rules |
| `Jenkinsfile` | CI/CD pipeline |
| `openspec/config.yaml` | OpenSpec spec-driven development|
| `openapi/gigame.yaml` | OpenAPI 3.0 specification|

---


## Troubleshooting

### Common Issues

1. **Certificate auth fails**: Ensure `giga_ift.pem` and `giga_ift.key` in `src/main/resources/`
2. **Vector search returns empty**: Check pgvector extension + IVFFlat index exists
3. **JPA LazyInitializationException**: `open-in-view: false` → ensure `@Transactional`
4. **File upload fails (500)**: Max file size 30MB, max request 100MB
5. **GigaChat API timeouts**: `connect-timeout: 30s`, `read-timeout: 300s`
6. **Liquibase migrations fail**: Ensure PostgreSQL extensions (`uuid-ossp`, `vector`) exist

### Debug Logging

```bash
java -jar target/gigame-backend-1.3.0.jar \
  --logging.level.ru.sber.cs.ai.gigame=DEBUG \
  --logging.level.org.springframework.web=DEBUG
```